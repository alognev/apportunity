#!/bin/bash
# Двойной щелчок в Finder — запуск помощника.
# По умолчанию открывается приложение Goose в рабочей папке; если его нет — веб-помощник.
cd "$(dirname "$0")" || exit 1
WS="$(grep -E '^AGENT_WORKSPACE=' .env 2>/dev/null | cut -d= -f2-)"
WS="${WS:-~/magnit-agent-workspace}"
WS="${WS/#\~/$HOME}"
mkdir -p "$WS"

if [[ -d "/Applications/Goose.app" || -d "$HOME/Applications/Goose.app" ]]; then
  open -a Goose "$WS"
  echo "Открываю приложение Goose. Рабочая папка: $WS"
  echo "Это окно можно закрыть."
  sleep 3
  exit 0
elif [[ -x "agent-c-agent-sdk/.venv/bin/python" ]]; then
  exec "./Запустить веб-помощника.command"
elif command -v goose >/dev/null 2>&1; then
  cd "$WS" && exec "$OLDPWD/agent-b-goose/magnit-goose"
else
  echo "Помощник ещё не установлен: дважды щёлкните «Установить агента»."
  read -n 1 -s -r -p "Нажмите любую клавишу, чтобы закрыть окно…"
fi
