# Агент A — Claude Code на корпоративной LLM

Готовый агент Claude Code (Anthropic). Работает в терминале, в той папке, откуда запущен.

```bash
cd ~/Documents/отчёты
magnit-claude                      # интерактивный режим
magnit-claude -p "сделай сводку по всем xlsx в папке"   # разовое задание
```

- `magnit-claude`: обёртка. Загружает `.env`, поднимает локальный шлюз, подключает MCP `magnit-files` и `remote-mcp.json`, добавляет инструкции из `shared/instructions.md`.
- `settings.json`: права (MCP `magnit-files` без подтверждения) и хук `shared/read_guard.py`. Хук перенаправляет чтение PDF, Excel и картинок на MCP-инструменты.
- Профиль Claude Code отдельный: `~/.magnit-agent/claude-code`. Он не смешивается с личным аккаунтом Claude.
- Внутри доступны все возможности Claude Code: `/help`, `/mcp`, `/permissions`, `CLAUDE.md` в рабочей папке, режимы подтверждения (Shift+Tab).
