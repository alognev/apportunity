#!/usr/bin/env bash
# Установка агента A (Claude Code + корпоративная LLM через локальный шлюз)
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
"$HERE/../shared/install-shared.sh" --gateway
source "$HERE/../shared/env.sh"

if ! command -v claude >/dev/null; then
  echo "Устанавливаю Claude Code..."
  curl -fsSL https://claude.ai/install.sh | bash
fi

mkdir -p "$HOME/.local/bin"
ln -sf "$HERE/magnit-claude" "$HOME/.local/bin/magnit-claude"
echo
echo "Агент A установлен. Запуск: перейдите в рабочую папку и выполните magnit-claude"
case ":$PATH:" in *":$HOME/.local/bin:"*) ;; *) echo "Добавьте в ~/.zshrc: export PATH=\"\$HOME/.local/bin:\$PATH\"";; esac
