"""Агент C — веб-интерфейс (локальный чат в браузере).

  magnit-agent web                       — http://127.0.0.1:8765, папка из AGENT_WORKSPACE
  magnit-agent web --workspace ~/Docs    — другая рабочая папка
  magnit-agent web --port 9000 --no-browser
"""

from __future__ import annotations

import argparse
import asyncio
import os
import threading
import time
import uuid
import webbrowser
from pathlib import Path

import uvicorn
from claude_agent_sdk import (
    AssistantMessage,
    ClaudeSDKClient,
    PermissionResultAllow,
    PermissionResultDeny,
    ResultMessage,
    StreamEvent,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from fastapi import Body, Depends, FastAPI, HTTPException, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse

from agent_core import HERE, build_options, describe_tool_call, load_config, mcp_registry

app = FastAPI(title="Magnit Agent")
WORKSPACE = Path(load_config()["AGENT_WORKSPACE"])
SKIP_DIRS = {".git", ".venv", "node_modules", "__pycache__", ".claude"}
MAX_FILES = 500


def _safe_path(rel: str) -> Path:
    path = (WORKSPACE / rel).resolve()
    if not path.is_relative_to(WORKSPACE.resolve()):
        raise HTTPException(400, "Путь вне рабочей папки")
    return path


def same_origin(request: Request) -> None:
    """Изменяющие запросы — только со страницы самого помощника (защита от чужих сайтов в браузере)."""
    origin = request.headers.get("origin", "")
    host = request.headers.get("host", "")
    if origin not in (f"http://{host}", f"https://{host}"):
        raise HTTPException(403, "Запрос не со страницы помощника")


def _tool_result_text(block: ToolResultBlock) -> str:
    content = block.content
    if isinstance(content, list):
        content = "\n".join(c.get("text", "") for c in content if isinstance(c, dict))
    return (content or "")[:2000]


@app.get("/")
async def index():
    return FileResponse(HERE / "static" / "index.html")


@app.get("/api/files")
async def list_files():
    files = []
    for dirpath, dirnames, filenames in os.walk(WORKSPACE):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.startswith("."))
        for name in sorted(filenames):
            if name.startswith("."):
                continue
            p = Path(dirpath) / name
            st = p.stat()
            files.append({"path": str(p.relative_to(WORKSPACE)), "size": st.st_size, "mtime": st.st_mtime})
            if len(files) >= MAX_FILES:
                return {"workspace": str(WORKSPACE), "files": files, "truncated": True}
    return {"workspace": str(WORKSPACE), "files": files, "truncated": False}


@app.get("/api/file")
async def get_file(path: str, download: bool = False):
    p = _safe_path(path)
    if not p.is_file():
        raise HTTPException(404, "Файл не найден")
    return FileResponse(p, filename=p.name if download else None,
                        content_disposition_type="attachment" if download else "inline")


@app.get("/api/integrations")
async def get_integrations():
    """Инструменты (интеграции): доступна ли (есть токен), активна ли, сколько занимает контекста."""
    env = mcp_registry.load_env()
    avail, active = set(mcp_registry.available(env)), set(mcp_registry.enabled(env))
    return [{"name": n, "title": mcp_registry.TITLES[n], "available": n in avail, "active": n in active,
             "always_on": n in mcp_registry.ALWAYS_ON, "tokens": mcp_registry.CONTEXT_TOKENS.get(n)}
            for n in mcp_registry.SERVERS]


@app.post("/api/integrations", dependencies=[Depends(same_origin)])
async def set_integrations(active: list[str] = Body(..., embed=True)):
    unknown = [n for n in active if n not in mcp_registry.SERVERS]
    if unknown:
        raise HTTPException(400, f"Неизвестные интеграции: {unknown}")
    env = mcp_registry.load_env()
    # выбранные ранее, но пока без токена — не теряем
    keep = [n for n in (mcp_registry.selection(env) or set()) if n not in mcp_registry.available(env)]
    return {"saved": mcp_registry.save_selection(active + keep)}


@app.post("/api/upload", dependencies=[Depends(same_origin)])
async def upload(files: list[UploadFile]):
    saved = []
    for f in files:
        name = Path(f.filename or "file").name
        target = _safe_path(name)
        stem, suffix, i = target.stem, target.suffix, 1
        while target.exists():
            target = target.with_name(f"{stem} ({i}){suffix}")
            i += 1
        target.write_bytes(await f.read())
        saved.append(target.name)
    return {"saved": saved}


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    # Защита от подключения со сторонних сайтов, открытых в браузере
    origin = ws.headers.get("origin", "")
    host = ws.headers.get("host", "")
    if origin not in (f"http://{host}", f"https://{host}"):
        await ws.close(code=4403)
        return
    await ws.accept()

    pending: dict[str, asyncio.Future] = {}

    async def can_use_tool(tool_name, tool_input, _ctx):
        pid = uuid.uuid4().hex
        fut = asyncio.get_running_loop().create_future()
        pending[pid] = fut
        await ws.send_json({"type": "permission", "id": pid, "summary": describe_tool_call(tool_name, tool_input)})
        if await fut:
            return PermissionResultAllow()
        return PermissionResultDeny(message="Пользователь запретил это действие")

    options = None

    async def new_client() -> ClaudeSDKClient:
        # Настройки перечитываются при каждом новом диалоге — так применяется выбор инструментов
        nonlocal options
        options = await asyncio.to_thread(build_options, WORKSPACE, can_use_tool, True)
        c = ClaudeSDKClient(options)
        await c.connect()
        return c

    client = await new_client()
    await ws.send_json({"type": "ready", "model": options.model, "workspace": str(WORKSPACE)})
    turn: asyncio.Task | None = None

    async def run_turn(prompt: str):
        started = time.monotonic()
        try:
            await client.query(prompt)
            async for msg in client.receive_response():
                if isinstance(msg, StreamEvent):
                    ev = msg.event
                    if (msg.parent_tool_use_id is None and ev.get("type") == "content_block_delta"
                            and ev["delta"].get("type") == "text_delta"):
                        await ws.send_json({"type": "text_delta", "text": ev["delta"]["text"]})
                elif isinstance(msg, AssistantMessage):
                    for b in msg.content:
                        if isinstance(b, ToolUseBlock):
                            await ws.send_json({"type": "tool", "id": b.id, "summary": describe_tool_call(b.name, b.input)})
                    await ws.send_json({"type": "text_end"})
                elif isinstance(msg, UserMessage) and isinstance(msg.content, list):
                    for b in msg.content:
                        if isinstance(b, ToolResultBlock):
                            await ws.send_json({"type": "tool_result", "id": b.tool_use_id,
                                                "is_error": bool(b.is_error), "text": _tool_result_text(b)})
                    await ws.send_json({"type": "files_changed"})
                elif isinstance(msg, ResultMessage):
                    await ws.send_json({"type": "done", "turns": msg.num_turns, "is_error": msg.is_error,
                                        "error": (msg.result if msg.is_error else None),
                                        "seconds": round(time.monotonic() - started)})
        except Exception as e:  # noqa: BLE001 — показываем любую ошибку в чате
            await ws.send_json({"type": "done", "is_error": True, "error": str(e),
                                "seconds": round(time.monotonic() - started)})

    try:
        while True:
            data = await ws.receive_json()
            kind = data.get("type")
            if kind == "prompt":
                if turn and not turn.done():
                    await ws.send_json({"type": "error", "message": "Агент ещё работает над предыдущим запросом"})
                else:
                    turn = asyncio.create_task(run_turn(data["text"]))
            elif kind == "permission_reply":
                fut = pending.pop(data.get("id"), None)
                if fut and not fut.done():
                    fut.set_result(bool(data.get("allow")))
            elif kind == "interrupt":
                await client.interrupt()
            elif kind == "reset":
                if turn and not turn.done():
                    turn.cancel()
                await client.disconnect()
                client = await new_client()
                await ws.send_json({"type": "ready", "model": options.model, "workspace": str(WORKSPACE)})
    except WebSocketDisconnect:
        pass
    finally:
        if turn and not turn.done():
            turn.cancel()
        await client.disconnect()


def main():
    global WORKSPACE
    parser = argparse.ArgumentParser(description="Веб-интерфейс агента C")
    parser.add_argument("--workspace", "-w", default=str(WORKSPACE), help="рабочая папка агента")
    parser.add_argument("--port", "-p", type=int, default=int(os.environ.get("AGENT_WEB_PORT", "8765")))
    parser.add_argument("--no-browser", action="store_true", help="не открывать браузер")
    args = parser.parse_args()

    WORKSPACE = Path(os.path.expanduser(args.workspace)).resolve()
    WORKSPACE.mkdir(parents=True, exist_ok=True)
    url = f"http://127.0.0.1:{args.port}"
    print(f"Агент C: {url}  ·  рабочая папка: {WORKSPACE}  ·  Ctrl+C — остановить")
    if not args.no_browser:
        threading.Timer(1.5, webbrowser.open, args=[url]).start()
    uvicorn.run(app, host="127.0.0.1", port=args.port, log_level="warning")


if __name__ == "__main__":
    main()
