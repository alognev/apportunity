#!/usr/bin/env bash
# Установка агента C (свой агент на Claude Agent SDK: CLI + веб-интерфейс)
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
"$HERE/../shared/install-shared.sh" --gateway
source "$HERE/../shared/env.sh"

if [[ ! -f "$HERE/.venv/.installed" ]] || [[ "$HERE/requirements.txt" -nt "$HERE/.venv/.installed" ]]; then
  echo "Устанавливаю Claude Agent SDK и веб-сервер..."
  [[ -x "$HERE/.venv/bin/python" ]] || "$(command -v python3.13 || command -v python3)" -m venv "$HERE/.venv"
  "$HERE/.venv/bin/pip" install -q --upgrade pip
  "$HERE/.venv/bin/pip" install -q -r "$HERE/requirements.txt"
  touch "$HERE/.venv/.installed"
fi

mkdir -p "$HOME/.local/bin"
ln -sf "$HERE/magnit-agent" "$HOME/.local/bin/magnit-agent"
echo
echo "Агент C установлен."
echo "  Терминал:      magnit-agent        (в нужной рабочей папке)"
echo "  Веб-интерфейс: magnit-agent web    (папка: $AGENT_WORKSPACE)"
case ":$PATH:" in *":$HOME/.local/bin:"*) ;; *) echo "Добавьте в ~/.zshrc: export PATH=\"\$HOME/.local/bin:\$PATH\"";; esac
