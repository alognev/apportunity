"""Общее ядро агента C: настройки Claude Agent SDK для работы с корпоративной LLM.

Используется и в CLI (cli.py), и в веб-интерфейсе (web.py).
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path

from claude_agent_sdk import CanUseTool, ClaudeAgentOptions
from dotenv import dotenv_values

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "shared"))
import mcp_registry  # noqa: E402
from skills_sync import sync as sync_skills  # noqa: E402

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SHARED = ROOT / "shared"
SHARED_PY = SHARED / ".venv" / "bin" / "python"
ENV_REF = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")

# Инструменты, которые выполняются без подтверждения. Bash, изменения в Jira/Tag/календаре
# и прочее — через can_use_tool. Чтение из интеграций добавляется из mcp_registry.
AUTO_ALLOWED_TOOLS = [
    "Read", "Write", "Edit", "MultiEdit", "Glob", "Grep", "LS", "TodoWrite", "NotebookEdit", "Skill",
]
CONFIG_DIR = Path.home() / ".magnit-agent" / "agent-sdk"
# Серверные инструменты Anthropic — корпоративная модель их не поддерживает
DISALLOWED_TOOLS = ["WebSearch"]


def load_config() -> dict[str, str]:
    env_file = ROOT / ".env"
    if not env_file.exists():
        raise SystemExit(f"Не найден {env_file} — запустите {ROOT / 'setup.sh'}")
    cfg = {k: v or "" for k, v in dotenv_values(env_file).items()}
    if not cfg.get("LLM_API_KEY"):
        raise SystemExit(f"В {env_file} не задан LLM_API_KEY")
    cfg["LLM_BASE_URL"] = cfg["LLM_BASE_URL"].rstrip("/")
    cfg["AGENT_WORKSPACE"] = os.path.expanduser(cfg.get("AGENT_WORKSPACE") or "~/magnit-agent-workspace")
    return cfg


def ensure_gateway() -> str:
    """Запускает локальный шлюз Anthropic API -> chat/completions и возвращает его URL."""
    script = f'source "{SHARED}/env.sh" && source "{SHARED}/gateway.sh" && ensure_gateway && echo "$GATEWAY_URL"'
    out = subprocess.run(["bash", "-c", script], capture_output=True, text=True)
    if out.returncode != 0:
        raise SystemExit(out.stderr.strip() or "Не удалось запустить локальный шлюз LLM")
    return out.stdout.strip().splitlines()[-1]


def _stderr(line: str) -> None:
    # Предупреждение о «неизвестной» (не-Claude) модели ожидаемо — не показываем
    if "unrecognized_model" not in line and os.environ.get("AGENT_DEBUG"):
        print(line, file=sys.stderr)


def instructions() -> str:
    return (SHARED / "instructions.md").read_text().replace("{{PYTHON}}", str(SHARED_PY))


def mcp_servers(cfg: dict[str, str]) -> dict:
    servers: dict = mcp_registry.claude_config(cfg)["mcpServers"]
    remote = ROOT / "remote-mcp.json"
    if remote.exists():
        values = {**cfg, **os.environ}
        expand = lambda s: ENV_REF.sub(lambda m: values.get(m.group(1), ""), s)  # noqa: E731
        for name, srv in json.loads(remote.read_text()).get("mcpServers", {}).items():
            if "headers" in srv:
                srv = {**srv, "headers": {k: expand(v) for k, v in srv["headers"].items()}}
            servers[name] = srv
    return servers


def build_options(
    cwd: str | Path,
    can_use_tool: CanUseTool | None = None,
    partial_messages: bool = False,
) -> ClaudeAgentOptions:
    cfg = load_config()
    gateway = ensure_gateway()
    sync_skills(CONFIG_DIR / "skills")
    model, fast = cfg.get("LLM_MODEL") or "MagnitCopilot", cfg.get("LLM_FAST_MODEL") or "MagnitCopilotFlash"
    return ClaudeAgentOptions(
        model=model,
        cwd=str(cwd),
        system_prompt={"type": "preset", "preset": "claude_code", "append": instructions()},
        mcp_servers=mcp_servers(cfg),
        allowed_tools=AUTO_ALLOWED_TOOLS + mcp_registry.auto_allowed(cfg),
        disallowed_tools=DISALLOWED_TOOLS,
        permission_mode="bypassPermissions" if os.environ.get("AGENT_AUTO_APPROVE") == "1" else "default",
        can_use_tool=can_use_tool,
        settings=str(HERE / "settings.json"),
        # user — отдельный профиль агента (навыки), project — CLAUDE.md в рабочей папке.
        # Личные настройки ~/.claude пользователя не подмешиваются (CLAUDE_CONFIG_DIR ниже).
        setting_sources=["user", "project"],
        include_partial_messages=partial_messages,
        stderr=_stderr,
        max_turns=int(os.environ.get("AGENT_MAX_TURNS", "60")),
        env={
            "ANTHROPIC_BASE_URL": gateway,
            "ANTHROPIC_AUTH_TOKEN": "local-gateway",
            "ANTHROPIC_API_KEY": "",
            "ANTHROPIC_MODEL": model,
            "ANTHROPIC_DEFAULT_OPUS_MODEL": model,
            "ANTHROPIC_DEFAULT_SONNET_MODEL": model,
            "ANTHROPIC_DEFAULT_HAIKU_MODEL": fast,
            "ANTHROPIC_SMALL_FAST_MODEL": fast,
            "CLAUDE_CODE_SUBAGENT_MODEL": model,
            "CLAUDE_CODE_MAX_OUTPUT_TOKENS": cfg.get("LLM_MAX_OUTPUT_TOKENS") or "8192",
            "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1",
            "DISABLE_AUTOUPDATER": "1",
            "MAGNIT_ROOT": str(ROOT),  # для хука read_guard.py в settings.json
            # Отдельный профиль: история сессий агента не смешивается с личным Claude Code
            "CLAUDE_CONFIG_DIR": str(CONFIG_DIR),
        },
    )


def describe_tool_call(name: str, tool_input: dict) -> str:
    """Короткое человекочитаемое описание вызова инструмента."""
    name = name.removeprefix("mcp__magnit-files__")
    for key in ("command", "file_path", "path", "pattern", "url"):
        if key in tool_input:
            return f"{name}: {tool_input[key]}"
    return f"{name}: {json.dumps(tool_input, ensure_ascii=False)[:200]}"
