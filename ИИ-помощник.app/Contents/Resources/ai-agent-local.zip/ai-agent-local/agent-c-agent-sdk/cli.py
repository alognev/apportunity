"""Агент C — терминальный чат.

  magnit-agent                 — интерактивный чат в текущей папке
  magnit-agent "задание"       — выполнить одно задание и выйти
  magnit-agent -y ...          — не спрашивать подтверждение команд

Команды в чате: /new — новый диалог, /exit — выход.
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys

from claude_agent_sdk import (
    AssistantMessage,
    ClaudeSDKClient,
    PermissionResultAllow,
    PermissionResultDeny,
    ResultMessage,
    TextBlock,
    ToolPermissionContext,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)

from agent_core import build_options, describe_tool_call

DIM, BOLD, CYAN, YELLOW, RED, RESET = "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[31m", "\033[0m"


async def ask_permission(tool_name: str, tool_input: dict, _ctx: ToolPermissionContext):
    print(f"\n{YELLOW}Агент хочет выполнить → {describe_tool_call(tool_name, tool_input)}{RESET}")
    answer = (await asyncio.to_thread(input, f"{YELLOW}Разрешить? [y/N]: {RESET}")).strip().lower()
    if answer in ("y", "yes", "д", "да"):
        return PermissionResultAllow()
    return PermissionResultDeny(message="Пользователь запретил это действие")


async def run_turn(client: ClaudeSDKClient, prompt: str) -> None:
    await client.query(prompt)
    async for msg in client.receive_response():
        if isinstance(msg, AssistantMessage):
            for block in msg.content:
                if isinstance(block, TextBlock) and block.text.strip():
                    print(f"\n{block.text}")
                elif isinstance(block, ToolUseBlock):
                    print(f"{CYAN}▸ {describe_tool_call(block.name, block.input)}{RESET}")
        elif isinstance(msg, UserMessage) and isinstance(msg.content, list):
            for block in msg.content:
                if isinstance(block, ToolResultBlock) and block.is_error:
                    text = block.content if isinstance(block.content, str) else str(block.content)
                    print(f"{RED}  ошибка: {text[:300]}{RESET}")
        elif isinstance(msg, ResultMessage):
            if msg.is_error:
                print(f"{RED}Ошибка: {msg.result or msg.subtype}{RESET}")
            print(f"{DIM}— шагов: {msg.num_turns}, {msg.duration_ms / 1000:.0f} с{RESET}")


async def main() -> None:
    parser = argparse.ArgumentParser(description="Локальный ИИ-агент (Claude Agent SDK + корпоративная LLM)")
    parser.add_argument("prompt", nargs="*", help="задание; без него — интерактивный режим")
    parser.add_argument("-y", "--yes", action="store_true", help="выполнять команды без подтверждения")
    parser.add_argument("-C", "--cwd", default=os.getcwd(), help="рабочая папка (по умолчанию текущая)")
    args = parser.parse_args()
    if args.yes:
        os.environ["AGENT_AUTO_APPROVE"] = "1"

    options = build_options(args.cwd, can_use_tool=None if args.yes else ask_permission)

    if args.prompt:
        async with ClaudeSDKClient(options) as client:
            await run_turn(client, " ".join(args.prompt))
        return

    print(f"{BOLD}Агент C{RESET} · модель {options.model} · папка {args.cwd}")
    print(f"{DIM}/new — новый диалог, /exit — выход{RESET}")
    client = ClaudeSDKClient(options)
    await client.connect()
    try:
        while True:
            try:
                prompt = (await asyncio.to_thread(input, f"\n{BOLD}Вы ›{RESET} ")).strip()
            except (EOFError, KeyboardInterrupt):
                break
            if not prompt:
                continue
            if prompt in ("/exit", "/quit"):
                break
            if prompt == "/new":
                await client.disconnect()
                client = ClaudeSDKClient(options)
                await client.connect()
                print(f"{DIM}Начат новый диалог{RESET}")
                continue
            try:
                await run_turn(client, prompt)
            except KeyboardInterrupt:
                await client.interrupt()
    finally:
        await client.disconnect()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(130)
