#!/usr/bin/env bash
# Команды для приложения «ИИ-помощник.app» (и для скриптов): всё без вопросов в терминале.
#   agentctl.sh state                 — состояние установки и токенов (KEY=VALUE построчно)
#   agentctl.sh mark-configured       — отметить, что настройки уже показывались
#   agentctl.sh secret-file           — создать пустой файл для секрета (права 600), вывести путь
#   agentctl.sh set KEY ФАЙЛ          — записать значение из файла в .env (файл удаляется); KEY — из списка ALLOWED
#   agentctl.sh check-llm             — проверить токен LLM: ok | auth | cert | network
#   agentctl.sh install-certs         — добавить корпоративные сертификаты в доверенные (macOS спросит пароль)
#   agentctl.sh install               — установить всё нужное (Python, библиотеки, Goose), шаги пишутся в журнал
#   agentctl.sh progress              — «N|ВСЕГО|текст шага|running|done|failed» по журналу установки
#   agentctl.sh tools / tools-set a,b — список инструментов (имя|вкл|название|описание) / сохранить выбор
#   agentctl.sh systems               — системы с личными токенами (KEY|подключено|название|где взять|описание|ссылка)
#   agentctl.sh diagnose              — проверка подключений (текст без цветов)
#   agentctl.sh update                — скачать свежую версию помощника и обновить установку
#   agentctl.sh launch                — открыть Goose в рабочей папке
set -uo pipefail
ROOT="${MAGNIT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
ENV="$ROOT/.env"
STATE="$HOME/.magnit-agent"
LOG="$STATE/install.log"
export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:${PATH:-}"
mkdir -p "$STATE"

# Что разрешено записывать из приложения: токены и адреса подключений
ALLOWED=" LLM_API_KEY JIRA_TOKEN JIRA_IT_TOKEN CONFLUENCE_EPORTAL_TOKEN CONFLUENCE_IT_TOKEN TAG_WEBHOOK_URL TAG_BOT_TOKEN
 GITLAB_TOKEN GITLAB_PLATFORM_TOKEN MAGNITGPT_API_KEY "

get() { grep -E "^$1=" "$ENV" 2>/dev/null | head -1 | cut -d= -f2-; }
set_var() {
  if grep -qE "^$1=" "$ENV"; then
    local tmp; tmp="$(mktemp)"
    awk -v k="$1" -v v="$2" 'BEGIN{FS=OFS="="} $1==k {print k "=" v; next} {print}' "$ENV" > "$tmp" && cat "$tmp" > "$ENV"; rm -f "$tmp"
  else
    echo "$1=$2" >> "$ENV"
  fi
}
ensure_env() { [[ -f "$ENV" ]] || cp "$ROOT/.env.example" "$ENV"; chmod 600 "$ENV"; }
goose_app() { [[ -d "/Applications/Goose.app" || -d "$HOME/Applications/Goose.app" ]]; }

find_python() {  # Python 3.11+: окружение помощника, системный или установленный через uv
  local py
  [[ -x "$ROOT/shared/.venv/bin/python" ]] && { echo "$ROOT/shared/.venv/bin/python"; return 0; }
  for py in python3.13 python3.12 python3.11 python3; do
    py="$(command -v "$py" 2>/dev/null)" || continue
    [[ "$py" == /usr/bin/python3 ]] && ! xcode-select -p >/dev/null 2>&1 && continue
    "$py" -c 'import sys; sys.exit(sys.version_info < (3, 11))' 2>/dev/null && { echo "$py"; return 0; }
  done
  command -v uv >/dev/null 2>&1 && uv python find 3.13 2>/dev/null && return 0
  return 1
}
ensure_python() {
  local py
  if py="$(find_python)"; then echo "$py"; return 0; fi
  if ! command -v uv >/dev/null 2>&1; then
    curl -LsSf https://astral.sh/uv/install.sh | env UV_NO_MODIFY_PATH=1 sh >/dev/null 2>&1 || return 1
  fi
  uv python install 3.13 >/dev/null 2>&1 || return 1
  uv python find 3.13
}

llm_check() {  # ok | auth | cert | network (по коду ответа: при отказе curl -f возвращает разные коды)
  local rc=0 code
  code="$(curl -s -m 15 -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $(get LLM_API_KEY)" "$(get LLM_BASE_URL | sed 's#/*$##')/v1/models")" || rc=$?
  case "$rc:$code" in
    60:*|35:*|77:*) echo cert ;;
    *:200) echo ok ;;
    *:401|*:403) echo auth ;;
    *) echo network ;;
  esac
}

step() { STEP=$((STEP + 1)); echo "@@STEP $STEP/$TOTAL $*"; }
run_install() {
  STEP=0; TOTAL=5
  ensure_env
  xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null || true
  step "Готовлю Python"
  MAGNIT_PYTHON="$(ensure_python)" || { echo "@@FAIL Не удалось установить Python: нужен доступ к github.com"; return 1; }
  export MAGNIT_PYTHON
  step "Устанавливаю библиотеки и модель поиска (несколько минут)"
  bash "$ROOT/shared/install-shared.sh" || { echo "@@FAIL Не удалось установить библиотеки: проверьте интернет"; return 1; }
  step "Устанавливаю приложение Goose (~210 МБ)"
  bash "$ROOT/agent-b-goose/install.sh" --desktop || { echo "@@FAIL Не удалось установить Goose: нужен доступ к github.com"; return 1; }
  step "Применяю настройки"
  "$ROOT/shared/.venv/bin/python" "$ROOT/agent-b-goose/configure.py" >/dev/null || { echo "@@FAIL Не удалось настроить Goose"; return 1; }
  step "Проверяю подключения"
  "$ROOT/shared/.venv/bin/python" "$ROOT/shared/check_integrations.py" || true
  echo "@@DONE"
}

cmd="${1:-state}"; shift || true
case "$cmd" in
  state)
    ensure_env
    echo "ROOT=$ROOT"
    [[ -x "$ROOT/shared/.venv/bin/python" && -f "$ROOT/shared/.venv/.installed" ]] && goose_app && echo "INSTALLED=1" || echo "INSTALLED=0"
    [[ -f "$STATE/configured" ]] && echo "CONFIGURED=1" || echo "CONFIGURED=0"
    for k in $ALLOWED; do [[ -n "$(get "$k")" ]] && echo "$k=1" || echo "$k=0"; done
    echo "VERSION=$(cat "$ROOT/VERSION" 2>/dev/null || echo dev)"
    ;;
  mark-configured)  # настройки показаны пользователю хотя бы раз — дальше приложение сразу открывает Goose
    date '+%Y-%m-%d %H:%M' > "$STATE/configured"; echo ok ;;
  secret-file)
    rm -f "$STATE"/.secret.*   # остатки прерванных попыток (окна с токенами — по одному за раз)
    f="$(mktemp "$STATE/.secret.XXXXXX")"; chmod 600 "$f"; echo "$f" ;;
  set)
    key="${1:?}"; file="${2:?}"
    [[ "$ALLOWED" == *" $key "* ]] || { echo "Недопустимый параметр: $key" >&2; exit 2; }
    case "$file" in "$STATE"/.secret.*) ;; *) echo "Недопустимый файл" >&2; exit 2 ;; esac
    ensure_env
    value="$(tr -d '\r\n' < "$file" | sed -E 's/^[[:space:]]+|[[:space:]]+$//g')"; rm -f "$file"
    [[ -n "$value" ]] || { echo "empty"; exit 0; }
    set_var "$key" "$value"
    if [[ "$key" == TAG_BOT_TOKEN && -z "$(get TAG_USER)" ]]; then set_var TAG_USER "$(whoami)"; fi
    echo "saved" ;;
  check-llm) ensure_env; llm_check ;;
  install-certs)
    kc="$HOME/Library/Keychains/login.keychain-db"; dir="$ROOT/shared/certs"
    security add-trusted-cert -r trustRoot -p ssl -k "$kc" "$dir/tander-root-ca.cer" || exit 1
    [[ -f "$dir/platform-root-ca.cer" ]] && { security add-trusted-cert -r trustRoot -p ssl -k "$kc" "$dir/platform-root-ca.cer" || true; }
    for f in "$dir/tander-corp-ca.cer" "$dir/platform-intermediate-ca.cer"; do
      [[ -f "$f" ]] && { security add-certificates -k "$kc" "$f" 2>/dev/null || true; }
    done
    echo ok ;;
  install)
    : > "$LOG"
    run_install >> "$LOG" 2>&1 || { grep -q '^@@FAIL' "$LOG" || echo "@@FAIL Установка прервана, подробности: $LOG" >> "$LOG"; exit 1; } ;;
  progress)
    last="$(grep '^@@STEP' "$LOG" 2>/dev/null | tail -1)"
    n="$(sed -E 's#^@@STEP ([0-9]+)/([0-9]+) .*#\1#' <<< "$last")"; t="$(sed -E 's#^@@STEP ([0-9]+)/([0-9]+) .*#\2#' <<< "$last")"
    text="$(sed -E 's#^@@STEP [0-9]+/[0-9]+ ##' <<< "$last")"
    if grep -q '^@@DONE' "$LOG" 2>/dev/null; then status=done
    elif grep -q '^@@FAIL' "$LOG" 2>/dev/null; then status=failed; text="$(grep '^@@FAIL' "$LOG" | tail -1 | sed 's/^@@FAIL //')"
    else status=running; fi
    echo "${n:-0}|${t:-5}|${text:-Подготовка}|$status" ;;
  tools)
    "$ROOT/shared/.venv/bin/python" - "$ROOT" <<'PY'
import sys
sys.path.insert(0, sys.argv[1] + "/shared")
import mcp_registry as r
env = r.load_env(); on = set(r.enabled(env))
for name in r.available(env):
    if name in r.ALWAYS_ON:
        continue
    t = r.CONTEXT_TOKENS.get(name)
    size = " · ~" + f"{t / 1000:.1f}".replace(".", ",") + " тыс. токенов" if t else ""
    print(f"{name}|{int(name in on)}|{r.TITLES[name]}{size}|{r.DESCRIPTIONS.get(name, '')}")
PY
    ;;
  systems)  # системы с личными токенами: KEY|подключено|название|где взять|зачем нужна|ссылка (список — app/systems.tsv)
    ensure_env
    while IFS='|' read -r key title where desc url; do
      [[ -z "$key" || "$key" == \#* ]] && continue
      [[ -n "$(get "$key")" ]] && on=1 || on=0
      echo "$key|$on|$title|$where|$desc|$url"
    done < "$ROOT/app/systems.tsv" ;;
  tools-set)
    "$ROOT/shared/.venv/bin/python" - "$ROOT" "${1:-}" <<'PY'
import sys
sys.path.insert(0, sys.argv[1] + "/shared")
import mcp_registry as r
print(r.save_selection([n for n in sys.argv[2].split(",") if n in r.SERVERS]))
PY
    goose_app && "$ROOT/shared/.venv/bin/python" "$ROOT/agent-b-goose/configure.py" >/dev/null 2>&1 || true ;;
  apply)  # применить изменённые токены к Goose
    "$ROOT/shared/.venv/bin/python" "$ROOT/agent-b-goose/configure.py" >/dev/null 2>&1 && echo ok || echo failed ;;
  diagnose)
    "$ROOT/shared/.venv/bin/python" "$ROOT/shared/check_integrations.py" 2>&1 | sed -E $'s/\033\\[[0-9;]*m//g' ;;
  update)
    # Свежий архив из того же места, откуда ставился помощник; токен GitLab — из ~/.magnit-agent/dist-token
    url="$(head -1 "$ROOT/.dist-url" 2>/dev/null || true)"; [[ -n "$url" ]] || { echo "Не задан адрес обновлений"; exit 1; }
    [[ -d "$ROOT/.git" ]] && { echo "Это рабочая копия разработчика (git) — обновляйте через git pull"; exit 1; }
    tok="$(cat "$STATE/dist-token" 2>/dev/null || true)"; auth=(); [[ -n "$tok" ]] && auth=(-H "PRIVATE-TOKEN: $tok")
    tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
    fetch() { curl -fsSL --retry 2 -m 180 ${auth[@]+"${auth[@]}"} -o "$2" "${url//\{file\}/$1}"; }
    fetch install.sh "$tmp/install.sh" && fetch ai-agent-local.zip "$tmp/a.zip" || { echo "Не удалось скачать обновление: проверьте NetBird и токен GitLab"; exit 1; }
    want="$(sed -nE 's/^SHA256="([0-9a-f]{64})"$/\1/p' "$tmp/install.sh")"
    [[ -n "$want" && "$(shasum -a 256 "$tmp/a.zip" | cut -d' ' -f1)" == "$want" ]] || { echo "Контрольная сумма архива не совпала"; exit 1; }
    ditto -x -k "$tmp/a.zip" "$tmp/u" && rsync -a "$tmp/u/ai-agent-local/" "$ROOT/" || { echo "Не удалось распаковать обновление"; exit 1; }
    : > "$LOG"; run_install >> "$LOG" 2>&1 || { echo "Обновление скачано, но установка не завершилась: $LOG"; exit 1; }
    echo "Обновлено до версии $(cat "$ROOT/VERSION" 2>/dev/null || echo '?')" ;;
  launch)
    ws="$(get AGENT_WORKSPACE)"; ws="${ws:-~/magnit-agent-workspace}"; ws="${ws/#\~/$HOME}"; mkdir -p "$ws"
    # Goose не запущен: папку передаём аргументом --dir. Если открыть папку как документ (open -a Goose папка), Goose
    # при холодном старте создаёт два окна и два сервера сразу, и проверки их TLS-сертификатов путаются: «goose serve TLS
    # certificate fingerprint did not match readiness probe». Уже запущенному Goose папку передаём как документ — одно окно.
    if pgrep -x Goose >/dev/null 2>&1; then open -a Goose "$ws"; else open -a Goose --args --dir "$ws"; fi ;;
  *) echo "Неизвестная команда: $cmd" >&2; exit 2 ;;
esac
