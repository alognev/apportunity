#!/usr/bin/env bash
# Сборка «ИИ-помощник.app»: build-app.sh <архив ai-agent-local.zip> <версия> <куда положить .app>
# Приложение — скрипт AppleScript с вложенным архивом помощника. Без подписи Apple Developer: подпись ad-hoc.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ZIP="${1:?архив}"; VERSION="${2:?версия}"; OUTDIR="${3:?папка}"
APP="$OUTDIR/ИИ-помощник.app"
rm -rf "$APP"; mkdir -p "$OUTDIR"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
# osacompile надёжно читает кириллицу из UTF-16
iconv -f UTF-8 -t UTF-16 "$HERE/main.applescript" > "$TMP/main.applescript"
osacompile -o "$APP" "$TMP/main.applescript"
RES="$APP/Contents/Resources"
cp "$HERE/launcher.sh" "$RES/launcher.sh"; chmod +x "$RES/launcher.sh"
cp "$ZIP" "$RES/ai-agent-local.zip"
echo "$VERSION" > "$RES/VERSION"
PL="$APP/Contents/Info.plist"
if [[ -f "$HERE/AppIcon.icns" ]]; then
  cp "$HERE/AppIcon.icns" "$RES/applet.icns"
  # osacompile кладёт стандартный значок в Assets.car и ссылается на него через CFBundleIconName — он важнее
  # CFBundleIconFile, и наш applet.icns иначе не показывается. Оставляем только свой значок.
  rm -f "$RES/Assets.car"
  /usr/libexec/PlistBuddy -c "Delete :CFBundleIconName" "$PL" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Set :CFBundleIconFile applet" "$PL" 2>/dev/null || /usr/libexec/PlistBuddy -c "Add :CFBundleIconFile string applet" "$PL"
fi
/usr/libexec/PlistBuddy -c "Set :CFBundleName ИИ-помощник" "$PL" 2>/dev/null || /usr/libexec/PlistBuddy -c "Add :CFBundleName string ИИ-помощник" "$PL"
/usr/libexec/PlistBuddy -c "Add :CFBundleIdentifier string ru.magnit.ai-assistant" "$PL" 2>/dev/null || /usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier ru.magnit.ai-assistant" "$PL"
/usr/libexec/PlistBuddy -c "Add :CFBundleShortVersionString string $VERSION" "$PL" 2>/dev/null || /usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString $VERSION" "$PL"
xattr -cr "$APP"
codesign --force --deep -s - "$APP" >/dev/null 2>&1
echo "$APP"
