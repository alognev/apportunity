-- «ИИ-помощник»: оболочка над локальным помощником. Первый запуск — установка с вопросами в окнах.
-- Дальше при запуске две секунды показывается окно с кнопками «Настройки…» и «Запустить»; без нажатия
-- открывается Goose. Если запустить приложение с зажатой ⌥ Option — сразу открываются настройки.
-- Если настройки ещё ни разу не показывались (помощник ставили из Терминала), они откроются один раз сами. Вся работа — в app/agentctl.sh (через launcher.sh из ресурсов приложения).
use AppleScript version "2.4"
use framework "AppKit"
use scripting additions

property appTitle : "ИИ-помощник"
property launchDelay : 2
global ctl

-- Зажата ли клавиша ⌥ Option прямо сейчас
on optionDown()
	set flags to (current application's NSEvent's modifierFlags()) as integer
	return ((flags div 524288) mod 2) is 1
end optionDown

on ctlRun(args)
	return do shell script "/bin/bash " & quoted form of ctl & " " & args
end ctlRun

on splitText(t, d)
	set oldD to AppleScript's text item delimiters
	set AppleScript's text item delimiters to d
	set parts to text items of t
	set AppleScript's text item delimiters to oldD
	return parts
end splitText

on joinText(l, d)
	set oldD to AppleScript's text item delimiters
	set AppleScript's text item delimiters to d
	set t to l as text
	set AppleScript's text item delimiters to oldD
	return t
end joinText

-- Секрет не попадает в командную строку: пишем его в файл с правами 600, agentctl читает и удаляет файл
on saveSecret(key, value)
	set f to ctlRun("secret-file")
	-- Пишем через Foundation: «open for access POSIX file» не работает в скрипте с «use framework» (ошибка -1700).
	-- atomically:false — файл перезаписывается на месте и сохраняет права 600, выданные agentctl.
	set ok to (current application's NSString's stringWithString:value)'s writeToFile:f atomically:false encoding:(current application's NSUTF8StringEncoding) |error|:(missing value)
	if not (ok as boolean) then error "Не удалось сохранить токен во временный файл"
	return ctlRun("set " & key & " " & quoted form of f)
end saveSecret

property llmTokenPage : "https://llmlite.ailab-copilot-prod.corp.tander.ru/ui/api-keys"

-- Панель окна ввода токена: кликабельная ссылка на страницу создания токена (если есть) и поле ввода (точками).
-- Возвращает {панель, поле}.
on secretPanel(pageURL)
	set w to 440
	set field to current application's NSSecureTextField's alloc()'s initWithFrame:{{0, 0}, {w, 24}}
	field's setPlaceholderString:"вставьте токен (⌘ Cmd + V)"
	if pageURL is "" then
		set panel to current application's NSView's alloc()'s initWithFrame:{{0, 0}, {w, 24}}
		panel's addSubview:field
		return {panel, field}
	end if
	set caption to current application's NSTextField's labelWithString:"Страница, где создаётся токен (нажмите, откроется в браузере):"
	caption's setFont:(current application's NSFont's systemFontOfSize:11)
	caption's setTextColor:(current application's NSColor's secondaryLabelColor())
	set attrs to current application's NSMutableDictionary's dictionary()
	attrs's setObject:(current application's NSURL's URLWithString:pageURL) forKey:(current application's NSLinkAttributeName)
	attrs's setObject:(current application's NSFont's systemFontOfSize:12) forKey:(current application's NSFontAttributeName)
	set linkText to current application's NSAttributedString's alloc()'s initWithString:pageURL attributes:attrs
	set link to current application's NSTextField's labelWithAttributedString:linkText
	link's setSelectable:true
	link's setAllowsEditingTextAttributes:true -- без этого ссылка не нажимается
	link's setLineBreakMode:(current application's NSLineBreakByCharWrapping)
	link's setPreferredMaxLayoutWidth:w
	set lh to (height of ((link's cell()'s cellSizeForBounds:{{0, 0}, {w, 1000}}) as record)) + 4
	set total to 16 + 4 + lh + 12 + 24
	set panel to current application's NSView's alloc()'s initWithFrame:{{0, 0}, {w, total}}
	caption's setFrame:{{0, total - 16}, {w, 16}}
	link's setFrame:{{0, total - 20 - lh}, {w, lh}}
	field's setFrame:{{0, 0}, {w, 24}}
	panel's addSubview:caption
	panel's addSubview:link
	panel's addSubview:field
	return {panel, field}
end secretPanel

-- Окно ввода токена (системное окно AppKit вместо display dialog: в нём ссылка на страницу токена нажимается).
-- headline — заголовок, prompt — пояснение, skipLabel — вторая кнопка. Пустая строка — пропуск.
on askSecret(headline, prompt, skipLabel, pageURL)
	set {panel, field} to secretPanel(pageURL)
	set alert to current application's NSAlert's alloc()'s init()
	alert's setMessageText:headline
	alert's setInformativeText:prompt
	alert's addButtonWithTitle:"Сохранить"
	alert's addButtonWithTitle:skipLabel
	alert's setAccessoryView:panel
	alert's |layout|()
	alert's |window|()'s setInitialFirstResponder:field
	current application's NSApplication's sharedApplication()'s activateIgnoringOtherApps:true
	if ((alert's runModal()) as integer) is not 1000 then return ""
	return (field's stringValue()) as text
end askSecret

-- Токен LLM: спросить, сохранить, проверить. true — токен принят.
on setupLLM()
	repeat
		set tok to askSecret("Токен доступа к нейросети", "Вставьте токен вида sk-…: его создают на странице ниже (Virtual Keys → Create New Key) или выдаёт ответственный за Magnit Copilot. При вставке токен показывается точками — так задумано.", "Отмена", llmTokenPage)
		if tok is "" then return false
		saveSecret("LLM_API_KEY", tok)
		if checkLLM() then return true
	end repeat
end setupLLM

on checkLLM()
	repeat
		set res to ctlRun("check-llm")
		if res is "ok" then return true
		if res is "auth" then
			display dialog "Токен не принят. Проверьте, что он скопирован целиком, и вставьте ещё раз." buttons {"Продолжить"} default button 1 with title appTitle with icon caution
			return false
		else if res is "cert" then
			set r to display dialog "Этот Mac не доверяет корпоративным сертификатам (так бывает на личных компьютерах)." & return & return & "Добавить их в доверенные? macOS попросит пароль от Mac — дважды." buttons {"Отмена", "Добавить"} default button 2 with title appTitle with icon caution
			if button returned of r is "Отмена" then error number -128
			try
				ctlRun("install-certs")
			on error
				display dialog "Сертификаты не добавлены. Установите их вручную: файл ИНСТРУКЦИЯ.md, шаг 3.5а." buttons {"Закрыть"} default button 1 with title appTitle with icon stop
				error number -128
			end try
		else
			set r to display dialog "Нет связи с корпоративной нейросетью." & return & return & "Проверьте, что VPN NetBird подключён (значок рядом с часами), и повторите." buttons {"Отмена", "Повторить"} default button 2 with title appTitle with icon caution
			if button returned of r is "Отмена" then error number -128
		end if
	end repeat
end checkLLM

-- Список с флажками и пояснением под каждым пунктом (AppKit): {прокручиваемая панель, флажки}
on buildChecklist(titles, descs, flags)
	set w to 520
	set gap to 14
	set rows to {}
	set totalH to 6
	repeat with i from 1 to count of titles
		set cb to current application's NSButton's checkboxWithTitle:(item i of titles) target:(missing value) action:(missing value)
		cb's setFont:(current application's NSFont's boldSystemFontOfSize:13)
		if item i of flags then cb's setState:1
		set lbl to current application's NSTextField's wrappingLabelWithString:(item i of descs)
		lbl's setFont:(current application's NSFont's systemFontOfSize:12)
		lbl's setTextColor:(current application's NSColor's secondaryLabelColor())
		lbl's setPreferredMaxLayoutWidth:(w - 24)
		-- высота текста при заданной ширине (fittingSize иногда занижает и обрезает последнюю строку)
		set lh to (height of ((lbl's cell()'s cellSizeForBounds:{{0, 0}, {w - 24, 10000}}) as record)) + 4
		set end of rows to {cb, lbl, lh}
		set totalH to totalH + 20 + 2 + lh + gap
	end repeat
	set doc to current application's NSView's alloc()'s initWithFrame:{{0, 0}, {w, totalH}}
	set y to totalH - 4
	set boxes to {}
	repeat with r in rows
		set {cb, lbl, lh} to contents of r
		set y to y - 20
		cb's setFrame:{{0, y}, {w, 20}}
		set y to y - 2 - lh
		lbl's setFrame:{{20, y}, {w - 24, lh}}
		set y to y - gap
		doc's addSubview:cb
		doc's addSubview:lbl
		set end of boxes to cb
	end repeat
	set visibleH to totalH
	if visibleH > 520 then set visibleH to 520
	set sv to current application's NSScrollView's alloc()'s initWithFrame:{{0, 0}, {w + 20, visibleH}}
	sv's setHasVerticalScroller:(totalH > visibleH)
	sv's setDrawsBackground:false
	sv's setBorderType:0
	sv's setDocumentView:doc
	doc's scrollPoint:{0, totalH}
	return {sv, boxes}
end buildChecklist

-- Окно со списком: false — отмена, иначе список true/false по пунктам
on checklist(headline, info, titles, descs, flags, okLabel, cancelLabel)
	set {sv, boxes} to buildChecklist(titles, descs, flags)
	set alert to current application's NSAlert's alloc()'s init()
	alert's setMessageText:headline
	if (sv's hasVerticalScroller()) as boolean then set info to info & " Список прокручивается."
	alert's setInformativeText:info
	alert's addButtonWithTitle:okLabel
	alert's addButtonWithTitle:cancelLabel
	alert's setAccessoryView:sv
	current application's NSApplication's sharedApplication()'s activateIgnoringOtherApps:true
	set answer to (alert's runModal()) as integer
	if answer is not 1000 then return false
	set states to {}
	repeat with cb in boxes
		set end of states to ((cb's state()) as integer) is 1
	end repeat
	return states
end checklist

-- Корпоративные системы: каждую можно пропустить. Список и пояснения — app/systems.tsv
-- Согласие на отправку текста разговоров в Langfuse (по умолчанию — нет: только модели, время, токены, инструменты).
on askTracingContent()
	set answer to button returned of (display dialog "Отправлять в Langfuse и текст разговоров?" & return & return & "Да — команда помощника увидит ваши запросы и ответы (секреты и токены скрываются). Это сильнее всего помогает находить ошибки." & return & return & "Нет — только служебные данные: какие модели и инструменты вызывались, время, число токенов, ошибки." & return & return & "Изменить можно позже, подключив трассировку заново." buttons {"Нет, без текста", "Да, с текстом"} default button 1 with title appTitle)
	if answer is "Да, с текстом" then
		ctlRun("tracing-content on")
	else
		ctlRun("tracing-content off")
	end if
end askTracingContent

on setupIntegrations()
	set keys to {}
	set titles to {}
	set names to {}
	set hints to {}
	set descs to {}
	set pages to {}
	set flags to {}
	repeat with r in paragraphs of ctlRun("systems")
		if (r as text) is not "" then
			set p to splitText(r as text, "|")
			set end of keys to item 1 of p
			set end of names to item 3 of p
			if item 2 of p is "1" then
				set end of titles to (item 3 of p) & "   ✓ подключено"
			else
				set end of titles to item 3 of p
			end if
			set end of hints to item 4 of p
			set end of descs to item 5 of p
			if (count of p) ≥ 6 then
				set end of pages to item 6 of p
			else
				set end of pages to ""
			end if
			set end of flags to false
		end if
	end repeat
	set picked to checklist("Какие системы подключить?", "Отметьте те, с которыми работаете. Для каждой понадобится личный токен — подскажем, где его взять. Любую можно пропустить и подключить позже в настройках.", titles, descs, flags, "Далее", "Пропустить")
	if picked is false then return 0
	set saved to 0
	repeat with i from 1 to count of keys
		if item i of picked then
			set tok to askSecret(item i of names, "Где взять: " & (item i of hints) & ". Вставьте токен в поле ниже — при вставке он показывается точками.", "Пропустить", item i of pages)
			if tok is not "" then
				set res to saveSecret(item i of keys, tok)
				if res is "invalid" then
					display dialog "Это не похоже на ключ Langfuse. Нужна одна строка вида pk-lf-…:sk-lf-… — попросите её у ответственного за помощника и подключите позже в настройках." buttons {"Понятно"} default button 1 with title appTitle with icon caution
				else
					set saved to saved + 1
					if (item i of keys) is "LANGFUSE_KEYS" then askTracingContent()
				end if
			end if
		end if
	end repeat
	return saved
end setupIntegrations

-- Установка в фоне с окном прогресса. true — успешно.
on runInstall()
	do shell script "/bin/bash " & quoted form of ctl & " install > /dev/null 2>&1 &"
	set progress total steps to 5
	set progress completed steps to 0
	set progress description to "Устанавливаю помощника…"
	set progress additional description to "Это займёт 5–10 минут. Окно можно не закрывать."
	delay 2
	repeat
		set p to splitText(ctlRun("progress"), "|")
		set progress total steps to (item 2 of p) as integer
		set progress completed steps to ((item 1 of p) as integer) - 1
		set progress additional description to item 3 of p
		if item 4 of p is "done" then
			set progress completed steps to (item 2 of p) as integer
			return true
		else if item 4 of p is "failed" then
			display dialog "Установка не завершилась." & return & return & (item 3 of p) & return & return & "Запустите приложение ещё раз — установка продолжится с того же места." buttons {"Закрыть"} default button 1 with title appTitle with icon stop
			return false
		end if
		delay 2
	end repeat
end runInstall

on firstRun()
	display dialog "Установим ИИ-помощника на этот Mac." & return & return & "Понадобятся: подключённый VPN NetBird и токен доступа к нейросети (sk-…). Токены Jira, Confluence, Tag и GitLab можно добавить сейчас или позже." & return & return & "Будут скачаны приложение Goose и модель поиска — около 350 МБ, 5–10 минут." buttons {"Отмена", "Продолжить"} default button 2 with title appTitle
	set stateText to ctlRun("state")
	if stateText contains "LLM_API_KEY=1" then
		if not checkLLM() then
			if not setupLLM() then return
		end if
	else
		if not setupLLM() then return
	end if
	setupIntegrations()
	if runInstall() then
		ctlRun("mark-configured")
		display dialog "Помощник установлен." & return & return & "Он открывается этим же приложением. Настройки (подключить системы, выбрать инструменты, проверить подключения, обновить) открываются кнопкой «Настройки…» в окне при запуске или запуском с зажатой клавишей ⌥ Option." buttons {"Открыть помощника"} default button 1 with title appTitle
		ctlRun("launch")
	end if
end firstRun

on chooseTools()
	set names to {}
	set titles to {}
	set descs to {}
	set flags to {}
	repeat with r in paragraphs of ctlRun("tools")
		if (r as text) is not "" then
			set p to splitText(r as text, "|")
			set end of names to item 1 of p
			set end of titles to item 3 of p
			set end of descs to item 4 of p
			set end of flags to (item 2 of p is "1")
		end if
	end repeat
	set picked to checklist("Какие инструменты включить?", "Каждый включённый инструмент занимает «память» нейросети в каждом запросе, поэтому включайте только нужные — ответы будут быстрее и точнее. Изменить выбор можно в любой момент.", titles, descs, flags, "Сохранить", "Отмена")
	if picked is false then return
	set chosen to {}
	repeat with i from 1 to count of names
		if item i of picked then set end of chosen to item i of names
	end repeat
	ctlRun("tools-set " & quoted form of joinText(chosen, ","))
	display dialog "Сохранено. Изменения применятся в новом чате Goose." buttons {"Хорошо"} default button 1 with title appTitle
end chooseTools

on settingsMenu()
	set menuItems to {"Открыть помощника", "Подключить системы: Jira, Confluence, Tag, GitLab…", "Активные инструменты", "Проверка подключений", "Сменить токен нейросети", "Обновить помощника", "Открыть папку помощника"}
	repeat
		set picked to choose from list menuItems with title appTitle with prompt "Настройки помощника" OK button name "Выбрать" cancel button name "Закрыть"
		if picked is false then return
		set choice to item 1 of picked
		if choice is item 1 of menuItems then
			ctlRun("launch")
			return
		else if choice is item 2 of menuItems then
			if setupIntegrations() > 0 then
				ctlRun("apply")
				display dialog "Токены сохранены. Новые системы появятся в новом чате Goose." buttons {"Хорошо"} default button 1 with title appTitle
			end if
		else if choice is item 3 of menuItems then
			chooseTools()
		else if choice is item 4 of menuItems then
			display dialog ctlRun("diagnose") buttons {"Закрыть"} default button 1 with title appTitle
		else if choice is item 5 of menuItems then
			if setupLLM() then
				ctlRun("apply")
				display dialog "Токен сохранён." buttons {"Хорошо"} default button 1 with title appTitle
			end if
		else if choice is item 6 of menuItems then
			set progress total steps to -1
			set progress description to "Обновляю помощника…"
			set progress additional description to "Скачиваю свежую версию, это может занять несколько минут."
			try
				set res to ctlRun("update")
			on error e
				set res to e
			end try
			display dialog res buttons {"Закрыть"} default button 1 with title appTitle
		else if choice is item 7 of menuItems then
			set stateText to ctlRun("state")
			repeat with l in paragraphs of stateText
				if (l as text) starts with "ROOT=" then do shell script "open " & quoted form of (text 6 thru -1 of (l as text))
			end repeat
		end if
	end repeat
end settingsMenu

on run
	set ctl to POSIX path of (path to resource "launcher.sh")
	tell me to activate
	try
		set stateText to ctlRun("state")
		if stateText contains "INSTALLED=1" and stateText contains "LLM_API_KEY=1" then
			if stateText contains "CONFIGURED=0" then
				-- помощник установлен, но настройки ни разу не открывались: показываем их один раз
				ctlRun("mark-configured")
				settingsMenu()
			else if optionDown() then
				settingsMenu()
			else
				-- окно на launchDelay секунд: можно нажать «Настройки…» или «Запустить»; без нажатия открываем Goose
				set r to display dialog "Открываю помощника…" buttons {"Настройки…", "Запустить"} default button 2 with title appTitle giving up after launchDelay
				if button returned of r is "Настройки…" then
					settingsMenu()
				else
					ctlRun("launch")
				end if
			end if
		else
			firstRun()
		end if
	on error e number n
		if n is not -128 then display dialog "Ошибка: " & e buttons {"Закрыть"} default button 1 with title appTitle with icon stop
	end try
end run
