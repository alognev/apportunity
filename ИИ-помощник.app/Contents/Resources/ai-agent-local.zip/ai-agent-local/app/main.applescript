-- «ИИ-помощник»: оболочка над локальным помощником. Первый запуск — установка с вопросами в окнах.
-- Дальше при запуске две секунды показывается окно с кнопками «Настройки…» и «Запустить»; без нажатия
-- открывается Goose. Если запустить приложение с зажатой ⌥ Option — сразу открываются настройки.
-- Если настройки ещё ни разу не показывались (помощник ставили из Терминала), они откроются один раз сами. Вся работа — в app/agentctl.sh (через launcher.sh из ресурсов приложения).
use AppleScript version "2.4"
use framework "AppKit"
use scripting additions

property appTitle : "ИИ-помощник"
property launchDelay : 2
global ctl

-- Зажата ли клавиша ⌥ Option прямо сейчас
on optionDown()
	set flags to (current application's NSEvent's modifierFlags()) as integer
	return ((flags div 524288) mod 2) is 1
end optionDown

on ctlRun(args)
	return do shell script "/bin/bash " & quoted form of ctl & " " & args
end ctlRun

on splitText(t, d)
	set oldD to AppleScript's text item delimiters
	set AppleScript's text item delimiters to d
	set parts to text items of t
	set AppleScript's text item delimiters to oldD
	return parts
end splitText

on joinText(l, d)
	set oldD to AppleScript's text item delimiters
	set AppleScript's text item delimiters to d
	set t to l as text
	set AppleScript's text item delimiters to oldD
	return t
end joinText

-- Секрет не попадает в командную строку: пишем его в файл с правами 600, agentctl читает и удаляет файл
on saveSecret(key, value)
	set f to ctlRun("secret-file")
	-- Пишем через Foundation: «open for access POSIX file» не работает в скрипте с «use framework» (ошибка -1700).
	-- atomically:false — файл перезаписывается на месте и сохраняет права 600, выданные agentctl.
	set ok to (current application's NSString's stringWithString:value)'s writeToFile:f atomically:false encoding:(current application's NSUTF8StringEncoding) |error|:(missing value)
	if not (ok as boolean) then error "Не удалось сохранить токен во временный файл"
	return ctlRun("set " & key & " " & quoted form of f)
end saveSecret

property llmTokenPage : "https://llmlite.ailab-copilot-prod.corp.tander.ru/"

-- Панель окна ввода токена: кликабельная ссылка на страницу создания токена (если есть) и поле ввода (точками).
-- Возвращает {панель, поле}.
on secretPanel(pageURL)
	set w to 440
	set field to current application's NSSecureTextField's alloc()'s initWithFrame:{{0, 0}, {w, 24}}
	field's setPlaceholderString:"вставьте токен (⌘ Cmd + V)"
	if pageURL is "" then
		set panel to current application's NSView's alloc()'s initWithFrame:{{0, 0}, {w, 24}}
		panel's addSubview:field
		return {panel, field}
	end if
	set caption to current application's NSTextField's labelWithString:"Страница, где создаётся токен (нажмите, откроется в браузере):"
	caption's setFont:(current application's NSFont's systemFontOfSize:11)
	caption's setTextColor:(current application's NSColor's secondaryLabelColor())
	set attrs to current application's NSMutableDictionary's dictionary()
	attrs's setObject:(current application's NSURL's URLWithString:pageURL) forKey:(current application's NSLinkAttributeName)
	attrs's setObject:(current application's NSFont's systemFontOfSize:12) forKey:(current application's NSFontAttributeName)
	set linkText to current application's NSAttributedString's alloc()'s initWithString:pageURL attributes:attrs
	set link to current application's NSTextField's labelWithAttributedString:linkText
	link's setSelectable:true
	link's setAllowsEditingTextAttributes:true -- без этого ссылка не нажимается
	link's setLineBreakMode:(current application's NSLineBreakByCharWrapping)
	link's setPreferredMaxLayoutWidth:w
	set lh to (height of ((link's cell()'s cellSizeForBounds:{{0, 0}, {w, 1000}}) as record)) + 4
	set total to 16 + 4 + lh + 12 + 24
	set panel to current application's NSView's alloc()'s initWithFrame:{{0, 0}, {w, total}}
	caption's setFrame:{{0, total - 16}, {w, 16}}
	link's setFrame:{{0, total - 20 - lh}, {w, lh}}
	field's setFrame:{{0, 0}, {w, 24}}
	panel's addSubview:caption
	panel's addSubview:link
	panel's addSubview:field
	return {panel, field}
end secretPanel

-- Окно ввода токена (системное окно AppKit вместо display dialog: в нём ссылка на страницу токена нажимается).
-- headline — заголовок, prompt — пояснение, skipLabel — вторая кнопка. Пустая строка — пропуск.
on askSecret(headline, prompt, skipLabel, pageURL)
	set {panel, field} to secretPanel(pageURL)
	set alert to current application's NSAlert's alloc()'s init()
	alert's setMessageText:headline
	alert's setInformativeText:prompt
	alert's addButtonWithTitle:"Сохранить"
	alert's addButtonWithTitle:skipLabel
	alert's setAccessoryView:panel
	alert's |layout|()
	alert's |window|()'s setInitialFirstResponder:field
	current application's NSApplication's sharedApplication()'s activateIgnoringOtherApps:true
	if ((alert's runModal()) as integer) is not 1000 then return ""
	return (field's stringValue()) as text
end askSecret

-- Токен LLM: спросить, сохранить, проверить. true — токен принят.
on setupLLM()
	repeat
		set tok to askSecret("Токен доступа к нейросети", "Вставьте токен вида sk-…: его создают на странице ниже: Virtual Keys → + Create New Key → Team: not-ai-lab, Models: All Team Models, Key Name: ИИ-помощник → Create Key или выдаёт ответственный за Magnit Copilot. При вставке токен показывается точками — так задумано.", "Отмена", llmTokenPage)
		if tok is "" then return false
		saveSecret("LLM_API_KEY", tok)
		if checkLLM() then return true
	end repeat
end setupLLM

on checkLLM()
	repeat
		set res to ctlRun("check-llm")
		if res is "ok" then return true
		if res is "auth" then
			display dialog "Токен не принят. Проверьте, что он скопирован целиком, и вставьте ещё раз." buttons {"Продолжить"} default button 1 with title appTitle with icon caution
			return false
		else if res is "cert" then
			set r to display dialog "Этот Mac не доверяет корпоративным сертификатам (так бывает на личных компьютерах)." & return & return & "Добавить их в доверенные? macOS попросит пароль от Mac — дважды." buttons {"Отмена", "Добавить"} default button 2 with title appTitle with icon caution
			if button returned of r is "Отмена" then error number -128
			try
				ctlRun("install-certs")
			on error
				display dialog "Сертификаты не добавлены. Установите их вручную: инструкция по установке, раздел «Сертификаты вручную (личный Mac)»." buttons {"Закрыть"} default button 1 with title appTitle with icon stop
				error number -128
			end try
		else
			set r to display dialog "Нет связи с корпоративной нейросетью." & return & return & "Проверьте, что VPN (FortiClient или NetBird) подключён (значок рядом с часами), и повторите." buttons {"Отмена", "Повторить"} default button 2 with title appTitle with icon caution
			if button returned of r is "Отмена" then error number -128
		end if
	end repeat
end checkLLM

-- Список с флажками и пояснением под каждым пунктом (AppKit): {прокручиваемая панель, флажки}
on buildChecklist(titles, descs, flags)
	set w to 520
	set gap to 14
	set rows to {}
	set totalH to 6
	repeat with i from 1 to count of titles
		set cb to current application's NSButton's checkboxWithTitle:(item i of titles) target:(missing value) action:(missing value)
		cb's setFont:(current application's NSFont's boldSystemFontOfSize:13)
		if item i of flags then cb's setState:1
		set lbl to current application's NSTextField's wrappingLabelWithString:(item i of descs)
		lbl's setFont:(current application's NSFont's systemFontOfSize:12)
		lbl's setTextColor:(current application's NSColor's secondaryLabelColor())
		lbl's setPreferredMaxLayoutWidth:(w - 24)
		-- высота текста при заданной ширине (fittingSize иногда занижает и обрезает последнюю строку)
		set lh to (height of ((lbl's cell()'s cellSizeForBounds:{{0, 0}, {w - 24, 10000}}) as record)) + 4
		set end of rows to {cb, lbl, lh}
		set totalH to totalH + 20 + 2 + lh + gap
	end repeat
	set doc to current application's NSView's alloc()'s initWithFrame:{{0, 0}, {w, totalH}}
	set y to totalH - 4
	set boxes to {}
	repeat with r in rows
		set {cb, lbl, lh} to contents of r
		set y to y - 20
		cb's setFrame:{{0, y}, {w, 20}}
		set y to y - 2 - lh
		lbl's setFrame:{{20, y}, {w - 24, lh}}
		set y to y - gap
		doc's addSubview:cb
		doc's addSubview:lbl
		set end of boxes to cb
	end repeat
	set visibleH to totalH
	if visibleH > 520 then set visibleH to 520
	set sv to current application's NSScrollView's alloc()'s initWithFrame:{{0, 0}, {w + 20, visibleH}}
	sv's setHasVerticalScroller:(totalH > visibleH)
	sv's setDrawsBackground:false
	sv's setBorderType:0
	sv's setDocumentView:doc
	doc's scrollPoint:{0, totalH}
	return {sv, boxes}
end buildChecklist

-- Окно со списком: false — отмена, иначе список true/false по пунктам
on checklist(headline, info, titles, descs, flags, okLabel, cancelLabel)
	set {sv, boxes} to buildChecklist(titles, descs, flags)
	set alert to current application's NSAlert's alloc()'s init()
	alert's setMessageText:headline
	if (sv's hasVerticalScroller()) as boolean then set info to info & " Список прокручивается."
	alert's setInformativeText:info
	alert's addButtonWithTitle:okLabel
	alert's addButtonWithTitle:cancelLabel
	alert's setAccessoryView:sv
	current application's NSApplication's sharedApplication()'s activateIgnoringOtherApps:true
	set answer to (alert's runModal()) as integer
	if answer is not 1000 then return false
	set states to {}
	repeat with cb in boxes
		set end of states to ((cb's state()) as integer) is 1
	end repeat
	return states
end checklist

-- Корпоративные системы: каждую можно пропустить. Список и пояснения — app/systems.tsv
-- Согласие на отправку текста разговоров в Langfuse (по умолчанию — нет: только модели, время, токены, инструменты).
on askTracingContent()
	set answer to button returned of (display dialog "Отправлять в Langfuse и текст разговоров?" & return & return & "Да — команда помощника увидит ваши запросы и ответы (секреты и токены скрываются). Это сильнее всего помогает находить ошибки." & return & return & "Нет — только служебные данные: какие модели и инструменты вызывались, время, число токенов, ошибки." & return & return & "Изменить можно позже, подключив трассировку заново." buttons {"Нет, без текста", "Да, с текстом"} default button 1 with title appTitle)
	if answer is "Да, с текстом" then
		ctlRun("tracing-content on")
	else
		ctlRun("tracing-content off")
	end if
end askTracingContent

-- One form for an integration. Only entered values are saved.
on editConnection(serviceName, serviceKey, tableRows)
	set w to 510
	set panel to current application's NSView's alloc()'s initWithFrame:{{0, 0}, {w, 10}}
	set inputFields to {}
	set fieldRows to {}
	set fieldKeys to {}
	set totalH to 8
	set simpleRows to {}
	set passwordOnly to serviceKey is "AIRFLOW" or serviceKey is "TRINO"
	set savedAddress to ""
	if passwordOnly then
		set savedAddress to ctlRun("connection-address " & quoted form of serviceKey)
		set simpleRows to {{"LOCAL_URL", "Адрес", "HTTPS-адрес сервиса.", false}, {"LOCAL_LOGIN", "Логин", "Учётная запись этой системы.", false}, {"LOCAL_PASSWORD", "Пароль", "Ввод скрывается.", true}}
	else
		repeat with rowRef in tableRows
			set rowData to contents of rowRef
			set keyName to item 1 of rowData
			if item 7 of rowData is "secret" then
				if serviceKey is "S3" then
					set end of simpleRows to {"LOCAL_LOGIN", "Ключ доступа", "Введите идентификатор ключа S3.", false}
					set end of simpleRows to {"LOCAL_PASSWORD", "Секретный ключ", "Введите секрет для этого ключа S3.", true}
				else
					set titleText to "Данные доступа"
					if item 2 of rowData is "1" then set titleText to titleText & "   ✓ сохранено"
					set end of simpleRows to {keyName, titleText, item 4 of rowData, true}
				end if
			else
				set titleText to item -1 of splitText(item 3 of rowData, " · ")
				if item 2 of rowData is "1" then set titleText to titleText & "   ✓ сохранено"
				set end of simpleRows to {keyName, titleText, item 4 of rowData, false}
			end if
		end repeat
	end if
	repeat with rowRef in simpleRows
		set {keyName, titleText, hintText, secretFlag} to contents of rowRef
		if secretFlag then
			set tb to current application's NSSecureTextField's alloc()'s initWithFrame:{{0, 0}, {w, 24}}
		else
			set tb to current application's NSTextField's alloc()'s initWithFrame:{{0, 0}, {w, 24}}
		end if
		if keyName is "LOCAL_URL" then tb's setStringValue:savedAddress
		set lbl to current application's NSTextField's labelWithString:titleText
		lbl's setFont:(current application's NSFont's boldSystemFontOfSize:12)
		set helpText to current application's NSTextField's wrappingLabelWithString:hintText
		helpText's setPreferredMaxLayoutWidth:w
		helpText's setTextColor:(current application's NSColor's secondaryLabelColor())
		set helpHeight to (height of ((helpText's cell()'s cellSizeForBounds:{{0, 0}, {w, 200}}) as record)) + 3
		set end of fieldRows to {lbl, tb, helpText, helpHeight}
		set end of inputFields to tb
		set end of fieldKeys to keyName
		set totalH to totalH + 50 + helpHeight
	end repeat
	panel's setFrameSize:{w, totalH}
	set y to totalH
	repeat with fieldRow in fieldRows
		set {lbl, tb, helpText, helpHeight} to contents of fieldRow
		set y to y - 17
		lbl's setFrame:{{0, y}, {w, 17}}
		set y to y - 24
		tb's setFrame:{{0, y}, {w, 22}}
		set y to y - 2 - helpHeight
		helpText's setFrame:{{0, y}, {w, helpHeight}}
		set y to y - 7
		panel's addSubview:lbl
		panel's addSubview:tb
		panel's addSubview:helpText
	end repeat
	set visibleH to totalH
	if visibleH > 400 then set visibleH to 400
	set sv to current application's NSScrollView's alloc()'s initWithFrame:{{0, 0}, {w + 20, visibleH}}
	sv's setHasVerticalScroller:(totalH > visibleH)
	sv's setDrawsBackground:false
	sv's setDocumentView:panel
	panel's scrollPoint:{0, totalH}
	set alert to current application's NSAlert's alloc()'s init()
	alert's setMessageText:serviceName
	if passwordOnly then
		alert's setInformativeText:"При первом входе или смене адреса введите логин и пароль."
	else
		alert's setInformativeText:"Пустые поля сохранят текущие значения."
	end if
	alert's addButtonWithTitle:"Сохранить"
	alert's addButtonWithTitle:"Пропустить"
	set servicePage to item 6 of item 1 of tableRows
	if passwordOnly then set servicePage to savedAddress
	if servicePage starts with "https://" then alert's addButtonWithTitle:"Открыть сервис"
	alert's setAccessoryView:sv
	alert's |layout|()
	(alert's |window|())'s setInitialFirstResponder:(item 1 of inputFields)
	repeat
		set answer to alert's runModal() as integer
		if answer is 1002 then
			do shell script "/usr/bin/open " & quoted form of servicePage
			set answer to alert's runModal() as integer
		end if
		if answer is not 1000 then return 0
		set inputValues to {}
		set localLogin to ""
		set localPassword to ""
		set localAddress to ""
		repeat with i from 1 to count of inputFields
			set value to ((item i of inputFields)'s stringValue()) as text
			set keyName to item i of fieldKeys
			if keyName is "LOCAL_URL" then
				set localAddress to value
			else if keyName is "LOCAL_LOGIN" then
				set localLogin to value
			else if keyName is "LOCAL_PASSWORD" then
				set localPassword to value
			else if value is not "" then
				set end of inputValues to {keyName, value}
			end if
		end repeat
		if localLogin is "" and localPassword is "" and (not passwordOnly or localAddress is savedAddress) then exit repeat
		if localLogin is "" or localPassword is "" or localLogin contains ":" or (passwordOnly and localAddress is "") then
			display dialog "Заполните оба поля входа. Для Airflow и Trino проверьте адрес сервиса." buttons {"Понятно"} default button 1 with title appTitle with icon caution
		else
			if passwordOnly then
				set end of inputValues to {serviceKey & "_LOGIN_REQUEST", localAddress & tab & localLogin & ":" & localPassword}
			else
				set end of inputValues to {serviceKey & "_TOKEN", localLogin & ":" & localPassword}
			end if
			exit repeat
		end if
	end repeat
	set changed to 0
	repeat with pairRef in inputValues
		set {keyName, value} to contents of pairRef
		if saveSecret(keyName, value) is "saved" then
			set changed to changed + 1
		else
			display dialog "Не удалось сохранить параметр." buttons {"Закрыть"} default button 1 with title appTitle with icon caution
		end if
	end repeat
	return changed
end editConnection

on setupIntegrations()
	set selectedRows to {}
	set allRows to {}
	set titles to {}
	set descs to {}
	set flags to {}
	repeat with rowText in paragraphs of ctlRun("systems")
		if (rowText as text) is not "" then
			set p to splitText(rowText as text, "|")
			set showRow to true
			if (count of p) ≥ 7 then
				if item 7 of p is not "internal" then set end of allRows to p
				set showRow to item 7 of p is "secret"
			end if
			if showRow then
				set end of selectedRows to p
				set titleText to item 3 of p
				if item 2 of p is "1" then set titleText to titleText & "   ✓ сохранено"
				set end of titles to titleText
				set end of descs to item 5 of p
				set end of flags to false
			end if
		end if
	end repeat
	set picked to checklist("Какие системы подключить?", "Выберите системы. Данные доступа и параметры каждой системы откроются в отдельном окне.", titles, descs, flags, "Далее", "Пропустить")
	if picked is false then return 0
	set saved to 0
	repeat with i from 1 to count of selectedRows
		if item i of picked then
			set p to item i of selectedRows
			set keyName to item 1 of p
			set serviceName to item 3 of p
			if (count of p) ≥ 7 then
				set serviceKey to item 1 of splitText(keyName, "_")
				set keyPrefix to serviceKey & "_"
				set groupRows to {}
				repeat with rowRef in allRows
					if (item 1 of rowRef) starts with keyPrefix then set end of groupRows to contents of rowRef
				end repeat
				set saved to saved + editConnection(serviceName, serviceKey, groupRows)
			else
				set pageURL to ""
				if (count of p) ≥ 6 then set pageURL to item 6 of p
				set tok to askSecret(serviceName, (item 4 of p) & ". Значение в поле скрыто.", "Пропустить", pageURL)
				if tok is not "" then
					set res to saveSecret(keyName, tok)
					if res is "invalid" then
						display dialog "Это не похоже на ключ Langfuse. Нужна строка вида pk-lf-…:sk-lf-…." buttons {"Понятно"} default button 1 with title appTitle with icon caution
					else if res is "failed" then
						display dialog "Не удалось сохранить параметр." buttons {"Закрыть"} default button 1 with title appTitle with icon caution
					else
						set saved to saved + 1
						if keyName is "LANGFUSE_KEYS" then askTracingContent()
					end if
				end if
			end if
		end if
	end repeat
	return saved
end setupIntegrations

-- Установка в фоне с окном прогресса. true — успешно.
on runInstall()
	do shell script "/bin/bash " & quoted form of ctl & " install > /dev/null 2>&1 &"
	set progress total steps to 5
	set progress completed steps to 0
	set progress description to "Устанавливаю помощника…"
	set progress additional description to "Это займёт 5–10 минут. Окно можно не закрывать."
	delay 2
	repeat
		set p to splitText(ctlRun("progress"), "|")
		set progress total steps to (item 2 of p) as integer
		set progress completed steps to ((item 1 of p) as integer) - 1
		set progress additional description to item 3 of p
		if item 4 of p is "done" then
			set progress completed steps to (item 2 of p) as integer
			return true
		else if item 4 of p is "failed" then
			display dialog "Установка не завершилась." & return & return & (item 3 of p) & return & return & "Запустите приложение ещё раз — установка продолжится с того же места." buttons {"Закрыть"} default button 1 with title appTitle with icon stop
			return false
		end if
		delay 2
	end repeat
end runInstall

on firstRun()
	display dialog "Установим ИИ-помощника на этот Mac." & return & return & "Понадобятся: подключённый VPN (FortiClient или NetBird) и токен доступа к нейросети (sk-…). Токены Jira, Confluence, Tag и GitLab можно добавить сейчас или позже." & return & return & "Будут скачаны приложение Goose и модель поиска — около 350 МБ, 5–10 минут." buttons {"Отмена", "Продолжить"} default button 2 with title appTitle
	set stateText to ctlRun("state")
	if stateText contains "LLM_API_KEY=1" then
		if not checkLLM() then
			if not setupLLM() then return
		end if
	else
		if not setupLLM() then return
	end if
	setupIntegrations()
	if runInstall() then
		ctlRun("mark-configured")
		set authResult to ctlRun("install-auth")
		if authResult is not "" then set authResult to return & return & authResult
		display dialog "Помощник установлен." & authResult & return & return & "Он открывается этим же приложением. Настройки (подключить системы, выбрать инструменты, проверить подключения, обновить) открываются кнопкой «Настройки…» в окне при запуске или запуском с зажатой клавишей ⌥ Option." buttons {"Открыть помощника"} default button 1 with title appTitle
		ctlRun("launch")
	end if
end firstRun

on chooseTools()
	set names to {}
	set titles to {}
	set descs to {}
	set flags to {}
	repeat with r in paragraphs of ctlRun("tools")
		if (r as text) is not "" then
			set p to splitText(r as text, "|")
			set end of names to item 1 of p
			set end of titles to item 3 of p
			set end of descs to item 4 of p
			set end of flags to (item 2 of p is "1")
		end if
	end repeat
	set picked to checklist("Какие инструменты включить?", "Каждый включённый инструмент занимает «память» нейросети в каждом запросе, поэтому включайте только нужные — ответы будут быстрее и точнее. Изменить выбор можно в любой момент.", titles, descs, flags, "Сохранить", "Отмена")
	if picked is false then return
	set chosen to {}
	repeat with i from 1 to count of names
		if item i of picked then set end of chosen to item i of names
	end repeat
	ctlRun("tools-set " & quoted form of joinText(chosen, ","))
	display dialog "Сохранено. Изменения применятся в новом чате Goose." buttons {"Хорошо"} default button 1 with title appTitle
end chooseTools

on settingsMenu()
	set menuItems to {"Открыть помощника", "Подключить системы: Jira, Confluence, Tag, GitLab…", "Активные инструменты", "Проверка подключений", "Сменить токен нейросети", "Обновить помощника", "Открыть папку помощника"}
	repeat
		set picked to choose from list menuItems with title appTitle with prompt "Настройки помощника" OK button name "Выбрать" cancel button name "Закрыть"
		if picked is false then return
		set choice to item 1 of picked
		if choice is item 1 of menuItems then
			ctlRun("launch")
			return
		else if choice is item 2 of menuItems then
			if setupIntegrations() > 0 then
				set applyResult to ctlRun("apply")
				if applyResult is "ok" then set applyResult to "Настройки сохранены. Откройте новый чат Goose."
				if applyResult is "failed" then set applyResult to "Не удалось применить настройки. Запустите проверку подключений."
				if applyResult starts with ("ok" & linefeed) then set applyResult to text 4 thru -1 of applyResult
				display dialog applyResult buttons {"Хорошо"} default button 1 with title appTitle
			end if
		else if choice is item 3 of menuItems then
			chooseTools()
		else if choice is item 4 of menuItems then
			display dialog ctlRun("diagnose") buttons {"Закрыть"} default button 1 with title appTitle
		else if choice is item 5 of menuItems then
			if setupLLM() then
				ctlRun("apply")
				display dialog "Токен сохранён." buttons {"Хорошо"} default button 1 with title appTitle
			end if
		else if choice is item 6 of menuItems then
			set progress total steps to -1
			set progress description to "Обновляю помощника…"
			set progress additional description to "Скачиваю свежую версию, это может занять несколько минут."
			try
				set res to ctlRun("update")
			on error e
				set res to e
			end try
			display dialog res buttons {"Закрыть"} default button 1 with title appTitle
		else if choice is item 7 of menuItems then
			set stateText to ctlRun("state")
			repeat with l in paragraphs of stateText
				if (l as text) starts with "ROOT=" then do shell script "open " & quoted form of (text 6 thru -1 of (l as text))
			end repeat
		end if
	end repeat
end settingsMenu

on run
	set ctl to POSIX path of (path to resource "launcher.sh")
	tell me to activate
	try
		set stateText to ctlRun("state")
		if stateText contains "UPDATE_PENDING=1" and stateText contains "LLM_API_KEY=1" then
			if not runInstall() then return
			set stateText to ctlRun("state")
		end if
		if stateText contains "INSTALLED=1" and stateText contains "LLM_API_KEY=1" then
			if stateText contains "CONFIGURED=0" then
				-- помощник установлен, но настройки ни разу не открывались: показываем их один раз
				ctlRun("mark-configured")
				settingsMenu()
			else if optionDown() then
				settingsMenu()
			else
				-- окно на launchDelay секунд: можно нажать «Настройки…» или «Запустить»; без нажатия открываем Goose
				set r to display dialog "Открываю помощника…" buttons {"Настройки…", "Запустить"} default button 2 with title appTitle giving up after launchDelay
				if button returned of r is "Настройки…" then
					settingsMenu()
				else
					ctlRun("launch")
				end if
			end if
		else
			firstRun()
		end if
	on error e number n
		if n is not -128 then display dialog "Ошибка: " & e buttons {"Закрыть"} default button 1 with title appTitle with icon stop
	end try
end run
