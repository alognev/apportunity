-- «ИИ-помощник»: оболочка над локальным помощником. Первый запуск — установка с вопросами в окнах.
-- Дальше при запуске две секунды показывается окно с кнопками «Настройки…» и «Запустить»; без нажатия
-- открывается Goose. Если запустить приложение с зажатой ⌥ Option — сразу открываются настройки.
-- Если настройки ещё ни разу не показывались (помощник ставили из Терминала), они откроются один раз сами. Вся работа — в app/agentctl.sh (через launcher.sh из ресурсов приложения).
use AppleScript version "2.4"
use framework "AppKit"
use scripting additions

property appTitle : "ИИ-помощник"
property launchDelay : 2
global ctl

-- Зажата ли клавиша ⌥ Option прямо сейчас
on optionDown()
	set flags to (current application's NSEvent's modifierFlags()) as integer
	return ((flags div 524288) mod 2) is 1
end optionDown

on ctlRun(args)
	return do shell script "/bin/bash " & quoted form of ctl & " " & args
end ctlRun

on splitText(t, d)
	set oldD to AppleScript's text item delimiters
	set AppleScript's text item delimiters to d
	set parts to text items of t
	set AppleScript's text item delimiters to oldD
	return parts
end splitText

on joinText(l, d)
	set oldD to AppleScript's text item delimiters
	set AppleScript's text item delimiters to d
	set t to l as text
	set AppleScript's text item delimiters to oldD
	return t
end joinText

-- Секрет не попадает в командную строку: пишем его в файл с правами 600, agentctl читает и удаляет файл
on saveSecret(key, value)
	set f to ctlRun("secret-file")
	set fh to open for access (POSIX file f) with write permission
	try
		set eof fh to 0
		write value to fh as «class utf8»
		close access fh
	on error e
		close access fh
		error e
	end try
	return ctlRun("set " & key & " " & quoted form of f)
end saveSecret

on askSecret(prompt, skipLabel)
	set r to display dialog prompt default answer "" with hidden answer buttons {skipLabel, "Сохранить"} default button 2 with title appTitle
	if button returned of r is skipLabel then return ""
	return text returned of r
end askSecret

-- Токен LLM: спросить, сохранить, проверить. true — токен принят.
on setupLLM()
	repeat
		set tok to askSecret("Вставьте токен доступа к нейросети (вид sk-…). Его выдаёт ответственный за Magnit Copilot." & return & return & "Токен при вставке не отображается — так задумано.", "Отмена")
		if tok is "" then return false
		saveSecret("LLM_API_KEY", tok)
		if checkLLM() then return true
	end repeat
end setupLLM

on checkLLM()
	repeat
		set res to ctlRun("check-llm")
		if res is "ok" then return true
		if res is "auth" then
			display dialog "Токен не принят. Проверьте, что он скопирован целиком, и вставьте ещё раз." buttons {"Продолжить"} default button 1 with title appTitle with icon caution
			return false
		else if res is "cert" then
			set r to display dialog "Этот Mac не доверяет корпоративным сертификатам (так бывает на личных компьютерах)." & return & return & "Добавить их в доверенные? macOS попросит пароль от Mac — дважды." buttons {"Отмена", "Добавить"} default button 2 with title appTitle with icon caution
			if button returned of r is "Отмена" then error number -128
			try
				ctlRun("install-certs")
			on error
				display dialog "Сертификаты не добавлены. Установите их вручную: файл ИНСТРУКЦИЯ.md, шаг 3.5а." buttons {"Закрыть"} default button 1 with title appTitle with icon stop
				error number -128
			end try
		else
			set r to display dialog "Нет связи с корпоративной нейросетью." & return & return & "Проверьте, что VPN NetBird подключён (значок рядом с часами), и повторите." buttons {"Отмена", "Повторить"} default button 2 with title appTitle with icon caution
			if button returned of r is "Отмена" then error number -128
		end if
	end repeat
end checkLLM

-- Корпоративные системы: каждую можно пропустить
on setupIntegrations()
	set keys to {"JIRA_TOKEN", "CONFLUENCE_EPORTAL_TOKEN", "JIRA_IT_TOKEN", "CONFLUENCE_IT_TOKEN", "TAG_WEBHOOK_URL", "GITLAB_TOKEN", "GITLAB_PLATFORM_TOKEN", "MAGNITGPT_API_KEY"}
	set titles to {"Jira — track.magnit.ru", "Confluence — eportal.magnit.ru", "Jira IT — jira.corp.tander.ru", "Confluence — IT-портал", "Tag — личный вебхук", "GitLab — coderepo.corp.tander.ru", "GitLab — gitlab.platform.corp", "MagnitGPT"}
	set hints to {"track.magnit.ru → аватар → Профиль → Личные маркеры доступа → Создать маркер", "eportal.magnit.ru → аватар → Настройки → Маркеры → Личные маркеры доступа", "jira.corp.tander.ru → аватар → Профиль → Личные маркеры доступа", "it-portal.corp.tander.ru → аватар → Настройки → Маркеры → Личные маркеры доступа", "Tag → меню → Интеграции → Входящие вебхуки → Добавить. Вставьте ссылку вида https://tag.magnit.ru/hooks/…", "coderepo.corp.tander.ru → аватар → Preferences → Access tokens → Add new token (scope api)", "gitlab.platform.corp → аватар → Preferences → Access tokens → Add new token (scope api)", "gpt.ai.corp.tander.ru → Настройки → Аккаунт → API-ключи"}
	set stateText to ctlRun("state")
	set shown to {}
	repeat with i from 1 to count of keys
		if stateText contains ((item i of keys) & "=1") then
			set end of shown to (item i of titles) & "  ✓ подключено"
		else
			set end of shown to item i of titles
		end if
	end repeat
	set picked to choose from list shown with title appTitle with prompt "Какие системы подключить? Отметьте нужные (⌘ — несколько). Для каждой понадобится личный токен; любую можно пропустить и подключить позже." OK button name "Далее" cancel button name "Пропустить" with multiple selections allowed and empty selection allowed
	if picked is false then return 0
	set saved to 0
	repeat with p in picked
		repeat with i from 1 to count of keys
			if (p as text) starts with (item i of titles) then
				set tok to askSecret((item i of titles) & return & return & "Где взять: " & (item i of hints) & return & return & "Вставьте токен (при вставке не отображается):", "Пропустить")
				if tok is not "" then
					saveSecret(item i of keys, tok)
					set saved to saved + 1
				end if
			end if
		end repeat
	end repeat
	return saved
end setupIntegrations

-- Установка в фоне с окном прогресса. true — успешно.
on runInstall()
	do shell script "/bin/bash " & quoted form of ctl & " install > /dev/null 2>&1 &"
	set progress total steps to 5
	set progress completed steps to 0
	set progress description to "Устанавливаю помощника…"
	set progress additional description to "Это займёт 5–10 минут. Окно можно не закрывать."
	delay 2
	repeat
		set p to splitText(ctlRun("progress"), "|")
		set progress total steps to (item 2 of p) as integer
		set progress completed steps to ((item 1 of p) as integer) - 1
		set progress additional description to item 3 of p
		if item 4 of p is "done" then
			set progress completed steps to (item 2 of p) as integer
			return true
		else if item 4 of p is "failed" then
			display dialog "Установка не завершилась." & return & return & (item 3 of p) & return & return & "Запустите приложение ещё раз — установка продолжится с того же места." buttons {"Закрыть"} default button 1 with title appTitle with icon stop
			return false
		end if
		delay 2
	end repeat
end runInstall

on firstRun()
	display dialog "Установим ИИ-помощника на этот Mac." & return & return & "Понадобятся: подключённый VPN NetBird и токен доступа к нейросети (sk-…). Токены Jira, Confluence, Tag и GitLab можно добавить сейчас или позже." & return & return & "Будут скачаны приложение Goose и модель поиска — около 350 МБ, 5–10 минут." buttons {"Отмена", "Продолжить"} default button 2 with title appTitle
	set stateText to ctlRun("state")
	if stateText contains "LLM_API_KEY=1" then
		if not checkLLM() then
			if not setupLLM() then return
		end if
	else
		if not setupLLM() then return
	end if
	setupIntegrations()
	if runInstall() then
		ctlRun("mark-configured")
		display dialog "Помощник установлен." & return & return & "Он открывается этим же приложением. Настройки (подключить системы, выбрать инструменты, проверить подключения, обновить) открываются кнопкой «Настройки…» в окне при запуске или запуском с зажатой клавишей ⌥ Option." buttons {"Открыть помощника"} default button 1 with title appTitle
		ctlRun("launch")
	end if
end firstRun

on chooseTools()
	set rows to paragraphs of ctlRun("tools")
	set names to {}
	set shown to {}
	set preselected to {}
	repeat with r in rows
		if (r as text) is not "" then
			set p to splitText(r as text, "|")
			set end of names to item 1 of p
			set end of shown to item 3 of p
			if item 2 of p is "1" then set end of preselected to item 3 of p
		end if
	end repeat
	set picked to choose from list shown with title appTitle with prompt "Какие инструменты оставить активными? Выключенные не занимают «память» нейросети — ответы быстрее и точнее. (⌘ — выбрать несколько)" default items preselected OK button name "Сохранить" cancel button name "Отмена" with multiple selections allowed and empty selection allowed
	if picked is false then return
	set chosen to {}
	repeat with i from 1 to count of shown
		if picked contains (item i of shown) then set end of chosen to item i of names
	end repeat
	ctlRun("tools-set " & quoted form of joinText(chosen, ","))
	display dialog "Сохранено. Изменения применятся в новом чате Goose." buttons {"Хорошо"} default button 1 with title appTitle
end chooseTools

on settingsMenu()
	set menuItems to {"Открыть помощника", "Подключить системы: Jira, Confluence, Tag, GitLab…", "Активные инструменты", "Проверка подключений", "Сменить токен нейросети", "Обновить помощника", "Открыть папку помощника"}
	repeat
		set picked to choose from list menuItems with title appTitle with prompt "Настройки помощника" OK button name "Выбрать" cancel button name "Закрыть"
		if picked is false then return
		set choice to item 1 of picked
		if choice is item 1 of menuItems then
			ctlRun("launch")
			return
		else if choice is item 2 of menuItems then
			if setupIntegrations() > 0 then
				ctlRun("apply")
				display dialog "Токены сохранены. Новые системы появятся в новом чате Goose." buttons {"Хорошо"} default button 1 with title appTitle
			end if
		else if choice is item 3 of menuItems then
			chooseTools()
		else if choice is item 4 of menuItems then
			display dialog ctlRun("diagnose") buttons {"Закрыть"} default button 1 with title appTitle
		else if choice is item 5 of menuItems then
			if setupLLM() then
				ctlRun("apply")
				display dialog "Токен сохранён." buttons {"Хорошо"} default button 1 with title appTitle
			end if
		else if choice is item 6 of menuItems then
			set progress total steps to -1
			set progress description to "Обновляю помощника…"
			set progress additional description to "Скачиваю свежую версию, это может занять несколько минут."
			try
				set res to ctlRun("update")
			on error e
				set res to e
			end try
			display dialog res buttons {"Закрыть"} default button 1 with title appTitle
		else if choice is item 7 of menuItems then
			set stateText to ctlRun("state")
			repeat with l in paragraphs of stateText
				if (l as text) starts with "ROOT=" then do shell script "open " & quoted form of (text 6 thru -1 of (l as text))
			end repeat
		end if
	end repeat
end settingsMenu

on run
	set ctl to POSIX path of (path to resource "launcher.sh")
	tell me to activate
	try
		set stateText to ctlRun("state")
		if stateText contains "INSTALLED=1" and stateText contains "LLM_API_KEY=1" then
			if stateText contains "CONFIGURED=0" then
				-- помощник установлен, но настройки ни разу не открывались: показываем их один раз
				ctlRun("mark-configured")
				settingsMenu()
			else if optionDown() then
				settingsMenu()
			else
				-- окно на launchDelay секунд: можно нажать «Настройки…» или «Запустить»; без нажатия открываем Goose
				set r to display dialog "Открываю помощника…" buttons {"Настройки…", "Запустить"} default button 2 with title appTitle giving up after launchDelay
				if button returned of r is "Настройки…" then
					settingsMenu()
				else
					ctlRun("launch")
				end if
			end if
		else
			firstRun()
		end if
	on error e number n
		if n is not -128 then display dialog "Ошибка: " & e buttons {"Закрыть"} default button 1 with title appTitle with icon stop
	end try
end run
