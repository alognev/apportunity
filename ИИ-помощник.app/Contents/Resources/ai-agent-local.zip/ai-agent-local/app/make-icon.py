"""Значок приложения «ИИ-помощник»: логотип на тёмной «скруглённой» подложке по сетке значков macOS
(иначе macOS 26 кладёт круглый логотип в серую плашку). Запуск из корня проекта:
  shared/.venv/bin/python app/make-icon.py [логотип.png]   → app/AppIcon.icns
"""
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
LOGO = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "logo-final" / "dev" / "mk-dev-dark.png"
S, INSET, RADIUS = 1024, 100, 185  # поле 824×824 со скруглением, как у стандартных значков macOS

canvas = Image.new("RGBA", (S, S), (0, 0, 0, 0))
mask = Image.new("L", (S, S), 0)
ImageDraw.Draw(mask).rounded_rectangle([INSET, INSET, S - INSET, S - INSET], RADIUS, fill=255)
canvas.paste(Image.new("RGBA", (S, S), (26, 20, 24, 255)), (0, 0), mask)
side = S - 2 * INSET - 60
logo = Image.open(LOGO).convert("RGBA").resize((side, side), Image.LANCZOS)
canvas.alpha_composite(logo, ((S - side) // 2, (S - side) // 2))

with tempfile.TemporaryDirectory() as tmp:
    iconset = Path(tmp) / "AppIcon.iconset"
    iconset.mkdir()
    for size in (16, 32, 128, 256, 512):
        canvas.resize((size, size), Image.LANCZOS).save(iconset / f"icon_{size}x{size}.png")
        canvas.resize((size * 2, size * 2), Image.LANCZOS).save(iconset / f"icon_{size}x{size}@2x.png")
    subprocess.run(["iconutil", "-c", "icns", str(iconset), "-o", str(ROOT / "app" / "AppIcon.icns")], check=True)
print(ROOT / "app" / "AppIcon.icns")
