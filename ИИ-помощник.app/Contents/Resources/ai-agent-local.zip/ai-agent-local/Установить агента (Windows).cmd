@echo off
rem Windows: double-click to install or reconfigure the assistant (no administrator rights needed).
if not exist "%~dp0windows\setup.ps1" goto nozip
rem With arguments (-Tools, -Reconfigure) - text mode in this console, as before.
if not "%~1"=="" goto text
rem Installer window; if windows cannot open on this computer, setup-gui.ps1 starts the text mode itself.
rem conhost --headless: PowerShell without a console window (Windows Terminal would show an empty one).
start "" conhost.exe --headless powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0windows\setup-gui.ps1"
exit /b

:text
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\setup.ps1" %*
echo.
pause
exit /b

:nozip
rem Started from inside the zip (Explorer) or a broken copy. UTF-8 text below is read only after chcp.
chcp 65001 >nul
echo Сначала распакуйте архив: правый щелчок по ai-agent-local.zip — «Извлечь всё…»,
echo затем запустите этот файл из распакованной папки ai-agent-local.
echo.
pause
exit /b 1
