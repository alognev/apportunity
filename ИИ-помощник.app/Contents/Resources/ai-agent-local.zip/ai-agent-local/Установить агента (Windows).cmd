@echo off
rem Windows: double-click to install or reconfigure the assistant (no administrator rights needed).
if not exist "%~dp0windows\setup.ps1" goto nozip
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\setup.ps1" %*
echo.
pause
exit /b

:nozip
rem Started from inside the zip (Explorer) or a broken copy. UTF-8 text below is read only after chcp.
chcp 65001 >nul
echo Сначала распакуйте архив: правый щелчок по ai-agent-local.zip — «Извлечь всё…»,
echo затем запустите этот файл из распакованной папки ai-agent-local.
echo.
pause
exit /b 1
