#!/usr/bin/env bash
# Первичная настройка: подключение к LLM (.env), проверка доступа, установка агентов.
#   ./setup.sh              — интерактивно
#   ./setup.sh a b c        — установить выбранных агентов (a, b, c)
#   ./setup.sh --reconfigure — заново ввести хост, токен и модель
#   ./setup.sh --tools       — только выбрать активные инструменты (интеграции)
#   ./setup.sh --databases   — подключить базы данных (DBHub, только чтение)
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV="$ROOT/.env"
B=$'\033[1m'; G=$'\033[32m'; Y=$'\033[33m'; R=$'\033[31m'; N=$'\033[0m'

# Снять карантин macOS со скачанной папки: иначе Finder не запускает .command («файл повреждён»)
xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null || true

[[ "$(uname)" == "Darwin" ]] || echo "${Y}Скрипты рассчитаны на macOS; на Linux большая часть тоже работает.${N}"

# Python для служебных скриптов: заданный установщиком (MAGNIT_PYTHON), уже созданное окружение помощника или системный.
# /usr/bin/python3 без Xcode Command Line Tools — заглушка, которая открывает окно установки; её не трогаем.
pick_python() {
  local py
  [[ -n "${MAGNIT_PYTHON:-}" && -x "${MAGNIT_PYTHON}" ]] && { echo "$MAGNIT_PYTHON"; return; }
  [[ -x "$ROOT/shared/.venv/bin/python" ]] && { echo "$ROOT/shared/.venv/bin/python"; return; }
  for py in python3.13 python3.12 python3.11 python3; do
    py="$(command -v "$py" 2>/dev/null)" || continue
    [[ "$py" == /usr/bin/python3 ]] && ! xcode-select -p >/dev/null 2>&1 && continue
    "$py" -c 'import sys; sys.exit(sys.version_info < (3, 11))' 2>/dev/null && { echo "$py"; return; }
  done
}
PYBIN="$(pick_python || true)"
[[ -n "$PYBIN" ]] || { echo "${R}Нужен Python 3.11+${N} (ИНСТРУКЦИЯ, шаг 3.4) — или установите помощника одной командой (раздел 3)."; exit 1; }
has_goose() { command -v goose >/dev/null 2>&1 || [[ -d /Applications/Goose.app || -d "$HOME/Applications/Goose.app" ]]; }

get() { grep -E "^$1=" "$ENV" 2>/dev/null | head -1 | cut -d= -f2-; }
set_var() {  # set_var KEY VALUE — заменить или добавить строку в .env
  if grep -qE "^$1=" "$ENV"; then
    local tmp; tmp="$(mktemp)"
    awk -v k="$1" -v v="$2" 'BEGIN{FS=OFS="="} $1==k {print k "=" v; next} {print}' "$ENV" > "$tmp" && mv "$tmp" "$ENV"
  else
    echo "$1=$2" >> "$ENV"
  fi
}

# ---------- 1. Настройки подключения ----------
AGENTS=()
RECONF=0
TOOLS_ONLY=0
DB_ONLY=0
for a in "$@"; do
  case "$a" in
    --reconfigure) RECONF=1 ;;
    --tools) TOOLS_ONLY=1 ;;
    --databases) DB_ONLY=1 ;;
    a|b|c|A|B|C) AGENTS+=("$(echo "$a" | tr 'ABC' 'abc')") ;;
    *) echo "Неизвестный аргумент: $a" >&2; exit 1 ;;
  esac
done

if [[ ! -f "$ENV" ]]; then cp "$ROOT/.env.example" "$ENV"; RECONF=1; fi
chmod 600 "$ENV"

choose_tools() {  # выбор активных интеграций + применение к Goose, если он установлен
  echo
  "$PYBIN" "$ROOT/shared/choose_integrations.py"
  if has_goose && [[ -x "$ROOT/shared/.venv/bin/python" ]]; then
    "$ROOT/shared/.venv/bin/python" "$ROOT/agent-b-goose/configure.py" | grep -A20 "^Интеграции" || true
  fi
}
setup_databases() {  # DBHub: Node.js, сам DBHub, список баз databases.toml, включение
  echo; echo "${B}Базы данных (DBHub): помощник только читает данные (SELECT), изменить их не может.${N}"
  if ! command -v node >/dev/null 2>&1; then
    command -v brew >/dev/null 2>&1 || { echo "${R}Нужен Homebrew (шаг 3.3 инструкции)${N}"; return 0; }
    echo "  Устанавливаю Node.js..."; brew install node >/dev/null || { echo "${R}Не удалось установить Node.js${N}"; return 0; }
  fi
  if [[ ! -x "$ROOT/shared/.dbhub/node_modules/.bin/dbhub" ]]; then
    echo "  Устанавливаю DBHub..."; mkdir -p "$ROOT/shared/.dbhub"
    npm install --prefix "$ROOT/shared/.dbhub" --silent @bytebase/dbhub@latest >/dev/null 2>&1 || { echo "${R}Не удалось установить DBHub${N}"; return 0; }
  fi
  local DB="$ROOT/databases.toml"
  [[ -f "$DB" ]] || printf '# Список баз данных для DBHub (только чтение). Личный файл с паролями.\n' > "$DB"
  chmod 600 "$DB"
  echo "  Уже подключены: $(grep -oE '^id *= *"[^"]+"' "$DB" | sed -E 's/.*"(.*)"/\1/' | tr '\n' ' ')"
  echo "  Формат строки подключения: postgres://логин:пароль@сервер:5432/база?sslmode=require (также mysql://, sqlserver://, sqlite:///…)"
  while true; do
    read -r -p "  Короткое имя новой базы (латиница; Enter — закончить): " id
    [[ -z "$id" ]] && break
    read -r -s -p "  Строка подключения (не отображается при вводе): " dsn; echo
    [[ -z "$dsn" ]] && continue
    DB_FILE="$DB" DB_ID="$id" DB_DSN="$dsn" "$PYBIN" "$ROOT/shared/add_database.py"
    echo "  ${G}База «$id» добавлена.${N}"
  done
  if grep -q '^\[\[sources\]\]' "$DB"; then
    "$PYBIN" -c "import sys; sys.path.insert(0, '$ROOT/shared'); import mcp_registry as r; e=r.load_env(); r.save_selection(r.enabled(e) + ['dbhub'])"
    echo "  ${G}DBHub включён.${N} Список баз: $DB"
  fi
}

if [[ $DB_ONLY == 1 ]]; then
  setup_databases
  has_goose && [[ -x "$ROOT/shared/.venv/bin/python" ]] && "$ROOT/shared/.venv/bin/python" "$ROOT/agent-b-goose/configure.py" >/dev/null
  echo; echo "${G}Готово.${N} Изменения применятся в новой сессии помощника."
  exit 0
fi
if [[ $TOOLS_ONLY == 1 ]]; then
  choose_tools
  echo; echo "${G}Готово.${N} Изменения применятся в новой сессии помощника (новый чат или перезапуск)."
  exit 0
fi
[[ -z "$(get LLM_API_KEY)" ]] && RECONF=1

if [[ $RECONF == 1 ]]; then
  echo "${B}Подключение к корпоративной LLM${N} (Enter — оставить значение в скобках)"
  # MAGNIT_QUICK=1 (установка одной командой): адрес и модель — стандартные, спрашиваем только токен
  if [[ "${MAGNIT_QUICK:-0}" != 1 ]]; then
    read -r -p "Адрес шлюза [$(get LLM_BASE_URL)]: " v; [[ -n "$v" ]] && set_var LLM_BASE_URL "${v%/}"
  fi
  read -r -s -p "Токен доступа к LLM (sk-..., при вставке не отображается): " v; echo; [[ -n "$v" ]] && set_var LLM_API_KEY "$v"
  if [[ "${MAGNIT_QUICK:-0}" != 1 ]]; then
    read -r -p "Модель [$(get LLM_MODEL)]: " v; [[ -n "$v" ]] && set_var LLM_MODEL "$v"
  fi
fi

# ---------- 2. Проверка доступа ----------
BASE="$(get LLM_BASE_URL)"; KEY="$(get LLM_API_KEY)"; MODEL="$(get LLM_MODEL)"
fetch_models() {  # 0 — успех; 22 — сервер отказал (токен); 60/35/77 — сертификат; иначе нет связи
  local out rc=0 code
  out="$(mktemp)"
  code="$(curl -s -m 15 -o "$out" -w '%{http_code}' -H "Authorization: Bearer $KEY" "${BASE%/}/v1/models")" || rc=$?
  MODELS="$(cat "$out")"; rm -f "$out"
  [[ $rc == 60 || $rc == 35 || $rc == 77 ]] && return $rc
  [[ "$code" == 200 ]] && return 0
  [[ "$code" == 401 || "$code" == 403 ]] && return 22
  return 1
}

# Mac без корпоративного корневого сертификата (личный компьютер) не доверяет внутренним сайтам: curl выходит с кодом 60.
# Сертификаты TANDER (ROOT, CORP) и platform.corp (ca, intermediate) лежат в shared/certs — ставим в связку ключей пользователя с его согласия.
install_corp_ca() {
  local dir="$ROOT/shared/certs" kc="$HOME/Library/Keychains/login.keychain-db" f
  [[ -f "$dir/tander-root-ca.cer" && "$(uname)" == "Darwin" ]] || return 1
  echo "${Y}Этот Mac не доверяет корпоративным сертификатам${N} (обычно так на личных компьютерах)."
  echo "Без них помощник не сможет обращаться к корпоративным системам. Отпечатки SHA-256 корневых сертификатов:"
  for f in "$dir"/*-root-ca.cer; do
    echo "  $(openssl x509 -in "$f" -noout -subject | sed -E 's/.*CN ?= ?([^,/]*).*/\1/'): $(openssl x509 -in "$f" -noout -fingerprint -sha256 | cut -d= -f2)"
  done
  read -r -p "Добавить корпоративные сертификаты в доверенные для вашей учётной записи? [y/N]: " v
  [[ "$v" =~ ^[YyДд] ]] || return 1
  echo "macOS попросит пароль от Mac или Touch ID для каждого корневого сертификата — это подтверждение изменения доверия."
  security add-trusted-cert -r trustRoot -p ssl -k "$kc" "$dir/tander-root-ca.cer" || return 1
  # gitlab.platform.corp подписан отдельным центром сертификации ca.platform.corp
  [[ -f "$dir/platform-root-ca.cer" ]] && { security add-trusted-cert -r trustRoot -p ssl -k "$kc" "$dir/platform-root-ca.cer" || true; }
  for f in "$dir/tander-corp-ca.cer" "$dir/platform-intermediate-ca.cer"; do  # промежуточные: серверы их не присылают
    [[ -f "$f" ]] && { security add-certificates -k "$kc" "$f" 2>/dev/null || true; }
  done
  return 0
}

echo -n "Проверяю доступ к $BASE ... "
RC=0; fetch_models || RC=$?
if [[ $RC == 60 || $RC == 35 || $RC == 77 ]]; then
  echo "${Y}сертификат не принят${N}"
  if install_corp_ca; then
    echo -n "Проверяю доступ к $BASE ... "
    RC=0; fetch_models || RC=$?
  else
    echo "Сертификат не установлен. Установите его вручную (ИНСТРУКЦИЯ, шаг 3.5а) и запустите установку снова."
    exit 1
  fi
fi
# Код 22 — сервер ответил отказом: чаще всего токен введён с ошибкой. Даём ввести его заново.
TRIES=0
while [[ $RC == 22 && -t 0 && $TRIES -lt 3 ]]; do
  TRIES=$((TRIES + 1))
  echo "${Y}токен не принят${N}"
  echo "Проверьте, что токен скопирован целиком (начинается с sk-), и вставьте его ещё раз."
  read -r -s -p "Токен доступа к LLM (при вставке не отображается; Enter — прервать): " v; echo
  [[ -z "$v" ]] && break
  set_var LLM_API_KEY "$v"; KEY="$v"
  echo -n "Проверяю доступ к $BASE ... "
  RC=0; fetch_models || RC=$?
done
if [[ $RC == 22 ]]; then
  echo "${R}токен не принят${N}"
  echo "Сервер отклонил токен LLM. Проверьте токен и запустите: ./setup.sh --reconfigure"
  exit 1
fi
if [[ $RC != 0 ]]; then
  echo "${R}нет ответа${N}"
  echo "Проверьте, что VPN (NetBird) подключён, а адрес и токен верны. Затем: ./setup.sh --reconfigure"
  exit 1
fi
AVAILABLE="$(echo "$MODELS" | "$PYBIN" -c 'import json,sys; print(" ".join(m["id"] for m in json.load(sys.stdin)["data"]))')"
echo "${G}ok${N}"
echo "Доступные модели: $AVAILABLE"
for m in "$MODEL" "$(get LLM_FAST_MODEL)" "$(get LLM_VISION_MODEL)"; do
  [[ " $AVAILABLE " == *" $m "* ]] || echo "${Y}Внимание: модель $m недоступна для вашего токена — поправьте .env${N}"
done

# ---------- 3. Интеграции ----------
ask_token() {  # ask_token KEY "Название" "Где взять"
  local cur; cur="$(get "$1")"
  local state="не задан"; [[ -n "$cur" ]] && state="задан"
  echo "  ${B}$2${N} ($state). $3"
  read -r -s -p "  Токен (Enter — оставить как есть): " v; echo
  [[ -n "$v" ]] && set_var "$1" "$v"
}
INTEG=0
for k in JIRA_TOKEN CONFLUENCE_EPORTAL_TOKEN TAG_BOT_TOKEN; do [[ -z "$(get $k)" ]] && INTEG=1; done
if [[ $RECONF == 1 || $INTEG == 1 ]]; then
  echo
  read -r -p "${B}Подключить корпоративные системы (Jira, Confluence, Tag, MagnitGPT)?${N} [y/N]: " v
  if [[ "$v" =~ ^[yYдД] ]]; then
    ASK_TOOLS=1
    echo "  Jira и Confluence подключаются через облачный MCP AI Lab по вашим личным маркерам"
    echo "  (локальное подключение остаётся резервом и по умолчанию выключено)."
    ask_token JIRA_TOKEN "Jira" "track.magnit.ru → аватар → Профиль → Личные маркеры доступа → Создать маркер"
    ask_token CONFLUENCE_IT_TOKEN "Confluence IT-портал" "it-portal.corp.tander.ru → аватар → Настройки → Маркеры → Личные маркеры доступа"
    ask_token CONFLUENCE_EPORTAL_TOKEN "Confluence eportal" "eportal.magnit.ru → аватар → Настройки → Маркеры → Личные маркеры доступа"
    ask_token JIRA_IT_TOKEN "Jira IT (jira.corp.tander.ru)" "если пользуетесь: аватар → Профиль → Личные маркеры доступа"
    ask_token TAG_WEBHOOK_URL "Вебхук Tag (ваш личный)" "Tag → меню ⋮⋮⋮ → Интеграции → Входящие вебхуки → Добавить; вставьте ссылку https://tag.magnit.ru/hooks/..."
    ask_token TAG_BOT_TOKEN "Бот Tag (необязательно)" "токен бота по заявке в Help (см. ИНСТРУКЦИЯ.md, раздел 3а)"
    [[ -n "$(get TAG_BOT_TOKEN)" && -z "$(get TAG_USER)" ]] && set_var TAG_USER "$(whoami)"
    ask_token GITLAB_TOKEN "GitLab coderepo.corp.tander.ru" "coderepo.corp.tander.ru → аватар → Preferences → Access tokens → Add new token (scope api)"
    ask_token GITLAB_PLATFORM_TOKEN "GitLab gitlab.platform.corp" "gitlab.platform.corp → аватар → Preferences → Access tokens → Add new token (scope api)"
    if [[ -n "$(get GITLAB_TOKEN)$(get GITLAB_PLATFORM_TOKEN)" ]]; then
      read -r -p "  Включить GitLab в помощнике? По умолчанию выключен (~7 тыс. токенов контекста на инстанс) [y/N]: " v
      if [[ "$v" =~ ^[yYдД] ]]; then
        "$PYBIN" -c "import sys; sys.path.insert(0, '$ROOT/shared'); import mcp_registry as r; e=r.load_env(); r.save_selection(r.enabled(e) + [n for n in ('gitlab', 'gitlab-platform') if n in r.available(e)])"
        echo "  GitLab включён."
      fi
    fi
    read -r -p "  Подключить базы данных (DBHub, только чтение)? По умолчанию выключено [y/N]: " v
    [[ "$v" =~ ^[yYдД] ]] && setup_databases
    ask_token MAGNITGPT_API_KEY "MagnitGPT" "gpt.ai.corp.tander.ru → Настройки → Аккаунт → API-ключи (право выдаёт gpt_tander@magnit.ru)"
  fi
fi

# ---------- 3б. Активные инструменты ----------
# Спрашиваем при первой установке, после ввода токенов и при --reconfigure; иначе выбор сохраняется
if [[ -z "$(get ENABLED_INTEGRATIONS)" || $RECONF == 1 || ${ASK_TOOLS:-0} == 1 ]]; then
  echo
  "$PYBIN" "$ROOT/shared/choose_integrations.py"
fi

# ---------- 4. Установка агентов ----------
if [[ ${#AGENTS[@]} -eq 0 ]]; then
  echo
  echo "${B}Какие агенты установить?${N}"
  echo "  b — Goose: приложение Goose (рекомендуем, ставится по умолчанию)"
  echo "  c — веб-помощник в браузере (свой агент на Claude Agent SDK)"
  echo "  a — Claude Code (терминал, для продвинутых)"
  read -r -p "Введите буквы через пробел или нажмите Enter [b]: " v
  read -r -a AGENTS <<< "${v:-b}"
fi
for a in "${AGENTS[@]}"; do
  echo; echo "${B}=== Агент $(echo "$a" | tr abc ABC) ===${N}"
  case "$a" in
    a) "$ROOT/agent-a-claude-code/install.sh" ;;
    b) "$ROOT/agent-b-goose/install.sh" --desktop ;;
    c) "$ROOT/agent-c-agent-sdk/install.sh" ;;
  esac
done
if [[ -x "$ROOT/shared/.venv/bin/python" ]]; then
  echo; "$ROOT/shared/.venv/bin/python" "$ROOT/shared/check_integrations.py"
fi
echo; echo "${G}Готово.${N} Удалённые MCP-серверы подключаются в remote-mcp.json (пример — remote-mcp.example.json)."
