"""Сборка раздачи для пользователей — macOS и Windows из одного архива.

  shared/.venv/bin/python make_dist.py            (macOS; то же делает ./make-dist.sh)
  shared\\.venv\\Scripts\\python.exe make_dist.py  (Windows)

Результат в dist/:
  ai-agent-local.zip        — помощник без личных настроек (.env с токенами), окружений и служебных файлов
  install.sh, install.ps1   — установка одной командой (macOS / Windows): адрес загрузки и SHA-256 архива зашиты
  uninstall.ps1             — удаление на Windows (если папки помощника уже нет)
Инструкции для пользователей — только в docs/instructions (собираются заново при каждой сборке: в них команды
установки с адресом раздачи); в корень архива кладётся «Установка из архива — Windows.html» для окна установщика.
  AI-Assistant.app.zip      — приложение «ИИ-помощник» для macOS (собирается только на Mac; на Windows остаётся прежнее)
Адрес раздачи — DIST_URL или первая строка файла .dist-url; {file} в адресе заменяется именем файла
(GitLab API: …/repository/files/dist%2F{file}/raw?ref=main), иначе имя дописывается через «/».
"""

from __future__ import annotations

import fnmatch
import hashlib
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NAME = "ai-agent-local"
DIST = ROOT / "dist"
OUT = DIST / f"{NAME}.zip"

# Не попадают в архив: личные настройки и секреты, окружения, сборки, документы разработки, шаблоны установщиков
EXCLUDE_TOP = {"dist", "docs", "presentation", "tests", ".githooks", ".git", ".claude", ".obsidian", ".idea", ".vscode", "CLAUDE.md",
               "WORKLOG.md", "install.sh", "gitlab-ext.yaml", ".gitignore", ".gitattributes", "databases.toml",
               "env", "remote-mcp.json"}
EXCLUDE_TOP_GLOBS = [".env*", "env.*", "env *", "databases.toml.*", "logo-*"]
EXCLUDE_ANY = {".venv", ".venv-gateway", ".venv-atlassian", ".dbhub", "__pycache__", ".DS_Store"}
EXCLUDE_PATHS = {"app/AppIcon.icns", "windows/install.ps1"}
KEEP = {".env.example"}
CRLF = (".cmd", ".bat", ".ps1")  # скрипты Windows: cmd.exe с переводами строк LF местами ошибается


def excluded(rel: str) -> bool:
    if rel in KEEP:
        return False
    parts = rel.split("/")
    if parts[0] in EXCLUDE_TOP or any(fnmatch.fnmatch(parts[0], g) for g in EXCLUDE_TOP_GLOBS):
        return True
    return rel in EXCLUDE_PATHS or rel.endswith(".pyc") or any(p in EXCLUDE_ANY for p in parts)


def source_files() -> dict[str, int]:
    """Файлы рабочей копии (как в git: отслеживаемые и новые, без игнорируемых) → режим (0o755 — исполняемый)."""
    out = subprocess.run(["git", "-C", str(ROOT), "ls-files", "-z", "-s", "--cached"], capture_output=True, check=True)
    modes = {}
    for rec in filter(None, out.stdout.decode("utf-8").split("\0")):
        meta, path = rec.split("\t", 1)
        modes[path] = 0o755 if meta.split()[0] == "100755" else 0o644
    out = subprocess.run(["git", "-C", str(ROOT), "ls-files", "-z", "--others", "--exclude-standard"],
                         capture_output=True, check=True)
    for path in filter(None, out.stdout.decode("utf-8").split("\0")):
        modes[path] = 0o755 if os.name != "nt" and os.access(ROOT / path, os.X_OK) else 0o644
    return {p: m for p, m in sorted(modes.items()) if (ROOT / p).is_file() and not excluded(p)}


def url_for(dist_url: str, file: str) -> str:
    return dist_url.replace("{file}", file) if "{file}" in dist_url else f"{dist_url}/{file}"


def install_commands(dist_url: str) -> dict[str, str]:
    """Команды установки для пользователей: macOS (Терминал), macOS-приложение, Windows (PowerShell)."""
    base = dist_url or "__DIST_URL__"
    sh = url_for(base, "install.sh")
    gitlab = "/api/v4/projects/" in dist_url  # закрытый проект GitLab: нужен токен в заголовке

    def windows(file: str, local: str) -> str:  # скачать скрипт PowerShell в %TEMP% и запустить
        head = "[Net.ServicePointManager]::SecurityProtocol='Tls12'; "
        auth = ""
        if gitlab:
            head += "$env:MAGNIT_DIST_TOKEN='ВАШ_ТОКЕН_GITLAB'; "
            auth = "-Headers @{'PRIVATE-TOKEN'=$env:MAGNIT_DIST_TOKEN} "
        return (f"{head}$f=\"$env:TEMP\\{local}\"; Invoke-WebRequest -UseBasicParsing {auth}'{url_for(base, file)}' "
                "-OutFile $f; powershell -NoProfile -ExecutionPolicy Bypass -File $f")

    if gitlab:
        mac = (f'export MAGNIT_DIST_TOKEN=ВАШ_ТОКЕН_GITLAB; bash -c "$(curl -fsSL -H "PRIVATE-TOKEN: $MAGNIT_DIST_TOKEN" '
               f"'{sh}')\"")
    else:
        mac = f"bash -c \"$(curl -fsSL '{sh}')\""
    return {"__INSTALL_COMMAND_APP__": f"export MAGNIT_MODE=app; {mac}", "__INSTALL_COMMAND__": mac,
            "__INSTALL_COMMAND_WINDOWS__": windows("install.ps1", "magnit-install.ps1"),
            "__UNINSTALL_COMMAND_WINDOWS__": windows("uninstall.ps1", "magnit-uninstall.ps1")}


def fill(text: str, values: dict[str, str]) -> str:
    for key in sorted(values, key=len, reverse=True):  # длинные раньше: __INSTALL_COMMAND_APP__ до __INSTALL_COMMAND__
        text = text.replace(key, values[key])
    return text


def crlf(data: bytes) -> bytes:
    return data.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")


def secrets() -> list[tuple[str, str]]:
    """(откуда, значение): значения токенов и ключей из .env, строки подключения и пароли из databases.toml — их не должно быть в архиве."""
    found = []
    env = ROOT / ".env"
    if env.exists():
        for line in env.read_text(encoding="utf-8", errors="ignore").splitlines():
            m = re.match(r"^[A-Z_]*(TOKEN|KEY|SECRET|PASSWORD|WEBHOOK_URL)=(.+)$", line.strip())
            if m and len(m.group(2).strip().strip("\"'")) >= 8:
                found.append((line.split("=", 1)[0], m.group(2).strip().strip("\"'")))
    db = ROOT / "databases.toml"
    if db.exists():
        text = db.read_text(encoding="utf-8", errors="ignore")
        found += [("databases.toml", d) for d in re.findall(r'dsn\s*=\s*"([^"]+)"', text)]
        found += [("databases.toml", p) for p in re.findall(r"://[^:/@]+:([^@]+)@", text) if len(p) >= 4]
    return found


INSTRUCTIONS = ROOT / "docs" / "instructions"
GUIDE = INSTRUCTIONS / "Установка из архива — Windows.html"


def build_guides(dist_url: str) -> Path:
    """Четыре инструкции (docs/instructions/build.py) — с командами для этого адреса раздачи."""
    env = {**os.environ, "DIST_URL": dist_url} if dist_url else dict(os.environ)
    subprocess.run([sys.executable, str(INSTRUCTIONS / "build.py")], check=True, capture_output=True, env=env)
    return GUIDE


def build_archive(version: str, dist_url: str) -> None:
    files = source_files()
    DIST.mkdir(exist_ok=True)
    tmp = OUT.with_suffix(".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        def add(rel: str, data: bytes, mode: int) -> None:
            info = zipfile.ZipInfo(f"{NAME}/{rel}", time.localtime()[:6])
            info.create_system = 3  # Unix: права (исполняемые .sh/.command) сохраняются при распаковке на Mac
            info.external_attr = (stat.S_IFREG | mode) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data)

        for rel, mode in files.items():
            data = (ROOT / rel).read_bytes()
            if rel.lower().endswith(CRLF):
                data = crlf(data)
            add(rel, data, mode)
        add("VERSION", f"{version}\n".encode(), 0o644)
        # Инструкция для пользователей Windows (со снимками) — в корень архива: окно установщика открывает её
        # на разделе текущего шага (…html#key). Собирается из docs/instructions при каждой сборке архива.
        add(GUIDE.name, build_guides(dist_url).read_bytes(), 0o644)
    names = zipfile.ZipFile(tmp).namelist()
    if any(re.search(r"/\.env$|/databases\.toml$", n) for n in names):
        tmp.unlink()
        sys.exit("ОШИБКА: в архив попал .env или databases.toml")
    with zipfile.ZipFile(tmp) as z:
        content = [z.read(n) for n in names]
    for where, secret in secrets():
        if any(secret.encode("utf-8") in c for c in content):
            tmp.unlink()
            sys.exit(f"ОШИБКА: в архиве найден секрет ({where}) — значение не показываю")
    tmp.replace(OUT)
    print(f"Готово: {OUT} ({OUT.stat().st_size / 1e6:.1f} МБ, файлов: {len(names)}, версия {version})")


def build_app(version: str) -> Path | None:
    """Приложение «ИИ-помощник.app» (macOS): оболочка с окнами, архив помощника — внутри."""
    app_zip = DIST / "AI-Assistant.app.zip"
    if sys.platform != "darwin":
        if app_zip.exists():
            print(f"Приложение для macOS не пересобрано (нужен Mac): {app_zip.name} внутри — прежняя версия помощника; "
                  "после обновления пользователи получат новую через «Обновить помощника». Пересоберите на Mac.")
        return app_zip if app_zip.exists() else None
    with tempfile.TemporaryDirectory() as stage:
        subprocess.run([str(ROOT / "app" / "build-app.sh"), str(OUT), version, stage], check=True,
                       stdout=subprocess.DEVNULL)
        app_zip.unlink(missing_ok=True)
        subprocess.run(["ditto", "-c", "-k", "--keepParent", f"{stage}/ИИ-помощник.app", str(app_zip)], check=True)
    print(f"Приложение: {app_zip} ({app_zip.stat().st_size / 1e6:.1f} МБ)")
    return app_zip


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    dist_url = (os.environ.get("DIST_URL") or "").strip()
    if not dist_url and (ROOT / ".dist-url").exists():
        dist_url = (ROOT / ".dist-url").read_text(encoding="utf-8").splitlines()[0].strip()
    dist_url = dist_url.rstrip("/")
    commands = install_commands(dist_url)
    version = time.strftime("%Y%m%d%H%M")
    build_archive(version, dist_url)
    app_zip = build_app(version)
    values = {**commands, "__DIST_URL__": dist_url or "__DIST_URL__", "__SHA256__": sha256(OUT),
              "__APP_SHA256__": sha256(app_zip) if app_zip else "__APP_SHA256__"}
    sh = fill((ROOT / "install.sh").read_text(encoding="utf-8"), values)
    (DIST / "install.sh").write_bytes(sh.encode("utf-8").replace(b"\r\n", b"\n"))
    if os.name != "nt":
        (DIST / "install.sh").chmod(0o755)
    ps1 = fill((ROOT / "windows" / "install.ps1").read_text(encoding="utf-8-sig"), values)
    (DIST / "install.ps1").write_bytes(b"\xef\xbb\xbf" + crlf(ps1.encode("utf-8")))  # PowerShell 5.1: UTF-8 с BOM
    # Удаление — рядом с установщиком: если папки помощника уже нет, его скачивают командой из инструкций для Windows
    (DIST / "uninstall.ps1").write_bytes(crlf((ROOT / "windows" / "uninstall.ps1").read_bytes()))
    if dist_url:
        print("Установщики: dist/install.sh и dist/install.ps1 — выкладывайте вместе с архивом (все файлы dist/ сразу).")
        print("Команды для пользователей (они же — в инструкциях docs/instructions):")
        print(f"  macOS, приложение «ИИ-помощник»:  {commands['__INSTALL_COMMAND_APP__']}")
        print(f"  macOS, Терминал:                  {commands['__INSTALL_COMMAND__']}")
        print(f"  Windows, PowerShell:              {commands['__INSTALL_COMMAND_WINDOWS__']}")
    else:
        print("Установщики собраны БЕЗ адреса загрузки. Задайте адрес: DIST_URL=... или файл .dist-url")


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    shutil.which("git") or sys.exit("Нужен git: список файлов архива берётся из репозитория")
    main()
