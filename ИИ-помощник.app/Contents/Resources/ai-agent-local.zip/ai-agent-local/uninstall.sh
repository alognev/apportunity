#!/usr/bin/env bash
# Полное удаление ИИ-помощника с Mac: приложение, папка помощника с токенами, Goose с настройками и историей,
# модель поиска, автоматизации, Python от установщика. После этого установка пойдёт с нуля.
#   bash uninstall.sh          — спросит подтверждение
#   bash uninstall.sh --yes    — без вопроса
# Не трогает: рабочую папку с вашими файлами (~/magnit-agent-workspace) и корпоративные сертификаты в связке ключей.
# Одинаково в любой оболочке: из sh или zsh — перезапуск в bash (скрипт написан для bash)
if [ -z "${BASH_VERSION:-}" ]; then exec bash "$0" "$@"; fi
set -uo pipefail
# Windows (Git Bash, MSYS, Cygwin): тот же установщик, что по двойному щелчку «… (Windows).cmd», — Windows PowerShell
is_windows() { case "$(uname -s)" in MINGW*|MSYS*|CYGWIN*) return 0 ;; esac; return 1; }
win_ps() {  # win_ps ПУТЬ_К_PS1 [аргументы] — MAGNIT_PS подменяет powershell.exe в проверках
  local script; script="$(cygpath -w "$1" 2>/dev/null || echo "$1")"; shift
  exec "${MAGNIT_PS:-powershell.exe}" -NoProfile -ExecutionPolicy Bypass -File "$script" "$@"
}
if is_windows; then
  ps1="$(cd "$(dirname "$0")" && pwd)/windows/uninstall.ps1"
  [[ -f "$ps1" ]] || { echo "На Windows удаление — «Удалить помощника (Windows)» в папке помощника или «Пуск»."; exit 1; }
  win_args=(); [[ "${1:-}" == "--yes" ]] && win_args=(-Yes)
  win_ps "$ps1" ${win_args[@]+"${win_args[@]}"}
fi

if [[ "${1:-}" != "--yes" ]]; then
  echo "Будут удалены ИИ-помощник, Goose (приложение, настройки, история чатов), токены, модель поиска,"
  echo "базы знаний и автоматизации. Ваши файлы в ~/magnit-agent-workspace останутся."
  read -r -p "Удалить всё? Напечатайте «да»: " v
  [[ "$v" == "да" || "$v" == "yes" ]] || { echo "Отменено."; exit 0; }
fi

echo "Останавливаю Goose и помощника..."
osascript -e 'tell application "Goose" to quit' >/dev/null 2>&1
osascript -e 'tell application "ИИ-помощник" to quit' >/dev/null 2>&1
pkill -f "agent-c-agent-sdk/web.py" 2>/dev/null
pkill -f "shared/gateway" 2>/dev/null
sleep 2

echo "Автоматизации по расписанию..."
for plist in "$HOME"/Library/LaunchAgents/ru.magnit-agent.*.plist; do
  [[ -e "$plist" ]] || continue
  launchctl bootout "gui/$(id -u)" "$plist" 2>/dev/null || launchctl unload "$plist" 2>/dev/null
  rm -f "$plist"
done

launchctl unsetenv OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT 2>/dev/null   # трассировка Langfuse
launchctl unsetenv OTEL_METRICS_EXPORTER 2>/dev/null; launchctl unsetenv OTEL_LOGS_EXPORTER 2>/dev/null

echo "Приложения..."
rm -rf "/Applications/ИИ-помощник.app" "$HOME/Applications/ИИ-помощник.app"
rm -rf "/Applications/Goose.app" "$HOME/Applications/Goose.app"
command -v brew >/dev/null 2>&1 && { brew uninstall --cask block-goose >/dev/null 2>&1; brew uninstall block-goose-cli >/dev/null 2>&1; }

echo "Папка помощника (токены, окружения Python)..."
for d in "$HOME/ai-agent-local" "$HOME/Documents/ai-agent-local"; do
  [[ -f "$d/setup.sh" && ! -d "$d/.git" ]] && rm -rf "${d:?}"   # рабочую копию разработчика (git) не трогаем
done

echo "Данные помощника (модель поиска, базы знаний, журналы, настройки агентов)..."
rm -rf "$HOME/.magnit-agent"

echo "Goose: настройки, история чатов, данные приложения, навыки..."
rm -rf "$HOME/.config/goose" "$HOME/.local/share/goose" "$HOME/.local/state/goose" \
       "$HOME/Library/Application Support/Goose" "$HOME/Library/Logs/Goose" \
       "$HOME/Library/Caches/com.electron.goose" "$HOME/Library/Preferences/com.electron.goose.plist" \
       "$HOME/Library/Saved Application State/com.electron.goose.savedState"
for s in деловое-письмо поиск-в-confluence отчет-по-таблицам задача-в-jira разбор-почты протокол-встречи рутина-по-спеке \n         данные-из-teradata business-letter confluence-research data-report jira-task mail-digest meeting-protocol spec-routine teradata; do
  rm -rf "$HOME/.agents/skills/$s"
done
security delete-generic-password -s goose -a secrets >/dev/null 2>&1   # токен LLM в связке ключей
security delete-generic-password -s magnit-agent-teradata >/dev/null 2>&1  # пароль Teradata

echo "Команды и Python от установщика..."
rm -f "$HOME/.local/bin/magnit-goose" "$HOME/.local/bin/magnit-claude" "$HOME/.local/bin/magnit-agent" "$HOME/.local/bin/goose"
rm -rf "$HOME/.local/share/uv/python"            # Python, который ставил установщик через uv
rm -f "$HOME/.local/bin/uv" "$HOME/.local/bin/uvx"
rm -f /tmp/a.zip

echo
echo "Готово. ИИ-помощник и Goose удалены. Установить заново — командой из инструкции."
echo "Остались: ~/magnit-agent-workspace (ваши файлы) и корпоративные сертификаты в «Связке ключей», если их добавляли."
