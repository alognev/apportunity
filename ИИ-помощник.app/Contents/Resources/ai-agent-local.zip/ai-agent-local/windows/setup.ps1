﻿# ИИ-помощник для Windows: первичная настройка и установка Goose. Права администратора не нужны:
# всё ставится в профиль пользователя (%LOCALAPPDATA%\Programs), ярлыки — в его меню «Пуск».
#   «Установить агента (Windows).cmd»   — двойной щелчок: настройка (повторный запуск — сменить ключ, подключить системы)
#   setup.ps1 -Reconfigure    — заново ввести адрес, ключ и модель
#   setup.ps1 -Tools          — только выбрать активные инструменты
#   setup.ps1 -Quick          — установка одной командой: адрес и модель стандартные, спрашиваем только ключ
#   setup.ps1 -Gui            — запуск из окна установщика (setup-gui.ps1): вопросов в консоли нет, ответы — переменными:
#                               MAGNIT_LLM_API_KEY (новый ключ), MAGNIT_SET_<КЛЮЧ> (токены систем в .env),
#                               MAGNIT_CERTS_CONSENT=1 (согласие добавить корпоративные сертификаты)
# MAGNIT_LLM_API_KEY — ключ Magnit Copilot без вопроса; MAGNIT_DIR — постоянная папка помощника (по умолчанию
# %USERPROFILE%\ai-agent-local: распакованный в другое место архив предлагается перенести туда).
# Файл в UTF-8 с BOM: иначе PowerShell 5.1 читает русский текст в кодировке ANSI.
param([switch]$Reconfigure, [switch]$Tools, [switch]$Quick, [switch]$Gui)
# Одинаково в любой оболочке: из PowerShell 7 (pwsh) — перезапуск в Windows PowerShell 5.1, как по двойному щелчку
if ($PSVersionTable.PSEdition -eq 'Core') {
    $ps51 = Start-Process powershell.exe -NoNewWindow -Wait -PassThru -ArgumentList (@('-NoProfile', '-ExecutionPolicy',
        'Bypass', '-File', "`"$PSCommandPath`"") + @(foreach ($k in $PSBoundParameters.Keys) { "-$k" }))
    exit $ps51.ExitCode
}
$Passed = @(foreach ($k in $PSBoundParameters.Keys) { "-$k" })  # ключи запуска — для перезапуска из другой папки
# Адрес шлюза и модель спрашиваем только при явной перенастройке; при установке (из архива или одной командой) — лишь ключ
$AskAll = $Reconfigure.IsPresent -and -not $Quick
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'  # иначе Invoke-WebRequest в PowerShell 5.1 качает в разы медленнее
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
# Корпоративный прокси, требующий вход («(407) Требуется аутентификация посредника»): передавать ему учётные данные
# пользователя Windows, как это делает браузер
try { [Net.WebRequest]::DefaultWebProxy.Credentials = [Net.CredentialCache]::DefaultNetworkCredentials } catch { }
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)  # вывод Python (UTF-8) через конвейер PowerShell

$Root = Split-Path -Parent $PSScriptRoot
$EnvFile = Join-Path $Root '.env'
# MAGNIT_PROGRAMS — другая папка для программ (проверка установки с нуля, не трогая рабочую)
$Programs = if ($env:MAGNIT_PROGRAMS) { $env:MAGNIT_PROGRAMS } else { Join-Path $env:LOCALAPPDATA 'Programs' }
$UvDir = Join-Path $Programs 'uv'
$Uv = Join-Path $UvDir 'uv.exe'
$GooseHome = Join-Path $Programs 'Goose'
$GooseApp = Join-Path $GooseHome 'dist-windows\Goose.exe'
$GooseCli = Join-Path $GooseHome 'dist-windows\resources\bin\goose.exe'
$Venv = Join-Path $Root 'shared\.venv'
$Py = Join-Path $Venv 'Scripts\python.exe'
# MAGNIT_START_MENU — другая папка для ярлыков (проверка установки в песочнице, не трогая «Пуск»)
$StartMenu = if ($env:MAGNIT_START_MENU) { $env:MAGNIT_START_MENU } else { Join-Path ([Environment]::GetFolderPath('Programs')) 'ИИ-помощник' }

# Версии и контрольные суммы скачиваемых программ (обновлять вместе)
$UvVersion = '0.13.4'
$UvSha256 = 'ccec7508a07d9933d7cb1261880633efcf1f30d6e6eddab21823f1dae6f23225'
$GooseVersion = '1.55.0'
$GooseSha256 = '4a10e547730832afc2fb13d1c3c4e60b0332ce3e49fd3793cb04259206054c0c'

# uv и Python — в профиль пользователя; Python-скрипты помощника — в UTF-8 (иначе cp1251)
$env:UV_PYTHON_INSTALL_DIR = Join-Path $UvDir 'python'
$env:UV_CACHE_DIR = Join-Path $UvDir 'cache'
$env:UV_LINK_MODE = 'copy'
$env:UV_PYTHON_INSTALL_BIN = '0'  # не класть python3.13.exe в ~\.local\bin: помощнику он не нужен
# Корпоративные ноутбуки: трафик в интернет проверяет прокси со своим сертификатом (корень — в хранилище Windows).
# uv по умолчанию доверяет только своему списку центров сертификации («invalid peer certificate: UnknownIssuer»
# на github.com и pypi.org) — пусть берёт сертификаты из Windows, как браузер и PowerShell
$env:UV_SYSTEM_CERTS = '1'
$env:UV_NATIVE_TLS = '1'  # то же для прежних версий uv
$env:HF_HUB_DISABLE_SYMLINKS_WARNING = '1'  # модель поиска: без прав администратора Windows не даёт символьных ссылок — это нормально
$env:PYTHONUTF8 = '1'

# Оформление окна: рамки и линии из псевдографики (есть в шрифтах консоли Consolas/Cascadia), шаги «N из 4»
$Steps = 4
function Say([string]$Text, [string]$Color = 'Gray') { Write-Host $Text -ForegroundColor $Color }
function Title([string]$Text) { Write-Host ''; Write-Host $Text -ForegroundColor White }
function Done { Write-Host '✓' -ForegroundColor Green }
function Fail([string]$Text) {
    Write-Host ''
    Write-Host "  ✗ $Text" -ForegroundColor Red
    Write-Host '  Установка не завершена. Исправьте причину и запустите «Установить агента (Windows)» ещё раз —'
    Write-Host '  уже сделанное повторно не скачивается.'
    exit 1
}
# Любая непредвиденная ошибка — с объяснением, а не молчаливым закрытием окна
trap {
    Fail ("Непредвиденная ошибка: $($_.Exception.Message) Сделайте снимок этого окна (Win + Shift + S) и " +
          'отправьте ответственному за помощника.')
}
# Внешние программы (uv, Python). Windows PowerShell 5.1 при ErrorActionPreference=Stop может превратить их вывод
# в stderr (прогресс, предупреждения) в ошибку PowerShell и оборвать установку без сообщения — запускаем с Continue
# и решаем по коду выхода ($LASTEXITCODE)
# То же, но не дольше $Seconds: зависшую программу (прокси держит соединение, сеть пропала) прерываем — дальше повтор,
# а не бесконечное ожидание. Код выхода — в $LASTEXITCODE (124 — время вышло).
function Run-Timed {
    $seconds = [int]$args[0]
    $exe = $args[1]
    $rest = @($args | Select-Object -Skip 2)
    $line = ($rest | ForEach-Object { $a = [string]$_; if ($a -match '[\s"]' -or -not $a) { '"' + ($a -replace '"', '\"') + '"' } else { $a } }) -join ' '
    $p = Start-Process $exe -ArgumentList $line -NoNewWindow -PassThru
    $null = $p.Handle  # иначе в PowerShell 5.1 код выхода не сохранится
    if (-not $p.WaitForExit($seconds * 1000)) {
        & taskkill.exe /PID $p.Id /T /F 2>&1 | Out-Null
        $limit = if ($seconds -ge 60) { "$([int]($seconds / 60)) мин" } else { "$seconds с" }
        Say "  Не дождался ответа за $limit — прерываю." Yellow
        $global:LASTEXITCODE = 124
        return
    }
    $global:LASTEXITCODE = $p.ExitCode
}
function Run {
    $exe = $args[0]
    $rest = @($args | Select-Object -Skip 1)  # всегда массив: один аргумент-строку «@» разложил бы по буквам
    $ErrorActionPreference = 'Continue'
    & $exe @rest
}
function Box([string[]]$Lines, [string]$Color = 'Cyan') {
    $w = ($Lines | Measure-Object -Property Length -Maximum).Maximum + 4
    Write-Host ''
    Write-Host ('╔' + ('═' * $w) + '╗') -ForegroundColor $Color
    foreach ($l in $Lines) { Write-Host ('║  ' + $l.PadRight($w - 2) + '║') -ForegroundColor $Color }
    Write-Host ('╚' + ('═' * $w) + '╝') -ForegroundColor $Color
}
function Step([int]$N, [string]$Text) {
    $head = "── Шаг $N из $Steps · $Text "
    Write-Host ''
    Write-Host ($head + ('─' * [Math]::Max(3, 72 - $head.Length))) -ForegroundColor Cyan
}

# ---------- .env ----------
function Read-EnvLines { if (Test-Path $EnvFile) { [IO.File]::ReadAllLines($EnvFile, [Text.UTF8Encoding]::new($false)) } else { @() } }
function Get-EnvVar([string]$Key) {
    foreach ($line in Read-EnvLines) { if ($line.StartsWith("$Key=")) { return $line.Substring($Key.Length + 1).Trim() } }
    return ''
}
function Set-EnvVar([string]$Key, [string]$Value) {
    $lines = [Collections.Generic.List[string]]::new()
    $found = $false
    foreach ($line in Read-EnvLines) {
        if ($line.StartsWith("$Key=")) { $lines.Add("$Key=$Value"); $found = $true } else { $lines.Add($line) }
    }
    if (-not $found) { $lines.Add("$Key=$Value") }
    # UTF-8 без BOM и переводы строк LF — как на Mac (python-dotenv не понимает BOM в начале файла)
    [IO.File]::WriteAllText($EnvFile, (($lines -join "`n") + "`n"), [Text.UTF8Encoding]::new($false))
}
function Read-Secret([string]$Prompt) {
    $secure = Read-Host -AsSecureString $Prompt
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr).Trim() }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}
function Ask-Yes([string]$Prompt) {
    if ($Gui) { return $false }  # окно установщика: всё нужное оно спросило само
    return (Read-Host $Prompt) -match '^[yYдД]'
}

# Ключ трассировки Langfuse одной строкой «pk-lf-…:sk-lf-…[@https://адрес]» (как shared/tracing.sh на Mac)
function Import-LangfuseKey([string]$Text) {
    $s = $Text -replace '\s', ''
    if ($s -notmatch '^(pk-lf-[A-Za-z0-9-]+)[:,;]?(sk-lf-[A-Za-z0-9-]+)(@(https?://[^@]+))?$') { return $false }
    Set-EnvVar 'LANGFUSE_PUBLIC_KEY' $Matches[1]
    Set-EnvVar 'LANGFUSE_SECRET_KEY' $Matches[2]
    if ($Matches[4]) { Set-EnvVar 'LANGFUSE_BASE_URL' $Matches[4].TrimEnd('/') }
    elseif (-not (Get-EnvVar 'LANGFUSE_BASE_URL')) { Set-EnvVar 'LANGFUSE_BASE_URL' 'https://langfuse.k8s.dev.plai.corp' }
    # Текст разговоров — только с согласия сотрудника; по умолчанию — без него
    if (-not (Get-EnvVar 'LANGFUSE_CAPTURE_CONTENT')) { Set-EnvVar 'LANGFUSE_CAPTURE_CONTENT' '0' }
    return $true
}

# ---------- скачивание с проверкой контрольной суммы ----------
# ---------- сбои скачивания: повторить, открыть сайт в браузере, продолжить без этой части ----------
# На корпоративных ноутбуках первое обращение к сайту из интернета иногда срывается (прокси проверяет сайт:
# «invalid peer certificate», обрыв соединения), а после открытия сайта в браузере проходит. Поэтому: три попытки
# с паузой, затем — открыть сайт в браузере и попробовать ещё раз. Не вышло — установка продолжается, а в конце
# сказано, что осталось (повторный запуск доделает: скачанное повторно не скачивается).
# Действие сообщает успех кодом $LASTEXITCODE (0 — готово), итог — в $RetryOk. Не через возвращаемое значение:
# тогда вывод uv попал бы в него (не виден на экране, а вместо «да/нет» — строки вывода).
$Problems = [Collections.Generic.List[string]]::new()
$RetryOk = $false
# Сайты, откуда скачиваются Python, библиотеки и модель поиска (в т.ч. адреса, куда они перенаправляют)
$DownloadSites = @('https://releases.astral.sh', 'https://github.com', 'https://release-assets.githubusercontent.com', 'https://objects.githubusercontent.com',
                   'https://pypi.org/simple/', 'https://files.pythonhosted.org', 'https://huggingface.co',
                   'https://cdn-lfs.huggingface.co')
# Обратиться к сайтам из PowerShell — с сертификатами Windows, как браузер. Корпоративный прокси после первого
# обращения к сайту обычно пропускает его и для других программ (раньше для этого открывали сайт в браузере).
function Touch-Sites([string[]]$Sites) {
    foreach ($site in $Sites) {
        try { Invoke-WebRequest -Uri $site -Method Head -UseBasicParsing -TimeoutSec 15 | Out-Null } catch { }
    }
}
function Retry([string]$What, [string[]]$Sites, [scriptblock]$Action, [switch]$Optional) {
    $script:RetryOk = $false
    for ($i = 1; $i -le 3; $i++) {
        & $Action
        if ($LASTEXITCODE -eq 0) { $script:RetryOk = $true; return }
        if ($i -lt 3) {
            Say "  Не получилось: $What. Повторяю через $(5 * $i) с (попытка $($i + 1) из 3)..." Yellow
            Touch-Sites $Sites
            Start-Sleep (5 * $i)
        }
    }
    if (-not $Optional -and $Gui) {  # окно установщика: без ожидания Enter — ещё одна попытка после обращения к сайтам
        Touch-Sites $Sites
        & $Action
        if ($LASTEXITCODE -eq 0) { $script:RetryOk = $true; return }
    } elseif (-not $Optional) {
        Say "  $What — не скачивается. Так бывает на корпоративном ноутбуке, пока сайт не открыт в браузере." Yellow
        Say "  Открываю в браузере: $($Sites -join ', ')" Yellow
        if (-not $env:MAGNIT_NO_BROWSER) { foreach ($site in $Sites) { Start-Process $site } }  # проверки: без браузера
        Read-Host '  Дождитесь, пока страницы загрузятся, и нажмите Enter — попробую ещё раз' | Out-Null
        & $Action
        if ($LASTEXITCODE -eq 0) { $script:RetryOk = $true; return }
    }
    if ($Optional) { Say "  ! $What — пропущено, помощник работает и без этого; повторный запуск установки доделает." Yellow }
    else { $Problems.Add($What); Say "  ✗ $What — не получилось, продолжаю установку без этого." Red }
}
# Скачать файл (PowerShell, сертификаты Windows) и сверить контрольную сумму; успех — $LASTEXITCODE = 0 (для Retry)
function Get-Verified([string]$Url, [string]$OutFile, [string]$Sha256) {
    $global:LASTEXITCODE = 1
    try { Invoke-WebRequest -Uri $Url -OutFile $OutFile -UseBasicParsing -TimeoutSec 1800 }
    catch { Say "  $([IO.Path]::GetFileName($OutFile)): $($_.Exception.Message)" Yellow; return }
    $actual = (Get-FileHash $OutFile -Algorithm SHA256).Hash.ToLower()
    if ($actual -ne $Sha256) { Remove-Item $OutFile -Force; Fail "Контрольная сумма $([IO.Path]::GetFileName($OutFile)) не совпала — файл повреждён или подменён." }
    Unblock-File $OutFile  # снять «Mark of the Web» со скачанного архива
    $global:LASTEXITCODE = 0
}
function Expand-Zip([string]$Zip, [string]$Dest) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::ExtractToDirectory($Zip, $Dest)  # быстрее Expand-Archive в PowerShell 5.1
}
function New-TempDir { $d = Join-Path $env:TEMP ("magnit-" + [Guid]::NewGuid().ToString('N').Substring(0, 8)); New-Item -ItemType Directory $d | Out-Null; return $d }

# ---------- проверка доступа к LLM ----------
function Test-Llm {
    # 'ok' | 'token' (сервер отказал) | 'cert' (не доверяем сертификату) | 'net' (нет связи)
    $base = (Get-EnvVar 'LLM_BASE_URL').TrimEnd('/')
    try {
        $r = Invoke-WebRequest -Uri "$base/v1/models" -Headers @{ Authorization = "Bearer $(Get-EnvVar 'LLM_API_KEY')" } -UseBasicParsing -TimeoutSec 20
        $script:Models = @((ConvertFrom-Json $r.Content).data | ForEach-Object { $_.id })
        return 'ok'
    } catch {
        $e = $_.Exception
        while ($e -and -not ($e -is [Net.WebException])) { $e = $e.InnerException }
        if ($e -and $e.Response) {
            $code = [int]$e.Response.StatusCode
            if ($code -eq 401 -or $code -eq 403) { return 'token' }
            return 'net'
        }
        if ($e -and ($e.Status -eq 'TrustFailure' -or $e.Status -eq 'SecureChannelFailure')) { return 'cert' }
        return 'net'
    }
}

# Личный компьютер без корпоративных сертификатов: добавить их в доверенные для текущего пользователя
# (без прав администратора; Windows сама спросит подтверждение для каждого корневого сертификата)
function Install-CorpCerts {
    $dir = Join-Path $Root 'shared\certs'
    if (-not (Test-Path (Join-Path $dir 'tander-root-ca.cer'))) { return $false }
    Say 'Этот компьютер не доверяет корпоративным сертификатам (обычно так на личных компьютерах).' Yellow
    Say 'Без них помощник не сможет обращаться к корпоративным системам. Отпечатки SHA-1 корневых сертификатов:'
    foreach ($f in Get-ChildItem $dir -Filter '*-root-ca.cer') {
        $c = [Security.Cryptography.X509Certificates.X509Certificate2]::new($f.FullName)
        Say ("  {0}: {1}" -f $c.GetNameInfo('SimpleName', $false), $c.Thumbprint)
    }
    $agree = if ($Gui) { $env:MAGNIT_CERTS_CONSENT -eq '1' } else {
        Ask-Yes 'Добавить корпоративные сертификаты в доверенные для вашей учётной записи? [y/N]' }
    if (-not $agree) { return $false }
    Say 'Windows покажет предупреждение для каждого корневого сертификата — сверьте отпечаток и нажмите «Да».'
    foreach ($f in Get-ChildItem $dir -Filter '*-root-ca.cer') { Import-Certificate -FilePath $f.FullName -CertStoreLocation Cert:\CurrentUser\Root | Out-Null }
    foreach ($name in 'tander-corp-ca.cer', 'platform-intermediate-ca.cer') {  # промежуточные: серверы их не присылают
        $f = Join-Path $dir $name
        if (Test-Path $f) { Import-Certificate -FilePath $f -CertStoreLocation Cert:\CurrentUser\CA | Out-Null }
    }
    return $true
}

# ---------- программы: uv, Python, окружение, Goose ----------
# Python 3.13: сначала uv (не дольше 10 минут); не вышло — архив Python скачивает PowerShell (сертификаты и прокси
# Windows, как браузер), а uv ставит его из этой папки (UV_PYTHON_INSTALL_MIRROR=file://…). Успех — $LASTEXITCODE = 0.
function Install-PythonRuntime {
    Run-Timed 600 $Uv python install 3.13
    if ($LASTEXITCODE -eq 0) { return }
    Say '  Скачиваю Python через PowerShell (в обход загрузчика)...' Yellow
    $url = (& $Uv python list 3.13 --show-urls --only-downloads 2>$null) | Where-Object { $_ -match '^cpython-3\.13\.\d+-windows-x86_64-none\s' } |
        ForEach-Object { ($_ -split '\s+')[-1] } | Select-Object -First 1
    $m = [regex]::Match([string]$url, '/([^/]+)/([^/]+\.tar\.gz)$')  # выпуск и файл (адрес бывает и с зеркала)
    if (-not $m.Success) { Say '  Не нашёл адрес Python для скачивания.' Yellow; $global:LASTEXITCODE = 1; return }
    $mirror = Join-Path $UvDir 'python-mirror'
    $dir = Join-Path $mirror $m.Groups[1].Value
    New-Item -ItemType Directory -Force $dir | Out-Null
    $file = Join-Path $dir ([Uri]::UnescapeDataString($m.Groups[2].Value))
    $ok = $false
    $tail = "$($m.Groups[1].Value)/$($m.Groups[2].Value)"
    foreach ($u in "https://releases.astral.sh/github/python-build-standalone/releases/download/$tail",
                   "https://github.com/astral-sh/python-build-standalone/releases/download/$tail", $url) {
        try { Invoke-WebRequest -Uri $u -OutFile $file -UseBasicParsing -TimeoutSec 900; $ok = $true; break }
        catch { Say "  $([IO.Path]::GetFileName($file)): $($_.Exception.Message)" Yellow }
    }
    if (-not $ok) { $global:LASTEXITCODE = 1; return }
    $env:UV_PYTHON_INSTALL_MIRROR = 'file:///' + ($mirror -replace '\\', '/')  # uv сверит контрольную сумму сам
    try { Run-Timed 300 $Uv python install 3.13 } finally { Remove-Item Env:UV_PYTHON_INSTALL_MIRROR -ErrorAction SilentlyContinue }
}

function Install-Python {
    $have = if (Test-Path $Uv) { (& $Uv --version) -replace '^uv\s+(\S+).*$', '$1' } else { '' }
    if ($have -ne $UvVersion) {
        Write-Host -NoNewline "Скачиваю uv $UvVersion... "
        $tmp = New-TempDir
        $url = "https://github.com/astral-sh/uv/releases/download/$UvVersion/uv-x86_64-pc-windows-msvc.zip"
        Retry "загрузчик Python (uv)" @('https://github.com') { Get-Verified $url "$tmp\uv.zip" $UvSha256 }
        if (-not $RetryOk) { return }
        New-Item -ItemType Directory -Force $UvDir | Out-Null
        foreach ($exe in 'uv.exe', 'uvx.exe', 'uvw.exe') { Remove-Item (Join-Path $UvDir $exe) -Force -ErrorAction SilentlyContinue }
        Expand-Zip "$tmp\uv.zip" $UvDir
        Remove-Item $tmp -Recurse -Force
        Done
    }
    if (-not (Test-Path $Py) -or -not (Test-Path (Join-Path $Venv '.installed'))) {
        Touch-Sites $DownloadSites  # заранее, чтобы прокси пропустил скачивание Python и библиотек с первого раза
    }
    if (-not (Test-Path $Py)) {
        Say 'Устанавливаю Python 3.13 (в вашу папку профиля)...'
        Retry 'Python 3.13' @('https://releases.astral.sh', 'https://github.com') { Install-PythonRuntime }
        if (-not $RetryOk) { return }
        Run-Timed 300 $Uv venv $Venv --python 3.13
        if ($LASTEXITCODE -ne 0) { $Problems.Add('окружение Python'); Say '  ✗ Не удалось создать окружение Python.' Red; return }
    }
    $req = Join-Path $Root 'shared\requirements.txt'
    $stamp = Join-Path $Venv '.installed'
    if (-not (Test-Path $stamp) -or (Get-Item $stamp).LastWriteTime -lt (Get-Item $req).LastWriteTime) {
        Say 'Устанавливаю библиотеки помощника (первый раз — 5–20 минут, зависит от сети)...'
        # --compile-bytecode: без него первый запуск каждого инструмента в Goose медленный (и может не успеть стартовать)
        $sites = @('https://pypi.org', 'https://files.pythonhosted.org')
        Retry 'библиотеки помощника' $sites { Run-Timed 2400 $Uv pip install --python $Py --compile-bytecode -r $req }
        if (-not $RetryOk) { return }
        Set-Content $stamp (Get-Date -Format s)
        # Модель для поиска по смыслу в базах знаний (~130 МБ, один раз; без неё — полнотекстовый поиск)
        Retry 'модель поиска по смыслу' @() { Run-Timed 900 $Py (Join-Path $Root 'shared\embeddings.py') download } -Optional
    }
}

function Install-Goose {
    $have = if (Test-Path $GooseCli) { ((& $GooseCli --version) -join '').Trim() } else { '' }
    if ($have -eq $GooseVersion) { return }
    while (Get-Process -Name Goose, goosed -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "$GooseHome\*" }) {
        if ($Gui) { Fail 'Закройте приложение Goose (ИИ-помощник) и нажмите «Повторить».' }
        Read-Host 'Закройте приложение Goose (обновится до новой версии) и нажмите Enter' | Out-Null
    }
    Write-Host -NoNewline "Скачиваю Goose $GooseVersion (~250 МБ)... "
    $tmp = New-TempDir
    $url = "https://github.com/aaif-goose/goose/releases/download/v$GooseVersion/Goose-win32-x64.zip"
    Retry "приложение Goose" @('https://github.com') { Get-Verified $url "$tmp\goose.zip" $GooseSha256 }
    if (-not $RetryOk) { return }
    Expand-Zip "$tmp\goose.zip" "$tmp\unpacked"
    if (-not (Test-Path "$tmp\unpacked\dist-windows\Goose.exe")) { Fail 'Архив Goose повреждён: нет Goose.exe.' }
    New-Item -ItemType Directory -Force $GooseHome | Out-Null
    $old = Join-Path $GooseHome 'dist-windows'
    if (Test-Path $old) { Remove-Item $old -Recurse -Force }
    Move-Item "$tmp\unpacked\dist-windows" $old
    Remove-Item $tmp -Recurse -Force
    Done
}

function Get-Workspace {
    $ws = Get-EnvVar 'AGENT_WORKSPACE'
    if (-not $ws) { $ws = '~/magnit-agent-workspace' }
    if ($ws.StartsWith('~')) { $ws = Join-Path $HOME $ws.Substring(1).TrimStart('/', '\') }
    New-Item -ItemType Directory -Force $ws | Out-Null
    return (Resolve-Path $ws).Path
}

function New-Shortcuts {
    $ws = Get-Workspace
    New-Item -ItemType Directory -Force $StartMenu | Out-Null
    $shell = New-Object -ComObject WScript.Shell
    $lnk = $shell.CreateShortcut((Join-Path $StartMenu 'ИИ-помощник.lnk'))
    $lnk.TargetPath = $GooseApp
    $lnk.Arguments = "--dir `"$ws`""
    $lnk.WorkingDirectory = $ws
    $lnk.IconLocation = "$GooseApp,0"
    $lnk.Description = 'ИИ-помощник на корпоративной модели MagnitGPT (Goose)'
    $lnk.Save()
    $lnk = $shell.CreateShortcut((Join-Path $StartMenu 'Настройки ИИ-помощника.lnk'))
    $lnk.TargetPath = Join-Path $Root 'Установить агента (Windows).cmd'
    $lnk.WorkingDirectory = $Root
    $lnk.Description = 'Сменить ключ, подключить Jira, Confluence, Tag, выбрать инструменты'
    $lnk.Save()
    $lnk = $shell.CreateShortcut((Join-Path $StartMenu 'Папка помощника.lnk'))
    $lnk.TargetPath = $Root
    $lnk.Save()
    $lnk = $shell.CreateShortcut((Join-Path $StartMenu 'Удалить ИИ-помощника.lnk'))
    $lnk.TargetPath = Join-Path $Root 'Удалить помощника (Windows).cmd'
    $lnk.WorkingDirectory = $env:TEMP
    $lnk.Description = 'Полностью удалить помощника и Goose (ваши файлы в рабочей папке останутся)'
    $lnk.Save()
}

function Choose-Tools {
    Run $Py (Join-Path $Root 'shared\choose_integrations.py')
    if (Test-Path $GooseCli) { Run $Py (Join-Path $Root 'agent-b-goose\configure.py') | Select-String -Pattern '^Интеграции' -Context 0, 20 | ForEach-Object { $_.Line; $_.Context.PostContext } }
}

# Помощник, распакованный из архива куда угодно (обычно «Загрузки», которые часто чистят), переезжает в постоянную папку
# и установка продолжается оттуда. Так же ставится обновление: новый архив ложится поверх, .env и окружение остаются.
function Move-ToHome {
    $target = if ($env:MAGNIT_DIR) { $env:MAGNIT_DIR } else { Join-Path $env:USERPROFILE 'ai-agent-local' }
    $here = (Resolve-Path $Root).Path.TrimEnd('\')
    if ($Gui -or $Quick -or $here -eq $target.TrimEnd('\') -or (Test-Path (Join-Path $Root '.git'))) { return }  # окно переносит само  # install.ps1 / уже там / разработчик
    if (Test-Path (Join-Path $target '.git')) { Say "В $target рабочая копия git — переносить туда не буду." Yellow; return }
    Title 'Папка помощника'
    Say "Помощник запущен из папки $here."
    Say "Его постоянное место — $target (там же сохранятся ваши настройки при обновлениях)."
    if ((Read-Host 'Перенести туда и продолжить? [Y/n]') -match '^[nNнН]') { Say "Ставлю здесь: $here"; return }
    New-Item -ItemType Directory -Force $target | Out-Null
    # robocopy есть в любой Windows; окружение Python не переносим (оно привязано к своей папке), .env на месте не затираем
    $skip = @()
    if (Test-Path (Join-Path $target '.env')) { $skip = @('/XF', '.env') }
    & robocopy $here $target /E /XD (Join-Path $here 'shared\.venv') (Join-Path $here '.git') @skip /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -ge 8) { Fail "Не удалось скопировать помощника в $target (код robocopy $LASTEXITCODE)." }
    Say "Перенесено в $target. Папку $here после установки можно удалить." Green
    $env:MAGNIT_BANNER_SHOWN = '1'
    # Продолжение — в этом же окне. Не через «& powershell»: тогда вывод установщика идёт через конвейер PowerShell,
    # и сообщения внешних программ в stderr могут оборвать её молча (так было на корпоративном ноутбуке)
    $child = Start-Process powershell -NoNewWindow -Wait -PassThru -ArgumentList (@('-NoProfile', '-ExecutionPolicy',
        'Bypass', '-File', "`"$(Join-Path $target 'windows\setup.ps1')`"") + $Passed)
    exit $child.ExitCode
}

# Скачанный архив несёт отметку «из интернета» (Mark of the Web), и Проводник распаковывает её на все файлы: Windows
# переспрашивает «Не удаётся проверить издателя» при каждом запуске .cmd. Снимаем её со своих скриптов.
function Unblock-Scripts {
    foreach ($pattern in '*.cmd', 'windows\*.ps1', 'windows\*.cmd', 'agent-b-goose\*.cmd') {
        Get-ChildItem (Join-Path $Root $pattern) -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
    }
    # Файлы запуска переименованы с пометкой платформы (22.10.2026): обновление поверх установки прежние не удаляет
    foreach ($old in 'Установить агента.cmd', 'Запустить агента.cmd', 'Удалить помощника.cmd', 'Установить агента.command',
                     'Запустить агента.command', 'Запустить веб-помощника.command') {
        $f = Join-Path $Root $old
        $new = Join-Path $Root ($old -replace '\.(cmd|command)$', $(if ($old -like '*.cmd') { ' (Windows).cmd' } else { ' (macOS).command' }))
        if ((Test-Path -LiteralPath $f) -and (Test-Path -LiteralPath $new)) { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue }
    }
    # Инструкции собраны в четыре (27.10.2026): прежние файлы инструкций в папке помощника — убрать
    foreach ($old in 'ИНСТРУКЦИЯ.md', 'УСТАНОВКА.md', 'УСТАНОВКА-Windows.md', 'Инструкция по установке (Windows).html') {
        Remove-Item -LiteralPath (Join-Path $Root $old) -Force -ErrorAction SilentlyContinue
    }
}

# =====================================================================================================
try { $Host.UI.RawUI.WindowTitle = 'Установка ИИ-помощника' } catch { }
if (-not $Tools -and -not $env:MAGNIT_BANNER_SHOWN) { Box @('ИИ-помощник на корпоративной модели MagnitGPT', 'Установка и настройка для Windows · права администратора не нужны') }
Move-ToHome
Unblock-Scripts
Say "Папка помощника: $Root"
$guide = Join-Path $Root 'Установка из архива — Windows.html'
if (Test-Path $guide) { Say "Инструкция со снимками экрана: $guide" }
if (-not (Test-Path $EnvFile)) { Copy-Item (Join-Path $Root '.env.example') $EnvFile; $Reconfigure = $true }
$pending = Join-Path $HOME '.magnit-agent\langfuse-key'  # ключ трассировки из команды установки (MAGNIT_LANGFUSE)
if (Test-Path $pending) { Import-LangfuseKey ([IO.File]::ReadAllText($pending)) | Out-Null; Remove-Item $pending -Force }

if ($Tools) {
    if (-not (Test-Path $Py)) { Fail 'Помощник ещё не установлен: запустите «Установить агента (Windows)».' }
    Choose-Tools
    Say 'Готово. Изменения применятся в новом окне или сессии помощника.' Green
    exit 0
}
if (-not (Get-EnvVar 'LLM_API_KEY')) { $Reconfigure = $true }

# ---------- 1. Подключение к модели ----------
Step 1 'Подключение к модели MagnitGPT'
# Повторный запуск («Пуск» → Настройки ИИ-помощника): можно сменить ключ, не трогая остальное
$askKey = $Reconfigure -or ($Gui -and $env:MAGNIT_LLM_API_KEY)  # окно передаёт ключ, только если его ввели
if (-not $askKey -and -not $Quick -and -not $env:MAGNIT_LLM_API_KEY) {
    $askKey = Ask-Yes '  Ключ MagnitGPT уже сохранён. Сменить его (например, выдали новый)? [y/N]'
}
if ($askKey) {
    if ($AskAll) { Say '  Enter — оставить значение в скобках.' }
    if ($AskAll) {
        $v = Read-Host "  Адрес шлюза [$(Get-EnvVar 'LLM_BASE_URL')]"
        if ($v) { Set-EnvVar 'LLM_BASE_URL' $v.TrimEnd('/') }
    }
    if ($env:MAGNIT_LLM_API_KEY) {  # установка без вопросов (ИТ, проверки): ключ задан переменной
        Set-EnvVar 'LLM_API_KEY' $env:MAGNIT_LLM_API_KEY.Trim()
        Say '  Ключ MagnitGPT взят из переменной MAGNIT_LLM_API_KEY.'
    } else {
        Say '  Ключ создаётся здесь: https://llmlite.ailab-copilot-prod.corp.tander.ru/'
        Say '  Virtual Keys → + Create New Key → Team: not-ai-lab, Models: All Team Models, Key Name: ИИ-помощник → Create Key.'
        Say '  Скопируйте его и вставьте сюда правым щелчком мыши или Ctrl+V — символы не отображаются, это нормально.'
        $v = Read-Secret '  Ключ доступа к модели (sk-...)'
        if ($v) { Set-EnvVar 'LLM_API_KEY' $v }
    }
    if ($AskAll) {
        $v = Read-Host "  Модель [$(Get-EnvVar 'LLM_MODEL')]"
        if ($v) { Set-EnvVar 'LLM_MODEL' $v }
    }
}

Write-Host -NoNewline "  Проверяю доступ к $(Get-EnvVar 'LLM_BASE_URL') ... "
$state = Test-Llm
if ($state -eq 'cert') {
    Say 'сертификат не принят' Yellow
    if (-not (Install-CorpCerts)) { Fail 'Сертификаты не установлены — помощник не сможет работать. Запустите установку снова.' }
    Write-Host -NoNewline '  Проверяю ещё раз ... '
    $state = Test-Llm
}
$tries = 0
while ($state -eq 'token' -and $tries -lt 3 -and -not $Gui) {  # окно проверяет ключ само
    $tries++
    Say 'ключ не принят' Yellow
    Say '  Проверьте, что ключ скопирован целиком (начинается с sk-), и вставьте его ещё раз.'
    $v = Read-Secret '  Ключ доступа к модели (Enter — прервать)'
    if (-not $v) { break }
    Set-EnvVar 'LLM_API_KEY' $v
    Write-Host -NoNewline '  Проверяю ещё раз ... '
    $state = Test-Llm
}
if ($state -eq 'token') { Fail 'Сервер не принял ключ. Проверьте его и запустите «Установить агента (Windows)» снова.' }
if ($state -ne 'ok') { Fail 'Модель не отвечает. Проверьте, что VPN (FortiClient или NetBird) подключён.' }
Done
foreach ($m in (Get-EnvVar 'LLM_MODEL'), (Get-EnvVar 'LLM_FAST_MODEL'), (Get-EnvVar 'LLM_VISION_MODEL')) {
    if ($m -and $Models -notcontains $m) { Say "  ! Внимание: модель $m недоступна для вашего ключа — поправьте .env" Yellow }
}

# ---------- 2. Корпоративные системы ----------
function Ask-Token([string]$Key, [string]$Name, [string]$Where, [string]$Link = '') {
    $state = if (Get-EnvVar $Key) { 'задан' } else { 'не задан' }
    Write-Host "  $Name" -ForegroundColor White -NoNewline; Write-Host " ($state). $Where"
    if ($Link) { Say "  Ссылка: $Link" }
    $v = Read-Secret '  Токен (Enter — оставить как есть)'
    if ($v) { Set-EnvVar $Key $v }
}
Step 2 'Корпоративные системы'
$askTools = $false
if ($Gui) {  # окно установщика: токены, которые ввели, — переменными MAGNIT_SET_<КЛЮЧ>
    foreach ($key in 'JIRA_TOKEN', 'CONFLUENCE_IT_TOKEN', 'CONFLUENCE_EPORTAL_TOKEN', 'JIRA_IT_TOKEN', 'TAG_WEBHOOK_URL',
                     'GITLAB_TOKEN', 'GITLAB_PLATFORM_TOKEN') {
        $v = [Environment]::GetEnvironmentVariable("MAGNIT_SET_$key")
        if ($v) { Set-EnvVar $key $v.Trim(); $askTools = $true; Say "  $key — сохранён" }
    }
}
$missing = @('JIRA_TOKEN', 'CONFLUENCE_EPORTAL_TOKEN', 'TAG_WEBHOOK_URL') | Where-Object { -not (Get-EnvVar $_) }
if (-not ($Reconfigure -or $missing)) { Say '  Уже подключены. Изменить: «Пуск» → Настройки ИИ-помощника.' }
else {
    Say '  Можно пропустить и подключить позже: «Пуск» → Настройки ИИ-помощника.'
    if (Ask-Yes '  Подключить корпоративные системы (Jira, Confluence, Tag, GitLab)? [y/N]') {
        $askTools = $true
        Say '  Jira и Confluence подключаются через облачный MCP AI Lab по вашим личным маркерам.'
        Ask-Token 'JIRA_TOKEN' 'Jira' 'track.magnit.ru → аватар → Профиль → Личные маркеры доступа → Создать маркер' 'https://track.magnit.ru/secure/ViewProfile.jspa?selectedTab=com.atlassian.pats.pats-plugin:jira-user-personal-access-tokens'
        Ask-Token 'CONFLUENCE_IT_TOKEN' 'Confluence IT-портал' 'it-portal.corp.tander.ru → аватар → Настройки → Маркеры → Личные маркеры доступа' 'https://it-portal.corp.tander.ru/plugins/personalaccesstokens/usertokens.action'
        Ask-Token 'CONFLUENCE_EPORTAL_TOKEN' 'Confluence eportal' 'eportal.magnit.ru → аватар → Настройки → Маркеры → Личные маркеры доступа' 'https://eportal.magnit.ru/plugins/personalaccesstokens/usertokens.action'
        Ask-Token 'JIRA_IT_TOKEN' 'Jira IT (jira.corp.tander.ru)' 'если пользуетесь: аватар → Профиль → Личные маркеры доступа' 'https://jira.corp.tander.ru/secure/ViewProfile.jspa?selectedTab=com.atlassian.pats.pats-plugin:jira-user-personal-access-tokens'
        Ask-Token 'TAG_WEBHOOK_URL' 'Вебхук Tag (ваш личный)' 'Tag → меню → Интеграции → Входящие вебхуки → Добавить; вставьте ссылку https://tag.magnit.ru/hooks/...' 'https://tag.magnit.ru/tower-magnit/integrations/incoming_webhooks'
        Ask-Token 'TAG_BOT_TOKEN' 'Бот Tag (необязательно)' 'токен бота по заявке в Help (см. инструкцию по установке, раздел «Где взять токены» → Tag)'
        if ((Get-EnvVar 'TAG_BOT_TOKEN') -and -not (Get-EnvVar 'TAG_USER')) { Set-EnvVar 'TAG_USER' $env:USERNAME }
        Ask-Token 'GITLAB_TOKEN' 'GitLab coderepo.corp.tander.ru' 'аватар → Preferences → Access tokens → Add new token (scope api)' 'https://coderepo.corp.tander.ru/-/user_settings/personal_access_tokens'
        Ask-Token 'GITLAB_PLATFORM_TOKEN' 'GitLab gitlab.platform.corp' 'аватар → Preferences → Access tokens → Add new token (scope api)' 'https://gitlab.platform.corp/-/user_settings/personal_access_tokens'
        Ask-Token 'MAGNITGPT_API_KEY' 'Протоколы встреч MagnitGPT (gpt.ai)' 'gpt.ai.corp.tander.ru → Настройки → Аккаунт → API-ключи (право выдаёт gpt_tander@magnit.ru)' 'https://gpt.ai.corp.tander.ru/'
        if (-not (Get-EnvVar 'LANGFUSE_SECRET_KEY')) {
            Write-Host '  Трассировка Langfuse' -ForegroundColor White -NoNewline
            Write-Host ' (пилотная группа): ключ выдаёт ответственный за помощника, строка pk-lf-…:sk-lf-…'
            $v = Read-Secret '  Ключ (Enter — пропустить)'
            if ($v) {
                if (Import-LangfuseKey $v) {
                    $content = Ask-Yes '  Отправлять и текст разговоров (секреты скрываются)? По умолчанию — только служебные данные [y/N]'
                    Set-EnvVar 'LANGFUSE_CAPTURE_CONTENT' $(if ($content) { '1' } else { '0' })
                    Say '  Трассировка подключена.'
                } else { Say '  Это не похоже на ключ Langfuse — пропускаю.' Yellow }
            }
        }
    }
}

# ---------- 3. Программы ----------
Step 3 'Программы: Python и Goose (в папку профиля)'
Install-Python
Install-Goose  # даже если с Python не вышло: при повторном запуске Goose уже будет скачан
if ($Problems.Count -eq 0) { Write-Host -NoNewline "  Python 3.13, библиотеки помощника, Goose $GooseVersion "; Done }

# ---------- 4. Активные инструменты и настройка Goose ----------
Step 4 'Инструменты и настройка Goose'
$ready = (Test-Path $Py) -and (Test-Path (Join-Path $Venv '.installed')) -and (Test-Path $GooseCli)
if (-not $ready) {
    Say '  Пропускаю: сначала нужно доскачать то, что не получилось на шаге 3.' Yellow
} else {
    if (-not (Get-EnvVar 'ENABLED_INTEGRATIONS') -or $Reconfigure -or $askTools) {
        Run $Py (Join-Path $Root 'shared\choose_integrations.py')
    }
    Write-Host ''
    Run $Py (Join-Path $Root 'agent-b-goose\configure.py')
    if ($LASTEXITCODE -ne 0) { Fail 'Не удалось настроить Goose (см. сообщение выше).' }
    New-Shortcuts
    Write-Host ''
    Run $Py (Join-Path $Root 'shared\check_integrations.py')
}

if ($Problems.Count -gt 0) {
    Box (@('! Установка завершена не полностью', '', 'Не получилось:') + @($Problems | ForEach-Object { "  · $_" }) +
         @('', 'Проверьте VPN и интернет и запустите «Установить агента (Windows)» ещё раз:',
           'уже скачанное повторно не скачивается.', "Папка:      $Root")) Yellow
    exit 1
}
Box @('✓ Помощник установлен', '', 'Запуск:     «Пуск» → ИИ-помощник', '            или «Запустить агента (Windows)» в папке помощника', 'Настройки:  «Пуск» → Настройки ИИ-помощника', '            (сменить ключ, подключить Jira, Confluence, Tag)', "Папка:      $Root") Green
