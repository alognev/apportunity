﻿# ИИ-помощник для Windows: установщик в окнах (WinForms из встроенного Windows PowerShell 5.1, без прав администратора).
# Окно — оболочка над windows\setup.ps1: собирает ключ и токены, запускает setup.ps1 -Gui и показывает ход установки.
# Если окна на этом компьютере не открываются (политика безопасности: ограниченный режим PowerShell, запрет
# компиляции; любая ошибка окна) — сам запускает прежний текстовый установщик:
#   windows\Установщик в текстовом режиме (Windows).cmd
# Переменные для проверок: MAGNIT_FORCE_TEXT=1 — сразу текстовый режим; MAGNIT_GUI_CHECK=1 — только проверить,
# откроется ли окно, и написать gui-ok или text:<причина>; MAGNIT_DIR, MAGNIT_PROGRAMS, MAGNIT_START_MENU — как у setup.ps1.
# Файл в UTF-8 с BOM: иначе PowerShell 5.1 читает русский текст в кодировке ANSI.
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$TextMode = Join-Path $PSScriptRoot 'Установщик в текстовом режиме (Windows).cmd'

function Start-TextMode([string]$Why) {
    if ($env:MAGNIT_GUI_CHECK -eq '1') { Write-Output "text:$Why"; exit 0 }
    Start-Process cmd.exe -ArgumentList '/c', "`"$TextMode`""
    exit 0
}

# ---------- откроются ли окна ----------
try {
    if ($env:MAGNIT_FORCE_TEXT -eq '1') { throw 'выбран текстовый режим (MAGNIT_FORCE_TEXT)' }
    if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') {
        throw "ограниченный режим PowerShell ($($ExecutionContext.SessionState.LanguageMode))"
    }
    Add-Type -AssemblyName System.Windows.Forms, System.Drawing
    # Строки вывода установщика из фонового процесса — в очередь; окно забирает их по таймеру (без зависаний)
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Runtime.InteropServices;
public static class MagnitGui {
    public static ConcurrentQueue<string> Lines = new ConcurrentQueue<string>();
    public static void Attach(Process p) {
        p.OutputDataReceived += (s, e) => { if (e.Data != null) Lines.Enqueue(e.Data); };
        p.ErrorDataReceived += (s, e) => { if (e.Data != null) Lines.Enqueue(e.Data); };
        p.BeginOutputReadLine();
        p.BeginErrorReadLine();
    }
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
}
'@
    [void][MagnitGui]::SetProcessDPIAware()  # чёткий текст при масштабе 125–150 %
    [Windows.Forms.Application]::EnableVisualStyles()
} catch {
    Start-TextMode $_.Exception.Message
}
if ($env:MAGNIT_GUI_CHECK -eq '1') { Write-Output 'gui-ok'; exit 0 }

# ---------- папки и настройки ----------
$Target = if ($env:MAGNIT_DIR) { $env:MAGNIT_DIR } else { Join-Path $env:USERPROFILE 'ai-agent-local' }
$Here = (Resolve-Path $Root).Path.TrimEnd('\')
$NeedMove = -not ($Here -eq $Target.TrimEnd('\') -or (Test-Path (Join-Path $Root '.git')) -or (Test-Path (Join-Path $Target '.git')))
$InstallRoot = if ($NeedMove) { $Target } else { $Here }
$StartMenu = if ($env:MAGNIT_START_MENU) { $env:MAGNIT_START_MENU } else { Join-Path ([Environment]::GetFolderPath('Programs')) 'ИИ-помощник' }

function Read-Env([string]$Dir) {
    $map = @{}
    foreach ($file in (Join-Path $Dir '.env'), (Join-Path $Root '.env.example')) {
        if (-not (Test-Path $file)) { continue }
        foreach ($line in [IO.File]::ReadAllLines($file, [Text.UTF8Encoding]::new($false))) {
            if ($line -match '^([A-Z0-9_]+)=(.*)$' -and -not $map.ContainsKey($Matches[1])) { $map[$Matches[1]] = $Matches[2].Trim() }
        }
    }
    return $map
}
$Env0 = Read-Env $InstallRoot
$HaveKey = [bool]$Env0['LLM_API_KEY'] -and (Test-Path (Join-Path $InstallRoot '.env'))
$BaseUrl = if ($Env0['LLM_BASE_URL']) { $Env0['LLM_BASE_URL'] } else { 'https://llmlite.ailab-copilot-prod.corp.tander.ru' }
$KeyPage = 'https://llmlite.ailab-copilot-prod.corp.tander.ru/'

# Проверка ключа: 'ok' | 'token' (не принят) | 'cert' (не доверяем корпоративному сертификату) | 'net' (нет связи)
function Test-Key([string]$Key) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    try {
        Invoke-WebRequest -Uri "$($BaseUrl.TrimEnd('/'))/v1/models" -Headers @{ Authorization = "Bearer $Key" } -UseBasicParsing -TimeoutSec 20 | Out-Null
        return 'ok'
    } catch {
        $e = $_.Exception
        while ($e -and -not ($e -is [Net.WebException])) { $e = $e.InnerException }
        if ($e -and $e.Response) { if ([int]$e.Response.StatusCode -in 401, 403) { return 'token' }; return 'net' }
        if ($e -and ($e.Status -eq 'TrustFailure' -or $e.Status -eq 'SecureChannelFailure')) { return 'cert' }
        return 'net'
    }
}

# ---------- оформление ----------
$Accent = [Drawing.Color]::FromArgb(230, 52, 136)     # цвет инструкций помощника
$Ink = [Drawing.Color]::FromArgb(29, 29, 31)
$Muted = [Drawing.Color]::FromArgb(110, 110, 115)
$Green = [Drawing.Color]::FromArgb(22, 140, 60)
$Amber = [Drawing.Color]::FromArgb(176, 112, 0)
$Red = [Drawing.Color]::FromArgb(200, 30, 50)
$Font = New-Object Drawing.Font('Segoe UI', 10)
$FontBold = New-Object Drawing.Font('Segoe UI Semibold', 10)
$FontTitle = New-Object Drawing.Font('Segoe UI Semibold', 14)
$FontBig = New-Object Drawing.Font('Segoe UI Semibold', 18)

function New-Label([string]$Text, [int]$X, [int]$Y, [int]$W, [int]$H = 0, $F = $Font, $Color = $Ink) {
    $l = New-Object Windows.Forms.Label
    $l.Text = $Text; $l.Font = $F; $l.ForeColor = $Color; $l.Location = New-Object Drawing.Point($X, $Y)
    if ($H) { $l.Size = New-Object Drawing.Size($W, $H) } else { $l.MaximumSize = New-Object Drawing.Size($W, 0); $l.AutoSize = $true }
    return $l
}
function New-Link([string]$Text, [string]$Url, [int]$X, [int]$Y) {
    $l = New-Object Windows.Forms.LinkLabel
    $l.Text = $Text; $l.Font = $Font; $l.AutoSize = $true; $l.Location = New-Object Drawing.Point($X, $Y)
    $l.LinkColor = $Accent; $l.ActiveLinkColor = $Accent; $l.Tag = $Url
    $l.add_LinkClicked({ param($s) Start-Process $s.Tag })
    return $l
}
function New-Button([string]$Text, [int]$W = 120, [switch]$Primary) {
    $b = New-Object Windows.Forms.Button
    $b.Text = $Text; $b.Font = $Font; $b.Size = New-Object Drawing.Size($W, 34); $b.FlatStyle = 'Flat'
    if ($Primary) { $b.BackColor = $Accent; $b.ForeColor = [Drawing.Color]::White; $b.FlatAppearance.BorderSize = 0 }
    else { $b.BackColor = [Drawing.Color]::White; $b.FlatAppearance.BorderColor = [Drawing.Color]::FromArgb(200, 200, 205) }
    return $b
}
function New-Page {
    $p = New-Object Windows.Forms.Panel
    $p.Location = New-Object Drawing.Point(0, 76); $p.Size = New-Object Drawing.Size(720, 380); $p.Visible = $false
    $p.BackColor = [Drawing.Color]::White
    return $p
}

# ---------- окно ----------
$form = New-Object Windows.Forms.Form
$form.SuspendLayout()
$form.AutoScaleDimensions = New-Object Drawing.SizeF(96, 96)
$form.AutoScaleMode = 'Dpi'
$form.Text = 'Установка ИИ-помощника'
$form.ClientSize = New-Object Drawing.Size(720, 520)
$form.FormBorderStyle = 'FixedSingle'; $form.MaximizeBox = $false; $form.StartPosition = 'CenterScreen'
$form.BackColor = [Drawing.Color]::White; $form.Font = $Font
$goose = Join-Path $(if ($env:MAGNIT_PROGRAMS) { $env:MAGNIT_PROGRAMS } else { Join-Path $env:LOCALAPPDATA 'Programs' }) 'Goose\dist-windows\Goose.exe'
try { if (Test-Path $goose) { $form.Icon = [Drawing.Icon]::ExtractAssociatedIcon($goose) } } catch { }

$header = New-Object Windows.Forms.Panel
$header.Size = New-Object Drawing.Size(720, 76); $header.BackColor = $Accent
$header.Controls.Add((New-Label 'ИИ-помощник MagnitGPT' 24 12 660 0 $FontTitle ([Drawing.Color]::White)))
$hint = New-Label 'Установка и настройка для Windows · права администратора не нужны' 25 44 660 0 $Font ([Drawing.Color]::FromArgb(255, 230, 240))
$header.Controls.Add($hint)
$form.Controls.Add($header)

$footer = New-Object Windows.Forms.Panel
$footer.Location = New-Object Drawing.Point(0, 456); $footer.Size = New-Object Drawing.Size(720, 64)
$footer.BackColor = [Drawing.Color]::FromArgb(245, 245, 247)
$btnBack = New-Button 'Назад'; $btnBack.Location = New-Object Drawing.Point(316, 15)
$btnNext = New-Button 'Далее' -Primary; $btnNext.Location = New-Object Drawing.Point(446, 15)
$btnCancel = New-Button 'Отмена'; $btnCancel.Location = New-Object Drawing.Point(576, 15)
$linkText = New-Object Windows.Forms.LinkLabel
$linkText.Text = 'Текстовый режим'; $linkText.AutoSize = $true; $linkText.Location = New-Object Drawing.Point(20, 24)
$linkText.LinkColor = $Muted; $linkText.Font = $Font
$linkHelp = New-Object Windows.Forms.LinkLabel
$linkHelp.Text = 'Инструкция к этому шагу'; $linkHelp.AutoSize = $true; $linkHelp.Location = New-Object Drawing.Point(140, 24)
$linkHelp.LinkColor = $Accent; $linkHelp.Font = $Font
$footer.Controls.AddRange(@($btnBack, $btnNext, $btnCancel, $linkText, $linkHelp))
$form.Controls.Add($footer)

# ---------- страница 1: приветствие ----------
$pWelcome = New-Page
$pWelcome.Controls.Add((New-Label 'Здравствуйте! Установим ИИ-помощника' 32 22 640 0 $FontTitle))
$intro = if ($HaveKey) {
    'Помощник уже установлен на этом компьютере. Здесь можно сменить ключ MagnitGPT, подключить корпоративные ' +
    'системы или обновить помощника — ваши настройки сохранятся.'
} else {
    'Помощник работает на корпоративной модели MagnitGPT. Отвечает на вопросы, работает с документами и таблицами, ' +
    'помогает делать аналитические расчёты и работает со множеством корпоративных инструментов. Установка займёт ' +
    '10–25 минут, почти всё это время компьютер всё сделает сам.'
}
$pWelcome.Controls.Add((New-Label $intro 32 64 650))
$pWelcome.Controls.Add((New-Label 'Перед началом проверьте:' 32 166 640 0 $FontBold))
$pWelcome.Controls.Add((New-Label '✓  VPN подключён: FortiClient («VPN подключено») или NetBird (Connected)' 44 196 640))
$pWelcome.Controls.Add((New-Label '✓  Есть ключ MagnitGPT (строка sk-…) — где взять, покажем дальше' 44 226 640))
if ($NeedMove) {
    $pWelcome.Controls.Add((New-Label "Помощник будет установлен в папку $Target (папку «Загрузки» часто очищают)." 32 276 650 0 $Font $Muted))
}

# ---------- страница 2: ключ ----------
$pKey = New-Page
$pKey.Controls.Add((New-Label 'Ключ MagnitGPT' 32 22 640 0 $FontTitle))
$pKey.Controls.Add((New-Label 'Ключ — строка, которая начинается с sk-. Создайте его на странице MagnitGPT: войдите рабочей учётной записью → Virtual Keys → + Create New Key → Team: not-ai-lab, Models: All Team Models, Key Name: ИИ-помощник → Create Key, и скопируйте ключ.' 32 58 650))
$pKey.Controls.Add((New-Link 'Открыть страницу создания ключа →' $KeyPage 32 122))
$keepKey = New-Object Windows.Forms.CheckBox
$keepKey.Text = 'Оставить сохранённый ключ'; $keepKey.Font = $Font; $keepKey.AutoSize = $true
$keepKey.Location = New-Object Drawing.Point(32, 160); $keepKey.Checked = $HaveKey; $keepKey.Visible = $HaveKey
$pKey.Controls.Add($keepKey)
$keyTop = if ($HaveKey) { 196 } else { 166 }
$pKey.Controls.Add((New-Label 'Вставьте ключ (правый щелчок → «Вставить» или Ctrl+V):' 32 $keyTop 640))
$keyBox = New-Object Windows.Forms.TextBox
$keyBox.Font = New-Object Drawing.Font('Consolas', 11); $keyBox.UseSystemPasswordChar = $true
$keyBox.Location = New-Object Drawing.Point(32, ($keyTop + 28)); $keyBox.Size = New-Object Drawing.Size(520, 28)
$keyBox.Enabled = -not $HaveKey
$pKey.Controls.Add($keyBox)
$showKey = New-Object Windows.Forms.CheckBox
$showKey.Text = 'Показать'; $showKey.Font = $Font; $showKey.AutoSize = $true; $showKey.Location = New-Object Drawing.Point(566, ($keyTop + 30))
$showKey.add_CheckedChanged({ $keyBox.UseSystemPasswordChar = -not $showKey.Checked })
$pKey.Controls.Add($showKey)
$keyStatus = New-Label '' 32 ($keyTop + 72) 650
$pKey.Controls.Add($keyStatus)
$keepKey.add_CheckedChanged({ $keyBox.Enabled = -not $keepKey.Checked; if (-not $keepKey.Checked) { $keyBox.Focus() } })

# ---------- страница 3: корпоративные системы ----------
$pSys = New-Page
$pSys.Controls.Add((New-Label 'Корпоративные системы' 32 22 640 0 $FontTitle))
$pSys.Controls.Add((New-Label 'Можно пропустить: просто нажмите «Установить». Подключить позже — «Пуск» → Настройки ИИ-помощника. Вставьте токены тех систем, которыми пользуетесь.' 32 58 650))
$sysPanel = New-Object Windows.Forms.Panel
$sysPanel.Location = New-Object Drawing.Point(20, 104); $sysPanel.Size = New-Object Drawing.Size(690, 270); $sysPanel.AutoScroll = $true
$pSys.Controls.Add($sysPanel)
$Systems = @(
    @('JIRA_TOKEN', 'Jira (track.magnit.ru)', 'https://track.magnit.ru/secure/ViewProfile.jspa?selectedTab=com.atlassian.pats.pats-plugin:jira-user-personal-access-tokens'),
    @('CONFLUENCE_EPORTAL_TOKEN', 'Confluence eportal', 'https://eportal.magnit.ru/plugins/personalaccesstokens/usertokens.action'),
    @('CONFLUENCE_IT_TOKEN', 'Confluence IT-портал', 'https://it-portal.corp.tander.ru/plugins/personalaccesstokens/usertokens.action'),
    @('JIRA_IT_TOKEN', 'Jira IT (jira.corp)', 'https://jira.corp.tander.ru/secure/ViewProfile.jspa?selectedTab=com.atlassian.pats.pats-plugin:jira-user-personal-access-tokens'),
    @('TAG_WEBHOOK_URL', 'Вебхук Tag', 'https://tag.magnit.ru/'),
    @('GITLAB_TOKEN', 'GitLab coderepo', 'https://coderepo.corp.tander.ru/-/user_settings/personal_access_tokens'),
    @('GITLAB_PLATFORM_TOKEN', 'GitLab platform', 'https://gitlab.platform.corp/-/user_settings/personal_access_tokens')
)
$TokenBoxes = @{}
$y = 4
foreach ($s in $Systems) {
    $have = [bool]$Env0[$s[0]] -and (Test-Path (Join-Path $InstallRoot '.env'))
    $sysPanel.Controls.Add((New-Label ($s[1] + $(if ($have) { ' ✓' } else { '' })) 12 ($y + 4) 190))
    $tb = New-Object Windows.Forms.TextBox
    $tb.UseSystemPasswordChar = $true; $tb.Font = $Font; $tb.Location = New-Object Drawing.Point(206, $y); $tb.Size = New-Object Drawing.Size(330, 26)
    $sysPanel.Controls.Add($tb)
    $sysPanel.Controls.Add((New-Link 'где взять' $s[2] 548 ($y + 4)))
    $TokenBoxes[$s[0]] = $tb
    $y += 38
}
$sysPanel.Controls.Add((New-Label '✓ — токен уже сохранён; пустое поле оставит его как есть.' 12 ($y + 6) 640 0 $Font $Muted))

# ---------- страница 4: установка ----------
$pRun = New-Page
$runTitle = New-Label 'Готовлюсь к установке…' 32 22 650 0 $FontTitle
$pRun.Controls.Add($runTitle)
$progress = New-Object Windows.Forms.ProgressBar
$progress.Location = New-Object Drawing.Point(32, 66); $progress.Size = New-Object Drawing.Size(650, 22); $progress.Style = 'Continuous'
$pRun.Controls.Add($progress)
$runStatus = New-Label 'Это займёт 10–25 минут. Окно можно свернуть — установка продолжится.' 32 100 650 44
$pRun.Controls.Add($runStatus)
$btnLog = New-Object Windows.Forms.LinkLabel
$btnLog.Text = 'Подробности ▾'; $btnLog.AutoSize = $true; $btnLog.Location = New-Object Drawing.Point(32, 150); $btnLog.LinkColor = $Muted
$pRun.Controls.Add($btnLog)
$log = New-Object Windows.Forms.TextBox
$log.Multiline = $true; $log.ReadOnly = $true; $log.ScrollBars = 'Vertical'; $log.Font = New-Object Drawing.Font('Consolas', 9)
$log.Location = New-Object Drawing.Point(32, 176); $log.Size = New-Object Drawing.Size(650, 194); $log.Visible = $false
$log.BackColor = [Drawing.Color]::FromArgb(250, 250, 250)
$pRun.Controls.Add($log)
$btnLog.add_LinkClicked({ $log.Visible = -not $log.Visible; $btnLog.Text = $(if ($log.Visible) { 'Скрыть подробности ▴' } else { 'Подробности ▾' }) })

# ---------- страница 5: итог ----------
$pDone = New-Page
$doneTitle = New-Label '' 32 26 650 0 $FontBig
$doneText = New-Label '' 32 78 650 0
$doneLink = New-Object Windows.Forms.LinkLabel
$doneLink.Text = 'Показать подробности установки'; $doneLink.AutoSize = $true; $doneLink.LinkColor = $Muted
$doneLink.Location = New-Object Drawing.Point(32, 330)
$doneLink.add_LinkClicked({ Show-Page 3; $log.Visible = $true; $btnLog.Text = 'Скрыть подробности ▴'; Set-Buttons 'details' })
$pDone.Controls.AddRange(@($doneTitle, $doneText, $doneLink))

$Pages = @($pWelcome, $pKey, $pSys, $pRun, $pDone)
foreach ($p in $Pages) { $form.Controls.Add($p) }
$script:Page = 0
function Show-Page([int]$I) { for ($k = 0; $k -lt $Pages.Count; $k++) { $Pages[$k].Visible = ($k -eq $I) }; $script:Page = $I }

# Кнопки внизу по состоянию: wizard (страницы 1–3), running, success, partial, failed, details
function Set-Buttons([string]$State) {
    $btnBack.Visible = $State -eq 'wizard' -and $script:Page -gt 0
    $btnNext.Visible = $true; $btnCancel.Visible = $true; $btnNext.Enabled = $true
    $linkText.Visible = $State -in 'wizard', 'failed', 'partial'
    switch ($State) {
        'wizard'  { $btnNext.Text = $(if ($script:Page -eq 2) { 'Установить' } else { 'Далее' }); $btnCancel.Text = 'Отмена' }
        'running' { $btnNext.Visible = $false; $btnCancel.Text = 'Прервать' }
        'success' { $btnNext.Text = 'Запустить'; $btnCancel.Text = 'Готово' }
        'partial' { $btnNext.Text = 'Повторить'; $btnCancel.Text = 'Закрыть' }
        'failed'  { $btnNext.Text = 'Повторить'; $btnCancel.Text = 'Закрыть' }
        'details' { $btnNext.Text = 'Назад'; $btnCancel.Text = 'Закрыть' }
    }
    $script:State = $State
}

# ---------- установка: setup.ps1 -Gui в фоне ----------
$script:Proc = $null
$script:Lines = New-Object Collections.Generic.List[string]
$script:CertsConsent = $false
$script:Result = ''
$StepPercent = @{ 1 = 8; 2 = 14; 3 = 20; 4 = 85 }

$Esc = [char]27
function Strip([string]$Line) { return ($Line -replace "$Esc\[[0-9;]*m", '').TrimEnd() }  # цвета check_integrations

function Move-Assistant {
    # как setup.ps1: в постоянную папку; окружение Python и .git не копируем, .env на месте не затираем
    New-Item -ItemType Directory -Force $Target | Out-Null
    $rc = @($Here, $Target, '/E', '/XD', (Join-Path $Here 'shared\.venv'), (Join-Path $Here '.git'), '/NFL', '/NDL', '/NJH', '/NJS', '/NP')
    if (Test-Path (Join-Path $Target '.env')) { $rc += @('/XF', '.env') }
    & robocopy @rc | Out-Null
    if ($LASTEXITCODE -ge 8) { throw "не удалось скопировать помощника в $Target (код robocopy $LASTEXITCODE)" }
}

function Start-Install {
    Show-Page 3; Set-Buttons 'running'
    $script:Lines.Clear(); $log.Clear(); $progress.Value = 2; $runTitle.Text = 'Готовлюсь к установке…'
    try {
        if ($NeedMove) {
            $runStatus.Text = "Переношу помощника в постоянную папку $Target…"; $form.Refresh()
            Move-Assistant
        }
        $psi = New-Object Diagnostics.ProcessStartInfo
        $psi.FileName = 'powershell.exe'
        $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $InstallRoot 'windows\setup.ps1')`" -Gui"
        $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
        $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.RedirectStandardInput = $true
        $psi.StandardOutputEncoding = [Text.Encoding]::UTF8; $psi.StandardErrorEncoding = [Text.Encoding]::UTF8
        $psi.WorkingDirectory = $InstallRoot
        if (-not $keepKey.Checked -and $keyBox.Text.Trim()) { $psi.EnvironmentVariables['MAGNIT_LLM_API_KEY'] = $keyBox.Text.Trim() }
        foreach ($k in $TokenBoxes.Keys) {
            $v = $TokenBoxes[$k].Text.Trim()
            if ($v) { $psi.EnvironmentVariables["MAGNIT_SET_$k"] = $v }
        }
        if ($script:CertsConsent) { $psi.EnvironmentVariables['MAGNIT_CERTS_CONSENT'] = '1' }
        $psi.EnvironmentVariables['PYTHONIOENCODING'] = 'utf-8'
        $script:Proc = [Diagnostics.Process]::Start($psi)
        [MagnitGui]::Attach($script:Proc)
        for ($i = 0; $i -lt 6; $i++) { $script:Proc.StandardInput.WriteLine('') }  # вопросы выбора — ответ по умолчанию
        $script:Proc.StandardInput.Close()
        $timer.Start()
    } catch {
        Show-Result 'failed' @("Не удалось начать установку: $($_.Exception.Message)")
    }
}

function On-Line([string]$Line) {
    $clean = Strip $Line
    $script:Lines.Add($clean)
    $log.AppendText($clean + "`r`n")
    if ($clean -match '── Шаг (\d) из 4 · (.+?) ─') {
        $runTitle.Text = "Шаг $($Matches[1]) из 4 · $($Matches[2])"
        $progress.Value = [Math]::Max($progress.Value, $StepPercent[[int]$Matches[1]])
        return
    }
    $t = $clean.Trim()
    if (-not $t -or $t -match '^[╔╚║═─]' -or $t -match '^\+ ' -or $t -match '^(Using|Activate|Resolved|Prepared|Installed|Bytecode|Creating)') {
        if ($t -match '^Installed Python') { $progress.Value = [Math]::Max($progress.Value, 35) }
        if ($t -match '^Prepared \d+ packages') { $progress.Value = [Math]::Max($progress.Value, 60) }
        if ($t -match '^Installed \d+ packages') { $progress.Value = [Math]::Max($progress.Value, 70) }
        return
    }
    if ($t -match 'Устанавливаю библиотеки') { $progress.Value = [Math]::Max($progress.Value, 40) }
    if ($t -match 'Скачиваю Goose') { $progress.Value = [Math]::Max($progress.Value, 75) }
    if ($t -match 'Настраиваю Goose') { $progress.Value = [Math]::Max($progress.Value, 88) }
    if ($t -match 'Проверка интеграций') { $progress.Value = [Math]::Max($progress.Value, 95) }
    if ($t.Length -gt 140) { $t = $t.Substring(0, 140) + '…' }
    $runStatus.Text = $t
}

function Show-Result([string]$Kind, [string[]]$Details) {
    $timer.Stop()
    Show-Page 4
    switch ($Kind) {
        'success' {
            $doneTitle.Text = '✓  Помощник установлен'; $doneTitle.ForeColor = $Green
            $doneText.Text = "Запустите его кнопкой «Запустить» или потом: «Пуск» → ИИ-помощник.`r`n`r`n" +
                "Сменить ключ, подключить Jira, Confluence, Tag: «Пуск» → Настройки ИИ-помощника.`r`n`r`nПапка помощника: $InstallRoot"
        }
        'partial' {
            $doneTitle.Text = '!  Установка завершена не полностью'; $doneTitle.ForeColor = $Amber
            $doneText.Text = "Не получилось скачать:`r`n" + (($Details | ForEach-Object { "  •  $_" }) -join "`r`n") +
                "`r`n`r`nПроверьте VPN (FortiClient или NetBird) и интернет и нажмите «Повторить» — уже скачанное повторно не скачивается."
        }
        default {
            $doneTitle.Text = '✗  Установка не завершена'; $doneTitle.ForeColor = $Red
            $doneText.Text = (($Details | Select-Object -First 6) -join "`r`n") +
                "`r`n`r`nИсправьте причину и нажмите «Повторить». Если не получается — «Текстовый режим» внизу или снимок окна (Win + Shift + S) ответственному за помощника."
        }
    }
    Set-Buttons $Kind
    $script:Result = $Kind
}

function Finish-Install {
    $code = $script:Proc.ExitCode
    $text = $script:Lines
    if ($code -eq 0 -and ($text | Where-Object { $_ -match 'Помощник установлен' })) { Show-Result 'success' @(); return }
    if ($text | Where-Object { $_ -match 'Установка завершена не полностью' }) {
        $items = @($text | Where-Object { $_ -match '^\s*║\s+·\s+(.+?)\s*║\s*$' } | ForEach-Object { ($_ -replace '^\s*║\s+·\s+', '' -replace '\s*║\s*$', '') })
        Show-Result 'partial' $items; return
    }
    $errors = @($text | Where-Object { $_ -match '✗' } | ForEach-Object { ($_ -replace '^\s*✗\s*', '').Trim() })
    if (-not $errors) { $errors = @("Установщик завершился с кодом $code. Подробности — по ссылке ниже.") }
    Show-Result 'failed' $errors
}

$timer = New-Object Windows.Forms.Timer
$timer.Interval = 150
$timer.add_Tick({
    try {
        $line = $null
        $n = 0
        while ($n -lt 200 -and [MagnitGui]::Lines.TryDequeue([ref]$line)) { On-Line $line; $n++ }
        if ($script:Proc -and $script:Proc.HasExited -and [MagnitGui]::Lines.IsEmpty) { Finish-Install }
    } catch { Show-Result 'failed' @("Ошибка окна установщика: $($_.Exception.Message)") }
})

# ---------- кнопки ----------
$btnNext.add_Click({
    try {
        switch ($script:State) {
            'wizard' {
                if ($script:Page -eq 1 -and -not $keepKey.Checked) {
                    $key = $keyBox.Text.Trim()
                    if (-not $key) { $keyStatus.ForeColor = $Red; $keyStatus.Text = 'Вставьте ключ MagnitGPT (начинается с sk-).'; return }
                    $keyStatus.ForeColor = $Muted; $keyStatus.Text = 'Проверяю ключ…'; $btnNext.Enabled = $false
                    $form.Cursor = 'WaitCursor'; $form.Refresh()
                    $check = Test-Key $key
                    $form.Cursor = 'Default'; $btnNext.Enabled = $true
                    switch ($check) {
                        'token' { $keyStatus.ForeColor = $Red; $keyStatus.Text = 'Ключ не принят. Скопируйте его целиком — от sk- до конца — и вставьте ещё раз.'; return }
                        'net' { $keyStatus.ForeColor = $Red; $keyStatus.Text = 'Нет связи с MagnitGPT. Проверьте, что VPN (FortiClient или NetBird) подключён, и нажмите «Далее» ещё раз.'; return }
                        'cert' {
                            $answer = [Windows.Forms.MessageBox]::Show($form,
                                "Этот компьютер не доверяет корпоративным сертификатам (так бывает на личных компьютерах). Без них помощник не сможет работать.`r`n`r`nДобавить корпоративные сертификаты в доверенные для вашей учётной записи? Windows покажет предупреждение для каждого — нажмите «Да».",
                                'Корпоративные сертификаты', 'YesNo', 'Question')
                            if ($answer -ne 'Yes') { $keyStatus.ForeColor = $Red; $keyStatus.Text = 'Без корпоративных сертификатов установка невозможна.'; return }
                            $script:CertsConsent = $true
                        }
                        default { $keyStatus.ForeColor = $Green; $keyStatus.Text = '✓ Ключ принят' }
                    }
                }
                if ($script:Page -eq 2) { Start-Install; return }
                Show-Page ($script:Page + 1); Set-Buttons 'wizard'
                if ($script:Page -eq 1 -and $keyBox.Enabled) { $keyBox.Focus() }
            }
            'success' {
                $lnk = Join-Path $StartMenu 'ИИ-помощник.lnk'
                if (Test-Path $lnk) { Start-Process $lnk } else { Start-Process (Join-Path $InstallRoot 'Запустить агента (Windows).cmd') }
                $form.Close()
            }
            'details' { Show-Page 4; Set-Buttons $script:Result }
            default { Start-Install }  # partial, failed — повторить
        }
    } catch {
        [Windows.Forms.MessageBox]::Show($form, "Ошибка: $($_.Exception.Message)", 'ИИ-помощник', 'OK', 'Error') | Out-Null
    }
})
$btnBack.add_Click({ if ($script:Page -gt 0) { Show-Page ($script:Page - 1); Set-Buttons 'wizard' } })
$btnCancel.add_Click({
    if ($script:State -eq 'running') {
        $a = [Windows.Forms.MessageBox]::Show($form, 'Прервать установку? Уже скачанное сохранится, продолжить можно позже.', 'ИИ-помощник', 'YesNo', 'Question')
        if ($a -ne 'Yes') { return }
        try { Start-Process taskkill -ArgumentList '/PID', $script:Proc.Id, '/T', '/F' -NoNewWindow -Wait } catch { }
        Show-Result 'failed' @('Установка прервана.')
        return
    }
    $form.Close()
})
# Инструкция со снимками (лежит в корне помощника) — сразу на разделе текущего шага: …html#key
$GuideName = 'Инструкция по установке (Windows).html'
function Get-GuideAnchor {
    switch ($script:State) {
        'wizard'  { return @('welcome', 'key', 'systems')[$script:Page] }
        'running' { return 'wait' }
        'success' { return 'done' }
        default   { return 'trouble' }  # partial, failed, details
    }
}
function Open-Guide {
    $file = @((Join-Path $Root $GuideName), (Join-Path $InstallRoot $GuideName)) | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $file) {
        [Windows.Forms.MessageBox]::Show($form, "Не нашёл файл «$GuideName» в папке помощника. Попросите его у ответственного за помощника.",
            'ИИ-помощник', 'OK', 'Information') | Out-Null
        return
    }
    $url = ([Uri]$file).AbsoluteUri + '#' + (Get-GuideAnchor)
    # Файл с «#раздел» Windows открывает без раздела — запускаем браузер по умолчанию (или Edge) с адресом целиком
    $cmd = ''
    try {
        $progId = (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice' -ErrorAction Stop).ProgId
        $cmd = (Get-ItemProperty "Registry::HKEY_CLASSES_ROOT\$progId\shell\open\command" -ErrorAction Stop).'(default)'
    } catch { }
    if ($cmd -match '^\s*"([^"]+)"\s*(.*)$' -or $cmd -match '^\s*(\S+)\s*(.*)$') {
        $exe = $Matches[1]; $rest = $Matches[2]
        $line = if ($rest -match '%1') { $rest.Replace('%1', $url) } else { "$rest `"$url`"".Trim() }
        try { Start-Process $exe -ArgumentList $line; return } catch { }
    }
    foreach ($edge in "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") {
        if (Test-Path $edge) { Start-Process $edge -ArgumentList "`"$url`""; return }
    }
    Start-Process $file  # без раздела, но инструкция откроется
}
$linkHelp.add_LinkClicked({ try { Open-Guide } catch { Start-Process (Join-Path $Root $GuideName) } })
$linkText.add_LinkClicked({
    if ($script:State -eq 'running') { return }
    $form.Hide()
    Start-Process cmd.exe -ArgumentList '/c', "`"$(Join-Path $InstallRoot 'windows\Установщик в текстовом режиме (Windows).cmd')`""
    $form.Close()
})
$form.add_FormClosing({
    param($s, $e)
    if ($script:State -eq 'running' -and $script:Proc -and -not $script:Proc.HasExited) {
        $a = [Windows.Forms.MessageBox]::Show($form, 'Установка ещё идёт. Прервать её и закрыть окно?', 'ИИ-помощник', 'YesNo', 'Question')
        if ($a -ne 'Yes') { $e.Cancel = $true; return }
        try { Start-Process taskkill -ArgumentList '/PID', $script:Proc.Id, '/T', '/F' -NoNewWindow -Wait } catch { }
    }
})

$form.ResumeLayout()
# Запуск «скрытым» (ярлык, Планировщик, start /min) передаётся первому показу окна — окно осталось бы невидимым.
# Показываем его явно и выводим вперёд; консоль PowerShell, если видна, прячем.
$form.add_Shown({
    [void][MagnitGui]::ShowWindow($form.Handle, 5)
    $form.TopMost = $true; $form.Activate(); $form.TopMost = $false
    [void][MagnitGui]::SetForegroundWindow($form.Handle)
    $console = [MagnitGui]::GetConsoleWindow()
    if ($console -ne [IntPtr]::Zero) { [void][MagnitGui]::ShowWindow($console, 0) }
})
Show-Page 0; Set-Buttons 'wizard'
if ($env:MAGNIT_GUI_PAGE) { Show-Page ([int]$env:MAGNIT_GUI_PAGE); Set-Buttons 'wizard' }  # снимки для инструкции
try {
    [void]$form.ShowDialog()
} catch {
    Start-TextMode $_.Exception.Message
}
