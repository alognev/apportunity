﻿# Агент B на Windows: Goose CLI на корпоративной модели (аналог agent-b-goose/magnit-goose для macOS).
#   magnit-goose                — интерактивная сессия в текущей папке
#   magnit-goose run -t "…"     — разовое задание
# Переменные окружения переопределяют config.yaml Goose, поэтому изменения в .env применяются сразу.
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Programs = if ($env:MAGNIT_PROGRAMS) { $env:MAGNIT_PROGRAMS } else { Join-Path $env:LOCALAPPDATA 'Programs' }
$Goose = Join-Path $Programs 'Goose\dist-windows\resources\bin\goose.exe'
$EnvFile = Join-Path $Root '.env'
if (-not (Test-Path $EnvFile)) { Write-Host "Не найден $EnvFile — запустите «Установить агента (Windows)»." -ForegroundColor Red; exit 1 }
if (-not (Test-Path $Goose)) { Write-Host 'Goose не установлен — запустите «Установить агента (Windows)».' -ForegroundColor Red; exit 1 }

$cfg = @{}
foreach ($line in [IO.File]::ReadAllLines($EnvFile, [Text.UTF8Encoding]::new($false))) {
    if ($line -match '^\s*([A-Za-z_][A-Za-z0-9_]*)=(.*)$') { $cfg[$Matches[1]] = $Matches[2].Trim().Trim('"', "'") }
}
if (-not $cfg['LLM_API_KEY']) { Write-Host "В $EnvFile не задан LLM_API_KEY." -ForegroundColor Red; exit 1 }
$model = if ($cfg['LLM_MODEL']) { $cfg['LLM_MODEL'] } else { 'MagnitCopilot-Small' }
$maxTokens = if ($cfg['LLM_MAX_OUTPUT_TOKENS']) { $cfg['LLM_MAX_OUTPUT_TOKENS'] } else { '8192' }

# Провайдер litellm: лимит контекста каждой модели Goose берёт у LiteLLM (иначе 128 тыс.)
$env:GOOSE_PROVIDER = 'litellm'
$env:GOOSE_MODEL = $model
$env:LITELLM_HOST = $cfg['LLM_BASE_URL'].TrimEnd('/')
$env:LITELLM_BASE_PATH = 'v1/chat/completions'
$env:LITELLM_API_KEY = $cfg['LLM_API_KEY']
$env:GOOSE_MAX_TOKENS = $maxTokens
$env:PYTHONUTF8 = '1'
# Ключи Langfuse агенту не передаём: иначе Goose включит свою прямую отправку в Langfuse
foreach ($k in 'LANGFUSE_PUBLIC_KEY', 'LANGFUSE_SECRET_KEY', 'LANGFUSE_BASE_URL', 'LANGFUSE_HOST', 'LANGFUSE_URL') {
    Remove-Item "Env:$k" -ErrorAction SilentlyContinue
}

$gooseArgs = if ($args.Count -eq 0) { @('session') } else { $args }
& $Goose @gooseArgs
exit $LASTEXITCODE
