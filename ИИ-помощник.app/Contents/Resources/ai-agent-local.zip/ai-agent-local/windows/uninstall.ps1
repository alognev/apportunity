﻿# Полное удаление ИИ-помощника с Windows (аналог uninstall.sh): папка помощника с токенами, Goose с настройками и
# историей, Python и uv от установщика, модель поиска, базы знаний, автоматизации, ярлыки, ключи в «Диспетчере учётных
# данных». После этого установка пойдёт с нуля. Права администратора не нужны.
#   «Удалить помощника (Windows).cmd» или «Пуск» → ИИ-помощник → Удалить ИИ-помощника — спросит подтверждение
#   uninstall.ps1 -Yes      — без вопроса
#   uninstall.ps1 -DryRun   — только показать, что будет удалено
# Не трогает: рабочую папку с вашими файлами (magnit-agent-workspace), корпоративные сертификаты и рабочую копию git.
# Файл в UTF-8 с BOM: иначе PowerShell 5.1 читает русский текст в кодировке ANSI.
param([switch]$Yes, [switch]$DryRun)
$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
Set-Location $env:TEMP  # из удаляемой папки нужно выйти: Windows не удаляет текущую папку процесса

$Root = Split-Path -Parent $PSScriptRoot
$Programs = if ($env:MAGNIT_PROGRAMS) { $env:MAGNIT_PROGRAMS } else { Join-Path $env:LOCALAPPDATA 'Programs' }
$StartMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\ИИ-помощник'
$Profile_ = $env:USERPROFILE
# Встроенные навыки: русские имена и прежние латинские (установки до 22.10)
$Skills = 'деловое-письмо', 'поиск-в-confluence', 'отчет-по-таблицам', 'задача-в-jira', 'разбор-почты', 'протокол-встречи',
    'рутина-по-спеке', 'данные-из-teradata',
    'business-letter', 'confluence-research', 'data-report', 'jira-task', 'mail-digest', 'meeting-protocol', 'spec-routine', 'teradata'

function Step([string]$Text) { Write-Host $Text -ForegroundColor White }
function Remove-Path([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    if ($DryRun) { Write-Host "  удалю: $Path"; return }
    Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path -LiteralPath $Path) { Write-Host "  не удалось удалить (занято?): $Path" -ForegroundColor Yellow }
}
function Remove-Link([string]$Path) {
    # Только сама ссылка (junction/symlink): Remove-Item -Recurse в PowerShell 5.1 удалил бы и содержимое папки, куда она ведёт
    $item = Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
    if (-not $item -or -not ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { return }
    if ($DryRun) { Write-Host "  удалю ссылку: $Path"; return }
    [IO.Directory]::Delete($Path, $false)
}

# Папки помощника: из которой запущено удаление и стандартная; рабочую копию разработчика (git) не трогаем
$helperDirs = @($Root, (Join-Path $Profile_ 'ai-agent-local')) | Select-Object -Unique |
    Where-Object { (Test-Path (Join-Path $_ 'windows\setup.ps1')) -and -not (Test-Path (Join-Path $_ '.git')) }

if (-not $Yes -and -not $DryRun) {
    Write-Host 'Будут удалены ИИ-помощник, Goose (программа, настройки, история чатов), ключи и токены, модель поиска,'
    Write-Host 'базы знаний и автоматизации. Ваши файлы в папке magnit-agent-workspace останутся.'
    if ((Read-Host 'Удалить всё? Напечатайте «да» (или y)').Trim().ToLower() -notin 'да', 'д', 'yes', 'y') {
        Write-Host 'Отменено.'; exit 0
    }
}
if ($DryRun) { Write-Host 'Проверка (-DryRun): ничего не удаляется, только список.' -ForegroundColor Yellow }

Step 'Останавливаю Goose и помощника...'
$mine = @($Programs) + $helperDirs
Get-CimInstance Win32_Process | Where-Object {
    $exe = $_.ExecutablePath
    $exe -and ($mine | Where-Object { $exe.StartsWith($_, [StringComparison]::OrdinalIgnoreCase) })
} | ForEach-Object {
    if ($DryRun) { Write-Host "  остановлю: $($_.Name) ($($_.ProcessId))" }
    else { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}
if (-not $DryRun) { Start-Sleep -Seconds 2 }

Step 'Автоматизации и ретранслятор трассировки (Планировщик заданий)...'
try {
    $service = New-Object -ComObject Schedule.Service
    $service.Connect()
    $folder = $service.GetFolder('\MagnitAgent')
    foreach ($task in @($folder.GetTasks(1))) {
        if ($DryRun) { Write-Host "  удалю задание: \MagnitAgent\$($task.Name)" }
        else { try { $task.Stop(0) } catch {}; $folder.DeleteTask($task.Name, 0) }
    }
    if (-not $DryRun) { try { $service.GetFolder('\').DeleteFolder('MagnitAgent', 0) } catch {} }
} catch { }  # папки \MagnitAgent нет — автоматизаций не было

Step 'Переменные среды трассировки...'
foreach ($name in 'OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT', 'OTEL_METRICS_EXPORTER', 'OTEL_LOGS_EXPORTER') {
    if ([Environment]::GetEnvironmentVariable($name, 'User') -ne $null) {
        if ($DryRun) { Write-Host "  удалю переменную: $name" }
        else { [Environment]::SetEnvironmentVariable($name, $null, 'User') }  # сама рассылает WM_SETTINGCHANGE
    }
}

Step 'Ключи в «Диспетчере учётных данных» (Magnit Copilot для Goose, пароль Teradata)...'
foreach ($line in (cmdkey /list)) {
    if ($line -match 'target=(\S*(secrets\.goose|\.magnit-agent-teradata))\s*$') {
        if ($DryRun) { Write-Host "  удалю запись: $($Matches[1])" } else { cmdkey "/delete:$($Matches[1])" | Out-Null }
    }
}

Step 'Ярлыки в меню «Пуск»...'
Remove-Path $StartMenu

Step 'Goose: программа, настройки, история чатов, навыки...'
Remove-Path (Join-Path $Programs 'Goose')
Remove-Path (Join-Path $env:APPDATA 'Block\goose')
Remove-Path (Join-Path $env:APPDATA 'Goose')          # данные окна приложения (Electron)
foreach ($s in $Skills) { Remove-Link (Join-Path $Profile_ ".agents\skills\$s") }

Step 'Данные помощника (модель поиска, базы знаний, журналы, автоматизации)...'
Remove-Path (Join-Path $Profile_ '.magnit-agent')

Step 'Папка помощника (токены, окружение Python)...'
foreach ($d in $helperDirs) { Remove-Path $d }
foreach ($d in @($Root, (Join-Path $Profile_ 'ai-agent-local')) | Select-Object -Unique) {
    if (Test-Path (Join-Path $d '.git')) { Write-Host "  рабочая копия git — не трогаю: $d" -ForegroundColor Yellow }
}

Step 'Python и uv от установщика...'
Remove-Path (Join-Path $Programs 'uv')

Write-Host ''
if ($DryRun) { Write-Host 'Проверка закончена: ничего не удалено.' -ForegroundColor Green; exit 0 }
Write-Host 'Готово. ИИ-помощник и Goose удалены. Установить заново — командой из инструкции.' -ForegroundColor Green
Write-Host 'Остались: папка magnit-agent-workspace (ваши файлы) и корпоративные сертификаты, если их добавляли'
Write-Host '(удалить вручную: Win+R → certmgr.msc → Доверенные корневые центры сертификации → Сертификаты).'
