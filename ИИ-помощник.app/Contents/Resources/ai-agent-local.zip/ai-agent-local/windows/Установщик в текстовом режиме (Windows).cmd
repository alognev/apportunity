@echo off
rem Text-mode installer (console). Used automatically when the installer window cannot open on this computer.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" %*
echo.
pause
exit /b
