﻿# Address lookup during setup, including verified profiles created from chat.
function Get-ConnectionAddress([string]$Prefix) {
    $default = ''
    foreach ($row in $ConnectionRows) {
        if ($row[0] -eq ($Prefix + '_TOKEN')) { $default = $row[4]; break }
    }
    $python = Join-Path $InstallRoot 'shared\.venv\Scripts\python.exe'
    if (Test-Path -LiteralPath $python -PathType Leaf) {
        $address = & $python (Join-Path $InstallRoot 'shared\connection_login.py') address ($Prefix.ToLowerInvariant()) 2>$null
        if ($LASTEXITCODE -eq 0 -and $address -match '^https://') { return [string]$address }
    }
    $savedProfileFile = Join-Path $ConnectionDir ($Prefix + '_TOKEN')
    if (Test-Path -LiteralPath $savedProfileFile -PathType Leaf) {
        $raw = [IO.File]::ReadAllText($savedProfileFile)
        if ($raw.StartsWith('{"magnit_connection"')) {
            try {
                $parsed = ConvertFrom-Json -InputObject $raw
                if ($parsed.magnit_connection -eq 1 -and $parsed.settings.URL -match '^https://') { return [string]$parsed.settings.URL }
            } catch { }
        }
    }
    $file = Join-Path $ConnectionDir ($Prefix + '_URL')
    if (Test-Path -LiteralPath $file -PathType Leaf) {
        $value = [IO.File]::ReadAllText($file).Trim()
        if ($value -match '^https://') { return $value }
    }
    return $default
}
