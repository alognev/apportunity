﻿# Запуск помощника на Windows: приложение Goose в рабочей папке (AGENT_WORKSPACE из .env).
# Вызывается из «Запустить агента (Windows).cmd»; ярлык в «Пуске» запускает Goose так же, напрямую.
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Programs = if ($env:MAGNIT_PROGRAMS) { $env:MAGNIT_PROGRAMS } else { Join-Path $env:LOCALAPPDATA 'Programs' }
$GooseApp = Join-Path $Programs 'Goose\dist-windows\Goose.exe'
if (-not (Test-Path $GooseApp)) {
    Write-Host 'Помощник ещё не установлен: дважды щёлкните «Установить агента (Windows)».' -ForegroundColor Yellow
    exit 1
}
$ws = '~/magnit-agent-workspace'
$envFile = Join-Path $Root '.env'
if (Test-Path $envFile) {
    $line = [IO.File]::ReadAllLines($envFile) | Where-Object { $_.StartsWith('AGENT_WORKSPACE=') } | Select-Object -First 1
    if ($line -and $line.Substring(16).Trim()) { $ws = $line.Substring(16).Trim() }
}
if ($ws.StartsWith('~')) { $ws = Join-Path $HOME $ws.Substring(1).TrimStart('/', '\') }
New-Item -ItemType Directory -Force $ws | Out-Null
Start-Process -FilePath $GooseApp -ArgumentList '--dir', "`"$ws`"" -WorkingDirectory $ws
