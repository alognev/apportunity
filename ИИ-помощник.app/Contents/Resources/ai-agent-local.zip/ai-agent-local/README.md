# Локальные ИИ-агенты на корпоративной LLM

Три варианта локального агента. Каждый умеет:

- работать с файлами на компьютере: читать, создавать, редактировать;
- читать Excel, PDF (включая сканы), Word, PowerPoint и картинки;
- писать и запускать скрипты на Python и в shell;
- подключать удалённые MCP-серверы.

Все три используют одну корпоративную модель (по умолчанию `MagnitCopilot`, это `openai/PhalaCloud/GLM-5.2-W4AFP8`).

| | A. Claude Code | B. Goose | C. Свой агент (Agent SDK) |
|---|---|---|---|
| Папка | `agent-a-claude-code/` | `agent-b-goose/` | `agent-c-agent-sdk/` |
| Команда | `magnit-claude` | `magnit-goose` | `magnit-agent` / `magnit-agent web` |
| Интерфейс | терминал | терминал + приложение Goose Desktop | терминал + веб-чат в браузере |
| Что это | готовый агент Anthropic | готовый open-source агент (Block) | наш код на Claude Agent SDK |
| Настраиваемость | настройки, хуки, MCP | настройки, расширения, рецепты | полностью наш код: UI, права, логика |
| Подтверждение действий | да, в терминале | да (режим `smart_approve`) | да, в терминале и кнопками в вебе |

## Установка на рабочий компьютер

> Пошаговая инструкция для пользователей без технического опыта: [ИНСТРУКЦИЯ.md](ИНСТРУКЦИЯ.md). Для них же в корне лежат файлы «Установить агента», «Запустить агента» (открывает Goose в рабочей папке) и «Запустить веб-помощника», которые запускаются двойным щелчком. По умолчанию (Enter) устанавливается агент B — Goose. Скачанный архив macOS помечает карантином и не запускает `.command` («файл повреждён»): один раз выполните `xattr -dr com.apple.quarantine <папка>` (или запустите `bash setup.sh` из Терминала — установщик снимает карантин сам).

Нужны macOS, подключённый VPN NetBird, Python 3.11+ и [Homebrew](https://brew.sh) (для Goose).

```bash
git clone <репозиторий> ~/ai-agent-local   # или скопируйте папку
cd ~/ai-agent-local
./setup.sh
```

Скрипт:
1. Спросит адрес шлюза, **ваш персональный токен** и модель, затем сохранит их в `.env`.
2. Проверит доступ к шлюзу и покажет модели, доступные вашему токену.
3. Установит выбранных агентов. Команды появятся в `~/.local/bin`.

Повторная настройка: `./setup.sh --reconfigure`. Установить только часть агентов: `./setup.sh a c`.

## Настройки: `.env`

Один файл на всех агентов. Хост, токен и модели можно поменять в любой момент.

| Переменная | По умолчанию | Назначение |
|---|---|---|
| `LLM_BASE_URL` | `https://llmlite.ailab-copilot-prod.corp.tander.ru` | OpenAI-совместимый шлюз (LiteLLM) |
| `LLM_API_KEY` | — | персональный токен |
| `LLM_MODEL` | `MagnitCopilot` | основная модель |
| `LLM_FAST_MODEL` | `MagnitCopilotFlash` | вспомогательные задачи (заголовки, сжатие контекста) |
| `LLM_VISION_MODEL` | `MagnitCopilot-VL` | анализ картинок и сканов |
| `LLM_MAX_OUTPUT_TOKENS` | `8192` | лимит длины ответа |
| `AGENT_WORKSPACE` | `~/magnit-agent-workspace` | рабочая папка веб-интерфейса агента C |

Агенты A и C подхватывают изменения сразу. Для Goose Desktop после правки `.env` выполните `agent-b-goose/install.sh`. Консольный `magnit-goose` берёт значения из `.env` сам.

## Удалённые MCP-серверы: `remote-mcp.json`

Один файл для всех трёх агентов (формат Claude, пример в `remote-mcp.example.json`):

```json
{
  "mcpServers": {
    "crm": {
      "type": "http",
      "url": "https://mcp.example.corp/mcp",
      "headers": { "Authorization": "Bearer ${CRM_MCP_TOKEN}" }
    }
  }
}
```

Секреты задавайте через `${ПЕРЕМЕННАЯ}`, а саму переменную добавьте в `.env`. Для Goose после изменения файла выполните `agent-b-goose/install.sh`.

## Интеграции (аналог возможностей MagnitGPT)

Подключаются ко всем трём агентам через реестр `shared/mcp_registry.py`. Интеграция включается автоматически, как только в `.env` заполнен её токен. Проверка: `shared/.venv/bin/python shared/check_integrations.py`.

| MagnitGPT | У нас | MCP-сервер | Авторизация |
|---|---|---|---|
| Jira + Confluence (облачный MCP AI Lab, выключено по умолчанию — Goose включает сам) | поиск (JQL/CQL), чтение, создание, комментарии, статусы — компактный набор из 16 инструментов | `atlassian` (ОМНИ: track + eportal), `atlassian-it` (jira.corp + IT-портал) — локальный мост к `mcp-atlassian.ailab-copilot-prod` | те же PAT, передаются в заголовках |
| GitLab (облачный MCP AI Lab, выключено по умолчанию) | репозитории, файлы, ветки, коммиты, MR, issues, комментарии, code review — компактный набор из 23 инструментов, удаление убрано | `gitlab` (coderepo.corp.tander.ru), `gitlab-platform` (gitlab.platform.corp) — локальный мост к `mcp-gitlab*.ailab-copilot-prod` | `GITLAB_TOKEN`, `GITLAB_PLATFORM_TOKEN` (Access Token, scope api); `GITLAB_PROFILE`, `GITLAB_GROUPS` |
| Базы данных (DBHub, выключено по умолчанию) | SQL только на чтение (SELECT/WITH/EXPLAIN/SHOW) и поиск объектов схемы по базам из списка | `dbhub` — локальный DBHub 1.4 (Node.js, `shared/.dbhub`), конфиг генерируется в `~/.magnit-agent/dbhub.toml` с `readonly = true` для каждой базы | `databases.toml` (личный, не в архиве; шаблон `databases.example.toml`); `./setup.sh --databases` |
| Jira (локально, резерв; скрыто, `SHOW_LOCAL_ATLASSIAN=1`) | поиск (JQL), чтение, создание, комментарии, статусы, спринты | `jira`, `jira-it` (mcp-atlassian) | `JIRA_TOKEN`, `JIRA_IT_TOKEN` (PAT) |
| Confluence (локально, резерв; скрыто, `SHOW_LOCAL_ATLASSIAN=1`) | живой поиск (CQL), страницы, вложения, создание страниц | `confluence-it`, `confluence-eportal` | `CONFLUENCE_*_TOKEN` (PAT) |
| Tag | отправка сообщений и файлов себе, коллегам, в каналы; чтение своих чатов | `tag` | `TAG_BOT_TOKEN` (бот по заявке в ШПС), либо `TAG_TOKEN` (личный маркер), либо `TAG_WEBHOOK_URL` (только отправка) |
| Knowledge, Заметки, ASR | заметки и протоколы встреч, базы знаний MagnitGPT, распознавание аудио | `magnitgpt` | `MAGNITGPT_API_KEY` |
| Knowledge (локально) | базы знаний из папок: гибридный поиск — по смыслу (эмбеддинги) и по словам (FTS5 + морфология) | `knowledge` | — |
| Календарь | Outlook/Exchange: встречи, свободное время коллег, приглашения | `calendar` | Kerberos (без пароля) |
| Почта (выключено по умолчанию, Goose включает сам) | Outlook/Exchange, только чтение: список и поиск писем, текст, сохранение вложений; письма не помечаются прочитанными, отправки нет. Навык `mail-digest` | `mail` | Kerberos (без пароля) |
| Magnit Drive (выключено по умолчанию, Goose включает сам) | drive.magnit.ru (Nextcloud): рабочая папка команды (по умолчанию `/MCOS`, своя — `drive_set_folder` или `DRIVE_DIR`), спеки для помощника, поиск, чтение, скачивание, загрузка и сохранение файлов, создание папок; удаления нет, замена — только явно. Навык `spec-routine` | `drive` (WebDAV) | вход в браузере корпоративной учётной записью (Login Flow v2) → пароль приложения в `~/.magnit-agent/drive-auth.json` |
| Автоматизация | задания по расписанию (launchd) → отчёт в файл, уведомление, Tag | `scheduler` | — |
| Поиск в интернете | поиск, новости, чтение страниц | `web` | — |
| Skills | общие навыки `shared/skills/*/SKILL.md` + личные `~/.magnit-agent/skills` | — | — |
| Папки | `CLAUDE.md` (агенты A, C) / `.goosehints` (B) в рабочей папке — общий промпт проекта | — | — |
| Генерация изображений | нет: у команды нет модели, у группы нет права в MagnitGPT | — | — |

**Права.** Чтение (поиск, просмотр) выполняется без подтверждения. Любые изменения — создание задач и страниц, сообщения, встречи — только после подтверждения пользователя (`auto_allowed` в реестре; в Goose по `readOnlyHint`). Удаление задач и страниц отключено.

**Автоматизации** выполняются без подтверждения действий (их создание подтверждает пользователь). CLI: `shared/.venv/bin/python shared/scheduler.py list|create|run|pause|resume|delete`.

## Раздача пользователям: установка одной командой

`./make-dist.sh` собирает в `dist/` три файла: `ai-agent-local.zip` (архив без секретов), `install.sh` (установщик
с адресом загрузки и контрольной суммой архива) и `УСТАНОВКА.md` (краткая инструкция с готовой командой).

Раздача идёт из этого же репозитория: `https://gitlab.platform.corp/magnitonline/mcos/shared/ai-agent-local`, папка `dist/`.

1. Адрес загрузки записан в `.dist-url` (шаблон GitLab API, `{file}` заменяется именем файла):
   `https://gitlab.platform.corp/api/v4/projects/7013/repository/files/dist%2F{file}/raw?ref=main`.
2. Выпуск новой версии: `./make-dist.sh`, затем закоммитить и отправить `dist/` (всегда `install.sh` и архив вместе —
   установщик проверяет SHA-256 архива): `git add -A && git commit -m "…" && git push`.
3. Команду для пользователей печатает `make-dist.sh`, она же — в `dist/УСТАНОВКА.md`. Проект закрытый, поэтому в команде
   нужен токен GitLab с правом `read_repository` (личный токен участника проекта или токен доступа проекта —
   Settings → Access tokens, роль Reporter). Если сделать проект публичным, команда работает и без токена.

### Приложение «ИИ-помощник.app»

`make-dist.sh` дополнительно собирает `dist/AI-Assistant.app.zip` — приложение-оболочку (AppleScript, `app/`):
первый запуск — установка с вопросами в окнах (токен LLM, выбор систем и их токены, полоса прогресса), дальше —
2 секунды показывается окно с кнопками «Настройки…» и «Запустить», без нажатия открывается Goose; с зажатой
клавишей ⌥ Option настройки открываются сразу — меню настроек (подключить системы, активные
инструменты, проверка, смена токена LLM, обновление). Если настройки ни разу не показывались (помощник ставили из
Терминала, нет отметки `~/.magnit-agent/configured`), меню откроется один раз само.
Внутри приложения лежит архив помощника; `launcher.sh` распаковывает его в `~/ai-agent-local` (или обновляет, если
версия в приложении новее; рабочую копию git не трогает) и передаёт команды в `app/agentctl.sh` — там вся логика,
без вопросов в терминале (`state`, `set`, `check-llm`, `install`, `progress`, `tools`, `diagnose`, `update`, `launch`).
Секреты из окон передаются через файл с правами 600, а не через командную строку.
Установка приложения: та же команда с `export MAGNIT_MODE=app;` в начале — `install.sh` кладёт приложение в
«Программы» и открывает его. Подписи Apple Developer нет (подпись ad-hoc): приложение, скачанное браузером или
мессенджером, macOS заблокирует — раздавать командой либо подписать и нотаризовать.
Значок: `app/AppIcon.icns`. Сборка отдельно: `app/build-app.sh <архив> <версия> <папка>`.

Что делает `install.sh`: скачивает и распаковывает архив в `~/ai-agent-local` (существующую установку обновляет на
месте, `.env` и базы сохраняются), снимает карантин macOS, находит Python 3.11+ или ставит его через `uv` в домашнюю
папку (без Homebrew и sudo) и запускает `setup.sh b` в быстром режиме (`MAGNIT_QUICK=1`: спрашивается только токен LLM,
интеграции пропускаются клавишей Enter). Goose Desktop без Homebrew скачивается с GitHub (официальная подписанная
сборка). Прочие переменные: `MAGNIT_DIR` (куда ставить), `MAGNIT_DIST_URL` (другой адрес), `MAGNIT_NO_SETUP=1` (только файлы и Python).

## Активные инструменты (экономия контекста)

Описания инструментов каждой интеграции уходят модели в каждом запросе. Jira/Confluence по умолчанию идут через облачный Atlassian MCP AI Lab с компактным профилем (`ATLASSIAN_PROFILE=compact`, 16 инструментов, ~9 тыс. токенов на контур против ~16,4 тыс. у локальной пары; `full` — прежний набор из 42). Облако само по себе контекст не уменьшает — это тот же `mcp-atlassian`; экономия даёт фильтрация инструментов в локальном мосте (`mcp_launch.run_atlassian_cloud`), который также убирает удаление и пропускает вызовы через защиту. Локальные `jira*`/`confluence*` — резерв, в `DEFAULT_OFF` реестра. Замер (токенизатор e5, порядок величины): Jira — ~10,4 тыс. токенов (каждая), Confluence — ~6 тыс. (каждый портал), остальные — 0,5–1,7 тыс., всего ~39 тыс.

- **По умолчанию включены только** файлы, интернет, базы знаний и автоматизации (`DEFAULT_ON`, ~3 тыс. токенов). Остальное
  (календарь, почта, Tag, Jira+Confluence ×2, GitLab ×2, DBHub) выключено: Goose записывает их
  в конфиг выключенными с описанием (`DESCRIPTIONS`), и встроенный Extension Manager (`search_available_extensions` →
  `manage_extensions`) включает нужный на время сессии — проверено: вопрос про Jira → включил `atlassian` → `jira_search`.
  Включение идёт без вопроса: `configure.py` пишет `extensionmanager__manage_extensions` и `…search_available_extensions`
  в `user.always_allow` файла `~/.config/goose/permission.yaml` (`GOOSE_AUTO_ENABLE_EXTENSIONS=0` — спрашивать).
  Изменяющие действия внутри расширений по-прежнему спрашивают подтверждение и проходят защиту. Агенты A и C так не
  умеют — им инструменты включают вручную; автоматизации по расписанию запускаются с `MAGNIT_ALL_INTEGRATIONS=1`
  (все подключённые инструменты), потому что включить нужное в них некому.
- **Скрыты** локальные Jira/Confluence (`HIDDEN` в реестре): не показываются в установщике, приложении, веб-чате и не
  пишутся в Goose. Код сохранён; вернуть — `SHOW_LOCAL_ATLASSIAN=1` в `.env`.
- Выбор хранится в `.env`: `ENABLED_INTEGRATIONS=jira,calendar,...` (пусто — все доступные). `magnit-files` включён всегда. Логика — `mcp_registry.available()` (есть токены) и `enabled()` (выбрано).
- Установщик спрашивает выбор при первой установке, после ввода токенов и при `--reconfigure` (`shared/choose_integrations.py`); отдельно — `./setup.sh --tools`.
- **Goose:** в конфиг пишутся все доступные расширения, флаг `enabled` — по выбору. Переключения в интерфейсе («Расширения») сохраняются, пока не изменится выбор в `.env` (отметка в `~/.magnit-agent/goose-applied-integrations`).
- **Веб-помощник:** панель «Инструменты» (`GET/POST /api/integrations`), применяется в новом диалоге — настройки сессии перечитываются.

## Защита корпоративных систем

Проверка в коде, а не только в промпте: `shared/mcp_launch.py` для серверов, меняющих корпоративные системы (Jira ×2, Confluence ×2, calendar, tag, scheduler), работает посредником и пропускает каждый `tools/call` через `shared/guard.py`. Запрещённый вызов до сервера не доходит — агент получает `⛔ Заблокировано защитой: <причина>`. Действует во всех агентах, веб-помощнике и автоматизациях.

| Правило | По умолчанию | Настройка в `.env` |
|---|---|---|
| Выключатель защиты | включена | `GUARD_ENABLED=0` — выключить |
| Чужие задачи Jira (не автор и не исполнитель): update, transition, assign, link_to_epic | разрешено | `GUARD_FOREIGN_OBJECTS=deny` — запретить (останутся комментарии) |
| Чужие страницы Confluence (createdBy ≠ вы): update, add_label | разрешено | `GUARD_FOREIGN_OBJECTS=deny` |
| Всплеск изменений во всех системах | 200 в минуту | `GUARD_BURST_PER_MINUTE` |
| Jira: изменения / новые задачи | 200 / 200 в час | `GUARD_JIRA_WRITES_PER_HOUR`, `GUARD_JIRA_CREATES_PER_HOUR` |
| Confluence: изменения / новые страницы | 100 / 50 в час | `GUARD_CONFLUENCE_WRITES_PER_HOUR`, `GUARD_CONFLUENCE_CREATES_PER_HOUR` |
| Календарь: изменения / участников во встрече | 30 в час / 40 | `GUARD_CALENDAR_WRITES_PER_HOUR`, `GUARD_CALENDAR_MAX_ATTENDEES` |
| Tag: сообщения / из них в каналы | 50 / 50 в час | `GUARD_TAG_MESSAGES_PER_HOUR`, `GUARD_TAG_CHANNEL_POSTS_PER_HOUR` |
| GitLab: изменения (любой инструмент, кроме get_/list_/search_) | 200 в час | `GUARD_GITLAB_WRITES_PER_HOUR` |
| Автоматизаций всего | 100 | `GUARD_AUTOMATIONS_MAX` |

Лимит `0` — без ограничения. Владелец объекта проверяется запросом к API с токеном пользователя; если проверить не удалось — действие отклоняется. Счётчики общие для всех процессов (`~/.magnit-agent/guard.db`), журнал всех изменений и отказов — `~/.magnit-agent/audit.log` (пишется и при выключенной защите). Удаляющих инструментов нет вовсе.

**Обход через терминал и файлы** (агенты A и C): PreToolUse-хук `shared/shell_guard.py` блокирует curl/скрипты к корпоративным хостам и API, чтение `.env` и связки ключей, изменение `.env`, кода и настроек защиты.

**Ограничения:** у Goose встроенный терминал (расширение developer) хуками не перехватывается — там обход через терминал сдерживают только инструкции (`.goosehints`) и подтверждение команд в режиме `smart_approve`. Защита рассчитана на ошибки, prompt-инъекции и «массовость в один запрос»; пользователь со своими токенами может обратиться к API и без помощника — это вне зоны ответственности агента.

## Трассировка в Langfuse (необязательно)

Включается ключами проекта в `.env` (`LANGFUSE_PUBLIC_KEY`, `LANGFUSE_SECRET_KEY`, `LANGFUSE_BASE_URL`) и применяется
`agent-b-goose/configure.py` (его запускают установщик и приложение). Без ключей ничего не запускается.

```
Goose (Desktop/CLI, OTLP GenAI) ─┐
шлюз LiteLLM (агенты A, C) ──────┼─► 127.0.0.1:4319 ретранслятор ──► очередь на диске ──► Langfuse /api/public/otel
                                 │   (shared/langfuse_relay.py)       (~/.magnit-agent/langfuse-spool)
```

- **Агенты не видят ошибок.** Ретранслятор сразу отвечает «принято», в Langfuse шлёт в фоне. Нет доступа (NetBird, сеть) —
  трассы ждут и досылаются позже; очередь ≤ 200 МБ и 7 дней, лишнее удаляется молча. Журнал — `~/.magnit-agent/langfuse-relay.log`.
- **Ключи только у ретранслятора:** `shared/env.sh` и автоматизации убирают `LANGFUSE_*` из окружения агентов (иначе Goose
  включит свою прямую отправку). Goose получает адрес из `config.yaml` (`otel_exporter_otlp_endpoint`), Goose Desktop —
  переменные сеанса launchd (`launchctl setenv`, выставляет ретранслятор при входе в систему); шлюз — колбэк `langfuse_otel`.
- **Перед отправкой:** маскируются секреты (значения токенов из `.env`, пароль Drive, DSN баз, форматы `sk-`, `glpat-`,
  `Bearer …`); добавляются `langfuse.session.id` (разговор Goose), `langfuse.user.id` (логин macOS), окружение, версия,
  теги `goose|claude-gateway` + `chat|automation`, имя трассы `goose-chat`, `goose-automation`, `claude-gateway-chat`.
- **Сертификат:** Langfuse `*.plai.corp` выпущен центром plai.corp, которого нет в системе, — доверие задаёт
  `shared/certs-extra/plai-intermediate-ca.pem` (промежуточный, до 2031-05-13), связка ключей не меняется.
- **Другим пользователям (пилот):** ключ проекта одной строкой `pk-lf-…:sk-lf-…[@https://адрес]` — в приложении
  «Подключить системы → Трассировка (Langfuse)» (`agentctl.sh set LANGFUSE_KEYS`), в `setup.sh` (раздел интеграций)
  или в команде установки `export MAGNIT_LANGFUSE='pk-lf-…:sk-lf-…'; …` (install.sh → `~/.magnit-agent/langfuse-key` →
  .env при первой настройке, `shared/tracing.sh`). Новым пользователям по умолчанию `LANGFUSE_CAPTURE_CONTENT=0`;
  согласие на текст — окно приложения / вопрос установщика (`agentctl.sh tracing-content on|off`). Секретный ключ даёт
  чтение всего проекта — раздавать только в пилоте; для широкого запуска — центральный OTel Collector без раздачи ключей.
- Настройки: `LANGFUSE_CAPTURE_CONTENT=0` — без текста сообщений; `LANGFUSE_TRACING=0` — выключить;
  `LANGFUSE_TRACING_ENVIRONMENT`; `LANGFUSE_RELAY_PORT`. Состояние: `shared/.venv/bin/python shared/tracing.py status`.

## Как это устроено

```
                    ┌──────────── .env (хост, токен, модели) ─────────────┐
                    │                                                     │
 A. Claude Code ──┐ │                                                     │
                  ├─► локальный шлюз 127.0.0.1:4141 ──┐                   │
 C. Agent SDK ────┘   (Anthropic API → chat/compl.)   ├─► корпоративный LiteLLM
                                                      │   (MagnitCopilot)
 B. Goose ────────────────────────────────────────────┘
         │
 все три ├─► MCP magnit-files (shared/files_mcp.py): read_document, describe_image, ocr_pdf
         └─► удалённые MCP из remote-mcp.json
```

- **Локальный шлюз** (`shared/gateway.py`, LiteLLM) нужен агентам A и C. Они работают по протоколу Anthropic, а корпоративный шлюз корректно обрабатывает вызовы инструментов только через `/v1/chat/completions`. Шлюз запускается автоматически и слушает только `127.0.0.1`. Сертификаты берутся из системного хранилища macOS (`truststore`), поэтому корпоративные CA подхватываются сами.
- **magnit-files** (`shared/files_mcp.py`) — MCP-сервер для документов. Основная модель понимает только текст, поэтому документы конвертируются в Markdown (`markitdown`), а картинки и сканы PDF описывает `MagnitCopilot-VL`.
- **Python для скриптов агента** — `shared/.venv`. В нём уже есть pandas, openpyxl, matplotlib, python-docx, python-pptx, pypdf и reportlab.
- **Локальные базы знаний** (`shared/servers/knowledge_mcp.py`): документы → фрагменты по 1500 символов → SQLite `~/.magnit-agent/knowledge.db`. Поиск гибридный: BM25 (FTS5) по леммам `pymorphy3` + косинусная близость эмбеддингов, объединение Reciprocal Rank Fusion. Эмбеддинги (`shared/embeddings.py`): по умолчанию локальная `intfloat/multilingual-e5-small` (ONNX int8, ~115 МБ, CPU; скачивается при установке в `~/.magnit-agent/models`), альтернативы — `EMBEDDINGS_BACKEND=litellm` (модель корпоративного шлюза) или `off`. Без модели работает только поиск по словам. При смене модели векторы пересчитываются на `kb_sync`.
- **Инструкции агента** — `shared/instructions.md`. Они общие для всех трёх агентов.

## Структура

```
setup.sh                  первичная настройка
.env / .env.example       подключение к LLM
remote-mcp.json           удалённые MCP-серверы
shared/                   общее: шлюз, инструкции, Python-окружения
  mcp_registry.py         реестр MCP-серверов (что включено, что без подтверждения)
  mcp_launch.py           запуск MCP-сервера по имени (загружает .env)
  files_mcp.py            документы и картинки
  servers/                web, tag, magnitgpt, knowledge, calendar, scheduler
  skills/                 встроенные навыки
  scheduler.py            автоматизации (launchd)
  check_integrations.py   проверка токенов и доступов
agent-a-claude-code/      A: обёртка magnit-claude + settings.json
agent-b-goose/            B: обёртка magnit-goose + configure.py (config.yaml Goose)
agent-c-agent-sdk/        C: agent_core.py, cli.py, web.py, static/index.html
examples/                 тестовые файлы (xlsx, pdf, png)
```

## Проблемы

- **«нет ответа» при `setup.sh`**: проверьте, что VPN NetBird подключён.
- **`team not allowed to access model`**: модель из `.env` недоступна вашему токену. `setup.sh` показывает список доступных.
- **Логи шлюза**: `~/.magnit-agent/gateway.log`. Остановить шлюз: `kill $(cat ~/.magnit-agent/gateway.pid)`.
- **Goose Desktop спрашивает доступ к связке ключей**: разрешите («Всегда разрешать»), там хранится токен.
