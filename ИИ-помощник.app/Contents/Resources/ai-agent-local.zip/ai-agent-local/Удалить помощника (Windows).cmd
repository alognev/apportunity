@echo off
rem Windows: double-click to remove the assistant completely (your files in magnit-agent-workspace stay).
rem The script deletes this folder: "(goto) 2>nul" ends the batch context first, the rest of the line runs from memory
rem (otherwise cmd re-reads the deleted file and prints "The system cannot find the path specified").
if not exist "%~dp0windows\uninstall.ps1" goto nozip
(goto) 2>nul & cd /d "%TEMP%" & powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\uninstall.ps1" %* & echo. & pause
exit /b

:nozip
rem Started from inside the zip (Explorer) or a broken copy. UTF-8 text below is read only after chcp.
chcp 65001 >nul
echo Этот файл нужно запускать из папки помощника ai-agent-local, а не из архива.
echo Или: «Пуск» → ИИ-помощник → Удалить ИИ-помощника.
echo.
pause
exit /b 1
