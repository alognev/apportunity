@echo off
rem Windows: double-click to open the assistant (Goose Desktop in the work folder).
if not exist "%~dp0windows\launch.ps1" goto nozip
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\launch.ps1"
if errorlevel 1 pause
exit /b

:nozip
rem Started from inside the zip (Explorer) or a broken copy. UTF-8 text below is read only after chcp.
chcp 65001 >nul
echo Сначала распакуйте архив: правый щелчок по ai-agent-local.zip — «Извлечь всё…»,
echo затем установите помощника: «Установить агента (Windows)» в распакованной папке ai-agent-local.
echo.
pause
exit /b 1
