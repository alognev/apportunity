#!/usr/bin/env bash
# Сборка раздачи для пользователей (macOS и Windows): вся логика — в make_dist.py, он же работает на Windows.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$ROOT/shared/.venv/bin/python" "$ROOT/make_dist.py" "$@"
