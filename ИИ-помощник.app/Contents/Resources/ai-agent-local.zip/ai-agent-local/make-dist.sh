#!/usr/bin/env bash
# Сборка архива для передачи пользователям: dist/ai-agent-local.zip
# Не включает личные настройки (.env с токеном), установленные окружения и служебные файлы.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NAME="$(basename "$ROOT")"
mkdir -p "$ROOT/dist"
OUT="$ROOT/dist/$NAME.zip"
rm -f "$OUT"

# Копия без лишнего во временной папке, затем архив средствами macOS (как «Сжать» в Finder)
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
rsync -a \
  --include "/.env.example" --exclude "/.env*" --exclude "/env" --exclude "/env.*" --exclude "/env *" \
  --exclude "/dist/" --exclude "/.git/" --exclude "/.gitignore" --exclude "/gitlab-ext.yaml" \
  --exclude ".venv/" --exclude ".venv-gateway/" --exclude ".venv-atlassian/" --exclude "/shared/.dbhub/" \
  --exclude "/databases.toml" --exclude "/databases.toml.*" --exclude "/install.sh" --exclude "/app/AppIcon.icns" --exclude "/docs/" --exclude "/CLAUDE.md" --exclude "/WORKLOG.md" \
  --exclude "__pycache__/" --exclude "*.pyc" --exclude ".DS_Store" \
  --exclude "/.claude/" --exclude "/.obsidian/" --exclude "/logo-*/" --exclude "/presentation/" --exclude "/.idea/" --exclude "/.vscode/" \
  "$ROOT/" "$STAGE/$NAME/"
# Адрес, откуда пользователи скачивают установщик и архив (см. конец файла); подставляется в краткую инструкцию
DIST_URL="${DIST_URL:-$(head -1 "$ROOT/.dist-url" 2>/dev/null || true)}"
DIST_URL="${DIST_URL%/}"
# Команда установки: адрес с {file} — шаблон (GitLab API); закрытому проекту GitLab нужен токен в заголовке
if [[ -z "$DIST_URL" ]]; then INSTALL_URL="__DIST_URL__/install.sh"
elif [[ "$DIST_URL" == *"{file}"* ]]; then INSTALL_URL="${DIST_URL//\{file\}/install.sh}"
else INSTALL_URL="$DIST_URL/install.sh"; fi
if [[ "$DIST_URL" == */api/v4/projects/* ]]; then
  INSTALL_CMD="export MAGNIT_DIST_TOKEN=ВАШ_ТОКЕН_GITLAB; bash -c \"\$(curl -fsSL -H \"PRIVATE-TOKEN: \$MAGNIT_DIST_TOKEN\" '$INSTALL_URL')\""
else
  INSTALL_CMD="bash -c \"\$(curl -fsSL '$INSTALL_URL')\""
fi
INSTALL_CMD_APP="export MAGNIT_MODE=app; $INSTALL_CMD"   # тот же установщик, но ставит приложение «ИИ-помощник.app»
INSTALL_CMD="$INSTALL_CMD" INSTALL_CMD_APP="$INSTALL_CMD_APP" "$ROOT/shared/.venv/bin/python" - "$STAGE/$NAME/УСТАНОВКА.md" <<'PY'
import os, sys
p = sys.argv[1]; s = open(p, encoding="utf-8").read()
s = s.replace("__INSTALL_COMMAND_APP__", os.environ["INSTALL_CMD_APP"]).replace("__INSTALL_COMMAND__", os.environ["INSTALL_CMD"])
open(p, "w", encoding="utf-8").write(s)
PY
cp "$STAGE/$NAME/УСТАНОВКА.md" "$ROOT/dist/УСТАНОВКА.md"
VERSION="$(date +%Y%m%d%H%M)"; echo "$VERSION" > "$STAGE/$NAME/VERSION"
ditto -c -k --norsrc --noextattr --keepParent "$STAGE/$NAME" "$OUT"

# Защита от случайной утечки токена
if unzip -l "$OUT" | grep -qE "/\.env$"; then
  echo "ОШИБКА: в архив попал .env" >&2; rm -f "$OUT"; exit 1
fi
# Все секреты из вашего .env (токены, ключи, вебхуки) не должны встречаться в архиве
SECRETS="$(grep -E '^[A-Z_]*(TOKEN|KEY|WEBHOOK_URL)=.+' "$ROOT/.env" 2>/dev/null | cut -d= -f2- || true)"
# пароли и полные строки подключения из списка баз данных
if [[ -f "$ROOT/databases.toml" ]]; then
  SECRETS="$SECRETS"$'\n'"$(grep -oE 'dsn *= *"[^"]+"' "$ROOT/databases.toml" | sed -E 's/^dsn *= *"(.*)"$/\1/' | tr -d '\r')"
  SECRETS="$SECRETS"$'\n'"$(grep -oE '://[^:/@]+:[^@]+@' "$ROOT/databases.toml" | sed -E 's#^://[^:]+:(.*)@$#\1#')"
fi
CONTENT="$(unzip -p "$OUT")"
while IFS= read -r secret; do
  [[ -z "$secret" ]] && continue
  if grep -qF -- "$secret" <<< "$CONTENT"; then
    echo "ОШИБКА: в архиве найден секрет из вашего .env (${secret:0:6}…)" >&2; rm -f "$OUT"; exit 1
  fi
done <<< "$SECRETS"

echo "Готово: $OUT ($(du -h "$OUT" | cut -f1))"

# Приложение «ИИ-помощник.app» (оболочка с окнами вместо Терминала, архив помощника — внутри) → dist/AI-Assistant.app.zip
APP_ZIP="$ROOT/dist/AI-Assistant.app.zip"; rm -f "$APP_ZIP"
"$ROOT/app/build-app.sh" "$OUT" "$VERSION" "$STAGE/app" >/dev/null
ditto -c -k --keepParent "$STAGE/app/ИИ-помощник.app" "$APP_ZIP"
APP_SHA="$(shasum -a 256 "$APP_ZIP" | cut -d' ' -f1)"
echo "Приложение: $APP_ZIP ($(du -h "$APP_ZIP" | cut -f1))"

# Установщик «одной командой»: dist/install.sh с адресом загрузки и контрольной суммой архива.
# Адрес — папка, где будут лежать install.sh и архив (например, raw-ссылка на ветку проекта GitLab):
#   .dist-url: https://gitlab.example/api/v4/projects/<id>/repository/files/dist%2F{file}/raw?ref=main  (GitLab API)
#   или простой адрес папки: https://host/path — имя файла допишется через «/»
SHA="$(shasum -a 256 "$OUT" | cut -d' ' -f1)"
INSTALL_CMD="$INSTALL_CMD" DIST_URL="${DIST_URL:-__DIST_URL__}" SHA="$SHA" APP_SHA="$APP_SHA" "$ROOT/shared/.venv/bin/python" - "$ROOT/install.sh" "$ROOT/dist/install.sh" <<'PY'
import os, sys
s = open(sys.argv[1], encoding="utf-8").read()
for k, v in (("__INSTALL_COMMAND__", os.environ["INSTALL_CMD"]), ("__DIST_URL__", os.environ["DIST_URL"]), ("__SHA256__", os.environ["SHA"]),
             ("__APP_SHA256__", os.environ["APP_SHA"])):
    s = s.replace(k, v)
open(sys.argv[2], "w", encoding="utf-8").write(s)
PY
chmod +x "$ROOT/dist/install.sh"
if [[ -n "$DIST_URL" ]]; then
  echo "Установщик: $ROOT/dist/install.sh — выложите его вместе с архивом (всегда оба файла сразу)."
  echo "Команда для пользователей (она же — в dist/УСТАНОВКА.md):"
  echo "  приложение «ИИ-помощник» (вопросы в окнах):  $INSTALL_CMD_APP"
  echo "  установка в Терминале:                        $INSTALL_CMD"
else
  echo "Установщик: $ROOT/dist/install.sh собран БЕЗ адреса загрузки. Задайте адрес: DIST_URL=... ./make-dist.sh (или файл .dist-url)"
fi
