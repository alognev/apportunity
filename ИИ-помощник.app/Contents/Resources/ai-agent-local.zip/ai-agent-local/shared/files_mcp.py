"""MCP-сервер «magnit-files»: чтение документов и картинок для агентов.

Основная модель (MagnitCopilot) принимает только текст, поэтому агенты не читают
PDF/Excel/картинки напрямую, а вызывают инструменты этого сервера:

  read_document  — любой документ (xlsx, xls, csv, pdf, docx, pptx, html, ...) -> Markdown
  describe_image — картинка -> описание/ответ на вопрос (через vision-модель)
  ocr_pdf        — страницы PDF-скана -> текст (рендер страниц + vision-модель)

Настройки берутся из переменных окружения (см. .env в корне проекта):
LLM_BASE_URL, LLM_API_KEY, LLM_VISION_MODEL.
"""

from __future__ import annotations

import base64
import io
import mimetypes
import os
from pathlib import Path

from dotenv import load_dotenv
from mcp.server.mcpserver import MCPServer
from openai import OpenAI

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env", override=False)

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff"}
MAX_IMAGE_SIDE = 2048

mcp = MCPServer("magnit-files")
_markitdown = None
_client = None


def _resolve(path: str) -> Path:
    p = Path(os.path.expanduser(path))
    if not p.is_absolute():
        p = Path(os.environ.get("AGENT_CWD") or os.getcwd()) / p
    p = p.resolve()
    if not p.exists():
        raise FileNotFoundError(f"Файл не найден: {p}")
    return p


def _llm() -> OpenAI:
    global _client
    if _client is None:
        base = os.environ["LLM_BASE_URL"].rstrip("/")
        _client = OpenAI(base_url=f"{base}/v1", api_key=os.environ["LLM_API_KEY"])
    return _client


def _png_data_url(img) -> str:
    img = img.convert("RGB")
    img.thumbnail((MAX_IMAGE_SIDE, MAX_IMAGE_SIDE))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def _ask_vision(data_url: str, question: str) -> str:
    resp = _llm().chat.completions.create(
        model=os.environ.get("LLM_VISION_MODEL", "MagnitCopilot-VL"),
        max_tokens=4096,
        messages=[{
            "role": "user",
            "content": [
                {"type": "text", "text": question},
                {"type": "image_url", "image_url": {"url": data_url}},
            ],
        }],
    )
    return resp.choices[0].message.content or ""


@mcp.tool()
def read_document(path: str, max_chars: int = 60000) -> str:
    """Прочитать документ и вернуть его содержимое в Markdown.

    Поддерживает: .xlsx .xls .csv .pdf .docx .pptx .html .json .xml .txt и др.
    Для Excel возвращает все листы в виде таблиц. Для больших файлов вывод
    обрезается до max_chars — тогда анализируйте файл скриптом (pandas/openpyxl).
    Для картинок используйте describe_image, для PDF-сканов без текста — ocr_pdf.
    """
    global _markitdown
    p = _resolve(path)
    if p.suffix.lower() in IMAGE_EXTS:
        return "Это изображение — используйте инструмент describe_image."
    if _markitdown is None:
        from markitdown import MarkItDown
        _markitdown = MarkItDown()
    text = _markitdown.convert(str(p)).text_content or ""
    if p.suffix.lower() == ".pdf" and len(text.strip()) < 50:
        return ("В PDF почти нет текстового слоя (вероятно, скан). "
                "Используйте ocr_pdf для распознавания страниц.")
    if len(text) > max_chars:
        return (text[:max_chars] + f"\n\n[... обрезано: показано {max_chars} из {len(text)} символов. "
                "Для полного анализа напишите и выполните скрипт.]")
    return text


@mcp.tool()
def describe_image(path: str, question: str = "Подробно опиши изображение. Если есть текст — перепиши его дословно.") -> str:
    """Проанализировать изображение (png, jpg, gif, webp, bmp, tiff) с помощью vision-модели.

    question — что нужно узнать о картинке (например, «извлеки таблицу в Markdown»).
    """
    from PIL import Image

    p = _resolve(path)
    mime = mimetypes.guess_type(p.name)[0] or ""
    if not mime.startswith("image/"):
        return "Это не изображение — используйте read_document."
    with Image.open(p) as img:
        return _ask_vision(_png_data_url(img), question)


@mcp.tool()
def ocr_pdf(path: str, pages: str = "1-3", question: str = "Дословно перепиши весь текст страницы без комментариев и пояснений. Таблицы оформи в Markdown.") -> str:
    """Распознать страницы PDF (сканы, фото документов) через vision-модель.

    pages — номера страниц с 1: «1», «1-3», «2,5,7». Обрабатывайте не больше ~10 страниц за вызов.
    """
    import pypdfium2 as pdfium

    pdf = pdfium.PdfDocument(str(_resolve(path)))
    total = len(pdf)
    numbers: list[int] = []
    for part in pages.replace(" ", "").split(","):
        if "-" in part:
            a, b = part.split("-", 1)
            numbers.extend(range(int(a), int(b) + 1))
        elif part:
            numbers.append(int(part))
    numbers = [n for n in numbers if 1 <= n <= total][:20]
    if not numbers:
        return f"Нет страниц для обработки. В документе {total} стр."

    out = [f"Документ: {total} стр."]
    for n in numbers:
        image = pdf[n - 1].render(scale=2).to_pil()
        out.append(f"\n## Страница {n}\n\n{_ask_vision(_png_data_url(image), question)}")
    return "\n".join(out)


if __name__ == "__main__":
    mcp.run()
