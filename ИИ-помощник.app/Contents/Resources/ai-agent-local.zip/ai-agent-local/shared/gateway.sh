# Запуск локального шлюза (если ещё не запущен). Использование: source gateway.sh; ensure_gateway
# Требует предварительно загруженный shared/env.sh.
GATEWAY_PORT="${GATEWAY_PORT:-4141}"
GATEWAY_URL="http://127.0.0.1:$GATEWAY_PORT"
GATEWAY_STATE="$HOME/.magnit-agent"

ensure_gateway() {
  mkdir -p "$GATEWAY_STATE"
  local fp_file="$GATEWAY_STATE/gateway.fp" pid_file="$GATEWAY_STATE/gateway.pid"
  local fp; fp="$(printf '%s|%s|%s' "$LLM_BASE_URL" "$LLM_API_KEY" "${MAGNIT_TRACING_URL:-}" | shasum | cut -c1-16)"

  if curl -s -m 2 "$GATEWAY_URL/health/liveliness" >/dev/null 2>&1; then
    [[ "$(cat "$fp_file" 2>/dev/null)" == "$fp" ]] && return 0
    # Настройки в .env поменялись — перезапускаем шлюз
    [[ -f "$pid_file" ]] && kill "$(cat "$pid_file")" 2>/dev/null
    sleep 1
  fi

  echo "Запускаю локальный шлюз LLM на порту $GATEWAY_PORT..." >&2
  # Трассировка Langfuse (если включена): колбэк langfuse_otel шлёт в локальный ретранслятор, ключи — заглушки,
  # настоящие только у ретранслятора; ошибки трассировки остаются в gateway.log и запросам не мешают
  local config="$ROOT/shared/gateway.yaml" tracing_env=()
  if [[ -n "${MAGNIT_TRACING_URL:-}" ]]; then
    config="$GATEWAY_STATE/gateway-tracing.yaml"
    { cat "$ROOT/shared/gateway.yaml"; printf '  callbacks: ["langfuse_otel"]\n'; } > "$config"
    tracing_env=(LANGFUSE_PUBLIC_KEY=relay LANGFUSE_SECRET_KEY=relay LANGFUSE_OTEL_HOST="$MAGNIT_TRACING_URL"
                 OTEL_SERVICE_NAME=litellm-gateway)
  fi
  env ${tracing_env[@]+"${tracing_env[@]}"} GW_API_BASE="$LLM_BASE_URL/v1" LLM_API_KEY="$LLM_API_KEY" \
    DISABLE_AIOHTTP_TRANSPORT=True \
    nohup "$ROOT/shared/.venv-gateway/bin/python" "$ROOT/shared/gateway.py" \
      --config "$config" --host 127.0.0.1 --port "$GATEWAY_PORT" \
      > "$GATEWAY_STATE/gateway.log" 2>&1 &
  echo $! > "$pid_file"
  echo "$fp" > "$fp_file"
  for _ in $(seq 1 60); do
    curl -s -m 2 "$GATEWAY_URL/health/liveliness" >/dev/null 2>&1 && return 0
    sleep 1
  done
  echo "Шлюз не запустился, см. $GATEWAY_STATE/gateway.log" >&2
  return 1
}
