# Запуск локального шлюза (если ещё не запущен). Использование: source gateway.sh; ensure_gateway
# Требует предварительно загруженный shared/env.sh.
GATEWAY_PORT="${GATEWAY_PORT:-4141}"
GATEWAY_URL="http://127.0.0.1:$GATEWAY_PORT"
GATEWAY_STATE="$HOME/.magnit-agent"

ensure_gateway() {
  mkdir -p "$GATEWAY_STATE"
  local fp_file="$GATEWAY_STATE/gateway.fp" pid_file="$GATEWAY_STATE/gateway.pid"
  local fp; fp="$(printf '%s|%s' "$LLM_BASE_URL" "$LLM_API_KEY" | shasum | cut -c1-16)"

  if curl -s -m 2 "$GATEWAY_URL/health/liveliness" >/dev/null 2>&1; then
    [[ "$(cat "$fp_file" 2>/dev/null)" == "$fp" ]] && return 0
    # Настройки в .env поменялись — перезапускаем шлюз
    [[ -f "$pid_file" ]] && kill "$(cat "$pid_file")" 2>/dev/null
    sleep 1
  fi

  echo "Запускаю локальный шлюз LLM на порту $GATEWAY_PORT..." >&2
  GW_API_BASE="$LLM_BASE_URL/v1" LLM_API_KEY="$LLM_API_KEY" DISABLE_AIOHTTP_TRANSPORT=True \
    nohup "$ROOT/shared/.venv-gateway/bin/python" "$ROOT/shared/gateway.py" \
      --config "$ROOT/shared/gateway.yaml" --host 127.0.0.1 --port "$GATEWAY_PORT" \
      > "$GATEWAY_STATE/gateway.log" 2>&1 &
  echo $! > "$pid_file"
  echo "$fp" > "$fp_file"
  for _ in $(seq 1 60); do
    curl -s -m 2 "$GATEWAY_URL/health/liveliness" >/dev/null 2>&1 && return 0
    sleep 1
  done
  echo "Шлюз не запустился, см. $GATEWAY_STATE/gateway.log" >&2
  return 1
}
