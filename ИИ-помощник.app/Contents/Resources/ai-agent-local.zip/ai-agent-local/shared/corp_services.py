"""Verified HTTPS and private connection settings for the optional integrations."""
from __future__ import annotations

import base64
import json
import os
from urllib.parse import unquote, urlsplit

import httpx

from mcp_registry import USER_AGENT, connection_file, load_env
from platform_util import corp_ssl_context

DEFAULT_URLS = {
    "airflow": "https://airflow-ml.prod.analytics.corp",
    "grafana": "https://grafana.platform.corp",
    "trino": "https://trino-ml.analytics.corp",
    "s3": "https://storage.yandexcloud.net",
    "sourcebot": "https://sourcebot.magnit.dev",
    "jupyterhub": "https://jupyterhub.k8s.dev.analytics.corp",
    "datalens": "https://datalens.ru",
    "help": "https://help.corp.tander.ru",
}
DEFAULT_AUTH = {
    "airflow": "bearer", "grafana": "bearer", "trino": "basic",
    "sourcebot": "cookie", "jupyterhub": "token", "help": "cookie",
}
MAX_RESPONSE = 2 * 1024 * 1024


class ServiceError(RuntimeError):
    """A stable message without upstream URLs, request headers or bodies."""

    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status
        self.status_code = status


def service_setting(service: str, key: str, default: str = "") -> str:
    if service not in DEFAULT_URLS or not key.isascii() or not key.isidentifier():
        raise ValueError("Неизвестная настройка интеграции.")
    name = f"{service.upper()}_{key.upper()}"
    try:
        stored = connection_file(name).read_text(
            encoding="utf-8-sig"
        ).strip()
    except FileNotFoundError:
        stored = ""
    except (OSError, UnicodeError) as exc:
        raise ServiceError(f"{service}: не удалось прочитать локальную настройку.") from exc
    return os.environ.get(name) or stored or load_env().get(name) or default


def credentials(service: str) -> str:
    value = service_setting(service, "TOKEN")
    if not value:
        raise ServiceError(f"{service}: подключите систему в настройках ИИ-помощника.")
    if any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise ServiceError(f"{service}: учётные данные должны быть одной строкой.")
    return value


def service_url(service: str) -> str:
    value = service_setting(service, "URL", DEFAULT_URLS[service]).rstrip("/")
    try:
        u = urlsplit(value)
        _ = u.port  # validates an explicitly supplied port
        if (u.scheme != "https" or not u.hostname
                or u.username is not None or u.password is not None or u.query or u.fragment
                or any(c.isspace() or c == "\\" for c in value)):
            raise ValueError
        if any(part in (".", "..") for part in unquote(u.path).split("/")):
            raise ValueError
    except ValueError:
        raise ServiceError(f"{service}: укажите корректный HTTPS-адрес сервиса в установщике.") from None
    return value


def auth_headers(service: str) -> dict[str, str]:
    method = service_setting(service, "AUTH", DEFAULT_AUTH[service]).lower()
    value = credentials(service)
    if method == "cookie":
        return {"Cookie": value}
    if method == "basic":
        login, sep, password = value.partition(":")
        if not sep or not login or not password:
            raise ServiceError(f"{service}: для входа с паролем укажите логин:пароль.")
        return {"Authorization": "Basic " + base64.b64encode(value.encode("utf-8")).decode("ascii")}
    if method in ("bearer", "token"):
        return {"Authorization": ("Bearer " if method == "bearer" else "token ") + value}
    raise ServiceError(f"{service}: неизвестный способ входа. Проверьте настройки подключения.")


def ref_path(service: str, value: str) -> str:
    """Take the path from a user URL without forwarding its host or credentials."""
    try:
        base, ref = urlsplit(service_url(service)), urlsplit(value)
        if (ref.username is not None or ref.password is not None
                or (ref.scheme, ref.hostname, ref.port or 443)
                != (base.scheme, base.hostname, base.port or 443)):
            raise ValueError
    except ValueError:
        raise ServiceError(f"{service}: ссылка должна быть с адреса настроенного сервиса.") from None
    return ref.path


def check_response(service: str, response: httpx.Response, changing: bool = False) -> None:
    status = response.status_code
    if 200 <= status < 300:
        return
    if status in (401, 403) or 300 <= status < 400:
        detail = "проверьте права и срок действия входа в настройках."
    elif status == 404:
        detail = "объект или API не найдены. Проверьте ссылку и адрес сервиса."
    elif status == 429:
        detail = "сервис ограничил частоту запросов. Повторите позже."
    elif changing and status >= 500:
        detail = "исход операции неизвестен. Проверьте состояние перед повтором."
    else:
        detail = "сервис отклонил запрос. Проверьте параметры и подключение."
    raise ServiceError(f"{service}: HTTP {status}, {detail}", status)


class Client:
    def __init__(self, service: str, headers: dict[str, str] | None = None):
        self.service = service
        self.base_url = service_url(service)
        self.http = httpx.Client(
            verify=corp_ssl_context(), follow_redirects=False, timeout=httpx.Timeout(25, connect=8),
            headers={"User-Agent": USER_AGENT, "Accept": "application/json", **(
                auth_headers(service) if headers is None else headers
            )},
        )

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *_exc) -> None:
        self.http.close()

    def request(
        self, method: str, path: str, *, params=None, json=None, files=None, content=None,
        headers=None, max_bytes: int = MAX_RESPONSE, raw: bool = False, changing: bool | None = None,
    ):
        if (not path.startswith("/") or path.startswith("//") or "\\" in path or "#" in path
                or any(part in (".", "..") for part in unquote(path.split("?", 1)[0]).split("/"))):
            raise ServiceError("Ожидается относительный путь API настроенного сервиса.")
        if changing is None:
            changing = method.upper() not in {"GET", "HEAD"}
        try:
            with self.http.stream(method, self.base_url + path, params=params, json=json, files=files,
                                  content=content, headers=headers) as resp:
                check_response(self.service, resp, changing)
                data = bytearray()
                for chunk in resp.iter_bytes(chunk_size=64 * 1024):
                    if len(data) + len(chunk) > max_bytes:
                        raise ServiceError(f"{self.service}: ответ слишком велик. Сузьте запрос.")
                    data.extend(chunk)
                if "text/html" in resp.headers.get("content-type", "").lower():
                    raise ServiceError(f"{self.service}: вместо данных вернулась веб-страница. Проверьте вход.")
                if raw:
                    return data.decode(resp.encoding or "utf-8", errors="replace")
                return self._json(data)
        except httpx.HTTPError:
            info = ("исход операции неизвестен, проверьте состояние перед повтором."
                    if changing else "сервис недоступен. Проверьте VPN, адрес и сертификаты.")
            raise ServiceError(f"{self.service}: {info}") from None

    def _json(self, data: bytearray):
        try:
            return json.loads(data) if data else {}
        except (ValueError, UnicodeError):
            raise ServiceError(f"{self.service}: сервис вернул неожиданный формат ответа.") from None
