"""Локальный ретранслятор трассировки в Langfuse: агенты → 127.0.0.1:4319 (OTLP/HTTP) → Langfuse.

Зачем посредник, а не прямая отправка из агентов:
  • агенты никогда не видят ошибок и задержек трассировки: ретранслятор сразу отвечает «принято»,
    а отправляет в Langfuse в фоне. Нет связи (NetBird без доступа к plai.corp, нет сети) — трассы ждут
    в очереди на диске и уходят позже; очередь ограничена по размеру и сроку, старое удаляется молча;
  • ключи Langfuse есть только у ретранслятора — в процессах агентов их нет;
  • перед отправкой в трассах маскируются секреты (токены из .env, известные форматы ключей);
  • добавляются сессия (gen_ai.conversation.id → langfuse.session.id), пользователь, окружение, теги;
  • сертификат Langfuse выпущен центром plai.corp, которого нет в системе, — доверие задаётся
    приложенным промежуточным сертификатом (shared/certs-extra), без изменения связки ключей.

Принимает POST …/v1/traces (Goose, LiteLLM, любой OTLP/HTTP-экспортёр; protobuf или JSON); метрики и логи
OTLP принимаются и отбрасываются. Запускается launchd-агентом ru.magnit-agent.langfuse-relay (shared/tracing.py).
Журнал — ~/.magnit-agent/langfuse-relay.log (только для диагностики, пользователю не показывается).
"""

from __future__ import annotations

import base64
import logging
import logging.handlers
import os
import re
import ssl
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tracing  # noqa: E402
from mcp_registry import ROOT, load_env  # noqa: E402

STATE = Path.home() / ".magnit-agent"
SPOOL = STATE / "langfuse-spool"
LOG = STATE / "langfuse-relay.log"
MAX_BODY = 32 * 1024 * 1024          # один запрос от агента
SPOOL_MAX_BYTES = 200 * 1024 * 1024  # вся очередь
SPOOL_MAX_FILES = 20_000
SPOOL_MAX_AGE = 7 * 86400            # старше недели — не отправляем
MASK = "[скрыто]"
PATTERNS = [  # известные форматы секретов — на случай, если токена нет в .env
    re.compile(r"\b(?:sk|pk)-lf-[0-9a-f-]{20,}"),
    re.compile(r"\bglpat-[\w-]{20,}"),
    re.compile(r"\bsk-[A-Za-z0-9_-]{20,}"),
    re.compile(r"(?i)\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]{16,}"),
    re.compile(r"(?i)(private-token|x-api-key|api[_-]?key|password|passwd|secret|token)([\"']?\s*[:=]\s*[\"']?)"
               r"[A-Za-z0-9._~+/=-]{12,}"),
]

log = logging.getLogger("langfuse-relay")
wake = threading.Event()


def setup_logging() -> None:
    STATE.mkdir(parents=True, exist_ok=True)
    handler = logging.handlers.RotatingFileHandler(LOG, maxBytes=1_000_000, backupCount=1, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.addHandler(handler)
    log.setLevel(logging.INFO)
    log.propagate = False


# ---------- приём от агентов ----------

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args) -> None:  # без вывода в консоль
        pass

    def _reply(self, code: int = 200, protobuf: bool = True) -> None:
        body = b"" if protobuf else b"{}"  # пустой ExportTraceServiceResponse = «принято полностью»
        self.send_response(code)
        self.send_header("Content-Type", "application/x-protobuf" if protobuf else "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        self._reply(200, protobuf=False)

    def do_POST(self) -> None:
        ctype = (self.headers.get("Content-Type") or "application/x-protobuf").split(";")[0].strip().lower()
        is_json = ctype.endswith("json")
        try:
            size = int(self.headers.get("Content-Length") or 0)
            body = self.rfile.read(size) if 0 < size <= MAX_BODY else b""
            if size > MAX_BODY:
                self.rfile.read(size)  # дочитать и выбросить
            path = self.path.split("?", 1)[0].rstrip("/")
            if body and (path.endswith("/v1/traces") or path.endswith("/api/public/otel")):
                if self.headers.get("Content-Encoding", "").lower() == "gzip":
                    import gzip
                    body = gzip.decompress(body)
                spool_put(body, "json" if is_json else "pb")
                wake.set()
        except Exception:  # noqa: BLE001 — агенту всегда «принято»
            log.exception("приём запроса")
        self._reply(200, protobuf=not is_json)


def spool_put(body: bytes, kind: str) -> None:
    SPOOL.mkdir(parents=True, exist_ok=True)
    name = f"{time.time_ns()}-{uuid.uuid4().hex[:8]}.{kind}"
    tmp = SPOOL / f".{name}.tmp"
    tmp.write_bytes(body)
    tmp.replace(SPOOL / name)


def spool_items() -> list[Path]:
    """Очередь по порядку поступления; лишнее (размер, число, возраст) удаляется — сначала самое старое."""
    try:
        files = sorted(p for p in SPOOL.iterdir() if not p.name.startswith("."))
    except FileNotFoundError:
        return []
    now, total, keep = time.time(), 0, []
    for p in reversed(files):  # от новых к старым
        try:
            st = p.stat()
        except FileNotFoundError:
            continue
        total += st.st_size
        if now - st.st_mtime > SPOOL_MAX_AGE or total > SPOOL_MAX_BYTES or len(keep) >= SPOOL_MAX_FILES:
            p.unlink(missing_ok=True)
        else:
            keep.append(p)
    return list(reversed(keep))


# ---------- обогащение и маскирование ----------

def secrets_from_env(env: dict[str, str]) -> list[str]:
    """Значения секретов из .env и пароль приложения Drive — точное совпадение заменяется на [скрыто]."""
    found = [v for k, v in env.items() if v and len(v) >= 8 and re.search(
        r"(TOKEN|_KEY|SECRET|PASSWORD|WEBHOOK_URL)$", k) and not k.startswith("LLM_MAX")]
    try:
        import json
        found.append(json.loads((STATE / "drive-auth.json").read_text()).get("password", ""))
    except (OSError, ValueError):
        pass
    try:
        found += re.findall(r"(?:postgres(?:ql)?|mysql|sqlserver|clickhouse)://[^\"'\s]+",
                            (ROOT / "databases.toml").read_text())
    except OSError:
        pass
    return sorted({s for s in found if len(s) >= 8}, key=len, reverse=True)


def mask(text: str, secrets: list[str]) -> str:
    for s in secrets:
        if s in text:
            text = text.replace(s, MASK)
    for p in PATTERNS:
        if p.groups == 2:
            text = p.sub(lambda m: f"{m.group(1)}{m.group(2)}{MASK}", text)
        elif p.groups == 1:
            text = p.sub(lambda m: f"{m.group(1)} {MASK}", text)
        else:
            text = p.sub(MASK, text)
    return text


def _mask_value(value, secrets: list[str]) -> None:
    kind = value.WhichOneof("value")
    if kind == "string_value":
        value.string_value = mask(value.string_value, secrets)
    elif kind == "array_value":
        for v in value.array_value.values:
            _mask_value(v, secrets)
    elif kind == "kvlist_value":
        for kv in value.kvlist_value.values:
            _mask_value(kv.value, secrets)


def _attrs(items) -> dict:
    out = {}
    for kv in items:
        kind = kv.value.WhichOneof("value")
        if kind in ("string_value", "int_value", "bool_value", "double_value"):
            out[kv.key] = getattr(kv.value, kind)
    return out


def _set(items, key: str, value) -> None:
    for kv in items:
        if kv.key == key:
            return  # не перетирать то, что задал источник
    kv = items.add()
    kv.key = key
    if isinstance(value, list):
        for v in value:
            kv.value.array_value.values.add().string_value = str(v)
    else:
        kv.value.string_value = str(value)


AGENT_TAGS = {"goose": "goose", "litellm": "claude-gateway"}  # шлюз LiteLLM — агенты A (Claude Code) и C (веб-чат)


def enrich(body: bytes, kind: str, ctx: dict) -> bytes:
    """OTLP → OTLP protobuf: маскирование, сессия, пользователь, окружение, теги, версия."""
    from google.protobuf import json_format
    from opentelemetry.proto.collector.trace.v1.trace_service_pb2 import ExportTraceServiceRequest

    req = ExportTraceServiceRequest()
    if kind == "json":
        json_format.Parse(body.decode("utf-8"), req, ignore_unknown_fields=True)
    else:
        req.ParseFromString(body)
    secrets = ctx["secrets"]
    for rs in req.resource_spans:
        res = _attrs(rs.resource.attributes)
        service = str(res.get("service.name", "agent"))
        tag = next((t for k, t in AGENT_TAGS.items() if k in service.lower()), service)
        mode = str(res.get("magnit.run_mode") or "chat")  # automation — задания по расписанию (scheduler.py)
        tags = [tag, mode]
        _set(rs.resource.attributes, "langfuse.environment", ctx["environment"])
        if ctx["release"]:
            _set(rs.resource.attributes, "langfuse.release", ctx["release"])
        for kv in rs.resource.attributes:
            _mask_value(kv.value, secrets)
        for ss in rs.scope_spans:
            for span in ss.spans:
                attrs = _attrs(span.attributes)
                session = attrs.get("gen_ai.conversation.id") or attrs.get("session.id")
                if session:
                    _set(span.attributes, "langfuse.session.id", session)
                _set(span.attributes, "langfuse.user.id", ctx["user"])
                _set(span.attributes, "langfuse.trace.tags", tags)
                if not span.parent_span_id:  # корневой span: имя трассы вместо общего «reply»
                    _set(span.attributes, "langfuse.trace.name", f"{tag}-{mode}")
                for kv in span.attributes:
                    _mask_value(kv.value, secrets)
                for ev in span.events:
                    for kv in ev.attributes:
                        _mask_value(kv.value, secrets)
                if span.status.message:
                    span.status.message = mask(span.status.message, secrets)
    return req.SerializeToString()


# ---------- отправка в Langfuse ----------

def ssl_context() -> ssl.SSLContext:
    """Публичные центры (certifi) + корпоративные из shared/certs и shared/certs-extra; промежуточный
    plai.corp — как точка доверия (его корневого нет в системе)."""
    import certifi

    ctx = ssl.create_default_context(cafile=certifi.where())
    for folder in (ROOT / "shared" / "certs", ROOT / "shared" / "certs-extra"):
        for f in sorted(folder.glob("*")) if folder.is_dir() else []:
            if f.suffix in (".pem", ".cer", ".crt"):
                try:
                    ctx.load_verify_locations(cadata=_pem(f))
                except (ssl.SSLError, ValueError):
                    log.warning("сертификат не загружен: %s", f.name)
    ctx.verify_flags |= ssl.VERIFY_X509_PARTIAL_CHAIN
    return ctx


def _pem(path: Path) -> str:
    raw = path.read_bytes()
    if b"BEGIN CERTIFICATE" in raw:
        return raw.decode("ascii", errors="ignore")
    return ssl.DER_cert_to_PEM_cert(raw)


def sender() -> None:
    import httpx

    client: httpx.Client | None = None
    delay, last_cfg = 0.0, None
    while True:
        wake.wait(timeout=delay or 30)
        wake.clear()
        try:
            env = load_env()
            cfg = tracing.settings(env)
            if not cfg:
                delay = 60
                continue
            if cfg != last_cfg or client is None:
                if client:
                    client.close()
                auth = base64.b64encode(f"{cfg['public_key']}:{cfg['secret_key']}".encode()).decode()
                client = httpx.Client(verify=ssl_context(), timeout=httpx.Timeout(20, connect=5), headers={
                    "Authorization": f"Basic {auth}", "x-langfuse-ingestion-version": "4",
                    "Content-Type": "application/x-protobuf", "User-Agent": "magnit-local-agent/1.0 (trace relay)"})
                last_cfg = cfg
            ctx = {"secrets": secrets_from_env(env), "environment": cfg["environment"], "user": cfg["user"],
                   "release": cfg["release"]}
            url = cfg["base_url"].rstrip("/") + "/api/public/otel/v1/traces"
            delay = 0.0
            for item in spool_items():
                kind = item.suffix.lstrip(".")
                try:
                    payload = enrich(item.read_bytes(), kind, ctx)
                except Exception:  # noqa: BLE001 — нечитаемая посылка: не отправляем немаскированное
                    log.exception("не разобрана посылка %s — удалена", item.name)
                    item.unlink(missing_ok=True)
                    continue
                try:
                    resp = client.post(url, content=payload)
                except httpx.HTTPError as e:  # нет связи — подождём
                    log.info("Langfuse недоступен (%s), в очереди %d", e.__class__.__name__, len(spool_items()))
                    delay = 120
                    break
                if resp.status_code < 300:
                    item.unlink(missing_ok=True)
                elif resp.status_code in (401, 403):
                    log.warning("Langfuse отклонил ключи (%s) — проверьте LANGFUSE_* в .env", resp.status_code)
                    delay = 600
                    break
                elif resp.status_code in (400, 404, 413, 422):
                    log.warning("Langfuse не принял посылку (%s): %s", resp.status_code, resp.text[:200])
                    item.unlink(missing_ok=True)
                else:
                    log.info("Langfuse ответил %s — повтор позже", resp.status_code)
                    delay = 60
                    break
        except Exception:  # noqa: BLE001 — фоновый поток не должен умирать
            log.exception("отправка")
            delay = 60


def main() -> None:
    setup_logging()
    cfg = tracing.settings(load_env())
    if not cfg:
        log.info("трассировка выключена (нет LANGFUSE_* в .env) — выхожу")
        return
    try:
        server = ThreadingHTTPServer(("127.0.0.1", cfg["port"]), Handler)
    except OSError:
        log.info("порт %s занят — ретранслятор уже запущен", cfg["port"])
        return
    server.daemon_threads = True
    tracing.session_env(load_env())  # после перезагрузки переменные сеанса для Goose Desktop пусты
    threading.Thread(target=sender, daemon=True).start()
    wake.set()  # отправить то, что накопилось до перезапуска
    log.info("слушаю 127.0.0.1:%s → %s", cfg["port"], cfg["base_url"])
    server.serve_forever()


if __name__ == "__main__":
    main()
