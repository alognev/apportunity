"""Запуск MCP-сервера по имени из реестра: python mcp_launch.py <name>.

Загружает .env (секреты не хранятся в конфигах агентов), подключает системное
хранилище сертификатов macOS и запускает нужный сервер.

Для серверов, которые меняют корпоративные системы (GUARDED), лаунчер работает посредником:
запускает сервер дочерним процессом и пропускает каждый вызов инструмента через guard.py.
Запрещённые вызовы до сервера не доходят — агент получает отказ с объяснением.
"""

from __future__ import annotations

import json
import os
import runpy
import subprocess
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mcp_registry import (  # noqa: E402
    ATLASSIAN_CONTOURS, ATLASSIAN_MCP_URL, CONFLUENCE_READ, CONFLUENCE_WRITE, GITLAB_INSTANCES, JIRA_READ,
    JIRA_WRITE, ROOT, USER_AGENT, atlassian_tools, gitlab_tools, load_env,
)

try:
    import truststore

    truststore.inject_into_ssl()
except ImportError:
    pass


def run_atlassian(kind: str, url: str, token: str, tools: list[str]) -> None:
    import requests.utils

    requests.utils.default_user_agent = lambda *a, **k: USER_AGENT
    for k in list(os.environ):
        if k.startswith(("JIRA_", "CONFLUENCE_")):
            del os.environ[k]
    prefix = kind.upper()
    os.environ[f"{prefix}_URL"] = url
    os.environ[f"{prefix}_PERSONAL_TOKEN"] = token
    os.environ["ENABLED_TOOLS"] = ",".join(tools)
    os.environ.setdefault("MCP_VERBOSE", "false")
    from mcp_atlassian import main

    # --env-file: иначе mcp-atlassian найдёт наш .env вверх по папкам и перезапишет переменные
    sys.argv = ["mcp-atlassian", "--transport", "stdio", "--env-file", os.devnull]
    main()


def run_atlassian_cloud(name: str, env: dict[str, str]) -> None:
    """Мост stdio ⇄ облачный Atlassian MCP (streamable HTTP) AI Lab.

    Токены и адреса контура — в заголовках (как в инструкции AI Lab). Список инструментов
    фильтруется до выбранного профиля (compact/full), вызовы вне профиля блокируются.
    """
    import httpx

    url = env.get("ATLASSIAN_MCP_URL") or ATLASSIAN_MCP_URL
    (jira_url, jira_tok), (conf_url, conf_tok) = ATLASSIAN_CONTOURS[name]
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json, text/event-stream",
               "Content-Type": "application/json"}
    groups = []
    if env.get(jira_tok):
        headers |= {"X-Atlassian-Jira-Personal-Token": env[jira_tok], "X-Atlassian-Jira-Url": env[jira_url]}
        groups += ["jira_read", "jira_write"]
    if env.get(conf_tok):
        headers |= {"X-Atlassian-Confluence-Personal-Token": env[conf_tok],
                    "X-Atlassian-Confluence-Url": env[conf_url]}
        groups += ["confluence_read", "confluence_write"]
    headers["Enabled-Groups"] = ",".join(groups)
    cloud_bridge(url, headers, set(atlassian_tools(env)), "Облачный Atlassian MCP",
                 "сообщите ответственному за помощника", "ATLASSIAN_PROFILE")


def run_dbhub() -> None:
    """DBHub MCP (Node.js): базы из databases.toml, каждая — строго только на чтение."""
    from mcp_registry import DBHUB_BIN, database_sources

    lines = []
    for s in database_sources():
        esc = lambda v: str(v).replace("\\", "\\\\").replace('"', '\\"')  # noqa: E731
        lines += ["[[sources]]", f'id = "{esc(s["id"])}"', f'dsn = "{esc(s["dsn"])}"']
        if s.get("description"):
            lines.append(f'description = "{esc(s["description"])}"')
        for tool in ("execute_sql", "search_objects"):
            lines += ["", "[[tools]]", f'name = "{tool}"', f'source = "{esc(s["id"])}"'] + \
                     (["readonly = true"] if tool == "execute_sql" else [])
        lines.append("")
    state = Path.home() / ".magnit-agent"
    state.mkdir(parents=True, exist_ok=True)
    config = state / "dbhub.toml"
    config.touch(mode=0o600)
    config.write_text("\n".join(lines))
    os.environ["PATH"] = "/opt/homebrew/bin:/usr/local/bin:" + os.environ.get("PATH", "")
    os.execv(str(DBHUB_BIN), [str(DBHUB_BIN), "--transport", "stdio", "--config", str(config)])


def run_gitlab_cloud(name: str, env: dict[str, str]) -> None:
    """Мост stdio ⇄ облачный GitLab MCP AI Lab (токен — в Authorization, группы — в Enabled-Groups)."""
    url, token_var, _ = GITLAB_INSTANCES[name]
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json, text/event-stream",
               "Content-Type": "application/json", "Authorization": f"Bearer {env[token_var]}",
               "Enabled-Groups": env.get("GITLAB_GROUPS") or "core,code_review"}
    tools = gitlab_tools(env)
    cloud_bridge(url, headers, set(tools) if tools else None, "Облачный GitLab MCP",
                 "проверьте токен GitLab", "GITLAB_PROFILE")


def cloud_bridge(url: str, headers: dict, allowed: set | None, label: str, fallback: str, profile_var: str) -> None:
    """Общий мост stdio ⇄ облачный MCP (streamable HTTP): фильтр инструментов, удаление запрещено всегда."""
    import httpx

    def permitted(tool: str) -> bool:
        return not tool.startswith("delete_") and (allowed is None or tool in allowed)

    client = httpx.Client(timeout=httpx.Timeout(180, connect=15))
    state: dict = {"session": None, "protocol": None}
    list_ids: set = set()
    lock = threading.Lock()
    workers: list[threading.Thread] = []

    def emit(obj: dict) -> None:
        with lock:
            sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
            sys.stdout.flush()

    def deliver(msg: dict) -> None:
        if msg.get("id") in list_ids and isinstance(msg.get("result"), dict):
            msg["result"]["tools"] = [t for t in msg["result"].get("tools", []) if permitted(t.get("name", ""))]
            list_ids.discard(msg.get("id"))
        if isinstance(msg.get("result"), dict) and "protocolVersion" in msg["result"]:
            state["protocol"] = msg["result"]["protocolVersion"]
        emit(msg)

    def fail(req: dict, text: str) -> None:
        if "id" in req:
            emit({"jsonrpc": "2.0", "id": req["id"], "error": {"code": -32000, "message": text}})

    def post(req: dict) -> None:
        h = dict(headers)
        if state["session"]:
            h["Mcp-Session-Id"] = state["session"]
        if state["protocol"]:
            h["MCP-Protocol-Version"] = state["protocol"]
        try:
            with client.stream("POST", url, json=req, headers=h) as resp:
                if resp.headers.get("mcp-session-id"):
                    state["session"] = resp.headers["mcp-session-id"]
                if resp.status_code == 202:
                    return
                if resp.status_code >= 400:
                    fail(req, f"{label} ответил {resp.status_code}: {resp.read()[:300]!r}")
                    return
                if "text/event-stream" in resp.headers.get("content-type", ""):
                    data: list[str] = []
                    for line in resp.iter_lines():
                        if line.startswith("data:"):
                            data.append(line[5:].strip())
                        elif not line and data:
                            deliver(json.loads("\n".join(data)))
                            data = []
                    if data:
                        deliver(json.loads("\n".join(data)))
                else:
                    body = resp.read()
                    if body.strip():
                        parsed = json.loads(body)
                        for msg in parsed if isinstance(parsed, list) else [parsed]:
                            deliver(msg)
        except Exception as e:  # noqa: BLE001
            fail(req, f"{label} недоступен ({e.__class__.__name__}). Проверьте NetBird или {fallback}.")

    for line in sys.stdin:
        try:
            req = json.loads(line)
        except ValueError:
            continue
        method = req.get("method")
        if method == "tools/list":
            list_ids.add(req.get("id"))
        if method == "tools/call" and not permitted((req.get("params") or {}).get("name", "")):
            emit({"jsonrpc": "2.0", "id": req.get("id"), "result": {"isError": True, "content": [
                {"type": "text", "text": f"Этот инструмент отключён в помощнике (см. {profile_var} в .env)."}]}})
            continue
        if method == "initialize" or state["session"] is None:
            post(req)  # инициализацию — синхронно: нужен идентификатор сессии
        else:
            t = threading.Thread(target=post, args=(req,), daemon=True)
            t.start()
            workers.append(t)
    for t in workers:
        t.join(timeout=180)


GUARDED = {"jira", "jira-it", "confluence-it", "confluence-eportal", "calendar", "tag", "scheduler",
           "atlassian", "atlassian-it", "gitlab", "gitlab-platform", "drive"}
CHILD_FLAG = "MAGNIT_GUARD_CHILD"


def guarded_proxy(name: str) -> None:
    """Посредник: агент ⇄ (проверка guard) ⇄ MCP-сервер. Протокол MCP stdio — JSON по строкам."""
    child = subprocess.Popen([sys.executable, __file__, name], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             env={**os.environ, CHILD_FLAG: "1"})
    out_lock = threading.Lock()

    def emit(data: bytes) -> None:
        with out_lock:
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.flush()

    def pump_out() -> None:  # ответы сервера -> агенту
        for line in child.stdout:
            emit(line)

    threading.Thread(target=pump_out, daemon=True).start()
    guard = None
    for line in sys.stdin.buffer:  # запросы агента -> серверу
        try:
            msg = json.loads(line)
        except ValueError:
            msg = None
        if isinstance(msg, dict) and msg.get("method") == "tools/call":
            tool = (msg.get("params") or {}).get("name", "")
            args = (msg.get("params") or {}).get("arguments") or {}
            if guard is None:
                import guard as guard_module  # загружается только при первом вызове инструмента
                guard = guard_module
            if guard.classify(name, tool):
                ok, reason = guard.check(name, tool, args)
                guard.audit(name, tool, args, ok, reason)
                if not ok:
                    emit((json.dumps({"jsonrpc": "2.0", "id": msg.get("id"), "result": {
                        "content": [{"type": "text", "text": f"⛔ Заблокировано защитой: {reason}"}],
                        "isError": True}}, ensure_ascii=False) + "\n").encode())
                    continue
                guard.record(name, tool, args)
        child.stdin.write(line)
        child.stdin.flush()
    child.stdin.close()
    child.wait()


def main() -> None:
    name = sys.argv[1]
    env = load_env()
    os.environ.update({k: v for k, v in env.items() if k not in os.environ})
    if name in GUARDED and os.environ.get(CHILD_FLAG) != "1":
        guarded_proxy(name)
        return

    if name in ATLASSIAN_CONTOURS:
        run_atlassian_cloud(name, env)
    elif name in GITLAB_INSTANCES:
        run_gitlab_cloud(name, env)
    elif name == "dbhub":
        run_dbhub()
    elif name.startswith("jira"):
        suffix = "_IT" if name == "jira-it" else ""
        run_atlassian("jira", env[f"JIRA{suffix}_URL"], env[f"JIRA{suffix}_TOKEN"], JIRA_READ + JIRA_WRITE)
    elif name.startswith("confluence-"):
        suffix = name.split("-", 1)[1].upper()
        run_atlassian("confluence", env[f"CONFLUENCE_{suffix}_URL"], env[f"CONFLUENCE_{suffix}_TOKEN"],
                      CONFLUENCE_READ + CONFLUENCE_WRITE)
    elif name == "magnit-files":
        runpy.run_path(str(ROOT / "shared" / "files_mcp.py"), run_name="__main__")
    else:
        runpy.run_path(str(ROOT / "shared" / "servers" / f"{name.replace('-', '_')}_mcp.py"), run_name="__main__")


if __name__ == "__main__":
    main()
