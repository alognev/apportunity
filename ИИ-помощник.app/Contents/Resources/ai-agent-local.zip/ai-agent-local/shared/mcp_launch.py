"""Запуск MCP-сервера по имени из реестра: python mcp_launch.py <name>.

Загружает .env (секреты не хранятся в конфигах агентов), подключает системное
хранилище сертификатов macOS и запускает нужный сервер.

Для серверов, которые меняют корпоративные системы (GUARDED), лаунчер работает посредником:
запускает сервер дочерним процессом и пропускает каждый вызов инструмента через guard.py.
Запрещённые вызовы до сервера не доходят — агент получает отказ с объяснением.
"""

from __future__ import annotations

import itertools
import json
import os
import runpy
import subprocess
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mcp_registry import (  # noqa: E402
    ATLASSIAN_CONTOURS, ATLASSIAN_MCP_URL, CONFLUENCE_READ, CONFLUENCE_WRITE, GITLAB_INSTANCES, JIRA_READ,
    JIRA_WRITE, ROOT, USER_AGENT, atlassian_tools, gitlab_tools, load_env,
)
import platform_util  # noqa: E402 — системные сертификаты + корпоративные корни из shared/certs

try:
    import truststore

    truststore.inject_into_ssl()
except ImportError:
    pass


def run_atlassian(kind: str, url: str, token: str, tools: list[str]) -> None:
    import requests.utils

    requests.utils.default_user_agent = lambda *a, **k: USER_AGENT
    for k in list(os.environ):
        if k.startswith(("JIRA_", "CONFLUENCE_")):
            del os.environ[k]
    prefix = kind.upper()
    os.environ[f"{prefix}_URL"] = url
    os.environ[f"{prefix}_PERSONAL_TOKEN"] = token
    os.environ["ENABLED_TOOLS"] = ",".join(tools)
    os.environ.setdefault("MCP_VERBOSE", "false")
    from mcp_atlassian import main

    # --env-file: иначе mcp-atlassian найдёт наш .env вверх по папкам и перезапишет переменные
    sys.argv = ["mcp-atlassian", "--transport", "stdio", "--env-file", os.devnull]
    main()


def run_atlassian_cloud(name: str, env: dict[str, str]) -> None:
    """Мост stdio ⇄ облачный Atlassian MCP (streamable HTTP) AI Lab.

    Токены и адреса контура — в заголовках (как в инструкции AI Lab). Список инструментов
    фильтруется до выбранного профиля (compact/full), вызовы вне профиля блокируются.
    """
    import httpx

    url = env.get("ATLASSIAN_MCP_URL") or ATLASSIAN_MCP_URL
    (jira_url, jira_tok), (conf_url, conf_tok) = ATLASSIAN_CONTOURS[name]
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json, text/event-stream",
               "Content-Type": "application/json"}
    groups = []
    if env.get(jira_tok):
        headers |= {"X-Atlassian-Jira-Personal-Token": env[jira_tok], "X-Atlassian-Jira-Url": env[jira_url]}
        groups += ["jira_read", "jira_write"]
    if env.get(conf_tok):
        headers |= {"X-Atlassian-Confluence-Personal-Token": env[conf_tok],
                    "X-Atlassian-Confluence-Url": env[conf_url]}
        groups += ["confluence_read", "confluence_write"]
    headers["Enabled-Groups"] = ",".join(groups)
    cloud_bridge(url, headers, set(atlassian_tools(env)), "Облачный Atlassian MCP",
                 "сообщите ответственному за помощника", "ATLASSIAN_PROFILE")


def run_rhetorica() -> None:
    """Мост stdio ⇄ MCP Риторики (Data Agent КПД: поиск витрин, атрибутов, маппинга КПД 2.0 ↔ КХД 1.0).
    Вход — OAuth через браузер (rhetorica_auth.py) или личный API-токен RHETORICA_TOKEN."""
    import rhetorica_auth

    def reauth() -> str:
        # Без ожидания в браузере: вход — отдельным процессом, мост сразу объясняет, что делать (иначе Goose Desktop
        # висит на «загрузке разговора» до 170 с, пока пользователь не войдёт)
        try:
            return f"Bearer {rhetorica_auth.token(force_refresh=True, interactive=False)}"
        except rhetorica_auth.LoginNeeded:
            raise rhetorica_auth.LoginNeeded(rhetorica_auth.start_login()) from None

    try:
        auth = f"Bearer {rhetorica_auth.token(interactive=False)}"
    except Exception:  # noqa: BLE001 — войдёт при первом запросе (ответ 401 → браузер)
        auth = "Bearer -"
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json, text/event-stream",
               "Content-Type": "application/json", "Authorization": auth}
    tools = None if (env_value("RHETORICA_TOOLS") or "").lower() == "all" else RHETORICA_TOOLS
    url = f"{rhetorica_auth.BASE}/mcp"

    def call(name: str, args: dict, timeout: float) -> dict:
        """Прямой вызов инструмента Риторики (сервер без сессий) — для дожидания долгого ответа агента."""
        import httpx
        body = {"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": name, "arguments": args}}
        for attempt in (1, 2):
            r = httpx.post(url, json=body, headers=headers, timeout=timeout, verify=platform_util.corp_ssl_context())
            if r.status_code == 401 and attempt == 1:
                headers["Authorization"] = reauth()
                continue
            r.raise_for_status()
            text = r.text
            if "text/event-stream" in r.headers.get("content-type", ""):
                text = "\n".join(ln[5:] for ln in text.splitlines() if ln.startswith("data:"))
            return json.loads(text.strip().splitlines()[-1]).get("result") or {}
        return {}

    def ask_chat(name: str, args: dict) -> dict | None:
        """Агент Риторики думает 1–3 минуты, а её прокси обрывает ответ через 60 с (504). Разговор при этом
        досчитывается — забираем ответ из него. Общее ожидание — до ~4,5 мин (лимит вызова у Goose — 5 мин)."""
        if name != "ask_chat":
            return None
        import httpx
        started = time.time()
        try:
            return call("ask_chat", args, timeout=75)
        except (httpx.HTTPStatusError, httpx.TimeoutException) as e:
            if isinstance(e, httpx.HTTPStatusError) and e.response.status_code not in (502, 504):
                raise
        prefix = str(args.get("question", "")).strip()[:60]
        conv_id = args.get("conversation_id")
        while time.time() - started < 270:
            if not conv_id:
                listed = call("list_conversations", {"limit": 10}, timeout=30).get("structuredContent") or {}
                for c in listed.get("conversations") or []:
                    if str(c.get("title", "")).startswith(prefix[:50]):
                        conv_id = c["id"]
                        break
            if conv_id:
                conv = call("get_conversation", {"conversation_id": conv_id}, timeout=30).get("structuredContent") or {}
                msgs = (conv.get("conversation") or conv).get("messages") or []
                if msgs and msgs[-1].get("role") == "assistant" and (msgs[-1].get("content") or "").strip():
                    return {"content": [{"type": "text", "text": f"{msgs[-1]['content']}\n\n(conversation_id: {conv_id})"}]}
            time.sleep(10)
        return {"isError": True, "content": [{"type": "text", "text": (
            "Агент Риторики ещё думает (дольше 4,5 минут). Ответ появится в разговоре "
            f"{conv_id or 'в Риторике'} — проверь позже get_conversation или переформулируй вопрос короче.")}]}

    cache = Path.home() / ".magnit-agent" / "rhetorica-tools.json"

    def save_tools(items: list) -> None:  # описания инструментов — на случай следующего запуска без входа
        if items:
            cache.parent.mkdir(parents=True, exist_ok=True)
            cache.write_text(json.dumps(items, ensure_ascii=False), encoding="utf-8")

    prelude = None
    if auth == "Bearer -":  # входа нет: запускаемся без сервера, вход — при первом обращении к Риторике
        prelude, token = rhetorica_offline([cache, Path(__file__).resolve().parent / "rhetorica_tools.json"], tools)
        headers["Authorization"] = f"Bearer {token}"
    cloud_bridge(url, headers, tools, "Риторика", "войдите в Риторику заново", "RHETORICA_TOOLS",
                 reauth=reauth, intercept=ask_chat, prelude=prelude, on_tools=save_tools)


RHETORICA_LOGIN_TOOL = {
    "name": "rhetorica_login",
    "description": ("Вход в Риторику (Data Agent КПД): откроет окно входа в браузере и дождётся, пока пользователь "
                    "войдёт корпоративной учётной записью. После входа станут доступны инструменты Риторики: поиск "
                    "витрин и атрибутов, вопросы агенту данных."),
    "inputSchema": {"type": "object", "properties": {}},
}


def rhetorica_wait_login() -> str:
    """Токен Риторики: обновить сохранённый или войти в браузере и дождаться (до LOGIN_WAIT). Если вход уже идёт в
    другом процессе (порт ответа занят) — дождаться его токена, а не открывать второе окно."""
    import rhetorica_auth
    platform_util.notify("ИИ-помощник: вход в Риторику",
                         "Войдите в открывшемся окне браузера корпоративной учётной записью")
    try:
        return rhetorica_auth.token(interactive=True)
    except rhetorica_auth.LoginNeeded as e:
        if "Порт" not in str(e):
            raise
    deadline = time.time() + rhetorica_auth.LOGIN_WAIT + 15
    while time.time() < deadline:
        time.sleep(2)
        try:
            return rhetorica_auth.token(interactive=False)
        except rhetorica_auth.LoginNeeded:
            pass
    raise rhetorica_auth.LoginNeeded("Вход в Риторику не завершён: войдите в открытом окне браузера и повторите запрос.")


def rhetorica_offline(sources: list, allowed: set | None) -> tuple[list, str]:
    """Риторика без входа: расширение запускается сразу (иначе Goose пишет «расширение не загружено» и при открытии
    чата, и при включении), список инструментов — из сохранённого (после прошлого входа или из дистрибутива), а при
    первом вызове инструмента — вход в браузере с ожиданием. Возвращает (запросы для моста, токен)."""
    def out(obj: dict) -> None:
        sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
        sys.stdout.flush()

    tools: list = []
    for src in sources:
        try:
            tools = json.loads(Path(src).read_text(encoding="utf-8"))
            break
        except (OSError, ValueError):
            continue
    if allowed is not None:
        tools = [t for t in tools if t.get("name") in allowed]
    placeholder = not tools
    if placeholder:
        tools = [RHETORICA_LOGIN_TOOL]
    for line in sys.stdin:
        try:
            req = json.loads(line)
        except ValueError:
            continue
        method, rid = req.get("method"), req.get("id")
        if method == "initialize":
            out({"jsonrpc": "2.0", "id": rid, "result": {
                "protocolVersion": (req.get("params") or {}).get("protocolVersion", "2025-06-18"),
                "capabilities": {"tools": {"listChanged": True}},
                "serverInfo": {"name": "rhetorica", "version": "login-pending"}}})
        elif method == "tools/list":
            out({"jsonrpc": "2.0", "id": rid, "result": {"tools": tools}})
        elif method == "ping":
            out({"jsonrpc": "2.0", "id": rid, "result": {}})
        elif method == "tools/call":
            try:
                token = rhetorica_wait_login()
            except Exception as e:  # noqa: BLE001 — объяснить модели, что делать пользователю
                out({"jsonrpc": "2.0", "id": rid, "result": {"isError": True, "content": [
                    {"type": "text", "text": str(e)}]}})
                continue
            if placeholder:  # настоящие инструменты появятся после входа — Goose перечитает список
                out({"jsonrpc": "2.0", "method": "notifications/tools/list_changed"})
            if (req.get("params") or {}).get("name") == RHETORICA_LOGIN_TOOL["name"]:
                out({"jsonrpc": "2.0", "id": rid, "result": {"content": [{"type": "text", "text": (
                    "Вход в Риторику выполнен. Инструменты Риторики доступны — повтори запрос пользователя.")}]}})
                return [], token
            return [req], token  # первый вызов выполнит уже мост с токеном
        elif rid is not None:
            out({"jsonrpc": "2.0", "id": rid, "error": {"code": -32601, "message": f"{method}: недоступно до входа"}})
    sys.exit(0)


# Риторика отдаёт ~150 инструментов (~60 тыс. токенов): берём только поиск витрин и разговор с Data Agent.
# Jira/Confluence у помощника свои; создание заявок, задач и правка каталога не подключаются.
RHETORICA_TOOLS = {
    "ask_chat", "list_agents", "get_conversation", "search_tables", "list_metadata_services",
    "openmetadata__get_entity_details", "openmetadata__get_entity_lineage",
}


def env_value(key: str) -> str:
    return os.environ.get(key) or load_env().get(key, "")


def run_dbhub() -> None:
    """DBHub MCP (Node.js): базы из databases.toml, каждая — строго только на чтение."""
    from mcp_registry import DBHUB_BIN, database_sources

    lines = []
    for s in database_sources():
        esc = lambda v: str(v).replace("\\", "\\\\").replace('"', '\\"')  # noqa: E731
        lines += ["[[sources]]", f'id = "{esc(s["id"])}"', f'dsn = "{esc(s["dsn"])}"']
        if s.get("description"):
            lines.append(f'description = "{esc(s["description"])}"')
        for tool in ("execute_sql", "search_objects"):
            lines += ["", "[[tools]]", f'name = "{tool}"', f'source = "{esc(s["id"])}"'] + \
                     (["readonly = true"] if tool == "execute_sql" else [])
        lines.append("")
    state = Path.home() / ".magnit-agent"
    state.mkdir(parents=True, exist_ok=True)
    config = state / "dbhub.toml"
    config.touch(mode=0o600)
    config.write_text("\n".join(lines), encoding="utf-8")
    if sys.platform == "darwin":  # node из Homebrew
        os.environ["PATH"] = "/opt/homebrew/bin:/usr/local/bin:" + os.environ.get("PATH", "")
    os.execv(str(DBHUB_BIN), [str(DBHUB_BIN), "--transport", "stdio", "--config", str(config)])


def run_gitlab_cloud(name: str, env: dict[str, str]) -> None:
    """Мост stdio ⇄ облачный GitLab MCP AI Lab (токен — в Authorization, группы — в Enabled-Groups)."""
    url, token_var, _ = GITLAB_INSTANCES[name]
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json, text/event-stream",
               "Content-Type": "application/json", "Authorization": f"Bearer {env[token_var]}",
               "Enabled-Groups": env.get("GITLAB_GROUPS") or "core,code_review"}
    tools = gitlab_tools(env)
    cloud_bridge(url, headers, set(tools) if tools else None, "Облачный GitLab MCP",
                 "проверьте токен GitLab", "GITLAB_PROFILE")


def cloud_bridge(url: str, headers: dict, allowed: set | None, label: str, fallback: str, profile_var: str,
                 reauth=None, intercept=None, prelude: list | None = None, on_tools=None) -> None:
    """Общий мост stdio ⇄ облачный MCP (streamable HTTP): фильтр инструментов, удаление запрещено всегда.
    reauth() — новый заголовок Authorization при ответе 401 (OAuth: обновить токен или войти заново).
    intercept(name, arguments) — свой обработчик вызова инструмента: результат MCP (dict) или None — переслать как есть.
    prelude — запросы, уже прочитанные из stdin до запуска моста (Риторика: первый вызов после входа);
    on_tools(tools) — получен список инструментов (после фильтра): Риторика сохраняет его на случай запуска без входа."""
    import httpx

    def permitted(tool: str) -> bool:
        return not tool.startswith("delete_") and (allowed is None or tool in allowed)

    client = httpx.Client(timeout=httpx.Timeout(180, connect=15), verify=platform_util.corp_ssl_context())
    state: dict = {"session": None, "protocol": None}
    list_ids: set = set()
    lock = threading.Lock()
    workers: list[threading.Thread] = []

    def emit(obj: dict) -> None:
        with lock:
            sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
            sys.stdout.flush()

    def deliver(msg: dict) -> None:
        if msg.get("id") in list_ids and isinstance(msg.get("result"), dict):
            msg["result"]["tools"] = [t for t in msg["result"].get("tools", []) if permitted(t.get("name", ""))]
            list_ids.discard(msg.get("id"))
            if on_tools:
                try:
                    on_tools(msg["result"]["tools"])
                except Exception:  # noqa: BLE001 — сохранение списка не должно мешать работе
                    pass
        if isinstance(msg.get("result"), dict) and "protocolVersion" in msg["result"]:
            state["protocol"] = msg["result"]["protocolVersion"]
        emit(msg)

    def fail(req: dict, text: str) -> None:
        if req.get("method") == "initialize":
            # Не запустились — выходим, а не отвечаем ошибкой: Goose Desktop на ошибку в initialize не реагирует и ждёт
            # процесс до таймаута (300 с) при открытии каждого чата. Причина — в stderr, Goose показывает её в сообщении.
            sys.stderr.write(f"{text}\n")
            sys.stderr.flush()
            os._exit(1)
        if "id" in req:
            emit({"jsonrpc": "2.0", "id": req["id"], "error": {"code": -32000, "message": text}})

    def post(req: dict, retry: bool = True) -> None:
        h = dict(headers)
        if state["session"]:
            h["Mcp-Session-Id"] = state["session"]
        if state["protocol"]:
            h["MCP-Protocol-Version"] = state["protocol"]
        try:
            with client.stream("POST", url, json=req, headers=h) as resp:
                if resp.headers.get("mcp-session-id"):
                    state["session"] = resp.headers["mcp-session-id"]
                if resp.status_code == 202:
                    return
                if resp.status_code == 401 and reauth and retry:
                    resp.read()
                    try:
                        headers["Authorization"] = reauth()
                    except Exception as e:  # noqa: BLE001 — вход не выполнен: объяснить агенту
                        fail(req, str(e))
                        return
                    post(req, retry=False)
                    return
                if resp.status_code >= 400:
                    fail(req, f"{label} ответил {resp.status_code}: {resp.read()[:300]!r}")
                    return
                if "text/event-stream" in resp.headers.get("content-type", ""):
                    data: list[str] = []
                    for line in resp.iter_lines():
                        if line.startswith("data:"):
                            data.append(line[5:].strip())
                        elif not line and data:
                            deliver(json.loads("\n".join(data)))
                            data = []
                    if data:
                        deliver(json.loads("\n".join(data)))
                else:
                    body = resp.read()
                    if body.strip():
                        parsed = json.loads(body)
                        for msg in parsed if isinstance(parsed, list) else [parsed]:
                            deliver(msg)
        except Exception as e:  # noqa: BLE001
            detail = str(e).splitlines()[0][:160] if str(e) else ""
            fail(req, f"Нет связи с сервером «{label}» ({e.__class__.__name__}{': ' + detail if detail else ''}). "
                      f"Проверьте VPN (FortiClient или NetBird) или {fallback}.")

    for line in itertools.chain((json.dumps(r) for r in prelude or []), sys.stdin):
        try:
            req = json.loads(line)
        except ValueError:
            continue
        method = req.get("method")
        if method == "tools/list":
            list_ids.add(req.get("id"))
        if method == "tools/call" and not permitted((req.get("params") or {}).get("name", "")):
            emit({"jsonrpc": "2.0", "id": req.get("id"), "result": {"isError": True, "content": [
                {"type": "text", "text": f"Этот инструмент отключён в помощнике (см. {profile_var} в .env)."}]}})
            continue
        if method == "tools/call" and intercept:
            params = req.get("params") or {}

            def handle(req=req, params=params) -> None:
                try:
                    result = intercept(params.get("name", ""), params.get("arguments") or {})
                except Exception as e:  # noqa: BLE001
                    result = {"isError": True, "content": [{"type": "text", "text": f"{label}: {e}"}]}
                if result is None:
                    post(req)
                else:
                    emit({"jsonrpc": "2.0", "id": req.get("id"), "result": result})
            t = threading.Thread(target=handle, daemon=True)
            t.start()
            workers.append(t)
            continue
        if method == "initialize" or state["session"] is None:
            post(req)  # инициализацию — синхронно: нужен идентификатор сессии
        else:
            t = threading.Thread(target=post, args=(req,), daemon=True)
            t.start()
            workers.append(t)
    for t in workers:
        t.join(timeout=180)


GUARDED = {"jira", "jira-it", "confluence-it", "confluence-eportal", "calendar", "tag", "scheduler",
           "atlassian", "atlassian-it", "gitlab", "gitlab-platform", "drive"}
CHILD_FLAG = "MAGNIT_GUARD_CHILD"


def guarded_proxy(name: str) -> None:
    """Посредник: агент ⇄ (проверка guard) ⇄ MCP-сервер. Протокол MCP stdio — JSON по строкам."""
    utf8 = ["-X", "utf8"] if sys.flags.utf8_mode else []  # режим UTF-8 (Windows) — и дочернему серверу
    child = subprocess.Popen([sys.executable, *utf8, __file__, name], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             env={**os.environ, CHILD_FLAG: "1"})
    out_lock = threading.Lock()

    def emit(data: bytes) -> None:
        with out_lock:
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.flush()

    def pump_out() -> None:  # ответы сервера -> агенту
        for line in child.stdout:
            emit(line)

    threading.Thread(target=pump_out, daemon=True).start()
    guard = None
    for line in sys.stdin.buffer:  # запросы агента -> серверу
        try:
            msg = json.loads(line)
        except ValueError:
            msg = None
        if isinstance(msg, list):  # пакет JSON-RPC мимо проверки не пропускаем: MCP по stdio шлёт сообщения по одному
            emit((json.dumps({"jsonrpc": "2.0", "id": None, "error": {
                "code": -32600, "message": "Пакетные запросы не поддерживаются"}}) + "\n").encode())
            continue
        if isinstance(msg, dict) and msg.get("method") == "tools/call":
            tool = (msg.get("params") or {}).get("name", "")
            args = (msg.get("params") or {}).get("arguments") or {}
            if guard is None:
                import guard as guard_module  # загружается только при первом вызове инструмента
                guard = guard_module
            if guard.classify(name, tool):
                try:
                    ok, reason = guard.check(name, tool, args)
                except Exception as e:  # noqa: BLE001 — не смогли проверить: отказать, но расширение не ронять
                    ok, reason = False, f"проверка не выполнена ({e.__class__.__name__}: {str(e)[:120]}). Повторите позже."
                guard.audit(name, tool, args, ok, reason)
                if not ok:
                    emit((json.dumps({"jsonrpc": "2.0", "id": msg.get("id"), "result": {
                        "content": [{"type": "text", "text": f"⛔ Заблокировано защитой: {reason}"}],
                        "isError": True}}, ensure_ascii=False) + "\n").encode())
                    continue
                guard.record(name, tool, args)
        child.stdin.write(line)
        child.stdin.flush()
    child.stdin.close()
    child.wait()


def main() -> None:
    name = sys.argv[1]
    env = load_env()
    os.environ.update({k: v for k, v in env.items() if k not in os.environ})
    if name in GUARDED and os.environ.get(CHILD_FLAG) != "1":
        guarded_proxy(name)
        return

    if name in ATLASSIAN_CONTOURS:
        run_atlassian_cloud(name, env)
    elif name in GITLAB_INSTANCES:
        run_gitlab_cloud(name, env)
    elif name == "dbhub":
        run_dbhub()
    elif name == "rhetorica":
        run_rhetorica()
    elif name.startswith("jira"):
        suffix = "_IT" if name == "jira-it" else ""
        run_atlassian("jira", env[f"JIRA{suffix}_URL"], env[f"JIRA{suffix}_TOKEN"], JIRA_READ + JIRA_WRITE)
    elif name.startswith("confluence-"):
        suffix = name.split("-", 1)[1].upper()
        run_atlassian("confluence", env[f"CONFLUENCE_{suffix}_URL"], env[f"CONFLUENCE_{suffix}_TOKEN"],
                      CONFLUENCE_READ + CONFLUENCE_WRITE)
    elif name == "magnit-files":
        runpy.run_path(str(ROOT / "shared" / "files_mcp.py"), run_name="__main__")
    else:
        runpy.run_path(str(ROOT / "shared" / "servers" / f"{name.replace('-', '_')}_mcp.py"), run_name="__main__")


if __name__ == "__main__":
    main()
