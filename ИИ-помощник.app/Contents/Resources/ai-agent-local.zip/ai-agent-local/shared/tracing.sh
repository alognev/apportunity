# Ключ трассировки Langfuse для установщиков (setup.sh, app/agentctl.sh). Использование: source shared/tracing.sh.
# Требует функции get KEY и set_var KEY VALUE (работа с .env) у вызывающего скрипта.
# Ключ выдаёт ответственный за помощника одной строкой: «pk-lf-…:sk-lf-…», при другом сервере — «pk-lf-…:sk-lf-…@https://адрес».
LANGFUSE_DEFAULT_URL="https://langfuse.k8s.dev.plai.corp"
LANGFUSE_PENDING="$HOME/.magnit-agent/langfuse-key"   # ключ из команды установки (MAGNIT_LANGFUSE) до появления .env

langfuse_import() {  # langfuse_import "строка ключа" → LANGFUSE_* в .env; код 1 — строка не похожа на ключ
  local s="${1//[[:space:]]/}" re='^(pk-lf-[A-Za-z0-9-]+)[:,;]?(sk-lf-[A-Za-z0-9-]+)(@(https?://[^@]+))?$'
  [[ "$s" =~ $re ]] || return 1   # выражение в переменной — так его понимает и bash 3.2 из macOS
  set_var LANGFUSE_PUBLIC_KEY "${BASH_REMATCH[1]}"
  set_var LANGFUSE_SECRET_KEY "${BASH_REMATCH[2]}"
  if [[ -n "${BASH_REMATCH[4]}" ]]; then set_var LANGFUSE_BASE_URL "${BASH_REMATCH[4]%/}"
  elif [[ -z "$(get LANGFUSE_BASE_URL)" ]]; then set_var LANGFUSE_BASE_URL "$LANGFUSE_DEFAULT_URL"; fi
  # Текст разговоров — только с согласия сотрудника (спрашивает установщик); по умолчанию — без него
  [[ -n "$(get LANGFUSE_CAPTURE_CONTENT)" ]] || set_var LANGFUSE_CAPTURE_CONTENT 0
}

langfuse_import_pending() {  # ключ, переданный командой установки, переносится в .env
  [[ -f "$LANGFUSE_PENDING" ]] || return 0
  langfuse_import "$(cat "$LANGFUSE_PENDING")" || true
  rm -f "$LANGFUSE_PENDING"
}
