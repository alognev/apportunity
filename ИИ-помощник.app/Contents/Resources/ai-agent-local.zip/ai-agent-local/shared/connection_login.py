"""Explicit interactive setup of a corporate MCP connection after installation."""
from __future__ import annotations

from importlib import import_module
import json
import os
import re
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import webbrowser
from urllib.parse import urlsplit, unquote

import httpx

import platform_util
from corp_services import (CONNECTION_OVERRIDE, CONNECTION_PROFILE_VERSION, Client, DEFAULT_AUTH, basic_headers,
                           DEFAULT_URLS, ServiceError, check_response, service_url, validate_service_url)
from mcp_registry import ROOT, connection_file

TITLES = dict(airflow="Airflow", trino="Trino", grafana="Grafana", s3="S3", sourcebot="Sourcebot",
              jupyterhub="JupyterHub", datalens="DataLens", help="Help / ШПС")
METHODS = {
    "airflow": {"auto"}, "trino": {"auto"},
    "grafana": {"bearer", "cookie"}, "s3": {"keys"}, "sourcebot": {"cookie"},
    "jupyterhub": {"token"}, "datalens": {"session"}, "help": {"cookie"},
}
AUTH_DEFAULTS = {**DEFAULT_AUTH, "airflow": "auto", "trino": "auto", "s3": "keys", "datalens": "session"}
PROBES = {"datalens": "datalens_list_workbooks"}
CORP_SUFFIXES = (".corp", ".magnit.ru", ".tander.ru")


class Cancelled(Exception):
    """The user closed a local prompt."""


def _ask(title: str, label: str, default: str = "", *, hidden: bool = False) -> str:
    value = platform_util.ask_text(title, label, default, wait=50, hidden=hidden)
    if value is None:
        raise Cancelled
    return value


def _get_url(service: str, title: str) -> str:
    try:
        default = service_url(service)
    except ServiceError:
        default = DEFAULT_URLS[service]
    if service in {"datalens", "help", "sourcebot"}:
        # These sessions can only be used against the service configured on the machine.
        return default
    url = validate_service_url(service, _ask(title, "Введите HTTPS-адрес сервиса.", default))
    return _corporate_url(service, url)


def _fields(service: str, method: str, title: str) -> dict[str, str]:
    url = _get_url(service, title)
    values = {"URL": url, "AUTH": method}
    if method == "auto":
        pair = platform_util.ask_login(title, f"Вход для {url}. Введите учётную запись этой системы.", wait=50)
        if pair is None:
            raise Cancelled
        login, password = pair
        if ":" in login:
            raise ServiceError("Введите логин без двоеточия.")
        values.update(TOKEN=f"{login}:{password}", USER="")
    elif method == "keys":
        key = _ask(title, f"Идентификатор ключа доступа к {url}.").strip()
        if not key or ":" in key:
            raise ServiceError("Введите идентификатор ключа S3 без двоеточия.")
        secret = _ask(title, "Секретный ключ S3.", hidden=True)
        values["TOKEN"] = f"{key}:{secret}"
    else:
        labels = {
            "bearer": "Вставьте токен Bearer.",
            "token": "Вставьте API-токен из JupyterHub → Token.",
            "cookie": "Вставьте значение Cookie вашей действующей сессии.",
            "session": "Вставьте данные сессии JSON с полями cookie, csrf_token и tenant_id.",
        }
        values["TOKEN"] = _ask(title, f"{labels[method]} Сервер: {url}", hidden=True)
    return values


def _corporate_url(service: str, value: str) -> str:
    url = validate_service_url(service, value.strip())
    host = urlsplit(url).hostname or ""
    if host != urlsplit(DEFAULT_URLS[service]).hostname and not host.endswith(CORP_SUFFIXES):
        raise ServiceError("Укажите корпоративный HTTPS-адрес сервиса.")
    return url


def _oauth_path(base: str, candidate: str) -> str:
    """Honor coordinator-advertised endpoints only on its verified HTTPS origin."""
    target, origin = urlsplit(candidate), urlsplit(base)
    if (target.scheme != "https" or target.username is not None or target.password is not None
            or target.fragment or (target.hostname, target.port or 443) != (origin.hostname, origin.port or 443)
            or not unquote(target.path).startswith(origin.path.rstrip("/") + "/oauth2/")
            or any(part in (".", "..") for part in unquote(target.path).split("/"))
            or "\\" in candidate or any(c.isspace() for c in candidate)):
        raise ServiceError("Trino предоставил неподходящий адрес для входа.")
    return target.path[len(origin.path.rstrip("/")):] + ("?" + target.query if target.query else "")


def _trino_oauth(url: str, challenge: str) -> str:
    def param(name: str) -> str:
        match = re.search(r'\b' + name + r'\s*=\s*"([^"\r\n]+)"', challenge, re.I)
        return match[1] if match else ""

    redirect, token_uri = param("x_redirect_server"), param("x_token_server")
    if not redirect or not token_uri or not re.search(r"\bBearer\s", challenge, re.I):
        raise ServiceError("Trino отклонил вход. Проверьте логин, пароль и доступ к этому кластеру.", 401)
    _oauth_path(url, redirect)
    path = _oauth_path(url, token_uri)
    if not webbrowser.open(redirect):
        raise ServiceError("Не удалось открыть корпоративную страницу входа Trino.")
    deadline = time.monotonic() + 75
    with Client("trino", headers={}, base_url=url) as client:
        while time.monotonic() < deadline:
            response = client.request("GET", path, max_bytes=64 * 1024)
            if not isinstance(response, dict) or response.get("error"):
                break
            token = response.get("token")
            if isinstance(token, str) and 0 < len(token) <= 16_384 and token.isascii() and not any(c.isspace() for c in token):
                return token
            next_uri = response.get("nextUri")
            if not isinstance(next_uri, str):
                break
            path = _oauth_path(url, next_uri)
            if time.monotonic() < deadline:
                time.sleep(1)
    raise ServiceError("Вход в Trino через браузер не завершён. Попробуйте подключиться ещё раз.")


def _trino_password_login(url: str, login: str, password: str) -> dict[str, str]:
    if not login.isascii() or not login or ":" in login:
        raise ServiceError("Trino: укажите корректный логин.")
    credential = f"{login}:{password}"
    auth = basic_headers("trino", credential)
    auth.update({"X-Trino-User": login, "Content-Type": "text/plain; charset=utf-8"})
    with Client("trino", headers=auth, base_url=url) as client:
        try:
            # Inspect only the authentication challenge, without reading a rejected response body.
            with client.http.stream("POST", url + "/v1/statement", content=b"SELECT current_user") as response:
                if response.status_code == 401:
                    challenge = response.headers.get("www-authenticate", "")
                else:
                    check_response("trino", response)
                    body = bytearray()
                    for chunk in response.iter_bytes(chunk_size=8192):
                        if len(body) + len(chunk) > 64 * 1024:
                            raise ServiceError("Trino: неожиданный ответ при проверке входа.")
                        body.extend(chunk)
                    try:
                        result = json.loads(body)
                    except (ValueError, UnicodeError):
                        raise ServiceError("Trino: сервер не вернул ожидаемый ответ API.") from None
                    if not isinstance(result, dict) or not result.get("id") or "error" in result:
                        raise ServiceError("Trino: запрос проверки входа отклонён. Проверьте права на API.")
                    return {"URL": url, "AUTH": "basic", "TOKEN": credential, "USER": ""}
        except httpx.HTTPError:
            raise ServiceError("Trino: сервер недоступен. Проверьте VPN и адрес.") from None
    token = _trino_oauth(url, challenge)
    return {"URL": url, "AUTH": "bearer", "TOKEN": token, "USER": login}


def save_password_connection(service: str, address: str, login: str, password: str) -> None:
    if service not in {"airflow", "trino"}:
        raise ServiceError("Для этой системы вход по логину и паролю не поддерживается.")
    url = _corporate_url(service, address)
    login = login.strip()
    if not login or ":" in login or not password:
        raise ServiceError("Введите логин и пароль этой системы.")
    values = ({"URL": url, "AUTH": "basic", "TOKEN": f"{login}:{password}"}
              if service == "airflow" else _trino_password_login(url, login, password))
    if service != "trino" or values["AUTH"] == "bearer":
        _verify(service, values)
    _save(service, values)


def apply_pending_password_logins() -> list[str]:
    """Consume each installer submission once. Existing verified settings survive failures."""
    notes = []
    for service in ("airflow", "trino"):
        path = connection_file(f"{service.upper()}_LOGIN_REQUEST")
        try:
            if not path.is_file():
                continue
            # Rename before reading so two reconfigurations cannot both try the password.
            fd, name = tempfile.mkstemp(prefix=".login-", dir=path.parent)
            os.close(fd)
            claimed = Path(name)
            try:
                try:
                    path.replace(claimed)
                except FileNotFoundError:
                    continue
                if time.time() - claimed.stat().st_mtime > 3600:
                    raise ServiceError("Время ожидания установки истекло. Введите данные ещё раз.")
                record = claimed.read_text(encoding="utf-8").rstrip("\r\n")
            finally:
                claimed.unlink(missing_ok=True)
            address, sep, credential = record.partition("\t")
            login, colon, password = credential.partition(":")
            if not sep or not colon:
                raise ServiceError("Введите адрес, логин и пароль заново.")
            save_password_connection(service, address, login, password)
            notes.append(f"{TITLES[service]}: вход проверен и сохранён.")
        except ServiceError as exc:
            notes.append(f"{TITLES[service]}: не удалось подключиться. {exc}")
        except (OSError, ValueError, ImportError):
            notes.append(f"{TITLES[service]}: не удалось проверить вход. Повторите настройку.")
    return notes


def _verify(service: str, settings: dict[str, str]) -> None:
    override = CONNECTION_OVERRIDE.set((service, settings))
    try:
        module = import_module(f"servers.{service}_mcp")
        result = getattr(module, PROBES.get(service, f"{service}_status"))()
        # Trino and S3 render errors as localized strings in their MCP tools.
        if isinstance(result, str) and result.startswith(("Trino:", "S3:")):
            raise ServiceError(result)
    finally:
        CONNECTION_OVERRIDE.reset(override)


def _save(service: str, settings: dict[str, str]) -> None:
    dest = connection_file(f"{service.upper()}_TOKEN")
    dest.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".connection-", dir=dest.parent)
    staging = Path(name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as out:
            json.dump({"magnit_connection": CONNECTION_PROFILE_VERSION, "settings": settings}, out)
        staging.chmod(0o600)
        staging.replace(dest)
    finally:
        staging.unlink(missing_ok=True)


def _refresh_goose() -> bool:
    script = ROOT / "agent-b-goose" / "configure.py"
    try:
        proc = subprocess.run([sys.executable, str(script), "--connections-only"], cwd=ROOT,
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=45)
    except (OSError, subprocess.TimeoutExpired):
        return False
    return proc.returncode == 0


def configure_connection(service: str, method: str = "") -> str:
    if service not in TITLES:
        return "Эта система настраивается через меню «Подключить системы»."
    method = method or AUTH_DEFAULTS[service]
    if service in {"airflow", "trino"} and method == "basic":
        method = "auto"
    if method not in METHODS[service]:
        return f"{TITLES[service]}: доступные способы ввода — {', '.join(sorted(METHODS[service]))}."
    try:
        values = _fields(service, method, f"ИИ-помощник — вход в {TITLES[service]}")
        if method == "auto":
            login, password = values["TOKEN"].split(":", 1)
            save_password_connection(service, values["URL"], login, password)
        else:
            _verify(service, values)
            _save(service, values)
    except Cancelled:
        return "Вход отменён или окно не открылось. Подключение можно настроить через установщик."
    except ServiceError as exc:
        return str(exc)
    except (OSError, ValueError, ImportError):
        return "Не удалось проверить или сохранить подключение. Проверьте настройки и запустите диагностику."

    if _refresh_goose():
        return f"{TITLES[service]}: вход проверен и сохранён. Откройте новый чат для работы с системой."
    return (f"{TITLES[service]}: вход проверен и сохранён. Для применения сохраните настройки ИИ-помощника "
            "и откройте новый чат.")


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] != "address" or sys.argv[2] not in {"airflow", "trino"}:
        sys.exit(2)
    service = sys.argv[2]
    try:
        print(service_url(service))
    except ServiceError:
        print(DEFAULT_URLS[service])
