#!/usr/bin/env bash
# Общие Python-окружения. Идемпотентно. Флаг --gateway — ещё и локальный шлюз (для агентов A и C).
set -euo pipefail
SHARED="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

pick_python() {
  # Python от установщика (MAGNIT_PYTHON) или тот, на котором уже создано общее окружение
  [[ -n "${MAGNIT_PYTHON:-}" && -x "${MAGNIT_PYTHON}" ]] && { echo "$MAGNIT_PYTHON"; return; }
  [[ -x "$SHARED/.venv/bin/python" ]] && { echo "$SHARED/.venv/bin/python"; return; }
  for py in python3.13 python3.12 python3.11 python3; do
    py="$(command -v "$py" 2>/dev/null)" || continue
    # /usr/bin/python3 без Command Line Tools — заглушка с окном установки
    [[ "$py" == /usr/bin/python3 ]] && ! xcode-select -p >/dev/null 2>&1 && continue
    if "$py" -c 'import sys; sys.exit(sys.version_info < (3, 11))' 2>/dev/null; then
      echo "$py"; return
    fi
  done
  echo "Нужен Python 3.11+ (brew install python@3.13)" >&2; exit 1
}

make_venv() {  # $1 — папка venv, $2 — файл requirements
  local venv="$1" req="$2" stamp="$1/.installed"
  if [[ -f "$stamp" ]] && [[ "$stamp" -nt "$req" ]]; then return; fi
  echo "Устанавливаю зависимости: $(basename "$req")..."
  [[ -x "$venv/bin/python" ]] || "$(pick_python)" -m venv "$venv"
  "$venv/bin/pip" install -q --upgrade pip
  "$venv/bin/pip" install -q -r "$req"
  touch "$stamp"
}

make_venv "$SHARED/.venv" "$SHARED/requirements.txt"
make_venv "$SHARED/.venv-atlassian" "$SHARED/requirements-atlassian.txt"
# Модель эмбеддингов для семантического поиска (~115 МБ, один раз; без неё — полнотекстовый поиск)
"$SHARED/.venv/bin/python" "$SHARED/embeddings.py" download || true
[[ "${1:-}" == "--gateway" ]] && make_venv "$SHARED/.venv-gateway" "$SHARED/requirements-gateway.txt"
exit 0
