"""Трассировка в Langfuse: настройки и подключение агентов к локальному ретранслятору (langfuse_relay.py).

Включается ключами в .env: LANGFUSE_PUBLIC_KEY, LANGFUSE_SECRET_KEY, LANGFUSE_BASE_URL (или LANGFUSE_HOST).
Необязательно: LANGFUSE_TRACING=0 — выключить, не удаляя ключи; LANGFUSE_CAPTURE_CONTENT=0 — без текста
сообщений (только модели, токены, время, вызовы инструментов); LANGFUSE_TRACING_ENVIRONMENT (production);
LANGFUSE_RELAY_PORT (4319).

  python tracing.py apply   — включить/выключить по .env: launchd-агент ретранслятора и переменные для Goose Desktop
  python tracing.py status  — что включено, очередь, доступность Langfuse
Только стандартная библиотека (импортируется из разных окружений).
"""

from __future__ import annotations

import getpass
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LABEL = "ru.magnit-agent.langfuse-relay"
PLIST = Path.home() / "Library" / "LaunchAgents" / f"{LABEL}.plist"
OFF = {"0", "false", "no", "off", "нет", "выкл"}
# Для приложений, запущенных из Finder/Dock (Goose Desktop): адрес — в config.yaml Goose, остальное — переменными
# сеанса launchd. Метрики и логи OTLP Goose не шлёт: Langfuse принимает только трассы.
GUI_ENV = {"OTEL_METRICS_EXPORTER": "none", "OTEL_LOGS_EXPORTER": "none"}
CONTENT_ENV = "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"


def settings(env: dict[str, str]) -> dict | None:
    """Настройки трассировки или None, если она выключена."""
    public, secret = env.get("LANGFUSE_PUBLIC_KEY", ""), env.get("LANGFUSE_SECRET_KEY", "")
    base = env.get("LANGFUSE_BASE_URL") or env.get("LANGFUSE_HOST") or ""
    if not (public and secret and base) or (env.get("LANGFUSE_TRACING") or "1").strip().lower() in OFF:
        return None
    try:
        release = (ROOT / "VERSION").read_text().strip()
    except OSError:
        release = "dev"
    return {
        "public_key": public, "secret_key": secret, "base_url": base.rstrip("/"),
        "port": int(env.get("LANGFUSE_RELAY_PORT") or 4319) if (env.get("LANGFUSE_RELAY_PORT") or "4319").isdigit()
        else 4319,
        "environment": (env.get("LANGFUSE_TRACING_ENVIRONMENT") or "production").strip().lower(),
        "content": (env.get("LANGFUSE_CAPTURE_CONTENT") or "1").strip().lower() not in OFF,
        "user": getpass.getuser(), "release": release,
    }


def relay_url(env: dict[str, str]) -> str | None:
    cfg = settings(env)
    return f"http://127.0.0.1:{cfg['port']}" if cfg else None


def agent_env(env: dict[str, str]) -> dict[str, str]:
    """Переменные для процессов агентов (Goose CLI, автоматизации): без ключей Langfuse."""
    cfg = settings(env)
    if not cfg:
        return {}
    out = dict(GUI_ENV)
    if cfg["content"]:
        out[CONTENT_ENV] = "true"
    return out


def goose_config(cfg: dict, env: dict[str, str]) -> None:
    """Адрес ретранслятора в config.yaml Goose (его читают и Goose Desktop, и CLI)."""
    url = relay_url(env)
    if url:
        cfg["otel_exporter_otlp_endpoint"] = url
        cfg["otel_exporter_otlp_timeout"] = 3000  # мс; ретранслятор отвечает сразу
    else:
        cfg.pop("otel_exporter_otlp_endpoint", None)
        cfg.pop("otel_exporter_otlp_timeout", None)


def _launchctl(*args: str) -> None:
    subprocess.run(["launchctl", *args], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)


def session_env(env: dict[str, str]) -> None:
    """Переменные сеанса launchd для приложений из Finder/Dock (Goose Desktop). Сбрасываются при перезагрузке —
    ретранслятор выставляет их заново при каждом входе в систему."""
    cfg = settings(env)
    for k in [*GUI_ENV, CONTENT_ENV]:
        _launchctl("unsetenv", k)
    for k, v in agent_env(env).items() if cfg else []:
        _launchctl("setenv", k, v)


def apply(env: dict[str, str]) -> str:
    """Запустить/остановить ретранслятор и выставить переменные сеанса по настройкам в .env."""
    cfg = settings(env)
    domain = f"gui/{os.getuid()}"
    _launchctl("bootout", f"{domain}/{LABEL}")
    session_env(env)
    if not cfg:
        PLIST.unlink(missing_ok=True)
        return "выключена"
    py = ROOT / "shared" / ".venv" / "bin" / "python"
    PLIST.parent.mkdir(parents=True, exist_ok=True)
    PLIST.write_text(f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>{LABEL}</string>
  <key>ProgramArguments</key><array><string>{py}</string><string>{ROOT / 'shared' / 'langfuse_relay.py'}</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><dict><key>SuccessfulExit</key><false/></dict>
  <key>ThrottleInterval</key><integer>30</integer>
  <key>ProcessType</key><string>Background</string>
  <key>LowPriorityIO</key><true/>
  <key>StandardOutPath</key><string>/dev/null</string>
  <key>StandardErrorPath</key><string>/dev/null</string>
</dict></plist>
""")
    _launchctl("bootstrap", domain, str(PLIST))
    return f"включена → {cfg['base_url']} (через 127.0.0.1:{cfg['port']})"


def status(env: dict[str, str]) -> str:
    cfg = settings(env)
    if not cfg:
        return "Трассировка Langfuse: выключена (нет LANGFUSE_* в .env)"
    import urllib.request
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{cfg['port']}/", timeout=2)
        relay = "работает"
    except OSError:
        relay = "не запущен"
    spool = Path.home() / ".magnit-agent" / "langfuse-spool"
    queued = len([p for p in spool.glob("*") if not p.name.startswith(".")]) if spool.exists() else 0
    content = "с текстом сообщений" if cfg["content"] else "без текста сообщений"
    return (f"Трассировка Langfuse: включена, {content}, окружение {cfg['environment']}\n"
            f"  ретранслятор 127.0.0.1:{cfg['port']}: {relay}; в очереди посылок: {queued}\n"
            f"  Langfuse: {cfg['base_url']}")


if __name__ == "__main__":
    sys.path.insert(0, str(ROOT / "shared"))
    from mcp_registry import load_env

    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    print(apply(load_env()) if cmd == "apply" else status(load_env()))
