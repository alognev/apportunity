"""Защита корпоративных систем от массовых и разрушительных действий через агента.

Проверка выполняется в коде (mcp_launch.py — посредник между агентом и каждым MCP-сервером),
поэтому её нельзя отменить формулировкой запроса к модели. Действует для всех трёх агентов,
веб-помощника и автоматизаций.

Правила:
  • лимиты на изменения в час по каждой системе + лимит «всплеска» за минуту по всем системам;
  • чужие задачи Jira и страницы Confluence по умолчанию можно менять; при GUARD_FOREIGN_OBJECTS=deny —
    только комментировать (нельзя переписывать, переназначать, переводить по статусам);
  • встречи: ограничение числа участников и приглашений в час;
  • сообщения Tag: лимит в час, в каналы — отдельный, меньший лимит;
  • все изменения и отказы пишутся в журнал ~/.magnit-agent/audit.log.

Настройки в .env:
  GUARD_ENABLED=1            — 0/false/off выключает защиту целиком (журнал аудита пишется всегда);
  GUARD_FOREIGN_OBJECTS=allow — deny запрещает менять чужие задачи и страницы (только комментарии);
  GUARD_*                    — лимиты (см. DEFAULTS), 0 — без ограничения.
Счётчики общие для всех процессов (SQLite).
"""

from __future__ import annotations

import json
import sqlite3
import time
from functools import lru_cache
from pathlib import Path

import httpx

from mcp_registry import USER_AGENT, load_env

STATE = Path.home() / ".magnit-agent"
DB = STATE / "guard.db"
AUDIT = STATE / "audit.log"

DEFAULTS = {
    "GUARD_BURST_PER_MINUTE": 200,            # любых изменений во всех системах за минуту
    "GUARD_JIRA_WRITES_PER_HOUR": 200,       # изменений в Jira (все действия)
    "GUARD_JIRA_CREATES_PER_HOUR": 200,      # новых задач в Jira
    "GUARD_CONFLUENCE_WRITES_PER_HOUR": 100,  # страниц создано/изменено, комментариев
    "GUARD_CONFLUENCE_CREATES_PER_HOUR": 50,  # новых страниц
    "GUARD_CALENDAR_WRITES_PER_HOUR": 30,   # встреч создано/изменено/отменено
    "GUARD_CALENDAR_MAX_ATTENDEES": 40,     # участников в одной встрече
    "GUARD_TAG_MESSAGES_PER_HOUR": 50,      # сообщений в Tag
    "GUARD_TAG_CHANNEL_POSTS_PER_HOUR": 50,  # из них — в каналы
    "GUARD_GITLAB_WRITES_PER_HOUR": 200,    # изменений в GitLab (комментарии, review, запись файлов, MR)
    "GUARD_DRIVE_WRITES_PER_HOUR": 100,     # файлов и папок, записанных в Magnit Drive
    "GUARD_AUTOMATIONS_MAX": 100,            # всего автоматизаций
}

# Действия на чужих объектах, которые запрещаются при GUARD_FOREIGN_OBJECTS=deny (комментарии разрешены)
JIRA_FOREIGN_BLOCKED = {"jira_update_issue", "jira_transition_issue", "jira_assign_issue", "jira_link_to_epic"}
CONFLUENCE_FOREIGN_BLOCKED = {"confluence_update_page", "confluence_add_label"}

# инструмент -> (система, вид действия для лимитов)
WRITES = {
    "jira_create_issue": ("jira", "create"), "jira_update_issue": ("jira", "update"),
    "jira_assign_issue": ("jira", "update"), "jira_transition_issue": ("jira", "update"),
    "jira_add_comment": ("jira", "comment"), "jira_add_worklog": ("jira", "update"),
    "jira_link_to_epic": ("jira", "update"), "jira_create_issue_link": ("jira", "update"),
    "confluence_create_page": ("confluence", "create"), "confluence_update_page": ("confluence", "update"),
    "confluence_add_comment": ("confluence", "comment"), "confluence_add_label": ("confluence", "update"),
    "calendar_create_event": ("calendar", "create"), "calendar_update_event": ("calendar", "update"),
    "calendar_cancel_event": ("calendar", "update"), "calendar_respond": ("calendar", "respond"),
    "tag_send_message": ("tag", "message"), "tag_send_file": ("tag", "message"),
    "automation_create": ("scheduler", "create"),
    "drive_upload": ("drive", "write"), "drive_save_text": ("drive", "write"), "drive_mkdir": ("drive", "write"),
}


OFF_VALUES = {"0", "false", "no", "off", "нет", "выкл"}


def is_enabled() -> bool:
    """Общий выключатель защиты: GUARD_ENABLED в .env (по умолчанию включена)."""
    return (load_env().get("GUARD_ENABLED") or "1").strip().lower() not in OFF_VALUES


def foreign_blocked() -> bool:
    """Запрещено ли менять чужие задачи и страницы (по умолчанию — разрешено)."""
    return (load_env().get("GUARD_FOREIGN_OBJECTS") or "allow").strip().lower() in ("deny", "запретить")


GITLAB_SERVERS = {"gitlab", "gitlab-platform"}
GITLAB_READ_PREFIXES = ("get_", "list_", "search_", "mr_discussions")


def classify(server: str, tool: str) -> tuple[str, str] | None:
    """(система, вид действия) для изменяющего вызова; None — только чтение."""
    if server in GITLAB_SERVERS:
        return None if tool.startswith(GITLAB_READ_PREFIXES) else ("gitlab", "write")
    return WRITES.get(tool)


def limit(key: str) -> int:
    """Значение лимита; 0 — без ограничения."""
    raw = (load_env().get(key) or "").strip()
    try:
        return int(raw) if raw else DEFAULTS[key]
    except ValueError:
        return DEFAULTS[key]


def _over(key: str, count: int) -> bool:
    n = limit(key)
    return n > 0 and count >= n


def _db() -> sqlite3.Connection:
    STATE.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB, timeout=10)
    con.execute("CREATE TABLE IF NOT EXISTS events (ts REAL, system TEXT, kind TEXT, tool TEXT)")
    return con


def _count(system: str | None, seconds: int, kind: str | None = None) -> int:
    q, args = "SELECT COUNT(*) FROM events WHERE ts > ?", [time.time() - seconds]
    if system:
        q, args = q + " AND system = ?", args + [system]
    if kind:
        q, args = q + " AND kind = ?", args + [kind]
    with _db() as con:
        return con.execute(q, args).fetchone()[0]


def _record(system: str, kind: str, tool: str) -> None:
    with _db() as con:
        con.execute("INSERT INTO events VALUES (?,?,?,?)", (time.time(), system, kind, tool))
        con.execute("DELETE FROM events WHERE ts < ?", (time.time() - 7 * 86400,))


def audit(server: str, tool: str, args: dict, allowed: bool, reason: str = "") -> None:
    STATE.mkdir(parents=True, exist_ok=True)
    short = {k: (v if len(str(v)) < 200 else str(v)[:200] + "…") for k, v in (args or {}).items()}
    with AUDIT.open("a") as f:
        f.write(json.dumps({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "server": server, "tool": tool,
                            "allowed": allowed, "reason": reason, "args": short}, ensure_ascii=False) + "\n")


# ---------- кто владелец объекта (запросы к API с токеном пользователя) ----------

def _conn(server: str) -> tuple[str, str]:
    env = load_env()
    if server.startswith("jira"):
        sfx = "_IT" if server == "jira-it" else ""
        return env[f"JIRA{sfx}_URL"].rstrip("/"), env[f"JIRA{sfx}_TOKEN"]
    sfx = server.split("-", 1)[1].upper()
    return env[f"CONFLUENCE_{sfx}_URL"].rstrip("/"), env[f"CONFLUENCE_{sfx}_TOKEN"]


def _get(server: str, path: str) -> dict:
    base, token = _conn(server)
    r = httpx.get(base + path, timeout=20, headers={"Authorization": f"Bearer {token}", "Accept": "application/json",
                                                     "User-Agent": USER_AGENT})
    r.raise_for_status()
    return r.json()


@lru_cache
def _me(server: str) -> set[str]:
    d = _get(server, "/rest/api/2/myself" if server.startswith("jira") else "/rest/api/user/current")
    return {v for v in (d.get("name"), d.get("key"), d.get("username"), d.get("userKey")) if v}


def _jira_owned(server: str, key: str) -> bool:
    f = _get(server, f"/rest/api/2/issue/{key}?fields=reporter,assignee,creator")["fields"]
    people = {v for p in (f.get("reporter"), f.get("assignee"), f.get("creator")) if p
              for v in (p.get("name"), p.get("key"))}
    return bool(people & _me(server))


def _confluence_owned(server: str, page_id: str) -> bool:
    by = _get(server, f"/rest/api/content/{page_id}?expand=history")["history"]["createdBy"]
    return bool({by.get("username"), by.get("userKey")} & _me(server))


# ---------- главная проверка ----------

def check(server: str, tool: str, args: dict) -> tuple[bool, str]:
    """Можно ли выполнить вызов инструмента. Возвращает (разрешено, причина отказа)."""
    what = classify(server, tool)
    if what is None or not is_enabled():
        return True, ""
    system, kind = what
    if server in ("atlassian", "atlassian-it"):  # облачный MCP: Jira и Confluence одного контура
        it = server.endswith("-it")
        server = ("jira-it" if it else "jira") if system == "jira" else ("confluence-it" if it else "confluence-eportal")
    args = args or {}

    if _over("GUARD_BURST_PER_MINUTE", _count(None, 60)):
        return False, ("Слишком много изменений подряд (больше {} в минуту). Похоже на массовую операцию — "
                       "подождите минуту и выполняйте изменения по одному, проверяя каждое.").format(
            limit("GUARD_BURST_PER_MINUTE"))

    if system == "jira":
        if _over("GUARD_JIRA_WRITES_PER_HOUR", _count("jira", 3600)):
            return False, f"Достигнут лимит изменений в Jira: {limit('GUARD_JIRA_WRITES_PER_HOUR')} в час."
        if kind == "create" and _over("GUARD_JIRA_CREATES_PER_HOUR", _count("jira", 3600, "create")):
            return False, f"Достигнут лимит новых задач в Jira: {limit('GUARD_JIRA_CREATES_PER_HOUR')} в час."
        if tool in JIRA_FOREIGN_BLOCKED and foreign_blocked():
            key = str(args.get("issue_key", ""))
            try:
                owned = _jira_owned(server, key)
            except Exception as e:  # noqa: BLE001 — не смогли проверить владельца: безопаснее отказать
                return False, f"Не удалось проверить, ваша ли задача {key} ({e.__class__.__name__}). Действие отменено."
            if not owned:
                return False, (f"Задача {key} не ваша (вы не автор и не исполнитель). Менять чужие задачи через "
                               "помощника нельзя: можно оставить комментарий или попросить автора.")

    elif system == "confluence":
        if _over("GUARD_CONFLUENCE_WRITES_PER_HOUR", _count("confluence", 3600)):
            return False, f"Достигнут лимит изменений в Confluence: {limit('GUARD_CONFLUENCE_WRITES_PER_HOUR')} в час."
        if kind == "create" and _over("GUARD_CONFLUENCE_CREATES_PER_HOUR", _count("confluence", 3600, "create")):
            return False, f"Достигнут лимит новых страниц: {limit('GUARD_CONFLUENCE_CREATES_PER_HOUR')} в час."
        if tool in CONFLUENCE_FOREIGN_BLOCKED and foreign_blocked():
            page = str(args.get("page_id", ""))
            try:
                owned = _confluence_owned(server, page)
            except Exception as e:  # noqa: BLE001
                return False, f"Не удалось проверить автора страницы {page} ({e.__class__.__name__}). Действие отменено."
            if not owned:
                return False, (f"Страницу {page} создали не вы. Менять чужие страницы через помощника нельзя: "
                               "можно оставить комментарий или попросить автора.")

    elif system == "calendar":
        if kind != "respond" and _over("GUARD_CALENDAR_WRITES_PER_HOUR", _count("calendar", 3600)):
            return False, f"Достигнут лимит изменений в календаре: {limit('GUARD_CALENDAR_WRITES_PER_HOUR')} в час."
        people = args.get("attendees") or args.get("add_attendees") or []
        if 0 < limit("GUARD_CALENDAR_MAX_ATTENDEES") < len(people):
            return False, (f"Слишком много участников ({len(people)}). Через помощника можно пригласить не больше "
                           f"{limit('GUARD_CALENDAR_MAX_ATTENDEES')}; для больших встреч используйте Outlook.")

    elif system == "tag":
        if _over("GUARD_TAG_MESSAGES_PER_HOUR", _count("tag", 3600)):
            return False, f"Достигнут лимит сообщений в Tag: {limit('GUARD_TAG_MESSAGES_PER_HOUR')} в час."
        if str(args.get("to", "")).startswith("~"):
            if _over("GUARD_TAG_CHANNEL_POSTS_PER_HOUR", _count("tag", 3600, "channel")):
                return False, f"Достигнут лимит сообщений в каналы: {limit('GUARD_TAG_CHANNEL_POSTS_PER_HOUR')} в час."

    elif system == "gitlab":
        if _over("GUARD_GITLAB_WRITES_PER_HOUR", _count("gitlab", 3600)):
            return False, f"Достигнут лимит изменений в GitLab: {limit('GUARD_GITLAB_WRITES_PER_HOUR')} в час."

    elif system == "drive":
        if _over("GUARD_DRIVE_WRITES_PER_HOUR", _count("drive", 3600)):
            return False, f"Достигнут лимит записи в Magnit Drive: {limit('GUARD_DRIVE_WRITES_PER_HOUR')} файлов в час."

    elif system == "scheduler":
        import scheduler
        if _over("GUARD_AUTOMATIONS_MAX", len(scheduler.all_tasks())):
            return False, f"У вас уже {limit('GUARD_AUTOMATIONS_MAX')} автоматизаций — удалите ненужные."

    return True, ""


def record(server: str, tool: str, args: dict) -> None:
    """Учесть разрешённое изменение в счётчиках."""
    what = classify(server, tool)
    if what:
        system, kind = what
        if system == "tag" and str((args or {}).get("to", "")).startswith("~"):
            kind = "channel"
        _record(system, kind, tool)
