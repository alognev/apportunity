"""PreToolUse-хук для инструмента Read (агенты A и C).

Основная модель принимает только текст, поэтому бинарные документы и картинки
перенаправляем на MCP-инструменты magnit-files. В отличие от правил deny в settings,
хук не мешает Bash-скриптам работать с этими файлами.
"""

import json
import sys
from pathlib import Path

IMAGES = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".heic"}
DOCUMENTS = {".pdf", ".xlsx", ".xlsm", ".xls", ".docx", ".doc", ".pptx", ".ppt", ".odt", ".ods"}

data = json.load(sys.stdin)
suffix = Path(data.get("tool_input", {}).get("file_path", "")).suffix.lower()
if suffix in IMAGES:
    reason = "Модель не видит картинки. Используй инструмент mcp__magnit-files__describe_image."
elif suffix in DOCUMENTS:
    reason = "Бинарный документ. Используй mcp__magnit-files__read_document (или ocr_pdf для сканов)."
else:
    sys.exit(0)
print(json.dumps({"hookSpecificOutput": {
    "hookEventName": "PreToolUse", "permissionDecision": "deny", "permissionDecisionReason": reason}}))
