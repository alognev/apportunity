"""Добавить базу в databases.toml (вызывается из setup.sh). Параметры — в переменных окружения
DB_FILE, DB_ID, DB_DSN, чтобы пароль не попадал в аргументы процесса."""

import json
import os

# JSON-строка — корректная строка TOML (экранирование кавычек и обратных слэшей)
entry = f'\n[[sources]]\nid = {json.dumps(os.environ["DB_ID"], ensure_ascii=False)}\n' \
        f'dsn = {json.dumps(os.environ["DB_DSN"], ensure_ascii=False)}\n'
with open(os.environ["DB_FILE"], "a") as f:
    f.write(entry)
