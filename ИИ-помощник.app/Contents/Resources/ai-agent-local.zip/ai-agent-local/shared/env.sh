# Общая загрузка настроек для скриптов запуска. Использование: source "$ROOT/shared/env.sh"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ ! -f "$ROOT/.env" ]]; then
  echo "Не найден $ROOT/.env — запустите $ROOT/setup.sh" >&2
  exit 1
fi
set -a
# shellcheck disable=SC1091
source "$ROOT/.env"
set +a
# Трассировка Langfuse идёт через локальный ретранслятор (shared/langfuse_relay.py, ключи — только у него).
# Ключи убираем из окружения агентов: иначе Goose включит свою прямую отправку в Langfuse.
MAGNIT_TRACING_URL=""
if [[ -n "${LANGFUSE_PUBLIC_KEY:-}" && -n "${LANGFUSE_SECRET_KEY:-}" && -n "${LANGFUSE_BASE_URL:-${LANGFUSE_HOST:-}}" ]] \
   && [[ ! "${LANGFUSE_TRACING:-1}" =~ ^(0|false|no|off|нет|выкл)$ ]]; then
  MAGNIT_TRACING_URL="http://127.0.0.1:${LANGFUSE_RELAY_PORT:-4319}"
  export OTEL_METRICS_EXPORTER=none OTEL_LOGS_EXPORTER=none
  [[ "${LANGFUSE_CAPTURE_CONTENT:-1}" =~ ^(0|false|no|off|нет|выкл)$ ]] \
    || export OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT=true
fi
unset LANGFUSE_PUBLIC_KEY LANGFUSE_SECRET_KEY LANGFUSE_BASE_URL LANGFUSE_HOST LANGFUSE_URL \
      LANGFUSE_INIT_PROJECT_PUBLIC_KEY LANGFUSE_INIT_PROJECT_SECRET_KEY
export MAGNIT_TRACING_URL
LLM_BASE_URL="${LLM_BASE_URL%/}"
AGENT_WORKSPACE="${AGENT_WORKSPACE/#\~/$HOME}"
SHARED_PY="$ROOT/shared/.venv/bin/python"
FILES_MCP="$ROOT/shared/files_mcp.py"
if [[ ! -x "$SHARED_PY" ]]; then
  echo "Не установлено общее окружение. Запустите $ROOT/setup.sh" >&2
  exit 1
fi
if [[ -z "$LLM_API_KEY" ]]; then
  echo "В $ROOT/.env не задан LLM_API_KEY" >&2
  exit 1
fi
MAGNIT_ROOT="$ROOT"
export ROOT MAGNIT_ROOT SHARED_PY FILES_MCP LLM_BASE_URL AGENT_WORKSPACE

# Текст инструкций с подставленным путём к Python
agent_instructions() {
  sed "s#{{PYTHON}}#$SHARED_PY#g" "$ROOT/shared/instructions.md"
}
