# Общая загрузка настроек для скриптов запуска. Использование: source "$ROOT/shared/env.sh"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ ! -f "$ROOT/.env" ]]; then
  echo "Не найден $ROOT/.env — запустите $ROOT/setup.sh" >&2
  exit 1
fi
set -a
# shellcheck disable=SC1091
source "$ROOT/.env"
set +a
LLM_BASE_URL="${LLM_BASE_URL%/}"
AGENT_WORKSPACE="${AGENT_WORKSPACE/#\~/$HOME}"
SHARED_PY="$ROOT/shared/.venv/bin/python"
FILES_MCP="$ROOT/shared/files_mcp.py"
if [[ ! -x "$SHARED_PY" ]]; then
  echo "Не установлено общее окружение. Запустите $ROOT/setup.sh" >&2
  exit 1
fi
if [[ -z "$LLM_API_KEY" ]]; then
  echo "В $ROOT/.env не задан LLM_API_KEY" >&2
  exit 1
fi
MAGNIT_ROOT="$ROOT"
export ROOT MAGNIT_ROOT SHARED_PY FILES_MCP LLM_BASE_URL AGENT_WORKSPACE

# Текст инструкций с подставленным путём к Python
agent_instructions() {
  sed "s#{{PYTHON}}#$SHARED_PY#g" "$ROOT/shared/instructions.md"
}
