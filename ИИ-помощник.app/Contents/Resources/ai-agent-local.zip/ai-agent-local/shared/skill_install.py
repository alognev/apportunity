"""Установка навыка (skill) из Magnit Drive, по ссылке или с компьютера: python skill_install.py <источник>.

Источник:
  • путь в Magnit Drive: «MCOS/Sandbox/magnit-operkom.zip», «/MCOS/…», «drive:MCOS/…» (вход в Drive — через браузер);
  • ссылка https на архив на корпоративном сайте (*.magnit.ru, *.tander.ru, *.corp);
  • архив .zip или папка на этом компьютере.
Навык ставится в ~/.magnit-agent/skills/<имя> (прежняя версия — в ~/.magnit-agent/skills-backup) и подключается
к агентам. При установке ничего из навыка не запускается: проверяются шапка SKILL.md, состав, размер и пути внутри.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import unicodedata
import zipfile
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
SKILLS = Path.home() / ".magnit-agent" / "skills"
BACKUP = Path.home() / ".magnit-agent" / "skills-backup"
MAX_DOWNLOAD = 150 * 1024 * 1024
MAX_UNPACKED = 300 * 1024 * 1024
MAX_FILES = 3000
CORP_HOSTS = (".magnit.ru", ".tander.ru", ".corp")
# Как требует Goose: строчные буквы (латиница или кириллица — русское имя пользователь видит в Goose), цифры, дефис
NAME_RE = re.compile(r"^[a-zа-яё0-9][a-zа-яё0-9-]{1,63}$")


class InstallError(RuntimeError):
    pass


def _fetch(source: str, tmp: Path) -> Path:
    """Источник → локальный файл или папка во временной папке."""
    src = source.strip().strip('"').strip("'")
    if src.startswith(("http://", "https://")):
        host = urlparse(src).hostname or ""
        if "drive.magnit.ru" in host:
            raise InstallError("Для Magnit Drive укажите путь к файлу, например «MCOS/Sandbox/навык.zip», а не ссылку.")
        if not host.endswith(CORP_HOSTS):
            raise InstallError(f"Скачивать навыки можно только с корпоративных сайтов (*.magnit.ru, *.tander.ru, *.corp), "
                               f"а не с {host}.")
        import httpx
        try:
            import truststore
            truststore.inject_into_ssl()
        except ImportError:
            pass
        out = tmp / (Path(urlparse(src).path).name or "skill.zip")
        with httpx.stream("GET", src, timeout=120, follow_redirects=True,
                          headers={"User-Agent": "magnit-local-agent/1.0 (AI assistant)"}) as r:
            final = r.url.host or ""
            if not final.endswith(CORP_HOSTS) or "drive.magnit.ru" in final:  # переадресация на внешний сайт
                raise InstallError(f"Ссылка ведёт на {final} — скачивать навыки можно только с корпоративных сайтов.")
            if r.status_code in (401, 403):
                raise InstallError(f"Сайт не пустил скачать архив ({r.status_code}). Скачайте его в браузере и укажите "
                                   "путь к файлу на компьютере.")
            r.raise_for_status()
            size = 0
            with out.open("wb") as f:
                for chunk in r.iter_bytes():
                    size += len(chunk)
                    if size > MAX_DOWNLOAD:
                        raise InstallError("Архив больше 150 МБ — это не похоже на навык.")
                    f.write(chunk)
        return out
    local = Path(src).expanduser()
    if local.exists():
        return local
    # Magnit Drive: «drive:путь», «/MCOS/…» или «MCOS/…»
    path = src[6:] if src.lower().startswith("drive:") else src
    sys.path.insert(0, str(ROOT / "shared" / "servers"))
    import drive_mcp
    candidates = [path] if path.startswith("/") else ["/" + path, path]  # «MCOS/…» — от корня Drive, иначе — от рабочей папки
    last = None
    for cand in candidates:
        full = drive_mcp._norm(cand)
        try:
            item = drive_mcp._stat(full)
        except drive_mcp.LoginNeeded as e:
            raise InstallError(f"Нужен вход в Magnit Drive. {e}") from e
        if item:
            if item["dir"]:
                raise InstallError(f"{full} — это папка. Укажите архив .zip с навыком.")
            return drive_mcp._download(full, str(tmp / Path(full).name))
        last = full
    raise InstallError(f"Не нашёл «{source}» ни на компьютере, ни в Magnit Drive ({last}).")


def _unpack(path: Path, tmp: Path) -> Path:
    if path.is_dir():
        return path
    if path.suffix.lower() != ".zip" or not zipfile.is_zipfile(path):
        raise InstallError(f"{path.name}: нужен архив .zip с навыком или папка с SKILL.md.")
    out = tmp / "unpacked"
    out.mkdir()
    with zipfile.ZipFile(path) as z:
        infos = [i for i in z.infolist() if not i.filename.startswith("__MACOSX/") and not i.filename.endswith(".DS_Store")]
        if len(infos) > MAX_FILES:
            raise InstallError(f"В архиве {len(infos)} файлов — слишком много для навыка.")
        if sum(i.file_size for i in infos) > MAX_UNPACKED:
            raise InstallError("Навык в распакованном виде больше 300 МБ.")
        for i in infos:
            name = i.filename
            if not (i.flag_bits & 0x800):  # имя без пометки UTF-8: архив с macOS/Windows
                try:
                    name = name.encode("cp437").decode("utf-8")
                except (UnicodeEncodeError, UnicodeDecodeError):
                    pass
            name = unicodedata.normalize("NFC", name)
            target = (out / name).resolve()
            if not str(target).startswith(str(out.resolve()) + os.sep) and target != out.resolve():
                raise InstallError(f"Опасный путь в архиве: {i.filename}")
            if (i.external_attr >> 16) & 0o170000 == 0o120000:
                raise InstallError(f"Символическая ссылка в архиве: {i.filename}")
            if i.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(i) as src, target.open("wb") as dst:
                    shutil.copyfileobj(src, dst)
    return out


def _skill_dir(base: Path) -> Path:
    found = sorted({p.parent for p in base.rglob("SKILL.md") if len(p.relative_to(base).parts) <= 3},
                   key=lambda p: len(p.parts))
    if not found:
        raise InstallError("В архиве нет файла SKILL.md — это не навык.")
    top = [p for p in found if len(p.parts) == len(found[0].parts)]
    if len(top) > 1:
        raise InstallError(f"В архиве несколько навыков ({', '.join(p.name for p in top)}) — устанавливайте по одному.")
    return top[0]


def _header(skill: Path) -> tuple[dict, list]:
    """Шапка SKILL.md. Частую ошибку — «: » в описании без кавычек — исправляет: иначе Goose навык не видит."""
    import yaml
    md = skill / "SKILL.md"
    text = md.read_text(encoding="utf-8")
    notes = []
    m = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    if not m:
        raise InstallError("SKILL.md должен начинаться с шапки между строками «---» (name и description).")
    try:
        head = yaml.safe_load(m.group(1))
    except yaml.YAMLError:
        lines = m.group(1).splitlines()
        fixed = []
        for ln in lines:
            k = re.match(r"^(name|description):\s*(.+)$", ln)
            if k and not k.group(2).startswith(('"', "'")):
                ln = f'{k.group(1)}: "{k.group(2).replace(chr(34), chr(39))}"'
            fixed.append(ln)
        head = yaml.safe_load("\n".join(fixed))
        text = text.replace(m.group(1), "\n".join(fixed), 1)
        md.write_text(text, encoding="utf-8")
        notes.append("в шапке SKILL.md было двоеточие без кавычек — описание взято в кавычки (иначе Goose не видит навык)")
    if not isinstance(head, dict) or not head.get("name") or not head.get("description"):
        raise InstallError("В шапке SKILL.md нужны name и description.")
    if not NAME_RE.match(str(head["name"])):
        raise InstallError(f"Имя навыка «{head['name']}»: только строчные буквы (русские или латинские), цифры и дефис, "
                           "без дефиса в начале.")
    return head, notes


def install(source: str, apply: bool = True) -> str:
    with tempfile.TemporaryDirectory(prefix="skill-") as t:
        tmp = Path(t)
        fetched = _fetch(source, tmp)
        skill = _skill_dir(_unpack(fetched, tmp))
        head, notes = _header(skill)
        name = str(head["name"])
        files = [p for p in skill.rglob("*") if p.is_file() and p.name != ".DS_Store" and "__pycache__" not in p.parts]
        scripts = sorted(str(p.relative_to(skill)) for p in files if p.suffix in (".py", ".sh", ".js", ".command"))
        size = sum(p.stat().st_size for p in files)
        dest = SKILLS / name
        replaced = dest.exists()
        if replaced:
            BACKUP.mkdir(parents=True, exist_ok=True)
            shutil.move(str(dest), str(BACKUP / f"{name}-{time.strftime('%Y%m%d-%H%M%S')}"))
        SKILLS.mkdir(parents=True, exist_ok=True)
        shutil.copytree(skill, dest, ignore=shutil.ignore_patterns(".DS_Store", "__pycache__", "__MACOSX"))
    applied = ""
    if apply:
        from mcp_registry import venv_python
        py = venv_python(ROOT / "shared" / ".venv")
        r = subprocess.run([str(py), str(ROOT / "agent-b-goose" / "configure.py")], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", env={**os.environ, "PYTHONUTF8": "1"}, timeout=300)
        warn = [ln.strip() for ln in r.stdout.splitlines() if "⚠" in ln and name in ln]
        applied = "подключён к Goose" if r.returncode == 0 and not warn else f"подключение: {'; '.join(warn) or r.stderr[-200:]}"
    lines = [
        f"Навык «{name}» {'обновлён' if replaced else 'установлен'}: {dest}",
        f"Описание: {str(head['description'])[:200]}",
        f"Файлов: {len(files)}, {size / 1024 / 1024:.1f} МБ" + (f"; скрипты: {', '.join(scripts[:8])}" if scripts else ""),
        f"Подключение: {applied}" if applied else "",
        "Доступен в новом чате (в Goose Desktop — после перезапуска окна чата)." if apply else "",
        *[f"Замечание: {n}" for n in notes],
        "При установке скрипты навыка не запускались; они выполняются только по вашей задаче." if scripts else "",
        f"Прежняя версия сохранена в {BACKUP}." if replaced else "",
    ]
    return "\n".join(ln for ln in lines if ln)


if __name__ == "__main__":
    try:
        print(install(" ".join(sys.argv[1:])))
    except InstallError as e:
        print(f"Не установлен: {e}")
        sys.exit(2)
