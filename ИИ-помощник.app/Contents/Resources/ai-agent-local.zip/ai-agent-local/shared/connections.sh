# Общие параметры дополнительных интеграций для macOS. ROOT — папка помощника.
CONNECTIONS_TSV="$ROOT/app/extended-systems.tsv"
CONNECTIONS_DIR="$HOME/.magnit-agent/connections"

connection_key() {
  [[ -f "$CONNECTIONS_TSV" ]] && awk -F '|' -v key="$1" '$1==key {found=1} END {exit !found}' "$CONNECTIONS_TSV"
}

save_connection() (
  umask 077
  [[ -n "$2" && "$2" != *$'\n'* && "$2" != *$'\r'* ]] || return 2
  connection_key "$1" || return 2
  mkdir -p "$CONNECTIONS_DIR" || return 1
  local tmp
  tmp="$(mktemp "$CONNECTIONS_DIR/.setting.XXXXXX")" || return 1
  trap 'rm -f "${tmp:?}"' EXIT
  printf '%s\n' "$2" > "$tmp" && mv -f "$tmp" "$CONNECTIONS_DIR/$1"
)

connection_address() {
  local key="$1" service default py
  case "$key" in AIRFLOW|TRINO) ;; *) return 2 ;; esac
  service="$(printf '%s' "$key" | tr '[:upper:]' '[:lower:]')"
  default="$(awk -F '|' -v key="${key}_TOKEN" '$1==key {print $5; exit}' "$CONNECTIONS_TSV")"
  py="$ROOT/shared/.venv/bin/python"
  if [[ -x "$py" ]] && "$py" "$ROOT/shared/connection_login.py" address "$service" 2>/dev/null; then
    return
  fi
  if [[ -s "$CONNECTIONS_DIR/${key}_URL" ]]; then
    head -1 "$CONNECTIONS_DIR/${key}_URL"
  else
    printf '%s\n' "$default"
  fi
}

ask_connections() {
  local key title hint desc link kind answer value address default login password selection=" "
  echo "Дополнительные подключения (можно пропустить)."
  while IFS='|' read -r key title hint desc link kind <&3; do
    [[ "$kind" == secret ]] || continue
    read -r -p "  Настроить $title? [y/N]: " answer || return 0
    if [[ "$answer" =~ ^[yYдД] ]]; then
      case "$key" in
        AIRFLOW_TOKEN|TRINO_TOKEN)
          key="${key%_TOKEN}"
          default="$(connection_address "$key")"
          read -r -p "  Адрес [$default]: " address || return 0
          read -r -p '  Логин (Enter — пропустить): ' login || return 0
          [[ -n "$login" ]] || continue
          read -r -s -p '  Пароль: ' password || return 0
          echo
          if [[ -n "$password" ]]; then
            save_connection "${key}_LOGIN_REQUEST" "${address:-$default}"$'\t'"$login:$password"
          fi ;;
        *) selection="$selection${key%_TOKEN} " ;;
      esac
    fi
  done 3< "$CONNECTIONS_TSV"
  while IFS='|' read -r key title hint desc link kind <&3; do
    [[ "$key" == \#* || "$kind" == internal ]] && continue
    [[ "$selection" == *" ${key%%_*} "* ]] || continue
    printf '  %s. %s\n' "$title" "$hint"
    [[ -z "$link" ]] || printf '  %s\n' "$link"
    if [[ "$kind" == secret ]]; then
      read -r -s -p '  Значение (Enter — оставить): ' value || return 0
      echo
    else
      read -r -p '  Значение (Enter — оставить): ' value || return 0
    fi
    if [[ -n "$value" ]] && ! save_connection "$key" "$value"; then
      echo "  Не удалось сохранить $title." >&2
    fi
  done 3< "$CONNECTIONS_TSV"
}
