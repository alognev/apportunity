# Общие параметры дополнительных интеграций для macOS. ROOT — папка помощника.
CONNECTIONS_TSV="$ROOT/app/extended-systems.tsv"
CONNECTIONS_DIR="$HOME/.magnit-agent/connections"

connection_key() {
  [[ -f "$CONNECTIONS_TSV" ]] && awk -F '|' -v key="$1" '$1==key {found=1} END {exit !found}' "$CONNECTIONS_TSV"
}

save_connection() (
  umask 077
  [[ -n "$2" && "$2" != *$'\n'* && "$2" != *$'\r'* ]] || return 2
  connection_key "$1" || return 2
  mkdir -p "$CONNECTIONS_DIR" || return 1
  local tmp
  tmp="$(mktemp "$CONNECTIONS_DIR/.setting.XXXXXX")" || return 1
  trap 'rm -f "${tmp:?}"' EXIT
  printf '%s\n' "$2" > "$tmp" && mv -f "$tmp" "$CONNECTIONS_DIR/$1"
)

ask_connections() {
  local key title hint desc link kind answer value selection=" "
  echo "Дополнительные подключения (можно пропустить)."
  while IFS='|' read -r key title hint desc link kind <&3; do
    [[ "$kind" == secret ]] || continue
    read -r -p "  Настроить $title? [y/N]: " answer || return 0
    if [[ "$answer" =~ ^[yYдД] ]]; then
      selection="$selection${key%_TOKEN} "
    fi
  done 3< "$CONNECTIONS_TSV"
  while IFS='|' read -r key title hint desc link kind <&3; do
    [[ "$key" == \#* ]] && continue
    [[ "$selection" == *" ${key%%_*} "* ]] || continue
    printf '  %s. %s\n' "$title" "$hint"
    [[ -z "$link" ]] || printf '  %s\n' "$link"
    if [[ "$kind" == secret ]]; then
      read -r -s -p '  Значение (Enter — оставить): ' value || return 0
      echo
    else
      read -r -p '  Значение (Enter — оставить): ' value || return 0
    fi
    if [[ -n "$value" ]] && ! save_connection "$key" "$value"; then
      echo "  Не удалось сохранить $title." >&2
    fi
  done 3< "$CONNECTIONS_TSV"
}
