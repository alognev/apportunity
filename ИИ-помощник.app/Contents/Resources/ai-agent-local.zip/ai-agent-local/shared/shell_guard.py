"""PreToolUse-хук (агенты A и C): не дать обойти защиту корпоративных систем через терминал и файлы.

Блокирует:
  • команды, обращающиеся к корпоративным системам напрямую (curl к Jira, Confluence, Tag,
    Exchange, MagnitGPT) — для них есть инструменты с проверками guard.py;
  • чтение секретов: .env, связка ключей macOS;
  • изменение настроек и кода защиты: .env, shared/*.py, счётчики и журнал аудита.
"""

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STATE = Path.home() / ".magnit-agent"

CORP_HOSTS = re.compile(r"(track\.magnit\.ru|jira\.corp\.tander\.ru|it-portal\.corp\.tander\.ru|eportal\.magnit\.ru|"
                        r"tag\.magnit\.ru|tag\.corp\.tander\.ru|mail\.magnit\.ru|gpt\.ai\.corp\.tander\.ru|"
                        r"drive\.magnit\.ru|/remote\.php/dav|/rest/api/|/api/v4/|/EWS/)", re.I)
SECRETS = re.compile(r"(\.env\b|find-generic-password|dump-keychain|_TOKEN\b|_API_KEY\b|WEBHOOK_URL|"
                     r"databases\.toml|dbhub\.toml|dist-token|drive-auth)", re.I)
PROTECTED = [ROOT / ".env", ROOT / "databases.toml", STATE / "dbhub.toml", STATE / "dist-token", STATE / "drive-auth.json", ROOT / "app", ROOT / "shared", ROOT / "agent-a-claude-code" / "settings.json",
             ROOT / "agent-c-agent-sdk" / "settings.json", STATE / "guard.db", STATE / "audit.log"]


def deny(reason: str) -> None:
    print(json.dumps({"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny",
                                             "permissionDecisionReason": f"Заблокировано защитой: {reason}"}},
                     ensure_ascii=False))
    sys.exit(0)


def is_protected(path: str) -> bool:
    try:
        p = Path(path).expanduser().resolve()
    except (OSError, RuntimeError):
        return False
    return any(p == t or t in p.parents for t in PROTECTED)


sys.path.insert(0, str(ROOT / "shared"))
from mcp_registry import load_env  # noqa: E402

if (load_env().get("GUARD_ENABLED") or "1").strip().lower() in {"0", "false", "no", "off", "нет", "выкл"}:
    sys.exit(0)  # защита выключена в .env

data = json.load(sys.stdin)
tool, inp = data.get("tool_name", ""), data.get("tool_input", {}) or {}

if tool == "Bash":
    cmd = inp.get("command", "")
    if CORP_HOSTS.search(cmd):
        deny("прямые запросы к корпоративным системам из терминала запрещены. Используйте инструменты "
             "Jira, Confluence, календаря, Tag и Drive — в них есть проверки и журнал.")
    if SECRETS.search(cmd):
        deny("команда обращается к токенам и секретам (.env, связка ключей). Это запрещено.")
    # Запуск shared/.venv/bin/python для скриптов разрешён; нельзя трогать сами файлы защиты
    if re.search(r"guard\.(py|db)|shell_guard|read_guard|audit\.log|mcp_registry|mcp_launch|"
                 r"agent-[ac]-[a-z-]+/settings\.json|\.claude/settings", cmd):
        deny("изменение настроек и файлов защиты помощника запрещено.")

elif tool in ("Read", "Grep", "Glob"):
    target = inp.get("file_path") or inp.get("path") or ""
    if target and Path(target).name in (".env", "databases.toml", "dbhub.toml", "dist-token") or \
            re.search(r"(^|/)(\.env|databases\.toml|dbhub\.toml|dist-token)$", inp.get("pattern", "") or ""):
        deny("чтение файлов с токенами и паролями (.env, databases.toml) запрещено.")

elif tool in ("Write", "Edit", "MultiEdit", "NotebookEdit"):
    if is_protected(inp.get("file_path") or inp.get("notebook_path") or ""):
        deny("изменение настроек и файлов защиты помощника запрещено.")
