"""MCP «tag»: корпоративный мессенджер Magnit Tag (API Mattermost v4).

Адресат: "me" — личный чат, "@login" — сотрудник, "~channel" — канал.

Режимы (по тому, что задано в .env):
  TAG_TOKEN        — личный маркер: всё от вашего имени (чтение, поиск, отправка);
  TAG_BOT_TOKEN    — бот (выпускается по заявке в ШПС): пишет от имени бота вам (TAG_USER),
                     коллегам и в каналы, куда добавлен; читает только свои чаты;
  TAG_WEBHOOK_URL  — входящий вебхук: только отправка текста в канал вебхука.

Из командной строки (для уведомлений планировщика):
  python tag_mcp.py --send me "текст" [путь_к_файлу]
"""

from __future__ import annotations

import getpass
import os
import sys
from datetime import datetime
from functools import lru_cache
from pathlib import Path

import httpx
from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

mcp = MCPServer("tag")
RO = ToolAnnotations(readOnlyHint=True)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False)


UA = "magnit-local-agent/1.0 (AI assistant)"


def _mode() -> str:
    if os.environ.get("TAG_TOKEN"):
        return "user"
    if os.environ.get("TAG_BOT_TOKEN"):
        return "bot"
    if os.environ.get("TAG_WEBHOOK_URL"):
        return "webhook"
    raise RuntimeError("Tag не настроен: задайте TAG_TOKEN, TAG_BOT_TOKEN или TAG_WEBHOOK_URL в .env")


@lru_cache
def _client() -> httpx.Client:
    if _mode() == "webhook":
        raise RuntimeError("В режиме вебхука доступна только отправка сообщений (tag_send_message)")
    base = os.environ["TAG_URL"].rstrip("/")
    token = os.environ.get("TAG_TOKEN") or os.environ["TAG_BOT_TOKEN"]
    return httpx.Client(base_url=f"{base}/api/v4", timeout=60,
                        headers={"Authorization": f"Bearer {token}", "User-Agent": UA})


def _owner_login() -> str:
    """Чей это помощник (для бота «me» = владелец)."""
    return os.environ.get("TAG_USER") or getpass.getuser()


def _api(method: str, path: str, **kw):
    resp = _client().request(method, path, **kw)
    if resp.status_code >= 400:
        try:
            msg = resp.json().get("message", resp.text)
        except ValueError:
            msg = resp.text
        raise RuntimeError(f"Tag API {resp.status_code}: {msg}")
    return resp.json() if resp.content else {}


@lru_cache
def _me() -> dict:
    return _api("GET", "/users/me")


def _user_by_login(login: str) -> dict:
    return _api("GET", f"/users/username/{login.lstrip('@')}")


def _resolve_channel(to: str) -> str:
    """'me' | '@login' | '~channel' | id канала -> id канала."""
    to = to.strip()
    me = _me()
    if to.lower() in ("me", "self", "я", "себе") and _mode() == "bot":
        owner = _user_by_login(_owner_login())
        return _api("POST", "/channels/direct", json=[me["id"], owner["id"]])["id"]
    if to.lower() in ("me", "self", "я", "себе", f"@{me['username']}"):
        return _api("POST", "/channels/direct", json=[me["id"], me["id"]])["id"]
    if to.startswith("@"):
        user = _user_by_login(to)
        return _api("POST", "/channels/direct", json=[me["id"], user["id"]])["id"]
    if to.startswith("~"):
        name = to[1:]
        for team in _api("GET", "/users/me/teams"):
            resp = _client().get(f"/teams/{team['id']}/channels/name/{name}")
            if resp.status_code == 200:
                return resp.json()["id"]
        raise RuntimeError(f"Канал {to} не найден среди ваших команд")
    return to


def _user_names(ids: set[str]) -> dict[str, str]:
    if not ids:
        return {}
    users = _api("POST", "/users/ids", json=list(ids))
    return {u["id"]: u["username"] for u in users}


def _format_posts(posts: list[dict]) -> str:
    names = _user_names({p["user_id"] for p in posts})
    lines = []
    for p in posts:
        ts = datetime.fromtimestamp(p["create_at"] / 1000).strftime("%d.%m %H:%M")
        files = f" [файлов: {len(p.get('file_ids') or [])}]" if p.get("file_ids") else ""
        lines.append(f"[{ts}] @{names.get(p['user_id'], '?')}: {p.get('message', '')}{files}")
    return "\n".join(lines) or "Сообщений нет."


def send(to: str, text: str, file_path: str | None = None) -> str:
    if _mode() == "webhook":
        note = f"\n\n(файл: {file_path})" if file_path else ""
        payload: dict = {"text": text + note}
        # "me" — канал, выбранный при создании вебхука; иначе пробуем переопределить канал
        # (работает, если в настройках вебхука не включена блокировка канала)
        if to.strip().lower() not in ("me", "self", "я", "себе", ""):
            payload["channel"] = to.strip().lstrip("~")
        resp = httpx.post(os.environ["TAG_WEBHOOK_URL"], json=payload, timeout=30, headers={"User-Agent": UA})
        if resp.status_code >= 400:
            raise RuntimeError(f"Вебхук Tag {resp.status_code}: {resp.text[:200]}")
        where = "в канал вебхука" if "channel" not in payload else f"в {to}"
        return f"Отправлено {where}" + (" (файлы через вебхук не передаются — указан путь)" if file_path else "")
    channel_id = _resolve_channel(to)
    body: dict = {"channel_id": channel_id, "message": text}
    if file_path:
        p = Path(os.path.expanduser(file_path)).resolve()
        with p.open("rb") as fh:
            uploaded = _api("POST", "/files", data={"channel_id": channel_id}, files={"files": (p.name, fh)})
        body["file_ids"] = [f["id"] for f in uploaded["file_infos"]]
    post = _api("POST", "/posts", json=body)
    return f"Отправлено в {to} (id сообщения {post['id']})"


@mcp.tool(annotations=RO)
def tag_whoami() -> str:
    """Кто я в Tag: логин, имя, почта (для бота — имя бота и владелец)."""
    if _mode() == "webhook":
        return "Режим вебхука: только отправка сообщений в заранее заданный канал"
    me = _me()
    if _mode() == "bot":
        return f"Бот @{me['username']}; сообщения «себе» получает @{_owner_login()}"
    return f"@{me['username']} · {me.get('first_name', '')} {me.get('last_name', '')} · {me.get('email', '')}"


@mcp.tool(annotations=RO)
def tag_find_users(query: str, limit: int = 10) -> str:
    """Найти сотрудников в Tag по ФИО или логину. Возвращает логины для отправки сообщений."""
    users = _api("POST", "/users/search", json={"term": query, "limit": limit})
    if not users:
        return "Никого не найдено."
    return "\n".join(f"@{u['username']} · {u.get('first_name', '')} {u.get('last_name', '')} · "
                     f"{u.get('position', '')} · {u.get('email', '')}" for u in users)


@mcp.tool(annotations=RO)
def tag_find_channels(query: str) -> str:
    """Найти каналы, в которых вы состоите (по названию)."""
    found = []
    for team in _api("GET", "/users/me/teams"):
        for ch in _api("GET", f"/users/me/teams/{team['id']}/channels"):
            if ch["type"] in ("O", "P") and query.lower() in (ch["display_name"] + ch["name"]).lower():
                found.append(f"~{ch['name']} · {ch['display_name']} · команда {team['display_name']}")
    return "\n".join(found) or "Каналы не найдены."


@mcp.tool(annotations=RO)
def tag_read_messages(to: str, limit: int = 30) -> str:
    """Прочитать последние сообщения: to = "me", "@login" (личный чат) или "~channel"."""
    channel_id = _resolve_channel(to)
    data = _api("GET", f"/channels/{channel_id}/posts", params={"per_page": limit})
    posts = [data["posts"][pid] for pid in reversed(data["order"])]
    return _format_posts(posts)


@mcp.tool(annotations=RO)
def tag_search_messages(terms: str, limit: int = 20) -> str:
    """Поиск по сообщениям во всех ваших командах (синтаксис поиска Mattermost: from:, in:, after:)."""
    posts = []
    for team in _api("GET", "/users/me/teams"):
        data = _api("POST", f"/teams/{team['id']}/posts/search",
                    json={"terms": terms, "is_or_search": False, "per_page": limit})
        posts += [data["posts"][pid] for pid in data.get("order", [])]
    posts.sort(key=lambda p: p["create_at"])
    return _format_posts(posts[-limit:])


@mcp.tool(annotations=WRITE)
def tag_send_message(to: str, text: str) -> str:
    """Отправить сообщение в Tag. to = "me" (себе / канал вебхука), "@login" (сотруднику) или "~channel".

    Поддерживается Markdown. В режиме вебхука чтение сообщений недоступно.

    Отправляйте только по явной просьбе пользователя. Логин сотрудника уточните через tag_find_users.
    """
    return send(to, text)


@mcp.tool(annotations=WRITE)
def tag_send_file(to: str, path: str, text: str = "") -> str:
    """Отправить файл с компьютера в Tag с сопроводительным сообщением. to — как в tag_send_message."""
    return send(to, text, path)


if __name__ == "__main__":
    if len(sys.argv) >= 4 and sys.argv[1] == "--send":
        print(send(sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else None))
    else:
        mcp.run()
