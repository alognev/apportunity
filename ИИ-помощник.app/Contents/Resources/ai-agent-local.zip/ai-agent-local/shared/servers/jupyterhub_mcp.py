"""JupyterHub and the token owner's Jupyter Contents API."""

from __future__ import annotations

import difflib
import json
import re
from urllib.parse import quote

from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

from corp_services import Client, ServiceError, auth_headers, service_url

SERVICE = "jupyterhub"
mcp = MCPServer(SERVICE)
RO = ToolAnnotations(readOnlyHint=True)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=False)
STOP = ToolAnnotations(readOnlyHint=False, destructiveHint=True, idempotentHint=False)
MAX_ENTRIES = 100
MAX_DOCUMENT = 1024 * 1024
USERNAME = re.compile(r"[a-z0-9][a-z0-9._-]{0,127}")
SERVER_NAME = re.compile(r"[a-z0-9][a-z0-9_-]{0,127}")


def _server(name: str) -> str:
    if name and not SERVER_NAME.fullmatch(name):
        raise ServiceError("Имя сервера должно содержать латинские строчные буквы, цифры, дефис или подчёркивание.")
    return name


def _path(value: str, *, notebook: bool = False) -> str:
    if (len(value) > 1024 or any(c in value for c in "\\%:")
            or any(ord(c) < 32 or ord(c) == 127 for c in value)
            or (value and any(part in {"", ".", ".."} for part in value.split("/")))
            or (notebook and not value.endswith(".ipynb"))):
        raise ServiceError("Укажите путь внутри своей JupyterLab без начального слеша и '..'; для ноутбука нужен .ipynb.")
    return value


def _escape_path(path: str) -> str:
    return "/".join(quote(part, safe="") for part in path.split("/"))


def _lab(user: str, name: str) -> str:
    return "/user/" + user + ("/" + name if name else "")


def _contents(user: str, name: str, path: str) -> str:
    return _lab(user, name) + "/api/contents" + ("/" + _escape_path(path) if path else "")


def _lab_url(user: str, name: str, path: str = "") -> str:
    return service_url(SERVICE) + _lab(user, name) + "/lab" + ("/tree/" + _escape_path(path) if path else "")


def _own_name(client: Client) -> str:
    result = client.request("GET", "/hub/api/user")
    name = result.get("name") if isinstance(result, dict) else None
    if not isinstance(name, str) or not USERNAME.fullmatch(name):
        raise ServiceError("JupyterHub не подтвердил имя владельца API-токена.")
    return name


def _server_map(client: Client, user: str) -> dict:
    result = client.request("GET", "/hub/api/users/" + user, params={"include_stopped_servers": "true"})
    servers = result.get("servers") if isinstance(result, dict) else None
    if not isinstance(servers, dict):
        raise ServiceError("JupyterHub не вернул список серверов для текущей учётной записи.")
    return servers


def _state(user: str, name: str, raw: object) -> dict:
    state = raw if isinstance(raw, dict) else {}
    return {"server": name, "ready": state.get("ready") is True,
            "pending": state.get("pending"), "stopped": state.get("stopped", not state),
            "url": _lab_url(user, name)}


def _get_notebook(client: Client, user: str, name: str, path: str) -> dict:
    model = client.request("GET", _contents(user, name, path),
                           params={"type": "notebook", "format": "json", "content": 1})
    content = model.get("content") if isinstance(model, dict) else None
    if not isinstance(content, dict) or not isinstance(content.get("cells"), list):
        raise ServiceError("Сервер не вернул документ ноутбука. Проверьте путь и состояние JupyterLab.")
    return content


def _doc_payload(document: dict) -> dict:
    if (document.get("nbformat") != 4 or type(document.get("nbformat_minor")) is not int
            or not isinstance(document.get("metadata"), dict) or not isinstance(document.get("cells"), list)):
        raise ServiceError("Ожидается JSON документа .ipynb формата nbformat 4 с полями metadata и cells.")
    for cell in document["cells"]:
        source = cell.get("source") if isinstance(cell, dict) else None
        if (source is None or not isinstance(source, (str, list))
                or (isinstance(source, list) and not all(isinstance(line, str) for line in source))
                or cell.get("cell_type") not in ("code", "markdown", "raw")):
            raise ServiceError("У каждой ячейки нужны тип и текст (строка или список строк).")
    payload = {"type": "notebook", "format": "json", "content": document}
    if len(json.dumps(payload, ensure_ascii=False).encode("utf-8")) > MAX_DOCUMENT:
        raise ServiceError("Документ больше 1 МиБ. Сохраните его через JupyterLab или уберите объёмные результаты ячеек.")
    return payload


def _notebook_diff(previous: dict, new: dict) -> str:
    def source_lines(notebook: dict) -> list[str]:
        lines = []
        for cell in notebook["cells"]:
            if not isinstance(cell, dict):
                continue
            source = cell.get("source", "")
            if isinstance(source, list):
                source = "".join(part for part in source if isinstance(part, str))
            lines.extend([f"[{cell.get('cell_type')}]", *str(source).splitlines()])
        return lines

    lines = []
    size = 0
    for line in difflib.unified_diff(source_lines(previous), source_lines(new),
                                    fromfile="исходные ячейки", tofile="новые ячейки", lineterm=""):
        fragment = line[:1000]
        size += len(fragment)
        if len(lines) >= 160 or size > 12_000:
            lines.append("… остальная часть изменений скрыта")
            break
        lines.append(fragment)
    return "\n".join(lines)


@mcp.tool(annotations=RO)
def jupyterhub_status() -> dict:
    """Проверить подключение JupyterHub под владельцем токена, показать его серверы и ссылки на JupyterLab."""
    with Client(SERVICE, headers=auth_headers(SERVICE)) as client:
        user = _own_name(client)
        servers = _server_map(client, user)
    entries = [_state(user, name, state) for name, state in list(servers.items())[:MAX_ENTRIES]
               if isinstance(name, str) and (not name or SERVER_NAME.fullmatch(name))]
    return {"user": user, "servers": entries, "truncated": len(servers) > MAX_ENTRIES}


@mcp.tool(annotations=RO)
def jupyterhub_server_status(server: str = "") -> dict:
    """Узнать, готов ли собственный сервер JupyterHub. Пустое имя означает сервер по умолчанию."""
    name = _server(server)
    with Client(SERVICE, headers=auth_headers(SERVICE)) as client:
        user = _own_name(client)
        return _state(user, name, _server_map(client, user).get(name))


@mcp.tool(annotations=RO)
def jupyterhub_list_notebooks(directory: str = "", server: str = "") -> dict:
    """Показать ноутбуки и папки в выбранном каталоге своей JupyterLab. Пустой путь означает корень."""
    name, directory = _server(server), _path(directory)
    with Client(SERVICE, headers=auth_headers(SERVICE)) as client:
        user = _own_name(client)
        result = client.request("GET", _contents(user, name, directory), params={"type": "directory", "content": 1})
    items = result.get("content") if isinstance(result, dict) else None
    if not isinstance(items, list):
        raise ServiceError("JupyterLab не вернула содержимое папки. Проверьте состояние сервера и путь.")
    entries = []
    for item in items:
        if not isinstance(item, dict) or item.get("type") not in ("directory", "notebook"):
            continue
        path = item.get("path")
        if not isinstance(path, str):
            continue
        try:
            _path(path, notebook=item["type"] == "notebook")
        except ServiceError:
            continue
        if len(entries) == MAX_ENTRIES:
            return {"directory": directory, "entries": entries, "truncated": True}
        entries.append({"path": path, "type": item["type"], "modified": item.get("last_modified"),
                        "url": _lab_url(user, name, path)})
    return {"directory": directory, "entries": entries, "truncated": False}


@mcp.tool(annotations=RO)
def jupyterhub_get_notebook(path: str, server: str = "", include_outputs: bool = False) -> dict:
    """Прочитать документ .ipynb из своей JupyterLab. Исторические результаты ячеек включаются по запросу."""
    name, path = _server(server), _path(path, notebook=True)
    with Client(SERVICE, headers=auth_headers(SERVICE)) as client:
        user = _own_name(client)
        notebook = _get_notebook(client, user, name, path)
    if not include_outputs:
        for cell in notebook["cells"]:
            if isinstance(cell, dict) and cell.get("cell_type") == "code":
                cell["outputs"] = []
                cell["execution_count"] = None
                if isinstance(cell.get("metadata"), dict):
                    cell["metadata"].pop("execution", None)
    return {"path": path, "url": _lab_url(user, name, path), "notebook": notebook,
            "includes_historical_outputs": include_outputs}


def _change_server(action: str, server: str, confirm: bool) -> dict:
    name = _server(server)
    with Client(SERVICE, headers=auth_headers(SERVICE)) as client:
        user = _own_name(client)
        state = _state(user, name, _server_map(client, user).get(name))
        detail = ("Запуск занимает несколько минут и использует ресурсы хаба." if action == "start"
                  else "Остановка завершит ядра и прервёт выполняемые расчёты. Сначала сохраните работу.")
        result = {"executed": False, "operation": action, **state, "note": detail}
        if not confirm or state["pending"] or (action == "start") == state["ready"]:
            return result
        route = "/hub/api/users/" + user + ("/servers/" + name if name else "/server")
        if action == "start":
            client.request("POST", route)
        else:
            client.request("DELETE", route)
    return {"executed": True, "operation": action, "server": name, "url": _lab_url(user, name),
            "note": "Запрос принят. Проверяйте готовность через jupyterhub_server_status."}


@mcp.tool(annotations=WRITE)
def jupyterhub_start(server: str = "", confirm: bool = False) -> dict:
    """Запросить запуск своего сервера с настройками хаба по умолчанию. Без confirm только показать текущее состояние."""
    return _change_server("start", server, confirm)


@mcp.tool(annotations=STOP)
def jupyterhub_stop(server: str = "", confirm: bool = False) -> dict:
    """Остановить свой сервер, завершив ядра. Без confirm только показать состояние и последствия."""
    return _change_server("stop", server, confirm)


@mcp.tool(annotations=WRITE)
def jupyterhub_save_notebook(notebook: dict, source_path: str = "", directory: str = "",
                            server: str = "", confirm: bool = False) -> dict:
    """Показать изменения и сохранить новый .ipynb. Имя свободного файла выделяет JupyterLab. Вычисления не запускаются."""
    name, directory = _server(server), _path(directory)
    source = _path(source_path, notebook=True) if source_path else ""
    if source and not directory:
        directory = source.rpartition("/")[0]
    payload = _doc_payload(notebook)
    with Client(SERVICE, headers=auth_headers(SERVICE)) as client:
        user = _own_name(client)
        preview = {"executed": False, "server": name, "directory": directory, "source": source,
                   "cells": len(notebook["cells"]), "note": "Будет создан новый файл с именем, выбранным JupyterLab."}
        if source:
            previous = _get_notebook(client, user, name, source)
            preview["cell_source_diff"] = _notebook_diff(previous, notebook)
        if not confirm:
            return preview
        created = client.request("POST", _contents(user, name, directory), json={"type": "notebook"})
        path = created.get("path") if isinstance(created, dict) else None
        if not isinstance(path, str):
            raise ServiceError("JupyterLab могла создать пустой ноутбук, но не сообщила его путь. Проверьте папку.")
        _path(path, notebook=True)
        if path.rpartition("/")[0] != directory or path == source:
            raise ServiceError("JupyterLab вернула неожиданный путь нового ноутбука. Проверьте папку перед повтором.")
        try:
            client.request("PUT", _contents(user, name, path), json=payload)
        except ServiceError:
            raise ServiceError(f"Новый файл {path} выделен, но сохранение не подтверждено. "
                               "Проверьте его в JupyterLab перед повтором.") from None
    return {"executed": True, "path": path, "url": _lab_url(user, name, path), "cells": len(notebook["cells"])}


if __name__ == "__main__":
    mcp.run()
