"""MCP «scheduler»: задания агенту по расписанию (аналог «Автоматизаций» MagnitGPT)."""

from __future__ import annotations

import sys
from pathlib import Path

from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import scheduler  # noqa: E402

mcp = MCPServer("scheduler")
RO = ToolAnnotations(readOnlyHint=True)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False)


@mcp.tool(annotations=RO)
def automation_list() -> str:
    """Список автоматизаций: расписание, статус, последний запуск."""
    return "\n".join(scheduler.describe(t) for t in scheduler.all_tasks()) or "Автоматизаций нет."


@mcp.tool(annotations=RO)
def automation_history(automation_id: str) -> str:
    """История запусков автоматизации с путями к файлам-отчётам."""
    task = scheduler._load(automation_id)
    rows = [f"{h['at']} · {'✅' if h['ok'] else '❌'} · {h['seconds']} с · {h['file']}" for h in task.get("history", [])]
    return "\n".join(rows) or "Запусков ещё не было."


@mcp.tool(annotations=WRITE)
def automation_create(name: str, schedule: str, prompt: str, notify_tag: bool = False, workdir: str = "") -> str:
    """Создать автоматизацию: агент сам выполнит задание по расписанию, результат сохранится в файл.

    schedule: "hourly", "daily 09:00", "weekdays 09:00", "weekly пн 09:00", "monthly 1 09:00",
              "once 2026-10-01 10:00".
    prompt: полное самодостаточное задание (агент не видит текущий диалог).
    notify_tag: дополнительно прислать результат себе в Tag.
    workdir: рабочая папка (по умолчанию AGENT_WORKSPACE).
    Задания выполняются без подтверждения действий — формулируйте их аккуратно.
    """
    return "Создано:\n" + scheduler.describe(scheduler.create(name, schedule, prompt, notify_tag, workdir))


@mcp.tool(annotations=WRITE)
def automation_run_now(automation_id: str) -> str:
    """Выполнить автоматизацию прямо сейчас (для проверки). Возвращает путь к отчёту."""
    report = scheduler.run(automation_id)
    return f"Готово: {report}\n\n{report.read_text()[:6000]}"


@mcp.tool(annotations=WRITE)
def automation_pause(automation_id: str, paused: bool = True) -> str:
    """Поставить автоматизацию на паузу (paused=true) или возобновить (paused=false)."""
    return scheduler.describe(scheduler.set_enabled(automation_id, not paused))


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=True))
def automation_delete(automation_id: str) -> str:
    """Удалить автоматизацию (отчёты остаются в папке)."""
    scheduler.delete(automation_id)
    return "Удалено"


if __name__ == "__main__":
    mcp.run()
