"""MCP «magnitgpt»: данные пользователя в MagnitGPT (gpt.ai.corp.tander.ru) через API.

- Заметки, включая протоколы встреч от бота «Запись Встреч (MagnitGPT)»;
- Knowledge (базы знаний MagnitGPT): список и поиск;
- Распознавание аудио/видео (ASR).

Настройки: MAGNITGPT_URL, MAGNITGPT_API_KEY (Настройки → Аккаунт → API-ключи;
право выдаётся по запросу на gpt_tander@magnit.ru).
"""

from __future__ import annotations

import datetime as dt
import os
from functools import lru_cache
from pathlib import Path

import httpx
from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

mcp = MCPServer("magnitgpt")
RO = ToolAnnotations(readOnlyHint=True)


@lru_cache
def _client() -> httpx.Client:
    base = os.environ["MAGNITGPT_URL"].rstrip("/")
    return httpx.Client(base_url=base, timeout=300,
                        headers={"Authorization": f"Bearer {os.environ['MAGNITGPT_API_KEY']}",
                                 "User-Agent": "magnit-local-agent/1.0 (AI assistant)"})


def _api(method: str, path: str, **kw):
    resp = _client().request(method, path, **kw)
    if resp.status_code in (401, 403):
        raise RuntimeError("MagnitGPT отклонил ключ: проверьте MAGNITGPT_API_KEY и право на API-ключи")
    resp.raise_for_status()
    return resp.json()


def _when(ns: int | float | None) -> str:
    if not ns:
        return "—"
    ts = ns / 1e9 if ns > 1e14 else ns  # MagnitGPT отдаёт наносекунды
    return dt.datetime.fromtimestamp(ts).strftime("%d.%m.%Y %H:%M")


def _notes() -> list[dict]:
    data = _api("GET", "/api/v1/notes/")
    return data.get("items", data) if isinstance(data, dict) else data


@mcp.tool(annotations=RO)
def magnitgpt_list_notes(query: str = "", limit: int = 30) -> str:
    """Список заметок MagnitGPT (в т.ч. протоколы встреч), новые сверху. query — фильтр по названию и тексту."""
    notes = sorted(_notes(), key=lambda n: n.get("updated_at") or 0, reverse=True)
    q = query.lower().strip()
    if q:
        notes = [n for n in notes if q in (n.get("title", "") + (n.get("data") or {}).get("content", {}).get("md", "")).lower()]
    if not notes:
        return "Заметок не найдено."
    return "\n".join(f"{_when(n.get('updated_at'))} · {n.get('title') or '(без названия)'} · id: {n['id']}"
                     for n in notes[:limit])


@mcp.tool(annotations=RO)
def magnitgpt_get_note(note_id: str) -> str:
    """Полный текст заметки / протокола встречи (Markdown)."""
    n = _api("GET", f"/api/v1/notes/{note_id}")
    md = ((n.get("data") or {}).get("content") or {}).get("md", "")
    return f"# {n.get('title', '')}\n_{_when(n.get('updated_at'))}_\n\n{md}"


@mcp.tool(annotations=RO)
def magnitgpt_list_knowledge() -> str:
    """Базы знаний (Knowledge) в MagnitGPT, доступные пользователю."""
    data = _api("GET", "/api/v1/knowledge/")
    items = data.get("items", data) if isinstance(data, dict) else data
    if not items:
        return "Баз знаний нет."
    return "\n".join(f"«{k.get('name')}» · id: {k['id']}" + (f" · {k['description']}" if k.get("description") else "")
                     for k in items)


@mcp.tool(annotations=RO)
def magnitgpt_search_knowledge(query: str, knowledge_ids: list[str], k: int = 8) -> str:
    """Семантический поиск по базам знаний MagnitGPT (id из magnitgpt_list_knowledge)."""
    data = _api("POST", "/api/v1/retrieval/query/collection",
                json={"collection_names": knowledge_ids, "query": query, "k": k})
    docs = (data.get("documents") or [[]])[0]
    metas = (data.get("metadatas") or [[]])[0]
    if not docs:
        return "Ничего не найдено."
    return "\n\n".join(f"{i}. {(m or {}).get('name') or (m or {}).get('source', '')}\n{d[:1500]}"
                       for i, (d, m) in enumerate(zip(docs, metas), 1))


@mcp.tool(annotations=RO)
def magnitgpt_transcribe_audio(path: str) -> str:
    """Распознать речь в аудио/видео-файле (mp3, m4a, wav, mp4, ...) и вернуть текст."""
    p = Path(os.path.expanduser(path)).resolve()
    with p.open("rb") as fh:
        data = _api("POST", "/api/v1/audio/transcriptions", files={"file": (p.name, fh)})
    return data.get("text") or str(data)


if __name__ == "__main__":
    mcp.run()
