"""MCP «web»: поиск в интернете и чтение веб-страниц (в т.ч. внутренних корпоративных)."""

from __future__ import annotations

import io

import httpx
from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

mcp = MCPServer("web")
RO = ToolAnnotations(readOnlyHint=True, openWorldHint=True)
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"


@mcp.tool(annotations=RO)
def web_search(query: str, max_results: int = 8, region: str = "ru-ru") -> str:
    """Поиск в интернете. Возвращает заголовки, ссылки и фрагменты.

    Для подробностей откройте найденную страницу инструментом web_fetch.
    region: ru-ru, us-en, wt-wt (без региона).
    """
    from ddgs import DDGS

    results = DDGS().text(query, region=region, max_results=max_results)
    if not results:
        return "Ничего не найдено."
    return "\n\n".join(f"{i}. {r.get('title')}\n{r.get('href')}\n{r.get('body')}"
                       for i, r in enumerate(results, 1))


@mcp.tool(annotations=RO)
def web_news(query: str, max_results: int = 8, region: str = "ru-ru") -> str:
    """Свежие новости по теме (с датами и источниками)."""
    from ddgs import DDGS

    results = DDGS().news(query, region=region, max_results=max_results)
    if not results:
        return "Новостей не найдено."
    return "\n\n".join(f"{i}. {r.get('date', '')[:10]} · {r.get('source', '')}\n{r.get('title')}\n{r.get('url')}\n{r.get('body')}"
                       for i, r in enumerate(results, 1))


@mcp.tool(annotations=RO)
def web_fetch(url: str, max_chars: int = 40000) -> str:
    """Открыть веб-страницу или файл по ссылке и вернуть содержимое в Markdown.

    Поддерживает HTML, PDF, DOCX, XLSX и другие документы по прямой ссылке.
    """
    from markitdown import MarkItDown, StreamInfo

    with httpx.Client(follow_redirects=True, timeout=30, headers={"User-Agent": UA}) as client:
        resp = client.get(url)
    if resp.status_code >= 400:
        return f"Ошибка {resp.status_code} при загрузке {url}"
    ctype = resp.headers.get("content-type", "").split(";")[0]
    info = StreamInfo(mimetype=ctype or None, url=str(resp.url), charset=resp.encoding)
    text = MarkItDown().convert_stream(io.BytesIO(resp.content), stream_info=info).text_content or ""
    if len(text) > max_chars:
        text = text[:max_chars] + f"\n\n[... обрезано: {max_chars} из {len(text)} символов]"
    return f"Источник: {resp.url}\n\n{text}"


if __name__ == "__main__":
    mcp.run()
