"""Read workbook, dashboard and entry metadata from the DataLens UI gateway."""

from __future__ import annotations

import json
import re
from datetime import datetime
from urllib.parse import unquote, urlsplit
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

from corp_services import Client, ServiceError, credentials, ref_path, service_setting, service_url

SERVICE = "datalens"
mcp = MCPServer(SERVICE)
RO = ToolAnnotations(readOnlyHint=True, destructiveHint=False)
GATEWAY = "/gateway/root/"
OBJECT_ID = re.compile(r"[A-Za-z0-9_-]{13,128}")
SLUG_ID = re.compile(r"([a-z0-9]{13})-[^/]+")
MAX_BOOKS = 5
PAGE_SIZE = 50
MAX_TABS = 25
MAX_WIDGETS = 50
MAX_RESULTS = 30


def _id(value: str) -> str:
    value = value.strip()
    if "://" in value:
        path = ref_path(SERVICE, value).strip("/")
        parts = path.split("/")
        if len(parts) != 1 and not (len(parts) == 2 and parts[0] in {"workbooks", "wizard", "datasets", "editor", "ql"}):
            raise ServiceError("Вставьте прямую ссылку на рабочую книгу, дашборд, график или датасет.")
        value = unquote(parts[-1])
        slug = SLUG_ID.fullmatch(value)
        if slug:
            value = slug[1]
    if not OBJECT_ID.fullmatch(value):
        raise ServiceError("Укажите прямую ссылку DataLens или идентификатор объекта (от 13 символов).")
    return value


def _session_headers() -> dict[str, str]:
    try:
        data = json.loads(credentials(SERVICE))
    except ValueError:
        raise ServiceError("В настройках DataLens сохраните однострочный JSON с полями cookie, csrf_token и tenant_id.") from None
    if not isinstance(data, dict):
        raise ServiceError("В настройках DataLens нужен JSON-объект сессии.")
    values = {}
    for key, limit in (("cookie", 8192), ("csrf_token", 512), ("tenant_id", 128)):
        value = data.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > limit or not all(32 <= ord(c) <= 126 for c in value):
            raise ServiceError(f"В настройках DataLens отсутствует или недопустимо поле {key}.")
        values[key] = value
    tenant = service_setting(SERVICE, "TENANT_ID")
    if tenant and tenant != values["tenant_id"]:
        raise ServiceError("Сохранённая сессия DataLens относится к другой организации.")
    base = urlsplit(service_url(SERVICE))
    origin = f"{base.scheme}://{base.netloc}"
    zone = service_setting(SERVICE, "TIMEZONE", "Europe/Moscow")
    if zone == "Europe/Moscow":
        minutes = 180
    else:
        try:
            offset = datetime.now(ZoneInfo(zone)).utcoffset()
        except (ValueError, ZoneInfoNotFoundError):
            raise ServiceError("Укажите часовой пояс из базы IANA в настройках DataLens.") from None
        minutes = int(offset.total_seconds() // 60) if offset is not None else 0
    return {"Cookie": values["cookie"], "x-csrf-token": values["csrf_token"],
            "x-dl-tenantid": values["tenant_id"], "Origin": origin, "Referer": origin + "/",
            "x-dl-user-timezone": zone, "x-timezone-offset": str(minutes)}


def _action(client: Client, name: str, body: dict) -> dict:
    try:
        result = client.request("POST", GATEWAY + name, json=body, changing=False)
    except ServiceError as exc:
        if exc.status in (401, 419):
            raise ServiceError("Сессия DataLens истекла. Обновите её через настройки помощника.", exc.status) from None
        raise
    if not isinstance(result, dict):
        raise ServiceError("DataLens вернул неожиданный формат ответа.")
    return result


def _title(item: dict) -> str:
    meta = item.get("meta")
    title = item.get("title") or (meta.get("title") if isinstance(meta, dict) else None)
    return str(title or item.get("name") or item.get("key") or "")[:256]


def _entry(item: dict) -> dict:
    output = {key: item[key] for key in ("entryId", "scope", "type", "key") if isinstance(item.get(key), str)}
    output["title"] = _title(item)
    if output.get("scope") == "dash" and OBJECT_ID.fullmatch(output.get("entryId", "")):
        output["url"] = f"{service_url(SERVICE)}/{output['entryId']}"
    return output


def _workbooks(client: Client, query: str, only_my: bool) -> dict:
    if len(query) > 256:
        raise ServiceError("Поисковый запрос должен быть не длиннее 256 символов.")
    body = {"onlyMy": only_my}
    if query:
        body["filterString"] = query
    # The browser gateway returns misleading empty lists if page or pageSize is sent here.
    result = _action(client, "us/getWorkbooksList", body)
    data = result.get("workbooks")
    if not isinstance(data, list):
        raise ServiceError("DataLens не вернул список рабочих книг.")
    books = []
    for item in data[:PAGE_SIZE]:
        if not isinstance(item, dict):
            continue
        identifier = item.get("workbookId") or item.get("id")
        if isinstance(identifier, str) and OBJECT_ID.fullmatch(identifier):
            books.append({"workbookId": identifier, "title": _title(item),
                          "url": f"{service_url(SERVICE)}/workbooks/{identifier}"})
    return {"workbooks": books, "partial": bool(result.get("nextPageToken")) or len(data) > PAGE_SIZE}


def _entries(client: Client, workbook: str, page_size: int) -> dict:
    result = _action(client, "us/getWorkbookEntries", {"workbookId": workbook, "pageSize": page_size})
    data = result.get("entries")
    if not isinstance(data, list):
        raise ServiceError("DataLens не вернул содержимое рабочей книги.")
    entries = [_entry(item) for item in data[:page_size] if isinstance(item, dict)]
    return {"workbookId": workbook, "entries": entries,
            "partial": bool(result.get("nextPageToken")) or len(data) >= page_size}


def _aliases() -> dict[str, str]:
    raw = service_setting(SERVICE, "REPORTS")
    try:
        values = json.loads(raw) if raw else {}
    except ValueError:
        return {}
    return {name: ref for name, ref in values.items() if isinstance(ref, str)} if isinstance(values, dict) else {}


def _bookmarks(query: str) -> list[dict]:
    matches = []
    for name, ref in list(_aliases().items())[:MAX_RESULTS]:
        if query.casefold() not in name.casefold():
            continue
        try:
            identifier = _id(ref)
        except ServiceError:
            continue
        matches.append({"title": name[:256], "entryId": identifier, "scope": "dash",
                        "url": f"{service_url(SERVICE)}/{identifier}", "bookmark": True})
    return matches


def _dashboard_structure(entry: dict) -> tuple[list[dict], bool]:
    version = entry.get("version")
    data = entry.get("data")
    if not isinstance(data, dict) or "tabs" not in data:
        data = version.get("data") if isinstance(version, dict) else None
    tabs = data.get("tabs") if isinstance(data, dict) else None
    if not isinstance(tabs, list):
        raise ServiceError("DataLens не вернул структуру вкладок дашборда.")
    output = []
    partial = len(tabs) > MAX_TABS
    for tab in tabs[:MAX_TABS]:
        if not isinstance(tab, dict):
            continue
        items = tab.get("items")
        items = items if isinstance(items, list) else []
        widgets = []
        for item in items[:MAX_WIDGETS]:
            if not isinstance(item, dict):
                continue
            info = {key: item[key] for key in ("id", "type", "chartId", "datasetId") if isinstance(item.get(key), str)}
            info["title"] = _title(item)
            spec = item.get("data")
            if isinstance(spec, dict):
                info.update({key: spec[key] for key in ("chartId", "datasetId", "fieldId") if isinstance(spec.get(key), str)})
                info["title"] = info["title"] or _title(spec)
                charts = spec.get("tabs")
                if isinstance(charts, list):
                    info["charts"] = [
                        {key: chart[key] for key in ("chartId", "datasetId", "title") if isinstance(chart.get(key), str)}
                        for chart in charts[:MAX_WIDGETS] if isinstance(chart, dict)
                    ]
                    partial |= len(charts) > MAX_WIDGETS
            widgets.append(info)
        output.append({"id": tab.get("id"), "title": _title(tab), "widgets": widgets})
        partial |= len(items) > MAX_WIDGETS
    return output, partial


@mcp.tool(annotations=RO)
def datalens_list_workbooks(query: str = "", only_my: bool = False) -> dict:
    """Первая страница доступных рабочих книг DataLens с поиском по названию. partial означает неполный список."""
    with Client(SERVICE, headers=_session_headers()) as client:
        return _workbooks(client, query, only_my)


@mcp.tool(annotations=RO)
def datalens_list_workbook_entries(workbook: str, page_size: int = PAGE_SIZE) -> dict:
    """Показать дашборды, графики, датасеты и другие объекты рабочей книги DataLens по ссылке или ID."""
    identifier = _id(workbook)
    if not 1 <= page_size <= 100:
        raise ServiceError("Укажите от 1 до 100 объектов.")
    with Client(SERVICE, headers=_session_headers()) as client:
        return _entries(client, identifier, page_size)


@mcp.tool(annotations=RO)
def datalens_get_dashboard(dashboard: str, draft: bool = False) -> dict:
    """Разобрать вкладки, графики и фильтры дашборда по ссылке, ID или имени из личного каталога. Без значений графиков."""
    query = dashboard.strip().casefold()
    ref = next((ref for name, ref in _aliases().items() if name.casefold() == query), dashboard)
    identifier = _id(ref)
    branch = "draft" if draft else "published"
    with Client(SERVICE, headers=_session_headers()) as client:
        result = _action(client, "mix/getDashboardV2", {"dashboardId": identifier, "branch": branch,
                                                       "includeLinks": False, "includePermissions": False})
    entry = result.get("entry")
    if not isinstance(entry, dict):
        raise ServiceError("DataLens не вернул описание дашборда.")
    tabs, partial = _dashboard_structure(entry)
    return {"dashboardId": identifier, "title": _title(entry), "url": f"{service_url(SERVICE)}/{identifier}",
            "branch": branch, "tabs": tabs, "partial": partial}


@mcp.tool(annotations=RO)
def datalens_get_entry(entry: str) -> dict:
    """Показать тип и название графика, дашборда или датасета по ссылке или ID DataLens."""
    identifier = _id(entry)
    with Client(SERVICE, headers=_session_headers()) as client:
        result = _action(client, "us/getEntry", {"entryId": identifier})
    item = result.get("entry")
    if not isinstance(item, dict):
        raise ServiceError("DataLens не вернул метаданные объекта.")
    return _entry(item)


@mcp.tool(annotations=RO)
def datalens_search_reports(query: str, workbook: str = "") -> dict:
    """Найти отчёты по имени среди личных ярлыков и первых доступных книг либо внутри указанной книги."""
    query = query.strip()
    if not query or len(query) > 256:
        raise ServiceError("Укажите название или его часть, от 1 до 256 символов.")
    matches = _bookmarks(query) if not workbook else []
    scanned = []
    partial = False
    inaccessible = 0
    with Client(SERVICE, headers=_session_headers()) as client:
        if workbook:
            books = [{"workbookId": _id(workbook), "title": ""}]
        else:
            catalog = _workbooks(client, "", False)
            books = sorted(catalog["workbooks"], key=lambda book: query.casefold() not in book["title"].casefold())
            partial = catalog["partial"] or len(books) > MAX_BOOKS
        for book in books[:MAX_BOOKS]:
            try:
                entries = _entries(client, book["workbookId"], PAGE_SIZE)
            except ServiceError as exc:
                if workbook or exc.status != 403:
                    raise
                inaccessible += 1
                partial = True
                continue
            scanned.append(book)
            partial |= entries["partial"]
            matches.extend({**item, "workbookId": book["workbookId"]} for item in entries["entries"]
                           if item.get("scope") == "dash" and query.casefold() in item["title"].casefold())

    unique = {}
    for item in matches:
        if item.get("entryId"):
            unique.setdefault(item["entryId"], item)
    return {"reports": list(unique.values())[:MAX_RESULTS], "checked_workbooks": scanned,
            "inaccessible_workbooks": inaccessible, "partial": partial or len(unique) > MAX_RESULTS}


if __name__ == "__main__":
    mcp.run()
