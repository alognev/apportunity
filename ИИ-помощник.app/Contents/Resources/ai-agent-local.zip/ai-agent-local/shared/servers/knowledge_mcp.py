"""MCP «knowledge»: локальные базы знаний по папкам на компьютере (гибридный RAG).

База = папка с документами (PDF, Word, Excel, PowerPoint, текст...). Документы извлекаются
в текст и режутся на фрагменты. Поиск гибридный:
  - полнотекстовый: SQLite FTS5 + BM25 по леммам (pymorphy3: «поставок» → «поставка»);
  - семантический: эмбеддинги фрагментов (shared/embeddings.py), косинусная близость;
  - результаты объединяются методом Reciprocal Rank Fusion.
Если модели эмбеддингов нет — работает только полнотекстовый поиск.
Повторная синхронизация обрабатывает только новые и изменённые файлы.

Хранилище: ~/.magnit-agent/knowledge.db
"""

from __future__ import annotations

import hashlib
import os
import re
import sqlite3
import sys
import time
from functools import lru_cache
from pathlib import Path

import numpy as np
from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import embeddings  # noqa: E402

mcp = MCPServer("knowledge")
RO = ToolAnnotations(readOnlyHint=True)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False)

DB = Path.home() / ".magnit-agent" / "knowledge.db"
SCHEMA_VERSION = 2
EXTS = {".pdf", ".docx", ".doc", ".pptx", ".xlsx", ".xls", ".csv", ".txt", ".md", ".html", ".htm",
        ".json", ".xml", ".rtf", ".odt"}
CHUNK, OVERLAP = 1500, 200
MAX_FILE_MB = 50
CANDIDATES, RRF_K = 40, 60
WORD = re.compile(r"[\w-]+", re.U)
STOP = set("и в во на с со по к ко о об от до из за для не ни но а же ли бы что как это то так или "
           "у при над под про без через его ее её их они он она оно мы вы я ты все всё быть есть был".split())
_md = None
_vec_cache: dict[str, tuple[float, np.ndarray, np.ndarray]] = {}


# ---------- текст и морфология ----------

@lru_cache(maxsize=1)
def _morph():
    import pymorphy3
    return pymorphy3.MorphAnalyzer()


@lru_cache(maxsize=200_000)
def _lemma(word: str) -> str:
    w = word.lower()
    if re.search(r"[а-яё]", w):
        return _morph().parse(w)[0].normal_form
    return w


def _lemmas(text: str) -> list[str]:
    return [_lemma(w) for w in WORD.findall(text)]


def _extract(path: Path) -> str:
    global _md
    if path.suffix.lower() in {".txt", ".md", ".csv", ".json", ".xml"}:
        return path.read_text(errors="ignore")
    if _md is None:
        from markitdown import MarkItDown
        _md = MarkItDown()
    return _md.convert(str(path)).text_content or ""


def _chunks(text: str):
    text = re.sub(r"\n{3,}", "\n\n", text)
    pos = 0
    while pos < len(text):
        yield pos, text[pos:pos + CHUNK]
        pos += CHUNK - OVERLAP


def _snippet(text: str, terms: set[str], width: int = 45) -> str:
    """Окно исходного текста с наибольшим числом совпавших лемм; совпадения в «»."""
    words = list(WORD.finditer(text))
    if not words:
        return text[:300]
    hits = [i for i, m in enumerate(words) if _lemma(m.group()) in terms]
    if not hits:
        return re.sub(r"\s+", " ", text[:350]).strip() + " …"
    best = max(hits, key=lambda i: sum(1 for h in hits if i <= h < i + width))
    start, end = max(0, best - 8), min(len(words), best + width)
    out, cursor = [], words[start].start()
    for m in words[start:end]:
        out.append(text[cursor:m.start()])
        out.append(f"«{m.group()}»" if _lemma(m.group()) in terms else m.group())
        cursor = m.end()
    return ("… " if start else "") + re.sub(r"\s+", " ", "".join(out)).strip() + (" …" if end < len(words) else "")


# ---------- хранилище ----------

def _db() -> sqlite3.Connection:
    DB.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB)
    if con.execute("PRAGMA user_version").fetchone()[0] < SCHEMA_VERSION:
        # Старая схема (только FTS по тексту): переносим список баз, содержимое переиндексируется
        con.executescript("DROP TABLE IF EXISTS chunks; DROP TABLE IF EXISTS docs; DROP TABLE IF EXISTS chunks_fts;")
        cols = [r[1] for r in con.execute("PRAGMA table_info(kb)")]
        if cols and "emb_model" not in cols:
            con.execute("ALTER TABLE kb ADD COLUMN emb_model TEXT")
    con.executescript(f"""
        CREATE TABLE IF NOT EXISTS kb (name TEXT PRIMARY KEY, path TEXT, description TEXT, synced REAL,
                                       emb_model TEXT);
        CREATE TABLE IF NOT EXISTS docs (kb TEXT, path TEXT, sha TEXT, mtime REAL, chars INTEGER,
                                         PRIMARY KEY (kb, path));
        CREATE TABLE IF NOT EXISTS chunks (id INTEGER PRIMARY KEY, kb TEXT, path TEXT, pos INTEGER,
                                           text TEXT, vec BLOB);
        CREATE INDEX IF NOT EXISTS chunks_kb ON chunks (kb, path);
        CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(lemmas, tokenize = 'unicode61 remove_diacritics 2');
        PRAGMA user_version = {SCHEMA_VERSION};
    """)
    return con


def _delete_doc(con: sqlite3.Connection, kb: str, path: str) -> None:
    ids = [r[0] for r in con.execute("SELECT id FROM chunks WHERE kb=? AND path=?", (kb, path))]
    con.executemany("DELETE FROM chunks_fts WHERE rowid=?", [(i,) for i in ids])
    con.execute("DELETE FROM chunks WHERE kb=? AND path=?", (kb, path))


def _embed_missing(con: sqlite3.Connection, name: str) -> int:
    model = embeddings.model_name()
    if not model:
        return 0
    old = con.execute("SELECT emb_model FROM kb WHERE name=?", (name,)).fetchone()[0]
    if old and old != model:
        con.execute("UPDATE chunks SET vec=NULL WHERE kb=?", (name,))
    rows = con.execute("SELECT id, text FROM chunks WHERE kb=? AND vec IS NULL", (name,)).fetchall()
    for i in range(0, len(rows), 256):
        part = rows[i:i + 256]
        vecs = embeddings.embed_passages([t for _, t in part])
        con.executemany("UPDATE chunks SET vec=? WHERE id=?", [(v.tobytes(), cid) for (cid, _), v in zip(part, vecs)])
        con.commit()
    con.execute("UPDATE kb SET emb_model=? WHERE name=?", (model, name))
    return len(rows)


def _sync(con: sqlite3.Connection, name: str, root: Path) -> str:
    known = {r[0]: (r[1], r[2]) for r in con.execute("SELECT path, sha, mtime FROM docs WHERE kb=?", (name,))}
    seen, added, updated, errors = set(), 0, 0, []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith(".")]
        for fn in filenames:
            p = Path(dirpath) / fn
            if p.suffix.lower() not in EXTS or fn.startswith(("~$", ".")):
                continue
            rel = str(p.relative_to(root))
            seen.add(rel)
            st = p.stat()
            if st.st_size > MAX_FILE_MB * 2**20 or (rel in known and known[rel][1] == st.st_mtime):
                continue
            sha = hashlib.sha1(p.read_bytes()).hexdigest()
            if rel in known and known[rel][0] == sha:
                con.execute("UPDATE docs SET mtime=? WHERE kb=? AND path=?", (st.st_mtime, name, rel))
                continue
            try:
                text = _extract(p)
            except Exception as e:  # noqa: BLE001
                errors.append(f"{rel}: {e}")
                continue
            _delete_doc(con, name, rel)
            for pos, chunk in _chunks(text):
                cid = con.execute("INSERT INTO chunks (kb, path, pos, text) VALUES (?,?,?,?)",
                                  (name, rel, pos, chunk)).lastrowid
                con.execute("INSERT INTO chunks_fts (rowid, lemmas) VALUES (?,?)", (cid, " ".join(_lemmas(chunk))))
            con.execute("INSERT OR REPLACE INTO docs VALUES (?,?,?,?,?)", (name, rel, sha, st.st_mtime, len(text)))
            updated += rel in known
            added += rel not in known
            con.commit()
    removed = set(known) - seen
    for rel in removed:
        _delete_doc(con, name, rel)
        con.execute("DELETE FROM docs WHERE kb=? AND path=?", (name, rel))
    embedded = _embed_missing(con, name)
    con.execute("UPDATE kb SET synced=? WHERE name=?", (time.time(), name))
    con.commit()
    _vec_cache.pop(name, None)
    total = con.execute("SELECT COUNT(*) FROM docs WHERE kb=?", (name,)).fetchone()[0]
    mode = "гибридный поиск" if embeddings.model_name() else "полнотекстовый поиск (модель эмбеддингов не найдена)"
    msg = (f"База «{name}»: документов {total} (новых {added}, изменённых {updated}, удалённых {len(removed)}); "
           f"векторизовано фрагментов: {embedded}; режим: {mode}")
    if errors:
        msg += f"\nНе удалось прочитать {len(errors)}:\n  " + "\n  ".join(errors[:10])
    return msg


def _ensure_indexed(con: sqlite3.Connection) -> None:
    """Базы, у которых нет документов (например, после смены схемы), индексируются при первом поиске."""
    for name, path in con.execute("SELECT name, path FROM kb").fetchall():
        if not con.execute("SELECT 1 FROM docs WHERE kb=? LIMIT 1", (name,)).fetchone() and Path(path).is_dir():
            _sync(con, name, Path(path))


def _vectors(con: sqlite3.Connection, name: str) -> tuple[np.ndarray, np.ndarray]:
    synced = con.execute("SELECT synced FROM kb WHERE name=?", (name,)).fetchone()[0] or 0
    cached = _vec_cache.get(name)
    if cached and cached[0] == synced:
        return cached[1], cached[2]
    rows = con.execute("SELECT id, vec FROM chunks WHERE kb=? AND vec IS NOT NULL", (name,)).fetchall()
    ids = np.array([r[0] for r in rows], dtype=np.int64)
    mat = np.vstack([np.frombuffer(r[1], dtype=np.float32) for r in rows]) if rows else np.zeros((0, 1), np.float32)
    _vec_cache[name] = (synced, ids, mat)
    return ids, mat


# ---------- инструменты ----------

@mcp.tool(annotations=RO)
def kb_list() -> str:
    """Список локальных баз знаний: название, папка, число документов, режим поиска, дата синхронизации."""
    con = _db()
    rows = con.execute("SELECT name, path, description, synced FROM kb ORDER BY name").fetchall()
    if not rows:
        return "Баз знаний пока нет. Создайте: kb_add_folder(name, path)."
    out = []
    for name, path, desc, synced in rows:
        n = con.execute("SELECT COUNT(*) FROM docs WHERE kb=?", (name,)).fetchone()[0]
        v = con.execute("SELECT COUNT(*) FROM chunks WHERE kb=? AND vec IS NOT NULL", (name,)).fetchone()[0]
        when = time.strftime("%d.%m.%Y %H:%M", time.localtime(synced)) if synced else "—"
        mode = "гибридный" if v else "полнотекстовый"
        out.append(f"«{name}» · {path} · документов: {n} · поиск: {mode} · синхронизация: {when}"
                   + (f"\n    {desc}" if desc else ""))
    return "\n".join(out)


@mcp.tool(annotations=WRITE)
def kb_add_folder(name: str, path: str, description: str = "") -> str:
    """Создать базу знаний из папки (со всеми вложенными папками) и проиндексировать её."""
    root = Path(os.path.expanduser(path)).resolve()
    if not root.is_dir():
        return f"Папка не найдена: {root}"
    con = _db()
    con.execute("INSERT OR REPLACE INTO kb (name, path, description, synced, emb_model) VALUES (?,?,?,NULL,NULL)",
                (name, str(root), description))
    return _sync(con, name, root)


@mcp.tool(annotations=WRITE)
def kb_sync(name: str) -> str:
    """Обновить базу знаний: проиндексировать новые и изменённые файлы, убрать удалённые."""
    con = _db()
    row = con.execute("SELECT path FROM kb WHERE name=?", (name,)).fetchone()
    if not row:
        return f"База «{name}» не найдена"
    return _sync(con, name, Path(row[0]))


@mcp.tool(annotations=RO)
def kb_search(query: str, name: str = "", limit: int = 8) -> str:
    """Поиск по базам знаний (все или одна — name): по смыслу и по словам одновременно.

    Формулируйте запрос естественным языком («как оформить отпуск»). Точную фразу возьмите
    в кавычки. Для полного текста документа используйте kb_read.
    """
    con = _db()
    _ensure_indexed(con)
    kbs = [name] if name else [r[0] for r in con.execute("SELECT name FROM kb")]
    if not kbs or (name and not con.execute("SELECT 1 FROM kb WHERE name=?", (name,)).fetchone()):
        return "База знаний не найдена. Список баз: kb_list."

    # 1) Полнотекстовый поиск по леммам
    phrases = re.findall(r'"([^"]+)"', query)
    terms = {t for t in _lemmas(re.sub(r'"[^"]+"', " ", query)) if len(t) > 2 and t not in STOP}
    parts = [f'"{" ".join(_lemmas(p))}"' for p in phrases] + [f'"{t}"' for t in sorted(terms)]
    terms |= {t for p in phrases for t in _lemmas(p)}
    marks = ",".join("?" * len(kbs))
    lexical: list[int] = []
    if parts:
        lexical = [r[0] for r in con.execute(
            f"SELECT c.id FROM chunks_fts f JOIN chunks c ON c.id = f.rowid "
            f"WHERE chunks_fts MATCH ? AND c.kb IN ({marks}) ORDER BY bm25(chunks_fts) LIMIT ?",
            (" OR ".join(parts), *kbs, CANDIDATES))]

    # 2) Семантический поиск
    semantic: list[int] = []
    qv = embeddings.embed_query(query)
    if qv is not None:
        scored = []
        for kb in kbs:
            ids, mat = _vectors(con, kb)
            if len(ids) and mat.shape[1] == qv.shape[0]:
                sims = mat @ qv
                top = np.argsort(-sims)[:CANDIDATES]
                scored += [(float(sims[i]), int(ids[i])) for i in top]
        semantic = [cid for _, cid in sorted(scored, reverse=True)[:CANDIDATES]]

    # 3) Объединение (Reciprocal Rank Fusion)
    fused: dict[int, float] = {}
    for ranking in (lexical, semantic):
        for rank, cid in enumerate(ranking):
            fused[cid] = fused.get(cid, 0) + 1 / (RRF_K + rank + 1)
    best = sorted(fused, key=fused.get, reverse=True)[:limit]
    if not best:
        return "Ничего не найдено. Попробуйте переформулировать запрос или проверьте kb_list."

    roots = dict(con.execute("SELECT name, path FROM kb"))
    lex, sem = set(lexical), set(semantic)
    out = []
    for i, cid in enumerate(best, 1):
        kb, path, pos, text = con.execute("SELECT kb, path, pos, text FROM chunks WHERE id=?", (cid,)).fetchone()
        how = "по словам и смыслу" if cid in lex and cid in sem else ("по словам" if cid in lex else "по смыслу")
        out.append(f"{i}. [{kb}] {Path(roots.get(kb, '')) / path} (позиция {pos}; найдено {how})\n"
                   f"{_snippet(text, terms)}")
    mode = "" if qv is not None else "\n\n(семантический поиск недоступен — только по словам)"
    return "\n\n".join(out) + mode


@mcp.tool(annotations=RO)
def kb_read(name: str, path: str, start: int = 0, max_chars: int = 30000) -> str:
    """Прочитать документ из базы целиком или по частям (start — позиция начала)."""
    con = _db()
    row = con.execute("SELECT path FROM kb WHERE name=?", (name,)).fetchone()
    if not row:
        return f"База «{name}» не найдена"
    text = _extract(Path(row[0]) / path)
    part = text[start:start + max_chars]
    tail = (f"\n\n[... показано {start}–{start + len(part)} из {len(text)}; продолжение: start={start + len(part)}]"
            if start + max_chars < len(text) else "")
    return part + tail


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=True))
def kb_remove(name: str) -> str:
    """Удалить базу знаний из индекса (файлы в папке не трогаются)."""
    con = _db()
    for (path,) in con.execute("SELECT path FROM docs WHERE kb=?", (name,)).fetchall():
        _delete_doc(con, name, path)
    con.execute("DELETE FROM docs WHERE kb=?", (name,))
    con.execute("DELETE FROM kb WHERE name=?", (name,))
    con.commit()
    _vec_cache.pop(name, None)
    return f"База «{name}» удалена из индекса"


if __name__ == "__main__":
    mcp.run()
