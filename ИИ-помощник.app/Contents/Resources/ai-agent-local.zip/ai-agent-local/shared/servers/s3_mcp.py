"""MCP для поиска и передачи файлов в S3-совместимом хранилище."""

from __future__ import annotations

import csv
import functools
import json
import logging
import mimetypes
import os
import re
import stat
import sys
import xml.etree.ElementTree as ET
from contextlib import contextmanager
from pathlib import Path, PurePosixPath
from urllib.parse import quote, unquote, urlencode, urlsplit
from uuid import uuid4
from zipfile import BadZipFile, ZipFile

import httpx
from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import corp_services
import platform_util
from mcp_registry import USER_AGENT

mcp = MCPServer("s3")
RO = ToolAnnotations(readOnlyHint=True)
LOCAL_WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False, openWorldHint=False)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=True)
BUCKET = re.compile(r"[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]")
REGION = re.compile(r"[a-z0-9-]{1,64}")
MAX_LIST = 2 * 1024 * 1024
MAX_TRANSFER = 512 * 1024 * 1024
MAX_SAMPLE = 25 * 1024 * 1024
CHUNK = 128 * 1024


class S3Error(ValueError):
    """Ошибка, текст которой можно показать пользователю."""


def _bucket(bucket: str) -> str:
    if not BUCKET.fullmatch(bucket) or ".." in bucket:
        raise S3Error("Укажите корректное имя бакета.")
    return bucket


def _key(key: str, *, allow_empty: bool = False) -> str:
    if (
        (not key and not allow_empty)
        or len(key.encode("utf-8")) > 1024
        or re.search(r"[\\\x00-\x1f\x7f]", key)
        or any(p in {".", ".."} for p in key.split("/"))
    ):
        raise S3Error("Некорректный ключ объекта S3.")
    return key


def _scope() -> tuple[str, str]:
    bucket = corp_services.service_setting("s3", "BUCKET").strip()
    prefix = corp_services.service_setting("s3", "PREFIX").strip("/")
    if prefix:
        _bucket(bucket)
        _key(prefix)
    return bucket, prefix + "/" if prefix else ""


def _address(value: str, *, listing: bool = False) -> tuple[str, str]:
    default, scope = _scope()
    if value.startswith("s3://"):
        parsed = urlsplit(value)
        if parsed.query or parsed.fragment or parsed.username is not None or parsed.password is not None:
            raise S3Error("Укажите адрес вида s3://бакет/путь. Символы # и ? кодируйте в адресе.")
        bucket, key = parsed.netloc, unquote(parsed.path.removeprefix("/"))
    elif default:
        bucket, key = default, scope + value.lstrip("/")
    elif listing and value and "/" not in value:
        bucket, key = value, ""
    else:
        raise S3Error("Укажите адрес s3://бакет/путь или задайте бакет в настройках.")
    _bucket(bucket)
    _key(key, allow_empty=listing)
    if scope and (bucket != default or not key.startswith(scope)):
        if listing and bucket == default and not key:
            key = scope
        else:
            raise S3Error("Этот адрес находится за пределами настроенной рабочей папки S3.")
    return bucket, key


def _uri(bucket: str, key: str = "") -> str:
    return f"s3://{bucket}/" + quote(key, safe="/~")


def _url(bucket: str, key: str, params: dict | None = None) -> str:
    base = corp_services.service_url("s3")
    path = f"/{bucket}" if bucket else "/"
    if key:
        path += "/" + quote(key, safe="/~")
    query = "?" + urlencode(sorted(params.items()), quote_via=quote, safe="~") if params else ""
    return base + path + query


@contextmanager
def _request(method: str, bucket: str = "", key: str = "", *, params=None, file=None, headers=None):
    from botocore.auth import S3SigV4Auth
    from botocore.awsrequest import AWSRequest
    from botocore.credentials import Credentials

    access, _, secret = corp_services.credentials("s3").partition(":")
    region = corp_services.service_setting("s3", "REGION", "ru-central1").strip()
    if not access or not secret or re.search(r"\s", access + secret) or not REGION.fullmatch(region):
        raise S3Error("Укажите ключ доступа и секретный ключ S3, а также корректный регион.")
    with httpx.Client(verify=platform_util.corp_ssl_context(), timeout=45, follow_redirects=False,
                      headers={"User-Agent": USER_AGENT}) as client:
        request = client.build_request(method, _url(bucket, key, params), headers=headers,
                                       content=iter(lambda: file.read(CHUNK), b"") if file else None)
        signing = AWSRequest(method=method, url=str(request.url), data=file, headers=dict(request.headers))
        S3SigV4Auth(Credentials(access, secret), "s3", region).add_auth(signing)
        request.headers.update(signing.headers.items())
        response = client.send(request, stream=True)
        try:
            yield response
        finally:
            response.close()


def _check(response: httpx.Response, *, write: bool = False) -> None:
    status = response.status_code
    if response.is_success:
        return
    if status in (401, 403):
        raise S3Error("S3 отказал в доступе. Проверьте ключ и права на бакет или префикс.")
    if status == 404:
        raise S3Error("Бакет или объект не найден.")
    if status in (409, 412):
        raise S3Error("Объект уже есть или изменился после проверки. Выберите другое имя или снова проверьте метаданные.")
    if write and status >= 500:
        raise S3Error("Исход загрузки неизвестен. Проверьте объект по адресу и размеру перед повтором.")
    raise S3Error(f"S3 вернул HTTP {status}. Проверьте адрес, регион и поддержку операции.")


def _xml(response: httpx.Response) -> ET.Element:
    _check(response)
    body = bytearray()
    for chunk in response.iter_bytes(chunk_size=CHUNK):
        body.extend(chunk)
        if len(body) > MAX_LIST:
            raise S3Error("Ответ со списком больше 2 МБ. Уточните префикс или уменьшите размер страницы.")
    if b"\x00" in body or b"<!DOCTYPE" in body.upper() or b"<!ENTITY" in body.upper():
        raise S3Error("Некорректный XML ответа S3.")
    try:
        root = ET.fromstring(body)
    except ET.ParseError as exc:
        raise S3Error("S3 вернул ответ, который не удалось разобрать.") from exc
    for node in root.iter():
        node.tag = node.tag.rsplit("}", 1)[-1]
    return root


def _workspace() -> Path:
    return Path(os.environ.get("AGENT_WORKSPACE") or "~/magnit-agent-workspace").expanduser().resolve()


def _local_path(value: str) -> Path:
    root = _workspace()
    path = (root / Path(value).expanduser()).resolve()
    parts = path.relative_to(root).parts if path.is_relative_to(root) else ()
    if not parts or any(p.startswith(".") or ":" in p for p in parts):
        raise S3Error("Укажите обычный файл внутри рабочей папки помощника.")
    if hasattr(os.path, "isreserved") and any(os.path.isreserved(part) for part in parts):
        raise S3Error("Имя файла зарезервировано операционной системой.")
    return path


def _name(key: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", PurePosixPath(key).name).strip(" .")
    if not name or re.fullmatch(r"(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?", name, re.I):
        name = "s3_" + name
    return name[:160]


def _head(bucket: str, key: str) -> dict:
    with _request("HEAD", bucket, key) as response:
        _check(response)
        return {name: response.headers.get(name) for name in
                ("etag", "content-length", "content-type", "last-modified")}


def _transfer(bucket: str, key: str, dest: Path, maximum: int) -> int:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        raise S3Error("Локальный файл уже существует. Выберите другое имя.")
    temp = dest.with_name(f".s3-{uuid4().hex}.part")
    try:
        with _request("GET", bucket, key, headers={"Accept-Encoding": "identity"}) as response:
            _check(response)
            length = response.headers.get("content-length", "")
            if length.isdigit() and int(length) > maximum:
                raise S3Error(f"Файл превышает допустимый размер для этой операции ({maximum // (1024 * 1024)} МБ).")
            count = 0
            with temp.open("xb") as f:
                for chunk in response.iter_raw(chunk_size=CHUNK):
                    count += len(chunk)
                    if count > maximum:
                        raise S3Error("Файл превышает допустимый размер для этой операции.")
                    f.write(chunk)
            if length.isdigit() and count != int(length):
                raise S3Error("Скачан неполный файл. Повторите операцию.")
        os.link(temp, dest)
        return count
    except FileExistsError as exc:
        raise S3Error("Локальный файл уже существует. Выберите другое имя.") from exc
    finally:
        temp.unlink(missing_ok=True)


def _errors(fn):
    @functools.wraps(fn)
    def call(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except (S3Error, corp_services.ServiceError) as exc:
            return f"S3: {exc}"
        except ImportError:
            return "S3: драйвер не установлен. Запустите обновление помощника."
        except (OSError, httpx.HTTPError, ValueError, BadZipFile, csv.Error) as exc:
            return f"S3: ошибка связи или обработки ({type(exc).__name__}). Проверьте VPN и настройки."

    return call


def _items(bucket: str, prefix: str, limit: int, cursor: str = "") -> tuple[list[dict], str]:
    params = {"list-type": 2, "prefix": prefix, "max-keys": limit, "encoding-type": "url"}
    if cursor:
        if len(cursor) > 4096 or re.search(r"[\x00-\x1f\x7f]", cursor):
            raise S3Error("Некорректный курсор.")
        params["continuation-token"] = cursor
    with _request("GET", bucket, params=params) as response:
        root = _xml(response)
    if root.tag != "ListBucketResult":
        raise S3Error("S3 вернул некорректный список объектов.")
    encoded = root.findtext("EncodingType") == "url"
    items = []
    for node in root.findall("Contents")[:limit]:
        key = node.findtext("Key", "")
        key = unquote(key) if encoded else key
        if not key.startswith(prefix):
            continue
        _key(key)
        items.append({"path": _uri(bucket, key), "bytes": node.findtext("Size"),
                      "modified": node.findtext("LastModified")})
    next_cursor = root.findtext("NextContinuationToken") or ""
    if root.findtext("IsTruncated") == "true" and not next_cursor:
        raise S3Error("S3 не вернул курсор для неполного списка.")
    return items, next_cursor


def _as_json(value) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, default=str)


@mcp.tool(annotations=RO)
@_errors
def s3_list_buckets() -> str:
    """Список доступных бакетов. При настроенной рабочей папке показывает её бакет."""
    bucket, prefix = _scope()
    if prefix:
        return _as_json({"workspace": _uri(bucket, prefix), "source": "settings"})
    with _request("GET") as response:
        if response.status_code == 403 and bucket:
            return _as_json({"buckets": [_bucket(bucket)], "source": "settings",
                             "note": "Ключ не имеет права на общий список бакетов."})
        root = _xml(response)
    if root.tag != "ListAllMyBucketsResult":
        raise S3Error("S3 вернул некорректный список бакетов.")
    return _as_json({"buckets": [node.findtext("Name") for node in root.findall("Buckets/Bucket")[:200]]})


@mcp.tool(annotations=RO)
@_errors
def s3_status() -> str:
    """Проверить доступ к настроенной папке или списку бакетов."""
    bucket, prefix = _scope()
    if bucket:
        _items(_bucket(bucket), prefix, 1)
        return f"S3 доступен: {_uri(bucket, prefix)}."
    return s3_list_buckets()


@mcp.tool(annotations=RO)
@_errors
def s3_list(path: str = "", limit: int = 40, cursor: str = "") -> str:
    """Перечислить объекты по префиксу. path — s3://бакет/префикс или путь в настроенной папке.
    Если ответ содержит next_cursor, передайте его с тем же path для следующей страницы."""
    bucket, prefix = _address(path, listing=True)
    items, next_cursor = _items(bucket, prefix, max(1, min(limit, 100)), cursor)
    return _as_json({"objects": items, "next_cursor": next_cursor or None})


@mcp.tool(annotations=RO)
@_errors
def s3_search(query: str, path: str = "", limit: int = 20, cursor: str = "") -> str:
    """Поиск по подстроке имени в заданном префиксе. Сканирует до 1000 объектов за вызов.
    Если есть next_cursor, поиск можно продолжить с теми же параметрами."""
    if not query.strip():
        raise S3Error("Введите часть имени файла для поиска.")
    bucket, prefix = _address(path, listing=True)
    hits = []
    seen = {cursor} if cursor else set()
    for _ in range(10):
        items, new_cursor = _items(bucket, prefix, 100, cursor)
        hits.extend(item for item in items if query.casefold() in unquote(item["path"]).casefold())
        cursor = new_cursor
        if not cursor:
            break
        if cursor in seen:
            raise S3Error("Хранилище повторило курсор списка. Уточните префикс.")
        seen.add(cursor)
    hits.sort(key=lambda item: item.get("modified") or "", reverse=True)
    cap = max(1, min(limit, 100))
    return _as_json({"objects": hits[:cap], "matches_scanned": len(hits), "next_cursor": cursor or None,
                     "note": "Сортировка по дате только среди просмотренных объектов."
                             + (" Уточните префикс или имя, чтобы увидеть больше совпадений." if len(hits) > cap else "")})


@mcp.tool(annotations=RO)
@_errors
def s3_head(path: str) -> str:
    """Узнать размер, тип, время изменения и ETag объекта S3 по адресу."""
    bucket, key = _address(path)
    return _as_json({"path": _uri(bucket, key), **_head(bucket, key)})


@mcp.tool(annotations=LOCAL_WRITE)
@_errors
def s3_download(path: str, to: str = "") -> str:
    """Скачать файл S3 без передачи содержимого через чат, до 512 МБ. to — новый файл в рабочей папке.
    По умолчанию используется подпапка S3."""
    bucket, key = _address(path)
    dest = _local_path(to or f"S3/{_name(key)}")
    size = _transfer(bucket, key, dest, MAX_TRANSFER)
    return f"Скачано {size} байт из {_uri(bucket, key)} → {dest}"


def _sample(path: Path, cap: int) -> dict:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        from itertools import islice

        with path.open(encoding="utf-8-sig", newline="") as f:
            preview = f.read(8192)
            f.seek(0)
            try:
                dialect = csv.Sniffer().sniff(preview, delimiters=",;\t|")
            except csv.Error:
                dialect = csv.excel
            reader = csv.reader(f, dialect)
            return {"columns": next(reader, []), "rows": list(islice(reader, cap))}
    if suffix == ".json":
        if path.stat().st_size > MAX_LIST:
            raise S3Error("Для предварительного просмотра JSON нужен файл до 2 МБ. Скачайте его для анализа.")
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return {"sample": data[:cap] if isinstance(data, list) else data}
    if suffix == ".xlsx":
        from openpyxl import load_workbook

        with ZipFile(path) as z:
            if sum(info.file_size for info in z.infolist()) > 64 * 1024 * 1024:
                raise S3Error("Распакованная таблица слишком велика для предварительного просмотра.")
        book = load_workbook(path, read_only=True, data_only=True, keep_links=False)
        try:
            return {"sheets": book.sheetnames, "rows_first_sheet": list(
                book.worksheets[0].iter_rows(max_row=cap + 1, max_col=80, values_only=True))}
        finally:
            book.close()
    if suffix == ".parquet":
        try:
            from pyarrow.parquet import ParquetFile
        except ImportError as exc:
            raise S3Error("Для просмотра Parquet нужен компонент pyarrow. Файл можно скачать через s3_download.") from exc

        pf = ParquetFile(path)
        try:
            batch = next(pf.iter_batches(batch_size=cap), None)
            return {"columns": pf.schema.names, "total_rows": pf.metadata.num_rows,
                    "rows": batch.to_pylist() if batch is not None else []}
        finally:
            pf.close()
    raise S3Error("Предварительный просмотр поддерживает CSV, XLSX, JSON и Parquet.")


@mcp.tool(annotations=RO)
@_errors
def s3_preview(path: str, rows: int = 10) -> str:
    """Показать структуру и образец строк CSV/XLSX/JSON/Parquet из S3. Для файлов до 25 МБ."""
    from tempfile import TemporaryDirectory

    bucket, key = _address(path)
    suffix = PurePosixPath(key).suffix.lower()
    if suffix not in {".csv", ".xlsx", ".json", ".parquet"}:
        raise S3Error("Предварительный просмотр поддерживает CSV, XLSX, JSON и Parquet.")
    with TemporaryDirectory(prefix="magnit-s3-") as temp:
        file = Path(temp) / f"sample{suffix}"
        size = _transfer(bucket, key, file, MAX_SAMPLE)
        sample = _sample(file, max(1, min(rows, 20)))
    message = _as_json({"path": _uri(bucket, key), "size": size, **sample})
    if len(message) > 24_000:
        return message[:24_000] + "\n… предпросмотр сокращён по размеру."
    return message


@mcp.tool(annotations=WRITE)
@_errors
def s3_upload(local_file: str, path: str = "", confirm: bool = False, expected_etag: str = "") -> str:
    """Загрузить локальный файл из рабочей папки в S3, до 512 МБ. Сначала confirm=false показывает черновик.
    По умолчанию создаёт только новый объект, без перезаписи. Перезапись требует согласия и актуального
    expected_etag из s3_head; если объект изменился, хранилище отклонит запись."""
    source = _local_path(local_file)
    if not source.is_file():
        raise S3Error("Локальный файл не найден.")
    bucket, key = _address(path or source.name)
    with source.open("rb") as file:
        st = os.fstat(file.fileno())
        if not stat.S_ISREG(st.st_mode) or st.st_size > MAX_TRANSFER:
            raise S3Error("Выберите обычный файл размером до 512 МБ.")
        uri = _uri(bucket, key)
        if expected_etag and not re.fullmatch(r'"[^"\x00-\x20\x7f]{1,200}"', expected_etag):
            raise S3Error("Для перезаписи передайте точный ETag из метаданных объекта.")
        mode = "замена только указанной версии" if expected_etag else "только создание нового объекта"
        if not confirm:
            return f"Черновик загрузки S3: {source} ({st.st_size} байт) → {uri}, {mode}. Файл не отправлен."
        headers = {"Content-Length": str(st.st_size),
                   "Content-Type": mimetypes.guess_type(source.name)[0] or "application/octet-stream"}
        if expected_etag:
            headers["If-Match"] = expected_etag
        else:
            headers["If-None-Match"] = "*"
        try:
            with _request("PUT", bucket, key, file=file, headers=headers) as response:
                _check(response, write=True)
                etag = response.headers.get("etag")
        except (httpx.HTTPError, OSError) as exc:
            raise S3Error("Исход загрузки неизвестен. Проверьте объект по адресу и размеру перед повтором.") from exc
    return _as_json({"uploaded": uri, "bytes": st.st_size, "etag": etag})


if __name__ == "__main__":
    logging.getLogger("httpx").setLevel(logging.WARNING)
    mcp.run()
