"""Read dashboards, VictoriaMetrics series and VictoriaLogs through Grafana."""

from __future__ import annotations

import json
import math
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Annotated
from urllib.parse import unquote

from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations
from pydantic import Field

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from corp_services import Client, ref_path, service_url  # noqa: E402

mcp = MCPServer("grafana")
RO = ToolAnnotations(readOnlyHint=True)
UID = re.compile(r"[A-Za-z0-9_-]{1,128}")
MAX_WINDOW = 7 * 86400
MAX_POINTS = 11000


def _uid(value: str) -> str:
    if not UID.fullmatch(value):
        raise ValueError("Неверный UID Grafana")
    return value


def _dashboard_uid(reference: str) -> str:
    if "://" not in reference:
        return _uid(reference)
    match = re.search(r"/(?:d|d-solo)/([^/]+)(?:/|$)", ref_path("grafana", reference))
    if not match:
        raise ValueError("Ссылка должна открывать дашборд Grafana")
    return _uid(unquote(match[1]))


def _timestamp(value: str) -> float:
    try:
        date = datetime.fromisoformat(value)
        if date.tzinfo is None:
            raise ValueError
        seconds = date.timestamp()
        if seconds < 0:
            raise ValueError
        return seconds
    except (ValueError, OverflowError, OSError):
        raise ValueError("Укажите дату и время в ISO 8601 с часовым поясом, например 2026-11-18T13:00:00+03:00") from None


def _window(start: str, end: str) -> tuple[float, float]:
    begin, finish = _timestamp(start), _timestamp(end)
    if not 0 <= finish - begin <= MAX_WINDOW:
        raise ValueError("Начало не должно быть позже конца, максимальный период — 7 суток")
    return begin, finish


@mcp.tool(annotations=RO)
def grafana_status() -> dict:
    """Проверить доступ к Grafana и показать имя текущего пользователя."""
    with Client("grafana") as client:
        user = client.request("GET", "/api/user")
    return {"accessible": True, "login": user.get("login"), "url": service_url("grafana")}


@mcp.tool(annotations=RO)
def grafana_list_datasources() -> list:
    """Показать доступные источники данных Grafana: название, UID и тип."""
    with Client("grafana") as client:
        sources = client.request("GET", "/api/datasources")
    return [{key: item.get(key) for key in ("name", "uid", "type", "isDefault")} for item in sources]


@mcp.tool(annotations=RO)
def grafana_find_dashboards(
    title: Annotated[str, Field(max_length=300)] = "",
    limit: Annotated[int, Field(ge=1, le=50)] = 20,
) -> list:
    """Найти дашборды по названию."""
    with Client("grafana") as client:
        dashboards = client.request("GET", "/api/search", params={"query": title, "type": "dash-db", "limit": limit})
    return [{key: item.get(key) for key in ("uid", "title", "url", "folderTitle")} for item in dashboards]


@mcp.tool(annotations=RO)
def grafana_get_dashboard(reference: str) -> dict:
    """Прочитать конфигурацию панелей, фильтров и источников по ссылке или UID."""
    uid = _dashboard_uid(reference.strip())
    with Client("grafana") as client:
        result = client.request("GET", f"/api/dashboards/uid/{uid}")
    result["url"] = f"{service_url('grafana')}/d/{uid}"
    return result


@mcp.tool(annotations=RO)
def grafana_metrics(
    datasource_uid: str, expression: Annotated[str, Field(min_length=1, max_length=16384)],
    start: str, end: str, step_seconds: Annotated[float, Field(gt=0, allow_inf_nan=False)] | None = None,
) -> dict:
    """Читать ряды VictoriaMetrics. Время указывается в ISO 8601 с часовым поясом, шаг может подбираться автоматически."""
    begin, finish = _window(start, end)
    step = step_seconds if step_seconds is not None else max(1, math.ceil((finish - begin) / 600))
    if math.floor((finish - begin) / step) + 1 > MAX_POINTS:
        raise ValueError("Слишком много точек на ряд. Увеличьте шаг или сузьте период")
    uid = _uid(datasource_uid)
    with Client("grafana") as client:
        result = client.request(
            "GET", f"/api/datasources/proxy/uid/{uid}/api/v1/query_range",
            params={"query": expression, "start": begin, "end": finish, "step": step},
        )
    return {"start": start, "end": end, "step_seconds": step, "response": result}


@mcp.tool(annotations=RO)
def grafana_logs(
    datasource_uid: str, query: Annotated[str, Field(min_length=1, max_length=16384)],
    start: str, end: str, limit: Annotated[int, Field(ge=1, le=1000)] = 50,
) -> dict:
    """Читать VictoriaLogs через Grafana по LogsQL и ISO 8601 времени. Указывайте фильтр сервиса и короткий период."""
    begin, finish = _window(start, end)
    uid = _uid(datasource_uid)
    with Client("grafana") as client:
        output = client.request(
            "GET", f"/api/datasources/proxy/uid/{uid}/select/logsql/query",
            params={"query": query, "start": begin, "end": finish, "limit": limit}, raw=True,
        )
    lines = []
    for line in output.splitlines():
        if len(line) > 4000:
            lines.append({"preview": line[:4000], "truncated": True})
        elif line:
            try:
                lines.append(json.loads(line))
            except ValueError:
                lines.append(line)
    return {"start": start, "end": end, "lines": lines[:limit], "truncated": len(lines) >= limit}


if __name__ == "__main__":
    mcp.run()
