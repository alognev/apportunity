"""Read the corporate Sourcebot index without changing repositories."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Annotated

from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations
from pydantic import Field

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from corp_services import Client, service_url  # noqa: E402

mcp = MCPServer("sourcebot")
RO = ToolAnnotations(readOnlyHint=True)
REPO = Annotated[str, Field(pattern=r"^[A-Za-z0-9._/-]{1,200}$")]
FILE = Annotated[str, Field(pattern=r"^[A-Za-z0-9._/*+,-]{1,200}$")]
LANGUAGE = Annotated[str, Field(pattern=r"^[A-Za-z0-9+#._-]{1,32}$")]


def _bound(value: object, limit: int, depth: int = 0) -> object:
    if depth > 12:
        return None
    if isinstance(value, dict):
        result = {key: _bound(item, limit, depth + 1) for key, item in value.items()}
        files = result.get("files")
        if isinstance(files, list) and len(files) > limit:
            result["files"] = files[:limit]
            result["truncated_matches"] = True
        return result
    if isinstance(value, list):
        return [_bound(item, limit, depth + 1) for item in value]
    if isinstance(value, str) and len(value) > 2000:
        return value[:2000] + "…"
    return value


@mcp.tool(annotations=RO)
def sourcebot_status() -> dict:
    """Проверить вход и версию корпоративного индекса Sourcebot."""
    with Client("sourcebot") as client:
        version = client.request("GET", "/api/version")
    return {"accessible": True, "service": version, "url": service_url("sourcebot")}


@mcp.tool(annotations=RO)
def sourcebot_search(
    query: Annotated[str, Field(min_length=1, max_length=2048)],
    repository: REPO | None = None, file: FILE | None = None, language: LANGUAGE | None = None,
    limit: Annotated[int, Field(ge=1, le=50)] = 12,
) -> dict:
    """Найти исходный код в индексе Sourcebot, с ограничением по репозиторию, файлу и языку."""
    query = query.strip()
    if not query:
        raise ValueError("Укажите непустой поисковый запрос")
    filters = [f"{key}:{value}" for key, value in (("repo", repository), ("file", file), ("lang", language)) if value]
    with Client("sourcebot") as client:
        result = client.request(
            "POST", "/api/search", changing=False,
            json={"query": " ".join([query, *filters]), "matches": limit, "contextLines": 2},
        )
    return {"results": _bound(result, limit), "index": service_url("sourcebot")}


if __name__ == "__main__":
    mcp.run()
