"""Help/ШПС: read own requests and send a request from a verified local form."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Annotated, Literal
from uuid import uuid4

from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations
from pydantic import Field

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from corp_services import Client, ServiceError, ref_path, service_setting, service_url  # noqa: E402

mcp = MCPServer("help")
RO = ToolAnnotations(readOnlyHint=True)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=False)
EVENTS = "/dwp/api/v1.0/events"
CREATE = "/dwp/rest/v2/service_request/create"
PROFILE = "/dwp/rest/v2/profile/user/"
HEADERS = {"X-Requested-By": "XMLHttpRequest"}
NUMBER = re.compile(r"REQ\d{12}", re.IGNORECASE)
EVENT_ID = re.compile(r"[A-Za-z0-9_-]{16,512}")
LOGIN = re.compile(r"[A-Za-z0-9._-]{1,64}")
FORM_NAME = re.compile(r"[a-z0-9][a-z0-9_-]{0,63}")
DIRECTION = re.compile(r"[A-Z]{3}[A-Za-z0-9+/=]{8,120}")
QUESTION = re.compile(r"[A-Z]{3,4}[A-Za-z0-9+/=]{8,120}")
MAX_FORMS_BYTES = 128 * 1024


def _login() -> str:
    value = service_setting("help", "LOGIN")
    if not LOGIN.fullmatch(value) or value in {".", ".."}:
        raise ServiceError("Help: укажите логин владельца сессии в настройках")
    return value


def _list(client, state: str, limit: int) -> dict:
    data = client.request("GET", EVENTS, params={"state": state, "perPage": limit}, headers=HEADERS)
    if not isinstance(data, dict) or not isinstance(data.get("content"), list):
        raise ServiceError("Help: портал вернул список заявок в неожиданном формате")
    return data


def _card_id(reference: str) -> str | None:
    if NUMBER.fullmatch(reference):
        return None
    if "://" in reference:
        reference = ref_path("help", reference)
    if reference.startswith(EVENTS + "/"):
        reference = reference.removeprefix(EVENTS + "/")
    if not EVENT_ID.fullmatch(reference):
        raise ValueError("Укажите номер REQ или ссылку на карточку из свежего списка Help")
    return reference


def _href(item: dict) -> str | None:
    links = item.get("links")
    if isinstance(links, list):
        for link in links:
            if isinstance(link, dict) and link.get("rel") == "self" and isinstance(link.get("href"), str):
                return link["href"]
    return None


def _find_card_id(client, number: str) -> str:
    for state in ("active", "inactive"):
        for item in _list(client, state, 100)["content"]:
            if not isinstance(item, dict):
                continue
            nested = item.get("requests")
            candidates = [item] + (nested if isinstance(nested, list) else [])
            for entry in candidates:
                if isinstance(entry, dict) and entry.get("displayId") == number.upper():
                    href = _href(entry) or _href(item)
                    if href:
                        card_id = _card_id(href)
                        if card_id:
                            return card_id
    raise ServiceError(f"Help: {number.upper()} не найден в недавних активных и завершённых заявках")


def _forms() -> dict:
    location = service_setting("help", "FORMS_FILE")
    if not location:
        return {}
    try:
        path = Path(location).expanduser()
        if not path.is_absolute() or not path.is_file():
            raise ValueError
        with path.open("rb") as stream:
            payload = stream.read(MAX_FORMS_BYTES + 1)
        if len(payload) > MAX_FORMS_BYTES:
            raise ValueError
        forms = json.loads(payload.decode("utf-8-sig"))
        if not isinstance(forms, dict) or len(forms) > 32:
            raise ValueError
        for name, form in forms.items():
            if not FORM_NAME.fullmatch(name) or not isinstance(form, dict):
                raise ValueError
            if not isinstance(form.get("title"), str) or not 1 <= len(form["title"].strip()) <= 140:
                raise ValueError
            if not DIRECTION.fullmatch(form.get("srd", "")):
                raise ValueError
            fields = form.get("fields")
            if not isinstance(fields, dict) or not 1 <= len(fields) <= 30:
                raise ValueError
            for field, spec in fields.items():
                if not FORM_NAME.fullmatch(field) or not isinstance(spec, dict):
                    raise ValueError
                if not QUESTION.fullmatch(spec.get("question_id", "")):
                    raise ValueError
                if not isinstance(spec.get("label"), str) or not 1 <= len(spec["label"].strip()) <= 140:
                    raise ValueError
                if not isinstance(spec.get("required", True), bool):
                    raise ValueError
            if len({spec["question_id"] for spec in fields.values()}) != len(fields):
                raise ValueError
        return forms
    except (OSError, TypeError, ValueError):
        raise ServiceError("Help: проверьте формат файла утверждённых форм в настройках") from None


@mcp.tool(annotations=RO)
def help_status() -> dict:
    """Проверить вход в Help. Используется собственная сессия пользователя."""
    with Client("help") as client:
        _list(client, "active", 1)
    return {"accessible": True, "url": service_url("help")}


@mcp.tool(annotations=RO)
def help_whoami() -> dict:
    """Проверить профиль владельца сессии Help, заданный в настройках."""
    with Client("help") as client:
        profile = client.request("GET", PROFILE + _login(), headers=HEADERS)
    if not profile:
        raise ServiceError("Help: профиль не найден. Проверьте логин владельца сессии")
    return {"profile": profile}


@mcp.tool(annotations=RO)
def help_list_requests(
    state: Literal["active", "inactive"] = "active",
    limit: Annotated[int, Field(ge=1, le=100)] = 20,
) -> dict:
    """Показать свои активные или завершённые заявки. Размер страницы ограничен."""
    with Client("help") as client:
        result = _list(client, state, limit)
    return {"state": state, "requests": result["content"][:limit], "possibly_more": len(result["content"]) >= limit}


@mcp.tool(annotations=RO)
def help_get_request(reference: Annotated[str, Field(min_length=1, max_length=1024)]) -> dict:
    """Получить карточку своей заявки по номеру REQ, свежей ссылке или идентификатору."""
    reference = reference.strip()
    card_id = _card_id(reference)
    with Client("help") as client:
        if not card_id:
            card_id = _find_card_id(client, reference)
        data = client.request("GET", f"{EVENTS}/{card_id}", headers=HEADERS)
    return {"request": data, "reference": reference}


@mcp.tool(annotations=RO)
def help_list_forms() -> dict:
    """Показать проверенные локальные формы и человекочитаемые названия полей."""
    forms = _forms()
    return {"forms": {
        name: {"title": form["title"], "fields": {
            field: {"label": spec["label"], "required": spec.get("required", True)}
            for field, spec in form["fields"].items()
        }}
        for name, form in forms.items()
    }}


@mcp.tool(annotations=WRITE)
def help_create_request(
    form_name: str, answers: dict[str, str], confirm: bool = False,
) -> dict:
    """Предпросмотр или создание собственной заявки по утверждённой форме. После предпросмотра нужно согласие."""
    form = _forms().get(form_name)
    if not form:
        raise ServiceError("Help: форма не подключена. Посмотрите доступные формы через help_list_forms")
    fields = form["fields"]
    unknown = answers.keys() - fields.keys()
    if unknown:
        raise ValueError("Проверьте названия полей по списку утверждённых форм")
    missing = [spec["label"] for field, spec in fields.items()
               if spec.get("required", True) and not answers.get(field, "").strip()]
    if missing:
        return {"executed": False, "form": form["title"], "missing_fields": missing}
    values = {field: value.strip() for field, value in answers.items() if value.strip()}
    if not values or any(len(value) > 4000 for value in values.values()):
        raise ValueError("Заполните хотя бы одно поле, максимум 4000 символов на поле")
    if not confirm:
        return {"executed": False, "form": form["title"],
                "answers": [{"field": fields[field]["label"], "value": value} for field, value in values.items()]}
    owner = _login()
    domain = service_setting("help", "EMAIL_DOMAIN", "magnit.ru")
    if not re.fullmatch(r"[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+", domain):
        raise ServiceError("Help: проверьте почтовый домен в настройках")
    key = str(uuid4())
    body = {
        "ServiceRequest": {
            "tempCreateId": key, "srdId": form["srd"], "requestedByLoginId": owner,
            "requestedForLoginId": owner, "requestedForEmail": f"{owner}@{domain}",
            "requestedForPhone": "", "providerSourceName": "srm",
        },
        "ServiceRequestAnswer": [
            {"tempCreateId": key, "questionId": spec["question_id"], "order": i, "value": values[field]}
            for i, (field, spec) in enumerate(fields.items(), 1) if field in values
        ],
    }
    files = {"request": (None, json.dumps(body, ensure_ascii=False).encode("utf-8")), "csrf": (None, "undefined")}
    with Client("help") as client:
        result = client.request("POST", CREATE, files=files, headers=HEADERS)
    return {"executed": True, "response": result}


if __name__ == "__main__":
    mcp.run()
