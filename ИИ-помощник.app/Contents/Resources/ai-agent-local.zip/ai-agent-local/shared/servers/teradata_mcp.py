"""MCP «teradata»: Teradata КХД (боевой teradata, DR tddr, разработка tddev, реплика tdtva) — только чтение.

Вход — личной корпоративной учётной записью. Логин — доменный (как в macOS, TERADATA_USER — если другой).
Сначала пробуется Kerberos (без пароля; работает не на всех серверах), затем LDAP: пароль пользователь вводит сам
в системном окне macOS при первом обращении, он хранится в «Связке ключей» (служба magnit-agent-teradata) и
спрашивается снова, если Teradata ответит «неверный пароль». Способ входа для каждого сервера запоминается
в ~/.magnit-agent/teradata.json. Настройки (необязательно): TERADATA_SERVER (по умолчанию teradata), TERADATA_USER.

Изменения запрещены в коде: допускаются только SELECT/WITH/HELP/SHOW/EXPLAIN, по одному запросу; чтение идёт
с блокировкой ACCESS (READ UNCOMMITTED), чтобы не мешать загрузкам. Права на данные — роли пользователя в Teradata.
"""

from __future__ import annotations

import getpass
import json
import os
import re
import sys
import threading
import time
from pathlib import Path

from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import platform_util  # noqa: E402

mcp = MCPServer("teradata")
RO = ToolAnnotations(readOnlyHint=True)

SERVERS = {  # имя → что это (адрес teradatasql находит сам: имя + cop1, cop2… в домене)
    "teradata": "боевой сервер (IFX)",
    "tddr": "DR-сервер",
    "tdtva": "реплика боевого (td2750)",
    "tddev": "сервер разработки",
}
STATE = Path.home() / ".magnit-agent" / "teradata.json"
KEYCHAIN_SERVICE = "magnit-agent-teradata"
ACCESS_HELP = ("Доступ к данным в Teradata выдаётся по ролям: запрос — через чат-бот MagnitData "
               "(https://data.cloudmagnit:9443/, роль ищется там же в поиске) с согласованием владельца роли; "
               "владельцы — https://it-portal.corp.tander.ru/pages/viewpage.action?pageId=1646323452. "
               "Новым пользователям нужно пройти тест по SQL — "
               "https://it-portal.corp.tander.ru/pages/viewpage.action?pageId=1716724141")
READ_START = {"SELECT", "SEL", "WITH", "HELP", "SHOW", "EXPLAIN", "LOCKING", "LOCK"}
WRITE_WORDS = re.compile(r"\b(INSERT|INS|UPDATE|UPD|DELETE|DEL|MERGE|CREATE|DROP|ALTER|REPLACE|RENAME|GRANT|REVOKE|"
                         r"CALL|EXEC|EXECUTE|COLLECT|MODIFY|COMMENT|BT|ET|COMMIT|ROLLBACK|ABORT|"
                         r"LOGOFF|LOGON|SET)\b", re.I)
MAX_CELL = 300

_conns: dict[str, object] = {}
_lock = threading.Lock()


# ---------- вход ----------

LOGIN_KEY = "login"  # в teradata.json: последний логин, с которым удалось войти (остальные ключи — сервер: способ входа)


def _system_user() -> str:
    """Учётная запись, под которой работает Windows/macOS (с ней же входит Kerberos)."""
    return getpass.getuser().strip()


def _user() -> str:
    """Логин Teradata: TERADATA_USER в .env → последний, с которым удалось войти → учётная запись системы.
    Корпоративная учётка может отличаться от системной (личный компьютер, другое имя) — тогда её вводят в окне входа."""
    return (os.environ.get("TERADATA_USER") or _state().get(LOGIN_KEY) or _system_user()).strip()


def _state() -> dict:
    try:
        return json.loads(STATE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _remember(server: str, method: str, login: str = "") -> None:
    STATE.parent.mkdir(parents=True, exist_ok=True)
    st = {**_state(), server: method}
    if login:
        st[LOGIN_KEY] = login
    STATE.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")


def _keychain_get(login: str) -> str | None:
    return platform_util.secret_get(KEYCHAIN_SERVICE, login)


def _keychain_set(login: str, password: str) -> None:
    platform_util.secret_set(KEYCHAIN_SERVICE, login, password, label="Teradata (ИИ-помощник)")


def _keychain_delete(login: str) -> None:
    platform_util.secret_delete(KEYCHAIN_SERVICE, login)


def _ask_login(reason: str, login: str) -> tuple[str, str] | None:
    """Системное окно входа: логин (подставлен login — последний удачный или системный, можно исправить) и пароль
    вводит сам пользователь."""
    store = "в диспетчере учётных данных Windows" if platform_util.WINDOWS else "в «Связке ключей» macOS"
    text = (f"{reason}\n\nЛогин — ваша корпоративная (доменная) учётная запись; если подставлена не та, исправьте. "
            f"Пароль сохранится {store} и больше спрашиваться не будет.")
    return platform_util.ask_login("ИИ-помощник — вход в Teradata", text, login)


class TdError(RuntimeError):
    pass


def _code(e: Exception) -> int:
    m = re.search(r"\[Error (\d+)\]", str(e))
    return int(m.group(1)) if m else 0


def _short(e: Exception) -> str:
    lines = [ln for ln in str(e).splitlines() if ln.strip()]
    line = next((ln for ln in lines if "[Error" in ln), lines[0] if lines else repr(e))
    return re.sub(r"^\[Version [^\]]*\]\s*(\[Session \d+\]\s*)?", "", line)[:300]


def _open(server: str, method: str, login: str = "", password: str | None = None):
    import teradatasql

    params = {"host": server, "encryptdata": "true", "tmode": "ANSI", "connect_timeout": "20000",
              "logmech": "KRB5" if method == "krb5" else "LDAP"}
    if method == "ldap":
        params.update(user=login, password=password or "")
    con = teradatasql.connect(**params)
    cur = con.cursor()
    try:  # чтение с блокировкой ACCESS: не ждём загрузок и не мешаем им
        cur.execute("SET SESSION CHARACTERISTICS AS TRANSACTION ISOLATION LEVEL READ UNCOMMITTED")
    except Exception:  # noqa: BLE001
        pass
    return con


def _connect(server: str):
    """Соединение с сервером: Kerberos → LDAP с паролем из «Связки ключей» → окно входа (логин и пароль)."""
    remembered = _state().get(server)
    errors = []
    # Kerberos входит под учётной записью системы — пробуем, только если логин Teradata с ней совпадает
    if remembered in (None, "krb5") and _user().lower() == _system_user().lower():
        try:
            con = _open(server, "krb5")
            _remember(server, "krb5")
            return con
        except Exception as e:  # noqa: BLE001
            if _code(e) == 0 and "Kerberos" not in str(e) and "GSS" not in str(e):
                raise TdError(f"Нет связи с Teradata ({server}): {_short(e)}. Проверьте VPN (FortiClient или NetBird).") from e
            errors.append(_short(e))
    login = _user()
    for attempt in range(3):
        password = _keychain_get(login) if attempt == 0 else None
        if not password:
            reason = "Введите логин и пароль доменной учётной записи." if attempt == 0 else \
                "Teradata не принял логин или пароль — проверьте и введите ещё раз."
            # после неудачи в окне — логин, который только что ввели; запоминается только после успешного входа
            got = _ask_login(f"Вход в Teradata ({server}, {SERVERS.get(server, '')}). {reason}", login)
            if not got:
                raise TdError("Вход в Teradata отменён или окно входа недоступно (нужен вход в систему). "
                              "Попросите пользователя войти — инструмент td_login — и повторите.")
            login, password = got
        try:
            con = _open(server, "ldap", login, password)
        except Exception as e:  # noqa: BLE001
            code = _code(e)
            if code == 8017:  # неверный логин или пароль
                _keychain_delete(login)
                errors.append(f"неверный логин или пароль ({login})")
                continue
            if code in (3032, 8018):
                raise TdError(f"Учётная запись {login} заблокирована или пароль истёк в Teradata ({server}): "
                              f"{_short(e)}") from e
            raise TdError(f"Teradata ({server}) не пускает: {_short(e)}. {ACCESS_HELP}") from e
        _keychain_set(login, password)
        _remember(server, "ldap", login)
        return con
    raise TdError(f"Не удалось войти в Teradata ({server}): {'; '.join(errors)}.")


def _cursor(server: str):
    server = (server or os.environ.get("TERADATA_SERVER") or "teradata").strip().lower()
    if server not in SERVERS:
        raise TdError(f"Неизвестный сервер «{server}». Доступны: {', '.join(SERVERS)}.")
    with _lock:
        con = _conns.get(server)
        if con is None:
            con = _conns[server] = _connect(server)
    return server, con


def _drop(server: str) -> None:
    with _lock:
        con = _conns.pop(server, None)
    try:
        con and con.close()
    except Exception:  # noqa: BLE001
        pass


# ---------- запросы ----------

# Строки, имена в кавычках и комментарии — одним проходом слева направо: «--» или «/*» внутри строки не должны
# прятать от проверки остаток запроса («SELECT '--'; DELETE …» — для Teradata это два запроса)
_TOKENS = re.compile(r"""'(?:[^']|'')*'|"(?:[^"]|"")*"|--[^\n]*|/\*.*?(?:\*/|$)""", re.S)


def _strip(sql: str) -> str:
    """Без комментариев, строковых литералов и имён в кавычках — для проверки ключевых слов."""
    def repl(m: re.Match) -> str:
        t = m.group(0)
        return "''" if t.startswith("'") else '""' if t.startswith('"') else " "
    return _TOKENS.sub(repl, sql)


def _check_readonly(sql: str) -> str:
    sql = sql.strip().rstrip(";").strip()
    bare = _strip(sql)
    if ";" in bare:
        raise TdError("Можно выполнить только один запрос за раз (без «;» внутри).")
    first = (bare.split() or [""])[0].upper()
    if first not in READ_START:
        raise TdError("Разрешено только чтение: SELECT, WITH, HELP, SHOW, EXPLAIN. Изменять данные через помощника нельзя.")
    body = re.sub(r"^\s*LOCK(ING)?\b.*?\bFOR\s+ACCESS\b", "", bare, flags=re.I | re.S)
    hit = WRITE_WORDS.search(body)
    if hit and first not in ("HELP", "SHOW"):
        raise TdError(f"В запросе есть изменяющая команда «{hit.group(1).upper()}» — разрешено только чтение.")
    return sql


def _run(server: str, sql: str, max_rows: int, timeout: int):
    for attempt in (1, 2):
        server, con = _cursor(server)
        cur = con.cursor()
        timer = threading.Timer(timeout, lambda: _safe_cancel(con))
        timer.start()
        started = time.time()
        try:
            cur.execute(sql)
            cols = [d[0] for d in cur.description or []]
            rows = cur.fetchmany(max_rows + 1) if cols else []
            return server, cols, rows, time.time() - started, cur
        except Exception as e:  # noqa: BLE001
            code = _code(e)
            if code == 0 and attempt == 1:  # соединение оборвалось — переподключиться
                _drop(server)
                continue
            if time.time() - started >= timeout - 1:
                raise TdError(f"Запрос выполнялся дольше {timeout} с и был остановлен. Сузьте период или добавьте "
                              "условия по ключевым полям (дата, магазин), агрегируйте на сервере.") from e
            if code in (3523, 3524, 5315, 3802):
                raise TdError(f"Нет доступа: {_short(e)}. {ACCESS_HELP}") from e
            if code == 8017:
                _drop(server)
                raise TdError("Teradata не принял пароль. Вызовите td_login, чтобы ввести его заново.") from e
            raise TdError(f"Teradata: {_short(e)}") from e
        finally:
            timer.cancel()
    raise TdError("Не удалось выполнить запрос.")


def _safe_cancel(con) -> None:
    try:
        con.cancel()
    except Exception:  # noqa: BLE001
        pass


def _fmt(v) -> str:
    if v is None:
        return ""
    import datetime as dt
    s = v.isoformat(sep=" ") if isinstance(v, dt.datetime) else v.isoformat() if hasattr(v, "isoformat") else str(v)
    s = s.replace("\t", " ").replace("\n", " ").strip()
    return s if len(s) <= MAX_CELL else s[:MAX_CELL] + "…"


def _table(cols: list[str], rows: list) -> str:
    return "\n".join(["\t".join(cols)] + ["\t".join(_fmt(v) for v in r) for r in rows])


def _errors(fn):
    import functools

    @functools.wraps(fn)
    def wrapper(*a, **kw):
        try:
            return fn(*a, **kw)
        except TdError as e:
            return str(e)
        except Exception as e:  # noqa: BLE001 — непредвиденное: понятный текст вместо падения инструмента
            return f"Teradata: ошибка {e.__class__.__name__}: {_short(e)}"
    return wrapper


# ---------- инструменты ----------

@mcp.tool(annotations=RO)
@_errors
def td_query(sql: str, server: str = "", max_rows: int = 200, save_to: str = "", timeout_seconds: int = 240) -> str:
    """SQL-запрос к Teradata только на чтение (SELECT, WITH, HELP, SHOW, EXPLAIN), один за раз.
    server: teradata (боевой, по умолчанию), tddr, tdtva, tddev. Возвращает до max_rows строк (TSV).
    save_to — путь .xlsx или .csv: сохранить весь результат (до 1 млн строк) в файл. На больших таблицах
    фильтруй по дате/ключам и агрегируй на сервере; для знакомства с данными — TOP 20 или SAMPLE 20."""
    sql = _check_readonly(sql)
    limit = 1_000_000 if save_to else max(1, min(max_rows, 5000))
    server, cols, rows, secs, cur = _run(server, sql, limit, max(10, min(timeout_seconds, 290)))
    if not cols:
        return f"Выполнено за {secs:.1f} с ({server}), строк в ответе нет."
    if save_to:
        path = Path(save_to).expanduser()
        if not path.is_absolute():
            path = Path(os.environ.get("AGENT_CWD") or os.getcwd()) / path
        path.parent.mkdir(parents=True, exist_ok=True)
        import pandas as pd
        df = pd.DataFrame([list(r) for r in rows[:limit]], columns=cols)
        if path.suffix.lower() == ".csv":
            df.to_csv(path, index=False, encoding="utf-8-sig", sep=";")
        else:
            path = path.with_suffix(".xlsx")
            df.to_excel(path, index=False)
        cut = f" (обрезано до {limit} строк)" if len(rows) > limit else ""
        return f"Сохранено {len(df)} строк{cut} → {path}\nВремя: {secs:.1f} с, сервер {server}.\n\n" + _table(cols, rows[:10])
    more = len(rows) > max_rows
    shown = rows[:max_rows]
    tail = f"\n… показаны первые {max_rows} строк; весь результат — параметр save_to." if more else ""
    return f"{len(shown)} строк, {secs:.1f} с, сервер {server}:\n" + _table(cols, shown) + tail


@mcp.tool(annotations=RO)
@_errors
def td_find_tables(pattern: str, database: str = "", server: str = "") -> str:
    """Найти таблицы и представления (витрины) по части имени или описания. pattern — слово или часть имени
    (например «sale», «остат»); database — ограничить базой. Показывает базу, имя, тип и комментарий."""
    p = f"%{pattern.strip().upper()}%"
    sql = ("SELECT TOP 100 TRIM(DatabaseName), TRIM(TableName), TableKind, CommentString FROM DBC.TablesV "
           "WHERE TableKind IN ('T','V','O') AND (UPPER(TableName) LIKE ? OR UPPER(CommentString) LIKE ?)" +
           (" AND UPPER(DatabaseName) = ?" if database else "") + " ORDER BY 1, 2")
    server, con = _cursor(server)
    cur = con.cursor()
    try:
        cur.execute(sql, [p, p] + ([database.strip().upper()] if database else []))
        rows = cur.fetchall()
    except Exception as e:  # noqa: BLE001
        raise TdError(f"Teradata: {_short(e)}") from e
    if not rows:
        return f"Ничего не найдено по «{pattern}» на {server}. Попробуйте другую часть имени или спросите витрину у Риторики."
    kinds = {"T": "таблица", "V": "представление", "O": "таблица"}
    return "\n".join([f"Найдено {len(rows)} (сервер {server}):"] +
                     [f"{r[0]}.{r[1]} · {kinds.get((r[2] or '').strip(), r[2])}" + (f" · {_fmt(r[3])}" if r[3] else "") for r in rows])


@mcp.tool(annotations=RO)
@_errors
def td_describe(table: str, server: str = "") -> str:
    """Колонки таблицы или представления: имя, тип, комментарий. table — «база.имя»."""
    if "." not in table:
        return "Укажите таблицу как «база.имя» (найти — td_find_tables)."
    db, name = [x.strip().strip('"').upper() for x in table.split(".", 1)]
    if not all(x and re.fullmatch(r"""[^"';]+""", x) for x in (db, name)):  # имя идёт в HELP COLUMN "db"."name"
        return "Имя таблицы — «база.имя» без кавычек и «;»."
    server, con = _cursor(server)
    cur = con.cursor()
    try:
        cur.execute("SELECT TRIM(ColumnName), ColumnType, ColumnLength, DecimalTotalDigits, DecimalFractionalDigits, "
                    "Nullable, CommentString FROM DBC.ColumnsV WHERE UPPER(DatabaseName) = ? AND UPPER(TableName) = ? "
                    "ORDER BY ColumnId", [db, name])
        rows = cur.fetchall()
    except Exception as e:  # noqa: BLE001
        if _code(e) in (3523, 3524, 3802, 3807):
            raise TdError(f"Нет доступа или объекта {db}.{name}: {_short(e)}. {ACCESS_HELP}") from e
        raise TdError(f"Teradata: {_short(e)}") from e
    types = {"CV": "VARCHAR", "CF": "CHAR", "I": "INTEGER", "I1": "BYTEINT", "I2": "SMALLINT", "I8": "BIGINT",
             "D": "DECIMAL", "F": "FLOAT", "DA": "DATE", "TS": "TIMESTAMP", "AT": "TIME", "N": "NUMBER"}
    note = ""
    if not rows or all(r[1] is None for r in rows):  # представление: типы — через HELP COLUMN (нужен доступ)
        try:
            cur.execute(f'HELP COLUMN "{db}"."{name}".*')
            cols = [d[0] for d in cur.description]
            keep = [i for i, c in enumerate(cols) if c in ("Column Name", "Type", "Max Length", "Decimal Total Digits",
                                                           "Decimal Fractional Digits", "Nullable", "Comment")]
            help_rows = cur.fetchall()
            return f"{db}.{name} ({server}), колонок {len(help_rows)}:\n" + \
                _table([cols[i] for i in keep], [[r[i] for i in keep] for r in help_rows])
        except Exception as e:  # noqa: BLE001
            if not rows:
                raise TdError(f"Нет доступа или объекта {db}.{name}: {_short(e)}. {ACCESS_HELP}") from e
            note = "\n(типы колонок представления видны только при доступе к нему — нужна роль; см. td_status)"
    out = []
    for name_, t, ln, dig, frac, nullable, comment in rows:
        t = (t or "").strip()
        ty = types.get(t, t) or "?"
        if t == "D":
            ty += f"({dig},{frac})"
        elif t in ("CV", "CF") and ln:
            ty += f"({ln})"
        out.append(f"{name_}\t{ty}{'' if nullable == 'Y' else ' NOT NULL'}" + (f"\t{_fmt(comment)}" if comment else ""))
    return f"{db}.{name} ({server}), колонок {len(rows)}:\n" + "\n".join(out) + note


@mcp.tool(annotations=RO)
@_errors
def td_status(server: str = "") -> str:
    """Вход в Teradata: пользователь, способ входа, роли (группы доступа) на сервере."""
    server, con = _cursor(server)
    cur = con.cursor()
    cur.execute("SELECT USER, SESSION, CURRENT_TIMESTAMP(0)")
    user, session, now = cur.fetchone()
    try:
        cur.execute("SELECT TRIM(RoleName) FROM DBC.RoleMembersV WHERE Grantee = USER ORDER BY 1")
        roles = [r[0] for r in cur.fetchall()]
    except Exception:  # noqa: BLE001
        roles = []
    method = {"krb5": "Kerberos (без пароля)", "ldap": "логин и пароль (LDAP)"}.get(_state().get(server), "—")
    roles_text = ", ".join(roles[:40]) + (f" и ещё {len(roles) - 40}" if len(roles) > 40 else "") if roles else \
        "нет ролей — данные, скорее всего, недоступны. " + ACCESS_HELP
    return f"Teradata {server} ({SERVERS[server]}): {user}, сеанс {session}, вход — {method}.\nРоли: {roles_text}"


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False))
@_errors
def td_login(server: str = "", login: str = "") -> str:
    """Войти в Teradata заново или под другой учётной записью: откроется окно входа, логин и пароль вводит
    пользователь (логин подставлен — последний или системный). Нужен, если пароль сменился, вход ещё не выполнялся
    или корпоративный логин отличается от учётной записи компьютера. login — подставить этот логин в окно."""
    server = (server or os.environ.get("TERADATA_SERVER") or "teradata").strip().lower()
    _drop(server)
    _keychain_delete(_user())
    st = _state()
    if login.strip():
        st[LOGIN_KEY] = login.strip()
    elif st.get(server) == "krb5":
        return f"Для {server} пароль не нужен — вход по Kerberos под учётной записью {_system_user()}."
    st.pop(server, None)
    STATE.parent.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    return td_status(server)


if __name__ == "__main__":
    mcp.run()
