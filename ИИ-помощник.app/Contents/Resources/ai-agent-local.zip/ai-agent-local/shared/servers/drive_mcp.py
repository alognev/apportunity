"""MCP «drive»: Magnit Drive (drive.magnit.ru, Nextcloud) — общая рабочая папка команды со спеками и файлами.

Вход — корпоративной учётной записью в браузере (Nextcloud Login Flow v2): помощник открывает страницу входа,
пользователь входит и нажимает «Разрешить доступ», Drive выдаёт помощнику отдельный пароль приложения.
Пароль от учётной записи помощник не видит; пароль приложения хранится в ~/.magnit-agent/drive-auth.json (права 600)
и отзывается в Drive → Настройки → Безопасность → «Устройства и сеансы» или инструментом drive_logout.

Рабочая папка — у каждого своя: drive_set_folder (пишется в ~/.magnit-agent/drive.json), DRIVE_DIR в .env
или по умолчанию /MCOS. Удаления и перемещения нет; перезапись — только явно (Drive хранит прежние версии).
Настройки (необязательно): DRIVE_URL, DRIVE_DIR, DRIVE_DOWNLOAD_DIR.
"""

from __future__ import annotations

import datetime as dt
import email.utils
import json
import logging
import os
import re
import sys
import threading
import time
import webbrowser
import xml.etree.ElementTree as ET
from difflib import SequenceMatcher
from pathlib import Path, PurePosixPath
from urllib.parse import parse_qs, quote, unquote, urlparse

import httpx
from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

mcp = MCPServer("drive")
logging.getLogger("httpx").setLevel(logging.WARNING)  # не писать каждый запрос в журнал агента
RO = ToolAnnotations(readOnlyHint=True)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False)

SERVER = (os.environ.get("DRIVE_URL") or "https://drive.magnit.ru").rstrip("/")
DEFAULT_DIR = "/MCOS"  # общая папка команды: https://drive.magnit.ru/apps/files/files/193068842?dir=/MCOS
STATE = Path.home() / ".magnit-agent"
AUTH = STATE / "drive-auth.json"      # пароль приложения — секрет
PENDING = STATE / "drive-login.json"  # незавершённый вход (токен опроса живёт 20 минут)
SETTINGS = STATE / "drive.json"       # личные настройки: рабочая папка
USER_AGENT = "magnit-local-agent/1.0 (AI assistant)"  # так помощник называется в «Устройствах и сеансах» Drive
LOGIN_WAIT = 150     # сколько ждать входа в браузере в drive_login, секунд
# Остальные инструменты ждут недолго: долгое ожидание внутри вызова выглядит в Goose как бесконечная «загрузка», а окно
# браузера часто открывается за окном Goose. Не успел войти — инструмент сразу просит войти и повторить.
QUICK_LOGIN_WAIT = 20
MAX_TEXT = 60_000
MAX_UPLOAD = 500 * 1024 * 1024
SEARCH_MIN_SCORE = 0.6  # меньше — уже не «похоже» (проверено на названиях вида «Анализ_рисков_остатков_Центр»)
TEXT_EXT = {".md", ".txt", ".csv", ".tsv", ".json", ".yaml", ".yml", ".sql", ".xml", ".html", ".py", ".ini", ".log"}
SPEC_EXT = {".md", ".txt", ".docx", ".doc", ".pdf"}
NS = {"d": "DAV:", "oc": "http://owncloud.org/ns", "nc": "http://nextcloud.org/ns"}
PROPS = ("<d:prop><d:getlastmodified/><d:getcontentlength/><d:resourcetype/><oc:size/><oc:fileid/>"
         "<oc:owner-display-name/><oc:permissions/></d:prop>")


class LoginNeeded(RuntimeError):
    pass


# ---------- вход ----------

def _read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _write_json(path: Path, data: dict) -> None:
    STATE.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)


def _start_login() -> dict:
    r = httpx.post(f"{SERVER}/index.php/login/v2", headers={"User-Agent": USER_AGENT}, timeout=30)
    r.raise_for_status()
    d = r.json()
    flow = {"token": d["poll"]["token"], "endpoint": d["poll"]["endpoint"], "login": d["login"], "started": time.time()}
    _write_json(PENDING, flow)
    webbrowser.open(flow["login"])  # браузер по умолчанию
    try:  # окно браузера могло открыться за окном Goose — подсказка уведомлением
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        import platform_util
        platform_util.notify("ИИ-помощник: вход в Magnit Drive",
                             "Войдите в открывшемся окне браузера и нажмите «Разрешить доступ»")
    except Exception:  # noqa: BLE001 — уведомление не обязательно
        pass
    return flow


def _poll(flow: dict, wait: int) -> dict | None:
    deadline = time.time() + wait
    while True:
        done = _read_json(AUTH)  # параллельный вызов уже завершил вход (токен опроса одноразовый)
        if done.get("password"):
            return done
        r = httpx.post(flow["endpoint"], data={"token": flow["token"]}, headers={"User-Agent": USER_AGENT}, timeout=30)
        if r.status_code == 200:
            d = r.json()
            auth = {"server": d["server"].rstrip("/"), "login": d["loginName"], "password": d["appPassword"]}
            auth.update(_whoami(auth))
            _write_json(AUTH, auth)
            PENDING.unlink(missing_ok=True)
            return auth
        if time.time() >= deadline:
            return None
        time.sleep(2)


def _whoami(auth: dict) -> dict:
    r = httpx.get(f"{auth['server']}/ocs/v2.php/cloud/user?format=json", auth=(auth["login"], auth["password"]),
                  headers={"OCS-APIRequest": "true", "User-Agent": USER_AGENT}, timeout=30)
    r.raise_for_status()
    d = r.json()["ocs"]["data"]
    return {"user": d["id"], "name": d.get("displayname") or d["id"]}


_login_lock = threading.Lock()  # параллельные вызовы drive_* не должны открывать вход дважды


PENDING_REUSE = 5 * 60  # обычные вызовы продолжают начатый вход столько секунд, потом открывают новый
FRESH_AFTER = 30        # drive_login начинает вход заново, если прежний открыт раньше (параллельные вызовы — не дважды)


def _login(wait: int = QUICK_LOGIN_WAIT, fresh: bool = False) -> dict:
    """Пароль приложения; если входа нет — открыть страницу входа в браузере и подождать, пока пользователь войдёт.
    fresh — начать вход заново: первая попытка в браузере могла сорваться (корпоративный вход, истёкшая сессия,
    закрытая вкладка), а сорвавшийся запрос входа сервер уже не завершит."""
    auth = _read_json(AUTH)
    if auth.get("password"):
        return auth
    with _login_lock:
        auth = _read_json(AUTH)  # другой вызов мог войти, пока ждали
        if auth.get("password"):
            return auth
        flow = _read_json(PENDING)
        age = time.time() - flow.get("started", 0)
        opened_now = False
        if not flow or age > (FRESH_AFTER if fresh else PENDING_REUSE):
            flow, opened_now = _start_login(), True
    auth = _poll(flow, wait)
    if auth:
        return auth
    raise LoginNeeded(
        ("Открыл в браузере страницу входа в Magnit Drive. " if opened_now else
         "Вход в Magnit Drive ещё не завершён. ") +
        "Попроси пользователя войти корпоративной учётной записью и нажать «Разрешить доступ» "
        f"(ссылка, если браузер не открылся: {flow['login']}), затем повтори действие. Если в браузере была ошибка "
        "или вкладку закрыли — вызови drive_login: откроется новое окно входа.")


def _client() -> tuple[httpx.Client, dict]:
    auth = _login()
    return httpx.Client(auth=(auth["login"], auth["password"]), timeout=120, follow_redirects=True,
                        headers={"User-Agent": USER_AGENT}), auth


def _dav(method: str, path: str, **kw) -> httpx.Response:
    """Запрос WebDAV к файлу или папке пользователя; при отозванном пароле — заново вход."""
    for attempt in (1, 2):
        client, auth = _client()
        with client:
            r = client.request(method, _url(auth, path), **kw)
        if r.status_code == 401 and attempt == 1:
            AUTH.unlink(missing_ok=True)  # пароль приложения отозван в Drive — войти заново
            continue
        return r
    return r


# ---------- пути ----------

def _folder() -> str:
    f = _read_json(SETTINGS).get("folder") or os.environ.get("DRIVE_DIR") or DEFAULT_DIR
    return "/" + f.strip("/")


class ShareLink(ValueError):
    """Публичная ссылка Drive (/s/<токен>): скачивается без входа, а не по пути в Drive пользователя."""


def _link_path(url: str) -> str:
    """Путь в Drive по ссылке из браузера: на файл (/f/<id>, /apps/files/files/<id>?openfile=true, ?fileid=<id>),
    на папку (?dir=...), WebDAV (/remote.php/dav/files/...). Публичная (/s/<токен>) — ShareLink."""
    u = urlparse(url)
    q = parse_qs(u.query)
    upath = unquote(u.path)
    m = re.search(r"/s/([A-Za-z0-9]+)", upath)
    if m:
        raise ShareLink(m.group(1))
    if "/remote.php/dav/files/" in upath:
        return "/" + upath.split("/remote.php/dav/files/", 1)[1].split("/", 1)[-1]
    file_id = (q.get("fileid") or q.get("fileId") or [""])[0]
    m = re.search(r"/f/(\d+)", upath) or re.search(r"/apps/files/files/(\d+)", upath)
    if not file_id and m and (m.re.pattern.startswith("/f/") or "openfile" in q or "dir" not in q):
        file_id = m.group(1)
    if file_id:
        found = _search(f"<d:eq><d:prop><oc:fileid/></d:prop><d:literal>{int(file_id)}</d:literal></d:eq>", "/", 1)
        if not found:
            raise FileNotFoundError(f"файл по ссылке (номер {file_id}) — нет доступа или файл удалён")
        return found[0]["path"]
    if "dir" in q:
        return q["dir"][0]
    raise ValueError("Не понял ссылку на Drive: нужна ссылка из адресной строки браузера на файл или папку.")


def _norm(path: str) -> str:
    """Путь от корня Drive. Относительный — от рабочей папки; можно передать ссылку из браузера (на файл или папку)."""
    path = (path or "").strip()
    if path.startswith("http"):
        path = _link_path(path)
    full = path if path.startswith("/") else f"{_folder()}/{path}"
    parts: list[str] = []
    for p in PurePosixPath(full).parts[1:]:
        if p == "..":
            parts = parts[:-1]
        elif p not in ("", "."):
            parts.append(p)
    return "/" + "/".join(parts)


def _url(auth: dict, path: str) -> str:
    return f"{auth['server']}/remote.php/dav/files/{quote(auth['user'])}{quote(path)}"


def _web(path: str, is_dir: bool) -> str:
    folder = path if is_dir else str(PurePosixPath(path).parent)
    return f"{SERVER}/apps/files/files?dir={quote(folder)}"


# ---------- WebDAV ----------

def _parse(xml: bytes, user: str) -> list[dict]:
    items = []
    prefix = f"/remote.php/dav/files/{user}"
    for resp in ET.fromstring(xml).findall("d:response", NS):
        href = unquote(resp.findtext("d:href", "", NS))
        prop = resp.find("d:propstat/d:prop", NS)
        if prop is None:
            continue
        path = href.split(prefix, 1)[-1].rstrip("/") or "/"
        is_dir = prop.find("d:resourcetype/d:collection", NS) is not None
        mod = prop.findtext("d:getlastmodified", "", NS)
        items.append({
            "path": path, "dir": is_dir,
            "size": int(prop.findtext("oc:size", "", NS) or prop.findtext("d:getcontentlength", "", NS) or 0),
            "modified": email.utils.parsedate_to_datetime(mod).astimezone() if mod else None,
            "owner": prop.findtext("oc:owner-display-name", "", NS),
            "perm": prop.findtext("oc:permissions", "", NS),
        })
    return items


def _propfind(path: str, depth: int = 1) -> list[dict]:
    body = f'<?xml version="1.0"?><d:propfind xmlns:d="DAV:" xmlns:oc="{NS["oc"]}">{PROPS}</d:propfind>'
    r = _dav("PROPFIND", path, content=body, headers={"Depth": str(depth), "Content-Type": "application/xml"})
    if r.status_code == 404:
        raise FileNotFoundError(path)
    r.raise_for_status()
    return _parse(r.content, _read_json(AUTH)["user"])


def _stat(path: str) -> dict | None:
    try:
        return _propfind(path, 0)[0]
    except FileNotFoundError:
        return None


def _search(where: str, scope: str = "/", limit: int = 500) -> list[dict]:
    """Поиск WebDAV (SEARCH) на сервере Drive — по всему дереву scope, включая общие папки; where — условие XML."""
    auth = _login()
    user = auth["user"]
    body = (f'<?xml version="1.0"?><d:searchrequest xmlns:d="DAV:" xmlns:oc="{NS["oc"]}" xmlns:nc="{NS["nc"]}">'
            f"<d:basicsearch><d:select>{PROPS}</d:select><d:from><d:scope>"
            f"<d:href>/files/{quote(user)}{quote(scope.rstrip('/'))}</d:href><d:depth>infinity</d:depth></d:scope></d:from>"
            f"<d:where>{where}</d:where><d:limit><d:nresults>{limit}</d:nresults></d:limit></d:basicsearch>"
            "</d:searchrequest>")
    client, auth = _client()
    with client:
        r = client.request("SEARCH", f"{auth['server']}/remote.php/dav/", content=body.encode("utf-8"),
                           headers={"Content-Type": "text/xml; charset=utf-8"})
    r.raise_for_status()
    return _parse(r.content, user)


def _plain(text: str) -> str:
    """Название для сравнения: строчные, ё → е, без расширения и знаков (подчёркивания, точки, скобки)."""
    text = text.lower().replace("ё", "е")
    return " ".join(re.sub(r"[\W_]+", " ", text).split())


_TRANSLIT = dict(zip("абвгдезийклмнопрстуфхцы", "abvgdeziiklmnoprstufhcy")) | {
    "ж": "zh", "ч": "ch", "ш": "sh", "щ": "sch", "ю": "yu", "я": "ya", "э": "e", "ъ": "", "ь": ""}


def _latin(text: str) -> str:
    """Латиницей — «оперком» ≈ «operkom», «демо» ≈ «demo» (файлы часто называют латиницей)."""
    return "".join(_TRANSLIT.get(ch, ch) for ch in _plain(text))


def _similarity(query: str, name: str) -> float:
    """Насколько имя похоже на запрос (0…1): совпадение подстрокой, по словам с учётом окончаний и опечаток,
    порядок слов не важен; русский запрос сравнивается и с латинским именем."""
    stem = PurePosixPath(name).stem
    if re.search("[а-яё]", query.lower()) and not re.search("[а-яё]", stem.lower()):
        return _similarity_plain(_latin(query), _latin(stem))
    return _similarity_plain(_plain(query), _plain(stem))


def _similarity_plain(q: str, n: str) -> float:
    if not q or not n:
        return 0.0
    if q in n:
        return 1.0
    words = n.split()

    def word_score(w: str) -> float:
        best = 0.0
        for x in words:
            if w in x or (len(w) >= 4 and x.startswith(w[:max(4, len(w) - 2)])):  # «отчет» ~ «отчета», «продаж» ~ «продажи»
                return 1.0
            best = max(best, SequenceMatcher(None, w, x).ratio())  # опечатки
        return best

    qwords = [w for w in q.split() if len(w) >= 3 or w.isdigit()] or q.split()  # «на», «по», «в» — не в счёт
    by_words = sum(word_score(w) for w in qwords) / len(qwords)
    return max(by_words, SequenceMatcher(None, q, n).ratio())


def _candidates(query: str, scope: str) -> list[dict]:
    """Файлы и папки, в имени которых есть начало хотя бы одного слова запроса (поиск на сервере); если сервер
    поиск не поддерживает — обход папок."""
    words = _plain(query).split()
    if re.search("[а-яё]", query.lower()):  # и латиницей: «оперком» найдёт «magnit-operkom.zip»
        words += _latin(query).split()
    stems = {w[:max(3, min(len(w) - 2, 6))] for w in words if len(w) >= 3} or {_plain(query)}
    if not any(stems):
        return []
    where = "".join(f"<d:like><d:prop><d:displayname/></d:prop><d:literal>%{s}%</d:literal></d:like>" for s in stems)
    where = f"<d:or>{where}</d:or>" if len(stems) > 1 else where
    try:
        return _search(where, scope)
    except httpx.HTTPStatusError:
        return _walk(scope)


def _walk(path: str, max_depth: int = 5, limit: int = 2000) -> list[dict]:
    """Все файлы и папки внутри (обход по уровням: Depth infinity на сервере обычно запрещён)."""
    found, queue = [], [(path, 0)]
    while queue and len(found) < limit:
        folder, level = queue.pop(0)
        for it in _propfind(folder, 1)[1:]:
            found.append(it)
            if it["dir"] and level + 1 < max_depth:
                queue.append((it["path"], level + 1))
    return found


def _missing(path: str) -> str:
    if path == _folder():
        return (f"Папка {path} не найдена в вашем Drive. Попросите владельца поделиться ею с вами или выберите "
                "свою рабочую папку — drive_set_folder (путь или ссылка из браузера).")
    return f"Не найдено: {path}. Посмотрите содержимое папки — drive_list."


def _size(n: int) -> str:
    for unit in ("Б", "КБ", "МБ", "ГБ"):
        if n < 1024 or unit == "ГБ":
            return f"{n:.0f} {unit}" if unit == "Б" else f"{n:.1f} {unit}"
        n /= 1024
    return ""


def _line(it: dict, base: str = "") -> str:
    name = it["path"][len(base):].lstrip("/") if base and it["path"].startswith(base) else it["path"]
    when = f"{it['modified']:%d.%m.%Y %H:%M}" if it["modified"] else ""
    if it["dir"]:
        return f"📁 {name}/  · {when}"
    owner = f" · {it['owner']}" if it["owner"] else ""
    return f"   {name}  · {_size(it['size'])} · {when}{owner}"


def _rel(path: str) -> str:
    base = _folder()
    return path[len(base) + 1:] if path.startswith(base + "/") else path


def _guard_errors(fn):
    """Понятные сообщения вместо трассировок: вход, нет папки, нет прав, нет сети."""
    import functools

    @functools.wraps(fn)
    def wrapper(*a, **kw):
        try:
            return fn(*a, **kw)
        except LoginNeeded as e:
            return f"Нужен вход в Magnit Drive. {e}"
        except ShareLink:
            return "Это публичная ссылка на файл Drive — скачать или прочитать: drive_download или drive_read с этой ссылкой."
        except PermissionError as e:
            return f"Drive: {e}."
        except ValueError as e:  # ссылка не на Drive или непонятного вида
            return str(e)
        except FileNotFoundError as e:
            return _missing(str(e))
        except httpx.HTTPStatusError as e:
            code = e.response.status_code
            if code == 403:
                return "Drive: нет прав на это действие в этой папке (403). Попросите владельца папки дать доступ."
            if code == 507:
                return "Drive: закончилось место (507)."
            return f"Drive ответил ошибкой {code}."
        except httpx.TransportError as e:
            return f"Нет связи с {SERVER} ({e.__class__.__name__}). Проверьте VPN (FortiClient или NetBird) и интернет."
    return wrapper


# ---------- инструменты ----------

@mcp.tool(annotations=RO)
@_guard_errors
def drive_status() -> str:
    """Вход в Magnit Drive, рабочая папка и свободное место. Браузер не открывает."""
    auth = _read_json(AUTH)
    folder = _folder()
    if not auth.get("password"):
        return (f"Вход в Magnit Drive не выполнен. Рабочая папка: {folder}. Войти — drive_login "
                "(откроется браузер, нужна корпоративная учётная запись).")
    r = httpx.get(f"{auth['server']}/ocs/v2.php/cloud/user?format=json", auth=(auth["login"], auth["password"]),
                  headers={"OCS-APIRequest": "true", "User-Agent": USER_AGENT}, timeout=30)
    if r.status_code == 401:
        AUTH.unlink(missing_ok=True)
        return "Доступ помощника к Drive отозван. Войти заново — drive_login."
    r.raise_for_status()
    q = r.json()["ocs"]["data"].get("quota") or {}
    free = f", свободно {_size(q['free'])}" if isinstance(q.get("free"), int) and q["free"] >= 0 else ""
    ok = _stat(folder)
    return (f"Вход выполнен: {auth['name']} ({auth['user']}){free}.\n"
            f"Рабочая папка: {folder} — " + ("доступна" if ok else "не найдена, выберите другую: drive_set_folder") +
            f"\n{_web(folder, True)}")


@mcp.tool(annotations=RO)
@_guard_errors
def drive_login() -> str:
    """Войти в Magnit Drive: откроет новую страницу входа в браузере и подождёт, пока пользователь войдёт корпоративной
    учётной записью и нажмёт «Разрешить доступ». Другие инструменты drive_* запускают вход сами, если его нет;
    drive_login — если прежняя попытка в браузере не удалась."""
    auth = _login(LOGIN_WAIT, fresh=True)
    return f"Вход в Magnit Drive выполнен: {auth['name']} ({auth['user']}). Рабочая папка: {_folder()}."


@mcp.tool(annotations=WRITE)
def drive_logout() -> str:
    """Выйти из Magnit Drive: отозвать доступ помощника на сервере и удалить его с компьютера."""
    auth = _read_json(AUTH)
    if not auth.get("password"):
        return "Вход в Drive не выполнен — выходить не из чего."
    try:
        httpx.delete(f"{auth['server']}/ocs/v2.php/core/apppassword", auth=(auth["login"], auth["password"]),
                     headers={"OCS-APIRequest": "true", "User-Agent": USER_AGENT}, timeout=30)
    except httpx.HTTPError:
        pass
    AUTH.unlink(missing_ok=True)
    return "Вышел из Magnit Drive: доступ помощника отозван."


@mcp.tool(annotations=WRITE)
@_guard_errors
def drive_set_folder(folder: str) -> str:
    """Сменить рабочую папку в Drive (своя у каждого пользователя). folder — путь от корня Drive («/MCOS/Отчёты»)
    или ссылка на папку из адресной строки браузера. «default» — вернуть общую папку команды /MCOS."""
    if folder.strip().lower() in ("default", "по умолчанию", ""):
        settings = _read_json(SETTINGS)
        settings.pop("folder", None)
        _write_json(SETTINGS, settings)
        return f"Рабочая папка: {_folder()} (по умолчанию)."
    path = _norm(folder if folder.startswith(("/", "http")) else "/" + folder)
    it = _stat(path)
    if not it:
        raise FileNotFoundError(path)
    if not it["dir"]:
        return f"{path} — это файл, а нужна папка."
    _write_json(SETTINGS, {**_read_json(SETTINGS), "folder": path})
    return f"Рабочая папка: {path}\n{_web(path, True)}"


@mcp.tool(annotations=RO)
@_guard_errors
def drive_list(path: str = "", recursive: bool = False) -> str:
    """Содержимое папки в Drive. path — относительно рабочей папки (пусто — сама рабочая папка) или от корня Drive,
    если начинается с «/»; можно ссылку из браузера. recursive — со всеми вложенными папками."""
    folder = _norm(path)
    items = _walk(folder) if recursive else _propfind(folder, 1)[1:]
    if not items:
        return f"{folder}: пусто."
    items.sort(key=lambda i: (not i["dir"], i["path"].lower()) if not recursive else i["path"].lower())
    head = f"{folder} ({len(items)}):"
    lines = [_line(i, folder) for i in items[:400]]
    tail = [f"… и ещё {len(items) - 400}"] if len(items) > 400 else []
    return "\n".join([head, *lines, *tail])


@mcp.tool(annotations=RO)
@_guard_errors
def drive_search(query: str, path: str = "") -> str:
    """Найти файлы и папки по примерному названию: можно не точно — с опечатками, в другой форме слов («отчет
    продажи» найдёт «Отчёт_по_продажам»), в другом порядке. Ищет в рабочей папке со всеми вложенными (или в path);
    если там нет — во всём Drive пользователя. Самые похожие — первыми."""
    folder = _norm(path)
    scopes = [folder] + (["/"] if folder != "/" else [])
    for scope in scopes:
        scored = sorted(((_similarity(query, i["path"]), i) for i in _candidates(query, scope)),
                        key=lambda x: (-x[0], x[1]["dir"], x[1]["path"]))
        good = [(s, i) for s, i in scored if s >= SEARCH_MIN_SCORE]
        if good:
            where = "в рабочей папке" if scope == folder else "во всём Drive (в рабочей папке не нашлось)"
            lines = [f"Найдено {where} {scope}: {len(good)}" + (" (показаны 30 самых похожих)" if len(good) > 30 else "")]
            lines += [_line(i, scope) + ("" if s >= 0.999 else f" · похоже на {s:.0%}") for s, i in good[:30]]
            return "\n".join(lines)
    return (f"Ничего похожего на «{query}» не нашлось ни в {folder}, ни во всём Drive. Уточните название "
            "или посмотрите папки — drive_list.")


def _spec_title(path: str) -> str:
    """Заголовок и первая строка описания спеки (.md, .txt) — по первым 4 КБ файла."""
    r = _dav("GET", path, headers={"Range": "bytes=0-4095"})
    if r.status_code not in (200, 206):
        return ""
    text = r.content[:4096].decode("utf-8", errors="ignore")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    title = next((ln.lstrip("#").strip() for ln in lines if ln.startswith("#")), lines[0] if lines else "")
    about = next((ln for ln in lines if not ln.startswith(("#", "|", "---")) and ln.lstrip("#").strip() != title), "")
    return f"{title} — {about[:160]}" if about else title


@mcp.tool(annotations=RO)
@_guard_errors
def drive_specs(query: str = "") -> str:
    """Спеки в рабочей папке Drive — описания, как помощнику решать рутинные задачи (отчёты, обработка выгрузок,
    данные из баз). Показывает файл, заголовок и автора. query — слова для отбора по имени и заголовку."""
    folder = _folder()
    files = [i for i in _walk(folder) if not i["dir"] and PurePosixPath(i["path"]).suffix.lower() in SPEC_EXT]
    words = [w.lower() for w in query.split() if w]
    rows = []
    for it in sorted(files, key=lambda i: i["modified"] or dt.datetime.min.replace(tzinfo=dt.timezone.utc), reverse=True):
        title = _spec_title(it["path"]) if PurePosixPath(it["path"]).suffix.lower() in (".md", ".txt") \
            and len(rows) < 60 else ""
        hay = (it["path"] + " " + title).lower()
        if words and not all(w in hay for w in words):
            continue
        when = f"{it['modified']:%d.%m.%Y}" if it["modified"] else ""
        rows.append(f"• {_rel(it['path'])}" + (f"\n    {title}" if title else "") +
                    f"\n    {it['owner'] or '—'}, {when}")
    if not rows:
        return (f"В {folder} нет спек" + (f" по «{query}»" if query else "") +
                ". Спека — файл .md/.txt/.docx с описанием: входные данные → обработка → результат.")
    return "\n".join([f"Спеки в {folder} ({len(rows)}):", *rows,
                      "Прочитать — drive_read, затем выполнить по шагам спеки."])


def _local_target(path: str, to: str) -> Path:
    if to:
        dest = Path(to).expanduser()
        return dest / PurePosixPath(path).name if dest.is_dir() or to.endswith("/") else dest
    base = Path(os.environ.get("DRIVE_DOWNLOAD_DIR") or
                Path(os.environ.get("AGENT_WORKSPACE") or "~/magnit-agent-workspace").expanduser() / "Drive")
    return base / path.lstrip("/")


def _download_share(token: str, to: str = "") -> Path:
    """Файл по публичной ссылке Drive (/s/<токен>) — без входа; ссылка с паролем или на папку — понятная ошибка."""
    with httpx.Client(timeout=120, follow_redirects=True, headers={"User-Agent": USER_AGENT}) as client:
        with client.stream("GET", f"{SERVER}/s/{token}/download") as r:
            if r.status_code in (401, 403) or "text/html" in r.headers.get("content-type", ""):
                raise PermissionError("публичная ссылка защищена паролем или ведёт на папку — откройте её в браузере, "
                                      "сохраните файл в свой Drive и укажите путь")
            if r.status_code == 404:
                raise FileNotFoundError(f"публичная ссылка /s/{token} (удалена или истекла)")
            r.raise_for_status()
            m = re.search(r"filename\*=UTF-8''([^;]+)|filename=\"?([^\";]+)", r.headers.get("content-disposition", ""))
            name = unquote(m.group(1) or m.group(2)) if m else f"drive-{token}"
            name = Path(name).name or f"drive-{token}"  # без папок из заголовка
            dest = _local_target("/Публичные ссылки/" + name, to)
            dest.parent.mkdir(parents=True, exist_ok=True)
            tmp = dest.with_name(dest.name + ".part")
            with tmp.open("wb") as f:
                for chunk in r.iter_bytes():
                    f.write(chunk)
            tmp.replace(dest)
    return dest


def _download(path: str, to: str = "") -> Path:
    dest = _local_target(path, to)
    dest.parent.mkdir(parents=True, exist_ok=True)
    client, auth = _client()
    with client, client.stream("GET", _url(auth, path)) as r:
        if r.status_code == 404:
            raise FileNotFoundError(path)
        r.raise_for_status()
        tmp = dest.with_name(dest.name + ".part")
        with tmp.open("wb") as f:
            for chunk in r.iter_bytes():
                f.write(chunk)
        tmp.replace(dest)
    return dest


@mcp.tool(annotations=RO)
@_guard_errors
def drive_read(path: str, max_chars: int = 30000) -> str:
    """Прочитать файл из Drive. Текст (.md, .txt, .csv, .json, .sql…) — вернёт содержимое; Excel, Word, PDF, картинки —
    скачает на компьютер и вернёт путь, дальше читай их инструментами для файлов (read_document).
    path — путь в Drive или ссылка из браузера на файл или папку (в том числе публичная /s/...)."""
    try:
        full = _norm(path)
    except ShareLink as e:
        local = _download_share(str(e))
        if local.suffix.lower() in TEXT_EXT and local.stat().st_size <= 5 * 1024 * 1024:
            raw = local.read_bytes()
            try:
                text = raw.decode("utf-8-sig")
            except UnicodeDecodeError:
                text = raw.decode("cp1251", errors="replace")
            return f"{local.name} (публичная ссылка)\n\n{text[:max(1000, min(max_chars, MAX_TEXT))]}"
        return f"Скачано по публичной ссылке: {local}\nПрочитай файл инструментом для файлов по этому пути."
    it = _stat(full)
    if not it:
        raise FileNotFoundError(full)
    if it["dir"]:
        return drive_list(path)
    if PurePosixPath(full).suffix.lower() in TEXT_EXT and it["size"] <= 5 * 1024 * 1024:
        r = _dav("GET", full)
        r.raise_for_status()
        raw = r.content
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = raw.decode("cp1251", errors="replace")
        limit = max(1000, min(max_chars, MAX_TEXT))
        cut = f"\n… (обрезано, всего {len(text)} символов)" if len(text) > limit else ""
        return f"{full} · {it['owner'] or '—'} · {it['modified']:%d.%m.%Y %H:%M}\n\n{text[:limit]}{cut}"
    local = _download(full)
    return f"Скачано: {local}\nЭто не текстовый файл — прочитай его инструментом для файлов по этому пути."


@mcp.tool(annotations=RO)
@_guard_errors
def drive_download(path: str, to: str = "") -> str:
    """Скачать файл из Drive на компьютер и вернуть путь. По умолчанию — в ~/magnit-agent-workspace/Drive
    с той же структурой папок; to — своя папка или имя файла. path — путь в Drive или ссылка из браузера на файл
    или папку (в том числе публичная /s/...). Не запускай скачанные файлы."""
    try:
        full = _norm(path)
    except ShareLink as e:
        return f"Скачано по публичной ссылке: {_download_share(str(e), to)}"
    it = _stat(full)
    if not it:
        raise FileNotFoundError(full)
    if it["dir"]:
        files = [i for i in _walk(full) if not i["dir"]]
        if len(files) > 100 or sum(i["size"] for i in files) > 1024 ** 3:
            return f"В папке {len(files)} файлов — слишком много для скачивания целиком; выберите нужные файлы."
        target = Path(to).expanduser() / PurePosixPath(full).name if to else None
        saved = [_download(i["path"], str(target / i["path"][len(full) + 1:]) if target else "") for i in files]
        return f"Скачано файлов: {len(saved)} → {saved[0].parent if saved else '—'}"
    return f"Скачано: {_download(full, to)}"


def _target(path: str, name: str) -> str:
    """Путь для записи: в папку (path заканчивается «/» или это существующая папка) — с именем name."""
    full = _norm(path)
    if path.endswith("/") or path.strip() == "":
        return f"{full.rstrip('/')}/{name}"
    it = _stat(full)
    return f"{full}/{name}" if it and it["dir"] else full


def _put(full: str, content, overwrite: bool) -> str:
    existing = _stat(full)
    if existing and existing["dir"]:
        return f"{full} — это папка. Укажите имя файла."
    if existing and not overwrite:
        return (f"Файл {full} уже есть (изменён {existing['modified']:%d.%m.%Y %H:%M}, {existing['owner'] or '—'}). "
                "Спроси пользователя, заменить ли его (overwrite=true — Drive сохранит прежнюю версию), "
                "или выбери другое имя.")
    parent = str(PurePosixPath(full).parent)
    if not _stat(parent):
        return f"Папки {parent} нет. Создай её (drive_mkdir), если пользователь согласен, или выбери другую."
    r = _dav("PUT", full, content=content)
    r.raise_for_status()
    action = "Заменён" if existing else "Сохранён"
    return f"{action}: {full}\n{_web(full, False)}"


@mcp.tool(annotations=WRITE)
@_guard_errors
def drive_upload(local_path: str, path: str = "", overwrite: bool = False) -> str:
    """Загрузить файл с компьютера в Drive. path — папка или полный путь файла (относительно рабочей папки
    или от корня с «/»); пусто — в рабочую папку. Существующий файл заменяется только при overwrite=true."""
    src = Path(local_path).expanduser()
    if not src.is_file():
        return f"Файл не найден на компьютере: {src}"
    if src.stat().st_size > MAX_UPLOAD:
        return f"Файл больше {MAX_UPLOAD // 1024 ** 2} МБ — загрузите его через браузер."
    with src.open("rb") as f:
        return _put(_target(path, src.name), f.read(), overwrite)


@mcp.tool(annotations=WRITE)
@_guard_errors
def drive_save_text(path: str, text: str, overwrite: bool = False) -> str:
    """Сохранить текст в файл Drive — например, новую спеку (.md) или заметку. path — путь файла относительно
    рабочей папки или от корня с «/». Существующий файл заменяется только при overwrite=true."""
    full = _norm(path)
    if not PurePosixPath(full).suffix:
        full += ".md"
    return _put(full, text.encode("utf-8"), overwrite)


@mcp.tool(annotations=WRITE)
@_guard_errors
def drive_mkdir(path: str) -> str:
    """Создать папку в Drive (с промежуточными). path — относительно рабочей папки или от корня с «/»."""
    full = _norm(path)
    made = []
    current = ""
    for part in PurePosixPath(full).parts[1:]:
        current += "/" + part
        it = _stat(current)
        if it and not it["dir"]:
            return f"{current} — это файл, папку здесь создать нельзя."
        if not it:
            r = _dav("MKCOL", current)
            r.raise_for_status()
            made.append(current)
    return f"Создана папка: {full}\n{_web(full, True)}" if made else f"Папка уже есть: {full}"


if __name__ == "__main__":
    mcp.run()
