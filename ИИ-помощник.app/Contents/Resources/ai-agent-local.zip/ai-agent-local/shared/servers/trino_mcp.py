"""MCP для поиска таблиц и чтения данных через Trino."""

from __future__ import annotations

import csv
import functools
import json
import logging
import os
import re
import shutil
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from uuid import uuid4

import httpx
from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import corp_services
import platform_util
from mcp_registry import USER_AGENT
from servers.teradata_mcp import _strip

mcp = MCPServer("trino")
RO = ToolAnnotations(readOnlyHint=True)
LOCAL_WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False, openWorldHint=False)
CANCEL = ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=True)
MAX_PAGE = 8 * 1024 * 1024
MAX_EXPORT = 64 * 1024 * 1024
MAX_PREVIEW = 40_000
QUERY_ID = re.compile(r"[A-Za-z0-9_-]{1,120}")
READ = {"SELECT", "WITH", "SHOW", "DESCRIBE", "DESC", "EXPLAIN", "VALUES"}
FORBIDDEN = re.compile(
    r"\b(?:INSERT|UPDATE|DELETE|MERGE|CREATE|DROP|ALTER|TRUNCATE|GRANT|REVOKE|DENY|"
    r"CALL|EXECUTE|PREPARE|DEALLOCATE|ANALYZE|REFRESH|COMMENT|ROLLBACK|COMMIT|RESET|"
    r"FUNCTION|SESSION)\b|\bTABLE\s*\(",
    re.I,
)
POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix="trino")
LOCK = threading.Lock()
JOBS: dict[str, Job] = {}


class TrinoError(ValueError):
    """Ошибка, текст которой можно показать пользователю."""


@dataclass
class Job:
    handle: str = field(default_factory=lambda: uuid4().hex)
    cancel: threading.Event = field(default_factory=threading.Event)
    state: str = "ожидает"
    query_id: str = ""
    count: int = 0
    done: bool = False
    report: str = ""


def _checked_sql(sql: str) -> str:
    sql = sql.strip()
    if len(sql) > 64_000 or re.search(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", sql):
        raise TrinoError("Слишком длинный запрос или недопустимые управляющие символы.")
    if sql.endswith(";"):
        sql = sql[:-1]
    tokens = _strip(sql)
    first = re.match(r"\s*([a-z]+)\b", tokens, re.I)
    if not first or first[1].upper() not in READ or ";" in tokens or FORBIDDEN.search(tokens):
        raise TrinoError("Разрешён один запрос чтения: SELECT, WITH, SHOW, DESCRIBE, EXPLAIN или VALUES.")
    return sql


def _identifier(value: str) -> str:
    if not value.strip() or len(value) > 255 or re.search(r"[\x00-\x1f\x7f]", value):
        raise TrinoError("Некорректное имя каталога, схемы или таблицы.")
    return '"' + value.replace('"', '""') + '"'


def _literal(value: str) -> str:
    if len(value) > 256 or re.search(r"[\x00-\x1f\x7f]", value):
        raise TrinoError("Недопустимый фильтр по имени таблицы.")
    return "'" + value.replace("'", "''") + "'"


def _next_uri(base: str, uri: object) -> str:
    if not isinstance(uri, str):
        raise TrinoError("Trino вернул некорректный адрес страницы.")
    home, target = httpx.URL(base), httpx.URL(uri)
    if (
        (target.scheme, target.host, target.port) != (home.scheme, home.host, home.port)
        or target.userinfo or target.fragment
        or not target.path.startswith(home.path.rstrip("/") + "/v1/statement/")
        or any(p in (".", "..") for p in target.path.split("/"))
    ):
        raise TrinoError("Trino вернул адрес страницы за пределами настроенного API.")
    return str(target)


def _response(client: httpx.Client, method: str, url: str, *, deadline: float, **kwargs) -> dict:
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TrinoError("Превышено время ожидания. Сузьте выборку или агрегируйте данные.")
    with client.stream(method, url, timeout=min(20, remaining), **kwargs) as response:
        if response.status_code in (401, 403):
            raise TrinoError("Trino отказал в доступе. Проверьте настройки подключения и права на данные.")
        if response.status_code >= 300:
            raise TrinoError(f"Trino вернул HTTP {response.status_code}. Проверьте состояние сервиса.")
        body = bytearray()
        for chunk in response.iter_bytes():
            if time.monotonic() >= deadline:
                raise TrinoError("Превышено время ожидания. Сузьте выборку или агрегируйте данные.")
            body.extend(chunk)
            if len(body) > MAX_PAGE:
                raise TrinoError("Страница результата превышает 8 МБ. Сузьте выборку или сократите объём колонок.")
    try:
        data = json.loads(body)
    except (ValueError, UnicodeError) as exc:
        raise TrinoError("Trino вернул ответ, который не удалось разобрать.") from exc
    if not isinstance(data, dict):
        raise TrinoError("Некорректный ответ Trino.")
    return data


def _sql_error(page: dict) -> None:
    if "error" not in page:
        return
    obj = page["error"]
    name = obj.get("errorName", "") if isinstance(obj, dict) else ""
    loc = obj.get("errorLocation", {}) if isinstance(obj, dict) else {}
    if not isinstance(name, str) or not re.fullmatch("[A-Z0-9_]{1,80}", name):
        name = "ошибка запроса"
    point = ""
    if isinstance(loc, dict) and isinstance(loc.get("lineNumber"), int) and isinstance(loc.get("columnNumber"), int):
        point = f", строка {loc['lineNumber']}, позиция {loc['columnNumber']}"
    raise TrinoError(f"Trino отклонил запрос ({name}{point}). Проверьте SQL, имена таблиц и доступ.")


def _stop(client: httpx.Client, cursor: str) -> bool:
    if not cursor:
        return False
    try:
        with client.stream("DELETE", cursor, timeout=5) as response:
            return response.is_success
    except httpx.HTTPError:
        return False


def _headers() -> dict:
    headers = corp_services.auth_headers("trino")
    auth_type = corp_services.service_setting("trino", "AUTH", "basic").lower()
    configured_user = corp_services.service_setting("trino", "USER", "").strip()
    user = configured_user or (corp_services.credentials("trino").split(":", 1)[0] if auth_type == "basic" else "")
    if not user or not user.isascii() or re.search(r"[\x00-\x20\x7f]", user):
        raise TrinoError("Для Trino укажите корпоративный логин (TRINO_USER при входе по Bearer-токену).")
    return {**headers, "X-Trino-User": user, "X-Trino-Source": "magnit-agent", "User-Agent": USER_AGENT}


def _workspace() -> Path:
    return Path(os.environ.get("AGENT_WORKSPACE") or "~/magnit-agent-workspace").expanduser().resolve()


def _export_path(save_to: str) -> Path:
    workspace = _workspace()
    given = Path(save_to).expanduser()
    path = (workspace / given).resolve()
    parts = path.relative_to(workspace).parts if path.is_relative_to(workspace) else ()
    if (not parts or path.suffix.lower() not in {".csv", ".xlsx"}
            or any(p.startswith(".") or ":" in p for p in parts) or path.exists()):
        raise TrinoError("Укажите новый файл .csv или .xlsx внутри рабочей папки помощника.")
    return path


def _value(value):
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return value


def _csv_value(value):
    value = _value(value)
    if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


class Export:
    """Потоковая запись с публикацией результата только после успешной выборки."""

    def __init__(self, target: Path):
        self.target = target
        target.parent.mkdir(parents=True, exist_ok=True)
        self.temp = target.with_name(f".trino-{uuid4().hex}{target.suffix}")
        self.file = None
        self.book = None

    def __enter__(self):
        if self.target.suffix.lower() == ".csv":
            self.file = self.temp.open("x", encoding="utf-8-sig", newline="")
            self.writer = csv.writer(self.file, delimiter=";")
        else:
            from openpyxl import Workbook

            self.book = Workbook(write_only=True)
            self.sheet = self.book.create_sheet("Trino")
        return self

    def row(self, values: list) -> None:
        if self.file is not None:
            self.writer.writerow([_csv_value(value) for value in values])
            return
        from openpyxl.cell import WriteOnlyCell
        from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

        cells = []
        for value in map(_value, values):
            if isinstance(value, str):
                value = ILLEGAL_CHARACTERS_RE.sub("", value)
            cell = WriteOnlyCell(self.sheet, value=value)
            if isinstance(value, str):
                cell.data_type = "s"
            cells.append(cell)
        self.sheet.append(cells)

    def finish(self) -> None:
        if self.file is not None:
            self.file.close()
        else:
            self.book.save(self.temp)
        # Запрещаем перезапись, даже если файл появился параллельно.
        with self.temp.open("rb") as src, self.target.open("xb") as dst:
            try:
                shutil.copyfileobj(src, dst)
            except OSError:
                dst.close()
                self.target.unlink(missing_ok=True)
                raise

    def __exit__(self, *_):
        if self.file is not None:
            self.file.close()
        elif self.book is not None:
            try:
                # Openpyxl освобождает временный файл листа при сохранении книги.
                if not self.sheet.closed:
                    self.book.save(self.temp)
            finally:
                self.book.close()
                self.temp.unlink(missing_ok=True)
            return
        self.temp.unlink(missing_ok=True)


@contextmanager
def _maybe_export(path: Path | None):
    if path is None:
        yield None
    else:
        with Export(path) as export:
            yield export


def _summary(job: Job, names: list[str], rows: list[str], cut: bool, path: Path | None) -> str:
    out = [f"Trino {job.query_id}: {job.count} строк."]
    if path:
        out.append(f"Файл: {path}")
    if cut:
        out.append("Достигнут лимит строк или размера. Выгружена только часть результата.")
    if names:
        out.extend(["\t".join(name[:300] for name in names)[:MAX_PREVIEW], *rows])
    if job.count > len(rows):
        out.append(f"В сообщении показаны первые {len(rows)} строк.")
    return "\n".join(out)


def _collect(job: Job, sql: str, limit: int, path: Path | None, timeout: int) -> str:
    base = corp_services.service_url("trino")
    headers = _headers()
    names: list[str] = []
    preview: list[str] = []
    preview_size = 0
    total_bytes = 0
    cut = False
    remaining_uri = ""
    end = time.monotonic() + timeout
    with (httpx.Client(verify=platform_util.corp_ssl_context(), headers=headers,
                       timeout=20, follow_redirects=False) as client, _maybe_export(path) as export):
        try:
            if job.cancel.is_set():
                return "Запрос отменён до отправки в Trino."
            job.state = "выполняется"
            page = _response(client, "POST", base + "/v1/statement", content=sql.encode("utf-8"),
                             headers={"Content-Type": "text/plain; charset=utf-8"}, deadline=end)
            while True:
                qid = page.get("id")
                if not isinstance(qid, str) or not QUERY_ID.fullmatch(qid) or (job.query_id and qid != job.query_id):
                    raise TrinoError("Trino вернул некорректный идентификатор запроса.")
                job.query_id = qid
                _sql_error(page)
                next_uri = page.get("nextUri")
                remaining_uri = _next_uri(base, next_uri) if next_uri is not None else ""
                columns = page.get("columns") if not names else None
                if columns is not None:
                    if not isinstance(columns, list) or any(
                        not isinstance(column, dict) or not isinstance(column.get("name"), str) for column in columns
                    ):
                        raise TrinoError("Trino вернул некорректный список колонок.")
                    names = [column["name"] for column in columns]
                    if export:
                        export.row(names)
                batch = page.get("data", [])
                if not isinstance(batch, list):
                    raise TrinoError("Trino вернул некорректные строки результата.")
                for row in batch:
                    if not isinstance(row, list) or not names or len(row) != len(names):
                        raise TrinoError("Строка результата не соответствует списку колонок.")
                    size = len(json.dumps(row, ensure_ascii=False).encode("utf-8"))
                    if job.count >= limit or total_bytes + size > MAX_EXPORT:
                        cut = True
                        break
                    job.count += 1
                    total_bytes += size
                    if export:
                        export.row(row)
                    if preview_size < MAX_PREVIEW and len(preview) < (10 if export else 200):
                        line = "\t".join(str(_value(value) if value is not None else "")[:300].replace("\n", " ")
                                         .replace("\r", " ").replace("\t", " ") for value in row)
                        if preview_size + len(line) <= MAX_PREVIEW:
                            preview_size += len(line) + 1
                            preview.append(line)
                if job.cancel.is_set():
                    stopped = _stop(client, remaining_uri)
                    remaining_uri = ""
                    return ("Запрос остановлен." if stopped else
                            "Сбор результата остановлен. Отмена запроса на сервере не подтверждена.")
                if cut or not remaining_uri:
                    break
                page = _response(client, "GET", remaining_uri, deadline=end)
            if export and names:
                export.finish()
            return _summary(job, names, preview, cut, path if export and names else None)
        finally:
            if remaining_uri:
                _stop(client, remaining_uri)


def _errors(fn):
    @functools.wraps(fn)
    def call(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except (TrinoError, corp_services.ServiceError) as exc:
            return f"Trino: {exc}"
        except (OSError, httpx.HTTPError, ValueError) as exc:
            return f"Trino: ошибка связи или обработки ({type(exc).__name__}). Проверьте VPN и настройки."

    return call


def _new_job() -> Job:
    with LOCK:
        if sum(not job.done for job in JOBS.values()) >= 2:
            raise TrinoError("Уже выполняются два запроса помощника. Дождитесь результата или отмените запрос.")
        if len(JOBS) >= 20:
            old = next(key for key, job in JOBS.items() if job.done)
            del JOBS[old]
        job = Job()
        JOBS[job.handle] = job
        return job


def _run(job: Job, sql: str, limit: int, path: Path | None, timeout: int) -> str:
    try:
        job.report = _errors(_collect)(job, sql, limit, path, timeout)
    finally:
        job.done = True
    return job.report


def _options(sql: str, max_rows: int, save_to: str, timeout_seconds: int):
    path = _export_path(save_to) if save_to else None
    return (_checked_sql(sql), max(1, min(max_rows, 100_000 if path else 10_000)),
            path, max(10, min(timeout_seconds, 240)))


def _job(handle: str) -> Job:
    with LOCK:
        job = JOBS.get(handle)
    if job is None:
        raise TrinoError("Запрос не найден среди запросов этой сессии помощника.")
    return job


@mcp.tool(annotations=LOCAL_WRITE)
@_errors
def trino_query(sql: str, max_rows: int = 200, save_to: str = "", timeout_seconds: int = 120) -> str:
    """Выполнить один SQL-запрос только на чтение. save_to — новый .csv/.xlsx в рабочей папке.
    В чат попадает краткий результат; при экспорте укажите max_rows до 100 000. Лимит данных 64 МБ."""
    opts = _options(sql, max_rows, save_to, timeout_seconds)
    return _run(_new_job(), *opts)


@mcp.tool(annotations=LOCAL_WRITE)
@_errors
def trino_start(sql: str, max_rows: int = 200, save_to: str = "", timeout_seconds: int = 180) -> str:
    """Запустить длительное чтение в фоне. Вернёт handle для trino_status и trino_cancel в этом чате."""
    opts = _options(sql, max_rows, save_to, timeout_seconds)
    job = _new_job()
    POOL.submit(_run, job, *opts)
    return f"Запрос принят: handle={job.handle}. Проверьте trino_status."


@mcp.tool(annotations=RO)
@_errors
def trino_status(handle: str = "") -> str:
    """Проверить подключение (без handle) или прогресс/результат своего фонового запроса."""
    if not handle:
        return _run(_new_job(), "SELECT current_user", 1, None, 20)
    job = _job(handle)
    return job.report if job.done else f"{job.state}: {job.query_id or 'ожидаю Trino'}, собрано строк {job.count}."


@mcp.tool(annotations=CANCEL)
@_errors
def trino_cancel(handle: str) -> str:
    """Запросить отмену только собственного активного чтения по handle из trino_start."""
    job = _job(handle)
    if job.done:
        return "Запрос уже завершён."
    job.cancel.set()
    return "Отмена запрошена. Проверьте trino_status для подтверждения результата."


@mcp.tool(annotations=RO)
@_errors
def trino_catalogs() -> str:
    """Посмотреть доступные каталоги Trino."""
    return _run(_new_job(), "SHOW CATALOGS", 200, None, 30)


@mcp.tool(annotations=RO)
@_errors
def trino_schemas(catalog: str) -> str:
    """Посмотреть схемы в каталоге Trino."""
    return _run(_new_job(), f"SHOW SCHEMAS FROM {_identifier(catalog)}", 200, None, 30)


@mcp.tool(annotations=RO)
@_errors
def trino_find_tables(catalog: str, schema: str, pattern: str = "") -> str:
    """Найти таблицы и представления в каталоге и схеме, pattern — часть имени."""
    prefix = f"SELECT table_name, table_type FROM {_identifier(catalog)}.information_schema.tables"
    conditions = f"WHERE table_schema = {_literal(schema)}"
    if pattern:
        conditions += f" AND strpos(lower(table_name), lower({_literal(pattern)})) > 0"
    return _run(_new_job(), f"{prefix} {conditions} ORDER BY table_name LIMIT 201", 200, None, 30)


@mcp.tool(annotations=RO)
@_errors
def trino_describe(catalog: str, schema: str, table: str) -> str:
    """Прочитать имена и типы колонок, а также комментарии таблицы Trino."""
    name = ".".join(map(_identifier, (catalog, schema, table)))
    return _run(_new_job(), f"DESCRIBE {name}", 200, None, 30)


if __name__ == "__main__":
    logging.getLogger("httpx").setLevel(logging.WARNING)
    mcp.run()
