"""MCP «calendar»: корпоративный календарь Outlook / Exchange (EWS).

Авторизация — Kerberos (доменная учётная запись macOS), пароль не нужен.
Настройки (необязательно): EXCHANGE_EWS_URL, EXCHANGE_EMAIL.
"""

from __future__ import annotations

import datetime as dt
import getpass
import os
from functools import lru_cache

from exchangelib import (
    DELEGATE, GSSAPI, Account, Attendee, CalendarItem, Configuration, EWSDateTime, EWSTimeZone, HTMLBody,
    Mailbox, Version,
)
from exchangelib.items import SEND_ONLY_TO_ALL, SEND_TO_NONE
from exchangelib.protocol import Protocol
from exchangelib.version import EXCHANGE_2016
from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

mcp = MCPServer("calendar")
RO = ToolAnnotations(readOnlyHint=True)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False)
TZ = EWSTimeZone.localzone()
WEEKDAYS = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"]


@lru_cache
def _config() -> Configuration:
    return Configuration(
        service_endpoint=os.environ.get("EXCHANGE_EWS_URL", "https://mail.magnit.ru/EWS/Exchange.asmx"),
        auth_type=GSSAPI, credentials=None, version=Version(build=EXCHANGE_2016),
    )


def _resolve(who: str) -> str:
    """Логин, ФИО или почта -> адрес почты."""
    if "@" in who and not who.startswith("@"):
        return who
    found = Protocol(config=_config()).resolve_names([who.lstrip("@")])
    mailboxes = [m for m in found if isinstance(m, Mailbox) and m.email_address]
    if not mailboxes:
        raise ValueError(f"Не удалось найти сотрудника «{who}» в адресной книге")
    return mailboxes[0].email_address


@lru_cache
def _account() -> Account:
    email = os.environ.get("EXCHANGE_EMAIL") or _resolve(getpass.getuser())
    return Account(primary_smtp_address=email, config=_config(), autodiscover=False, access_type=DELEGATE)


def _parse_dt(value: str) -> EWSDateTime:
    value = value.strip().replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%d.%m.%Y %H:%M"):
        try:
            return EWSDateTime.from_datetime(dt.datetime.strptime(value, fmt)).replace(tzinfo=TZ)
        except ValueError:
            continue
    raise ValueError(f"Неверный формат даты-времени «{value}», нужен YYYY-MM-DD HH:MM")


def _parse_date(value: str) -> dt.date:
    today = dt.date.today()
    special = {"today": 0, "сегодня": 0, "tomorrow": 1, "завтра": 1, "yesterday": -1, "вчера": -1}
    if value.strip().lower() in special:
        return today + dt.timedelta(days=special[value.strip().lower()])
    for fmt in ("%Y-%m-%d", "%d.%m.%Y"):
        try:
            return dt.datetime.strptime(value.strip(), fmt).date()
        except ValueError:
            continue
    raise ValueError(f"Неверный формат даты «{value}», нужен YYYY-MM-DD")


def _fmt(item: CalendarItem, details: bool = False) -> str:
    start, end = item.start.astimezone(TZ), item.end.astimezone(TZ)
    line = (f"{WEEKDAYS[start.weekday()]} {start:%d.%m %H:%M}–{end:%H:%M} · {item.subject or '(без темы)'}"
            + (f" · {item.location}" if item.location else "")
            + (f" · организатор: {item.organizer.name}" if item.organizer else "")
            + (f" · мой ответ: {item.my_response_type}" if item.my_response_type else "")
            + f"\n    id: {item.id}")
    if details:
        people = [f"{a.mailbox.name} <{a.mailbox.email_address}> ({a.response_type})"
                  for a in (item.required_attendees or []) + (item.optional_attendees or [])]
        body = str(item.text_body or item.body or "").strip()
        line += "\nУчастники:\n  " + "\n  ".join(people or ["—"])
        line += f"\nОписание:\n{body[:4000] or '—'}"
    return line


@mcp.tool(annotations=RO)
def calendar_whoami() -> str:
    """Чей календарь подключён (почта текущего пользователя)."""
    return _account().primary_smtp_address


@mcp.tool(annotations=RO)
def calendar_list_events(start_date: str = "today", days: int = 1) -> str:
    """Встречи из календаря Outlook. start_date: YYYY-MM-DD, «today», «tomorrow»; days — сколько дней показать."""
    day = _parse_date(start_date)
    start = EWSDateTime(day.year, day.month, day.day, tzinfo=TZ)
    end = start + dt.timedelta(days=max(1, days))
    items = _account().calendar.view(start=start, end=end).only(
        "id", "changekey", "subject", "start", "end", "location", "organizer", "my_response_type", "is_cancelled")
    lines = [_fmt(i) for i in items if not i.is_cancelled]
    return "\n".join(lines) or "Встреч нет."


@mcp.tool(annotations=RO)
def calendar_get_event(event_id: str) -> str:
    """Подробности встречи: участники, их ответы, описание."""
    return _fmt(_account().calendar.get(id=event_id), details=True)


@mcp.tool(annotations=RO)
def calendar_find_free_time(attendees: list[str], date: str, duration_minutes: int = 30,
                            work_start: str = "09:00", work_end: str = "18:00") -> str:
    """Найти общие свободные слоты для себя и участников (логины, ФИО или почты) в указанный день."""
    acc = _account()
    emails = [acc.primary_smtp_address] + [_resolve(a) for a in attendees]
    day = _parse_date(date)
    ws, we = (dt.datetime.strptime(t, "%H:%M").time() for t in (work_start, work_end))
    start = EWSDateTime.from_datetime(dt.datetime.combine(day, ws)).replace(tzinfo=TZ)
    end = EWSDateTime.from_datetime(dt.datetime.combine(day, we)).replace(tzinfo=TZ)
    busy: list[tuple] = []
    info = acc.protocol.get_free_busy_info(
        accounts=[(e, "Required", False) for e in emails], start=start, end=end, merged_free_busy_interval=15)
    for email, fb in zip(emails, info):
        for ev in getattr(fb, "calendar_events", None) or []:
            if ev.busy_type in ("Busy", "OOF", "Tentative"):
                busy.append((ev.start.astimezone(TZ), ev.end.astimezone(TZ)))
    busy.sort()
    slots, cursor = [], start
    for b_start, b_end in busy:
        if b_start - cursor >= dt.timedelta(minutes=duration_minutes):
            slots.append((cursor, b_start))
        cursor = max(cursor, b_end)
    if end - cursor >= dt.timedelta(minutes=duration_minutes):
        slots.append((cursor, end))
    if not slots:
        return f"На {day:%d.%m} нет общих окон по {duration_minutes} мин для: {', '.join(emails)}"
    return (f"Общие свободные окна {day:%d.%m} ({', '.join(emails)}):\n"
            + "\n".join(f"  {s:%H:%M}–{e:%H:%M}" for s, e in slots))


@mcp.tool(annotations=WRITE)
def calendar_create_event(subject: str, start: str, duration_minutes: int = 30, attendees: list[str] | None = None,
                          location: str = "", description: str = "") -> str:
    """Создать встречу в Outlook. start: YYYY-MM-DD HH:MM. Если есть участники — им уйдут приглашения.

    Создавайте только по явной просьбе пользователя, сначала проверьте время через calendar_find_free_time.
    """
    acc = _account()
    begin = _parse_dt(start)
    item = CalendarItem(
        account=acc, folder=acc.calendar, subject=subject, start=begin,
        end=begin + dt.timedelta(minutes=duration_minutes), location=location or None,
        body=HTMLBody(description.replace("\n", "<br>")) if description else None,
        required_attendees=[Attendee(mailbox=Mailbox(email_address=_resolve(a))) for a in attendees or []] or None,
    )
    item.save(send_meeting_invitations=SEND_ONLY_TO_ALL if attendees else SEND_TO_NONE)
    return "Встреча создана:\n" + _fmt(item)


@mcp.tool(annotations=WRITE)
def calendar_update_event(event_id: str, subject: str | None = None, start: str | None = None,
                          duration_minutes: int | None = None, location: str | None = None,
                          add_attendees: list[str] | None = None) -> str:
    """Изменить свою встречу (тему, время, место, добавить участников). Участники получат обновление."""
    item = _account().calendar.get(id=event_id)
    fields = []
    if subject is not None:
        item.subject = subject; fields.append("subject")
    if start is not None or duration_minutes is not None:
        length = dt.timedelta(minutes=duration_minutes) if duration_minutes else item.end - item.start
        item.start = _parse_dt(start) if start else item.start
        item.end = item.start + length
        fields += ["start", "end"]
    if location is not None:
        item.location = location; fields.append("location")
    if add_attendees:
        item.required_attendees = (item.required_attendees or []) + [
            Attendee(mailbox=Mailbox(email_address=_resolve(a))) for a in add_attendees]
        fields.append("required_attendees")
    if not fields:
        return "Нечего менять."
    item.save(update_fields=fields, send_meeting_invitations=SEND_ONLY_TO_ALL)
    return "Встреча обновлена:\n" + _fmt(item)


@mcp.tool(annotations=WRITE)
def calendar_respond(event_id: str, response: str, message: str = "") -> str:
    """Ответить на приглашение: response = accept | tentative | decline."""
    item = _account().calendar.get(id=event_id)
    action = {"accept": item.accept, "tentative": item.tentatively_accept, "decline": item.decline}[response]
    action(body=message or None)
    return f"Ответ «{response}» отправлен на «{item.subject}»"


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=True))
def calendar_cancel_event(event_id: str, message: str = "") -> str:
    """Отменить свою встречу (участники получат уведомление об отмене)."""
    item = _account().calendar.get(id=event_id)
    item.cancel(body=message or None)
    return f"Встреча «{item.subject}» отменена"


if __name__ == "__main__":
    mcp.run()
