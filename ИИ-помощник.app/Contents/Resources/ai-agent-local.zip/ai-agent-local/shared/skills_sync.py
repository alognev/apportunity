"""Подключение навыков (skills) к агенту: python skills_sync.py <папка_навыков_агента> [--ascii].

Источники: встроенные shared/skills/* и личные ~/.magnit-agent/skills/* (личные важнее).
В целевой папке создаются ссылки на папки навыков: macOS — символические, Windows — junction
(символические ссылки там требуют прав администратора или режима разработчика). Чужие навыки не трогаются.
Навыки называются по-русски (их видит пользователь Goose). --ascii — для Claude Code (агенты A и C): там имя навыка —
только латиница, поэтому навык с русским именем кладётся копией под латинским именем-транслитом (деловое-письмо →
delovoe-pismo); копии помечены файлом .magnit-skill-copy и пересоздаются при каждой синхронизации.
"""

import os
import re
import shutil
import sys
from pathlib import Path

SOURCES = [Path(__file__).resolve().parent / "skills", Path.home() / ".magnit-agent" / "skills"]
COPY_MARK = ".magnit-skill-copy"
ASCII_NAME = re.compile(r"^[a-z0-9][a-z0-9-]*$")
TRANSLIT = dict(zip("абвгдеёжзийклмнопрстуфхцчшщъыьэюя",
                    ["a", "b", "v", "g", "d", "e", "e", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p", "r", "s",
                     "t", "u", "f", "kh", "ts", "ch", "sh", "sch", "", "y", "", "e", "yu", "ya"]))


def ascii_slug(name: str) -> str:
    """Латинское имя навыка для Claude Code: русские буквы — транслитом, остальное — дефисом."""
    if ASCII_NAME.match(name):
        return name
    s = "".join(TRANSLIT.get(c, c) for c in name.lower())
    return re.sub(r"-{2,}", "-", re.sub(r"[^a-z0-9-]", "-", s)).strip("-")[:64] or "skill"


def _is_link(path: Path) -> bool:
    return path.is_symlink() or (hasattr(path, "is_junction") and path.is_junction())


def _make_link(link: Path, target: Path) -> None:
    if os.name == "nt":
        import _winapi
        _winapi.CreateJunction(str(target), str(link))
    else:
        link.symlink_to(target)


def _remove_link(link: Path) -> None:
    if link.is_symlink():
        link.unlink()
    else:
        os.rmdir(link)  # junction: удаляется сама ссылка, папка навыка остаётся


def _make_copy(dest: Path, source: Path, slug: str) -> None:
    shutil.copytree(source, dest, ignore=shutil.ignore_patterns("__pycache__", ".DS_Store"))
    skill = dest / "SKILL.md"
    text = skill.read_text(encoding="utf-8")
    skill.write_text(re.sub(r"^name:.*$", f"name: {slug}", text, count=1, flags=re.M), encoding="utf-8")
    (dest / COPY_MARK).write_text(str(source), encoding="utf-8")


# Встроенные навыки, переименованные по-русски 22.10.2026. Обновление поверх установки (архив, install.ps1/install.sh)
# только добавляет файлы — прежние папки удаляем сами, иначе в Goose каждый навык виден дважды.
RENAMED = {"business-letter": "деловое-письмо", "confluence-research": "поиск-в-confluence",
           "data-report": "отчет-по-таблицам", "jira-task": "задача-в-jira", "mail-digest": "разбор-почты",
           "meeting-protocol": "протокол-встречи", "spec-routine": "рутина-по-спеке", "teradata": "данные-из-teradata"}


def _drop_renamed() -> None:
    builtin = SOURCES[0]
    for old, new in RENAMED.items():
        if (builtin / old / "SKILL.md").exists() and (builtin / new / "SKILL.md").exists():
            shutil.rmtree(builtin / old, ignore_errors=True)


def sync(target: Path, ascii_names: bool = False) -> None:
    _drop_renamed()
    target.mkdir(parents=True, exist_ok=True)
    wanted = {}
    for src in SOURCES:
        src.mkdir(parents=True, exist_ok=True) if src.parent.exists() else None
        for skill in sorted(src.glob("*/SKILL.md")) if src.exists() else []:
            wanted[skill.parent.name] = skill.parent
    copies = {ascii_slug(n): p for n, p in wanted.items() if ascii_names and not ASCII_NAME.match(n)}
    links = {n: p for n, p in wanted.items() if not (ascii_names and not ASCII_NAME.match(n))}
    for item in target.iterdir():
        if _is_link(item) and any(str(item.resolve()).startswith(str(s)) for s in SOURCES):
            if links.get(item.name) != item.resolve():
                _remove_link(item)
        elif item.is_dir() and (item / COPY_MARK).exists():
            shutil.rmtree(item)  # своя копия: пересоздаём (навык мог измениться) или убираем ненужную
    for name, path in links.items():
        link = target / name
        if not link.exists() and not _is_link(link):
            _make_link(link, path)
    for slug, path in copies.items():
        if not (target / slug).exists():
            _make_copy(target / slug, path, slug)


if __name__ == "__main__":
    sync(Path(sys.argv[1]).expanduser(), ascii_names="--ascii" in sys.argv[2:])
