"""Подключение навыков (skills) к агенту: python skills_sync.py <папка_навыков_агента>.

Источники: встроенные shared/skills/* и личные ~/.magnit-agent/skills/* (личные важнее).
В целевой папке создаются символические ссылки; чужие навыки не трогаются.
"""

import sys
from pathlib import Path

SOURCES = [Path(__file__).resolve().parent / "skills", Path.home() / ".magnit-agent" / "skills"]


def sync(target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    wanted = {}
    for src in SOURCES:
        src.mkdir(parents=True, exist_ok=True) if src.parent.exists() else None
        for skill in sorted(src.glob("*/SKILL.md")) if src.exists() else []:
            wanted[skill.parent.name] = skill.parent
    for link in target.iterdir():
        if link.is_symlink() and any(str(link.resolve()).startswith(str(s)) for s in SOURCES):
            if wanted.get(link.name) != link.resolve():
                link.unlink()
    for name, path in wanted.items():
        link = target / name
        if not link.exists() and not link.is_symlink():
            link.symlink_to(path)


if __name__ == "__main__":
    sync(Path(sys.argv[1]).expanduser())
