"""Автоматизации: запуск заданий агента по расписанию (macOS — launchd, Windows — Планировщик заданий).

  python scheduler.py list
  python scheduler.py create "Название" "daily 09:00" "Текст задания" [--tag] [--dir ПАПКА]
  python scheduler.py run <id>        — выполнить сейчас (так же вызывает launchd / Планировщик)
  python scheduler.py delete|pause|resume <id>

Расписание: "hourly", "daily 09:00", "weekdays 09:00", "weekly пн 09:00",
            "monthly 1 09:00", "once 2026-10-01 10:00".
Результаты: <папка>/Автоматизации/<название>/<дата>.md
"""

from __future__ import annotations

import datetime as dt
import json
import os
import plistlib
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STATE = Path.home() / ".magnit-agent" / "automations"
AGENTS_DIR = Path.home() / "Library" / "LaunchAgents"
LABEL = "ru.magnit-agent.automation."
DAYS = {"пн": 1, "вт": 2, "ср": 3, "чт": 4, "пт": 5, "сб": 6, "вс": 0,
        "mon": 1, "tue": 2, "wed": 3, "thu": 4, "fri": 5, "sat": 6, "sun": 0}
ANSI = re.compile(r"\x1b\[[0-9;]*m")

WINDOWS = os.name == "nt"
WIN_DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]  # индекс — как в DAYS


def _hm(s: str) -> dict:
    h, m = s.split(":")
    return {"Hour": int(h), "Minute": int(m)}


def parse_schedule(spec: str) -> list[dict]:
    """Текст расписания -> StartCalendarInterval для launchd."""
    parts = spec.strip().lower().split()
    kind = parts[0]
    if kind == "hourly":
        return [{"Minute": int(parts[1]) if len(parts) > 1 else 0}]
    if kind == "daily":
        return [_hm(parts[1])]
    if kind == "weekdays":
        return [{"Weekday": d, **_hm(parts[1])} for d in range(1, 6)]
    if kind == "weekly":
        return [{"Weekday": DAYS[parts[1][:3]], **_hm(parts[2])}]
    if kind == "monthly":
        return [{"Day": int(parts[1]), **_hm(parts[2])}]
    if kind == "once":
        d = dt.datetime.strptime(f"{parts[1]} {parts[2]}", "%Y-%m-%d %H:%M")
        return [{"Month": d.month, "Day": d.day, "Hour": d.hour, "Minute": d.minute}]
    raise ValueError(f"Непонятное расписание «{spec}». Примеры: daily 09:00, weekly пн 10:00, once 2026-10-01 10:00")


def windows_triggers(spec: str, now: dt.datetime | None = None) -> str:
    """Текст расписания -> триггеры Планировщика заданий Windows (те же форматы, что у parse_schedule)."""
    now = now or dt.datetime.now()
    parts = spec.strip().lower().split()
    kind = parts[0]

    def start(hm: str) -> str:  # ближайшее время hh:mm — начало действия триггера
        h, m = map(int, hm.split(":"))
        at = now.replace(hour=h, minute=m, second=0, microsecond=0)
        return (at if at > now else at + dt.timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%S")

    def calendar(hm: str, schedule: str) -> str:
        return f"<CalendarTrigger><StartBoundary>{start(hm)}</StartBoundary>{schedule}</CalendarTrigger>"

    def week(days: list[int]) -> str:
        return ("<ScheduleByWeek><WeeksInterval>1</WeeksInterval><DaysOfWeek>"
                + "".join(f"<{WIN_DAYS[d]} />" for d in days) + "</DaysOfWeek></ScheduleByWeek>")

    parse_schedule(spec)  # проверка формата — с тем же сообщением об ошибке, что на macOS
    if kind == "hourly":
        minute = int(parts[1]) if len(parts) > 1 else 0
        at = now.replace(minute=minute, second=0, microsecond=0)
        at = at if at > now else at + dt.timedelta(hours=1)
        return (f"<TimeTrigger><Repetition><Interval>PT1H</Interval></Repetition>"
                f"<StartBoundary>{at.strftime('%Y-%m-%dT%H:%M:%S')}</StartBoundary></TimeTrigger>")
    if kind == "daily":
        return calendar(parts[1], "<ScheduleByDay><DaysInterval>1</DaysInterval></ScheduleByDay>")
    if kind == "weekdays":
        return calendar(parts[1], week([1, 2, 3, 4, 5]))
    if kind == "weekly":
        return calendar(parts[2], week([DAYS[parts[1][:3]]]))
    if kind == "monthly":
        months = "".join(f"<{m} />" for m in ("January", "February", "March", "April", "May", "June", "July",
                                              "August", "September", "October", "November", "December"))
        return calendar(parts[2], f"<ScheduleByMonth><DaysOfMonth><Day>{int(parts[1])}</Day></DaysOfMonth>"
                                  f"<Months>{months}</Months></ScheduleByMonth>")
    d = dt.datetime.strptime(f"{parts[1]} {parts[2]}", "%Y-%m-%d %H:%M")  # once
    return f"<TimeTrigger><StartBoundary>{d.strftime('%Y-%m-%dT%H:%M:%S')}</StartBoundary></TimeTrigger>"


def _load(aid: str) -> dict:
    return json.loads((STATE / f"{aid}.json").read_text(encoding="utf-8"))


def _save(task: dict) -> None:
    STATE.mkdir(parents=True, exist_ok=True)
    (STATE / f"{task['id']}.json").write_text(json.dumps(task, ensure_ascii=False, indent=2), encoding="utf-8")


def _plist_path(aid: str) -> Path:
    return AGENTS_DIR / f"{LABEL}{aid}.plist"


def _launchctl(*args: str) -> None:
    subprocess.run(["launchctl", *args], capture_output=True)


def _install(task: dict) -> None:
    if WINDOWS:
        import platform_util
        pyw = Path(sys.executable).with_name("pythonw.exe")  # без окна консоли
        xml = platform_util.task_xml(
            windows_triggers(task["schedule"]), str(pyw if pyw.exists() else sys.executable),
            f'-X utf8 "{Path(__file__).resolve()}" run {task["id"]}', task["workdir"],
            f"ИИ-помощник, автоматизация «{task['name']}» ({task['schedule']})")
        ok, msg = platform_util.task_install(LABEL + task["id"], xml)
        if not ok:
            raise RuntimeError(f"Планировщик заданий не принял задание: {msg}")
        return
    AGENTS_DIR.mkdir(parents=True, exist_ok=True)
    plist = {
        "Label": LABEL + task["id"],
        "ProgramArguments": [sys.executable, str(Path(__file__).resolve()), "run", task["id"]],
        "StartCalendarInterval": parse_schedule(task["schedule"]),
        "StandardOutPath": str(STATE / f"{task['id']}.log"),
        "StandardErrorPath": str(STATE / f"{task['id']}.log"),
        "EnvironmentVariables": {"PATH": "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin", "LANG": "ru_RU.UTF-8"},
    }
    path = _plist_path(task["id"])
    _launchctl("bootout", f"gui/{os.getuid()}", str(path))
    path.write_bytes(plistlib.dumps(plist))
    _launchctl("bootstrap", f"gui/{os.getuid()}", str(path))


def _uninstall(aid: str) -> None:
    if WINDOWS:
        import platform_util
        platform_util.task_delete(LABEL + aid)
        return
    path = _plist_path(aid)
    _launchctl("bootout", f"gui/{os.getuid()}", str(path))
    path.unlink(missing_ok=True)


def _env() -> dict[str, str]:
    sys.path.insert(0, str(ROOT / "shared"))
    from mcp_registry import load_env
    return load_env()


def create(name: str, schedule: str, prompt: str, notify_tag: bool = False, workdir: str = "") -> dict:
    parse_schedule(schedule)  # проверка формата до сохранения
    env = _env()
    task = {
        "id": uuid.uuid4().hex[:8], "name": name, "schedule": schedule, "prompt": prompt,
        "notify_tag": notify_tag, "enabled": True, "created": time.strftime("%Y-%m-%d %H:%M"),
        "workdir": os.path.expanduser(workdir or env.get("AGENT_WORKSPACE") or "~/magnit-agent-workspace"),
        "history": [],
    }
    _save(task)
    _install(task)
    return task


def all_tasks() -> list[dict]:
    STATE.mkdir(parents=True, exist_ok=True)
    return sorted((json.loads(p.read_text(encoding="utf-8")) for p in STATE.glob("*.json")), key=lambda t: t["created"])


def set_enabled(aid: str, enabled: bool) -> dict:
    task = _load(aid)
    task["enabled"] = enabled
    _save(task)
    _install(task) if enabled else _uninstall(aid)
    return task


def delete(aid: str) -> None:
    _uninstall(aid)
    (STATE / f"{aid}.json").unlink(missing_ok=True)


def _agent_command(task: dict) -> list[str]:
    """Кто выполняет задание: агент C, иначе A, иначе B. На Windows пока только Goose (B) — напрямую, без cmd:
    в тексте задания могут быть кавычки, & и |, которые cmd разобрал бы по-своему."""
    if WINDOWS:
        import platform_util
        return [str(platform_util.goose_cli()), "run", "--no-session", "-t", task["prompt"]]
    c = ROOT / "agent-c-agent-sdk"
    if (c / ".venv" / "bin" / "python").exists():
        return [str(c / "magnit-agent"), "-y", "-C", task["workdir"], task["prompt"]]
    if shutil.which("claude"):
        return [str(ROOT / "agent-a-claude-code" / "magnit-claude"), "-p", task["prompt"],
                "--permission-mode", "bypassPermissions"]
    return [str(ROOT / "agent-b-goose" / "magnit-goose"), "run", "--no-session", "-t", task["prompt"]]


def _notify(title: str, text: str) -> None:
    import platform_util
    platform_util.notify(title, text)


def _goose_env(env: dict[str, str]) -> dict[str, str]:
    """Windows: переменные, которые на macOS выставляет обёртка agent-b-goose/magnit-goose (см. windows/magnit-goose.ps1)."""
    if not WINDOWS:
        return {}
    import mcp_registry
    return {"GOOSE_PROVIDER": "magnit_copilot", "GOOSE_MODEL": env.get("LLM_MODEL") or mcp_registry.DEFAULT_LLM_MODEL,
            "MAGNIT_COPILOT_API_KEY": env.get("LLM_API_KEY", ""),
            "GOOSE_MAX_TOKENS": env.get("LLM_MAX_OUTPUT_TOKENS") or "32768",
            "PYTHONUTF8": "1"}


def run(aid: str) -> Path:
    task = _load(aid)
    started = time.time()
    outdir = Path(task["workdir"]) / "Автоматизации" / re.sub(r"[/:]", "_", task["name"])
    outdir.mkdir(parents=True, exist_ok=True)
    agent_env = {k: v for k, v in os.environ.items() if not k.startswith("LANGFUSE_")}  # ключи — только у ретранслятора
    try:
        import tracing
        trace_env = tracing.agent_env(_env())
    except Exception:  # noqa: BLE001 — трассировка не должна мешать автоматизации
        trace_env = {}
    proc = subprocess.run(_agent_command(task), cwd=task["workdir"], capture_output=True, text=True, timeout=3600,
                          encoding="utf-8", errors="replace",
                          env={**agent_env, **trace_env, **_goose_env(_env()), "AGENT_AUTO_APPROVE": "1",
                               "GOOSE_MODE": "auto", "OTEL_RESOURCE_ATTRIBUTES": "magnit.run_mode=automation",
                               "MAGNIT_ALL_INTEGRATIONS": "1"},  # агенты A и C не включают инструменты сами
                          creationflags=subprocess.CREATE_NO_WINDOW if WINDOWS else 0)
    output = ANSI.sub("", proc.stdout).strip()
    ok = proc.returncode == 0
    report = outdir / f"{time.strftime('%Y-%m-%d_%H-%M')}.md"
    report.write_text(f"# {task['name']}\n\n_{time.strftime('%d.%m.%Y %H:%M')} · задание: {task['prompt']}_\n\n"
                      f"{output or proc.stderr[-3000:]}\n", encoding="utf-8")
    task["history"] = (task.get("history") or [])[-49:] + [{
        "at": time.strftime("%Y-%m-%d %H:%M"), "ok": ok, "seconds": round(time.time() - started), "file": str(report)}]
    _save(task)

    _notify(f"Автоматизация «{task['name']}»", "Готово" if ok else "Ошибка — см. отчёт")
    env = _env()
    if task.get("notify_tag") and env.get("TAG_TOKEN"):
        os.environ.update({k: v for k, v in env.items() if k.startswith("TAG_")})
        sys.path.insert(0, str(ROOT / "shared" / "servers"))
        from tag_mcp import send
        try:
            send("me", f"**Автоматизация «{task['name']}»** {'✅' if ok else '❌'}\n\n{output[:3500]}", str(report))
        except Exception as e:  # noqa: BLE001
            print(f"Tag: {e}", file=sys.stderr)
    if task["schedule"].lower().startswith("once"):
        set_enabled(aid, False)
    return report


def describe(task: dict) -> str:
    last = (task.get("history") or [{}])[-1]
    status = "вкл" if task["enabled"] else "пауза"
    tail = f" · последний запуск {last['at']} {'✅' if last.get('ok') else '❌'}" if last else ""
    return (f"[{task['id']}] «{task['name']}» · {task['schedule']} · {status}"
            + (" · +Tag" if task.get("notify_tag") else "") + tail + f"\n    {task['prompt'][:200]}")


if __name__ == "__main__":
    cmd, *args = sys.argv[1:] or ["list"]
    if sys.stdout is None:  # Windows: pythonw из Планировщика — без консоли; вывод — в журнал, как у launchd
        STATE.mkdir(parents=True, exist_ok=True)
        sys.stdout = sys.stderr = open(STATE / f"{args[0] if args else 'scheduler'}.log", "a", encoding="utf-8")
    if cmd == "list":
        print("\n".join(describe(t) for t in all_tasks()) or "Автоматизаций нет.")
    elif cmd == "create":
        tag = "--tag" in args
        workdir = args[args.index("--dir") + 1] if "--dir" in args else ""
        name, schedule, prompt = [a for a in args if a not in ("--tag", "--dir", workdir)][:3]
        print(describe(create(name, schedule, prompt, tag, workdir)))
    elif cmd == "run":
        print(run(args[0]))
    elif cmd == "delete":
        delete(args[0]); print("Удалено")
    elif cmd in ("pause", "resume"):
        print(describe(set_enabled(args[0], cmd == "resume")))
    else:
        print(__doc__)
