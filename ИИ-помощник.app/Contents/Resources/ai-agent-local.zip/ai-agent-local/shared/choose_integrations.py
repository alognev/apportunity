"""Выбор активных интеграций (инструментов помощника) — вызывается из setup.sh.

  python choose_integrations.py          — спросить пользователя и сохранить в .env
  python choose_integrations.py --show   — только показать текущее состояние
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import mcp_registry as r  # noqa: E402

B, G, D, N = "\033[1m", "\033[32m", "\033[2m", "\033[0m"


def fmt_tokens(name: str) -> str:
    t = r.CONTEXT_TOKENS.get(name)
    return f"~{t / 1000:.1f}".replace(".", ",") + " тыс. токенов" if t else ""


def show(current: list[str], avail: list[str]) -> list[str]:
    numbered = [n for n in r.SERVERS if n in avail]
    for i, name in enumerate(numbered, 1):
        mark = f"{G}[x]{N}" if name in current else "[ ]"
        note = " (всегда включено)" if name in r.ALWAYS_ON else ""
        print(f"  {i:2}. {mark} {r.TITLES[name]:52}{D}{fmt_tokens(name)}{note}{N}")
    for name in r.SERVERS:
        if name not in avail:
            print(f"  {D}  –  {r.TITLES[name]:52}не настроено (нет токена){N}")
    return numbered


def main() -> None:
    env = r.load_env()
    avail, current = r.available(env), r.enabled(env)
    print(f"{B}Какие инструменты оставить активными?{N}")
    print("Неактивные не подключаются к помощнику и не занимают его «память» (контекст модели):")
    print("ответы быстрее и точнее. Включить их можно в любой момент.\n")
    numbered = show(current, avail)
    if "--show" in sys.argv:
        return
    total = sum(r.CONTEXT_TOKENS.get(n, 0) for n in numbered)
    if total:
        print(f"\n{D}Все доступные вместе: ~{total / 1000:.0f} тыс. токенов в каждом запросе к модели.{N}")
    try:
        answer = input(f"\nНомера нужных через пробел, «все» — все, Enter — оставить отмеченные: ").strip().lower()
    except EOFError:
        answer = ""
    if not answer:
        chosen = current
    elif answer in ("все", "all", "*"):
        chosen = numbered
    else:
        chosen = []
        for part in answer.replace(",", " ").split():
            if part.isdigit() and 1 <= int(part) <= len(numbered):
                chosen.append(numbered[int(part) - 1])
            else:
                print(f"  пропускаю «{part}»: нет такого номера")
    # Недоступные сейчас (без токена), но выбранные раньше — сохраняем, чтобы включились при появлении токена
    previous = r.selection(env) or set()
    keep = [n for n in previous if n not in avail]
    value = r.save_selection(list(chosen) + keep)
    active = [r.TITLES[n] for n in r.SERVERS if n in value.split(",") and n in avail]
    print(f"\n{G}Активны:{N} " + "; ".join(active))
    print(f"{D}Поменять позже: ./setup.sh --tools, в Goose — «Расширения», в веб-помощнике — панель «Инструменты».{N}")


if __name__ == "__main__":
    main()
