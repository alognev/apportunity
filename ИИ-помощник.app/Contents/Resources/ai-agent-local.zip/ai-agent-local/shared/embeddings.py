"""Эмбеддинги для семантического поиска по локальным базам знаний.

Бэкенды (EMBEDDINGS_BACKEND в .env):
  local   — по умолчанию: модель multilingual-e5-small (ONNX int8, ~115 МБ) на CPU, в ~/.magnit-agent/models;
            установщик скачивает её, только если базы знаний включены, иначе сервер баз знаний докачивает
            её в фоне при первом запуске (до этого — полнотекстовый поиск);
  litellm — модель эмбеддингов корпоративного шлюза (EMBEDDINGS_MODEL), если её добавят;
  off     — без семантики, только полнотекстовый поиск.

  python embeddings.py download [--if-enabled]   — скачать локальную модель (установщик: только если базы знаний
                                                   включены; уже скачанная — без обращения к сети)
  python embeddings.py status
"""

from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mcp_registry import load_env  # noqa: E402

MODELS_DIR = Path.home() / ".magnit-agent" / "models"
LOCAL_REPO = "intfloat/multilingual-e5-small"
LOCAL_FILES = ("onnx/model_qint8_avx512_vnni.onnx", "onnx/tokenizer.json")
BATCH = 32

os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("HF_HUB_VERBOSITY", "error")
os.environ.setdefault("HF_HUB_DISABLE_IMPLICIT_TOKEN", "1")


def _cfg() -> dict[str, str]:
    env = load_env()
    return {
        "backend": (os.environ.get("EMBEDDINGS_BACKEND") or env.get("EMBEDDINGS_BACKEND") or "local").lower(),
        "model": os.environ.get("EMBEDDINGS_MODEL") or env.get("EMBEDDINGS_MODEL") or "",
        "base": (env.get("LLM_BASE_URL") or "").rstrip("/"),
        "key": env.get("LLM_API_KEY") or "",
    }


def download() -> dict[str, str]:
    from huggingface_hub import hf_hub_download

    return _local_paths() or {f: hf_hub_download(LOCAL_REPO, f, cache_dir=str(MODELS_DIR)) for f in LOCAL_FILES}


BACKGROUND_LOCK = MODELS_DIR / ".downloading"


def download_in_background() -> None:
    """Модели нет — скачать её отдельным процессом, не задерживая запуск сервера (один раз в 30 минут)."""
    try:
        if BACKGROUND_LOCK.exists() and time.time() - BACKGROUND_LOCK.stat().st_mtime < 1800:
            return
        MODELS_DIR.mkdir(parents=True, exist_ok=True)
        BACKGROUND_LOCK.write_text(str(os.getpid()), encoding="utf-8")
        cmd = [sys.executable, "-X", "utf8", str(Path(__file__).resolve()), "download"]
        quiet = dict(stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if os.name != "nt":
            subprocess.Popen(cmd, start_new_session=True, **quiet)
            return
        # Windows: вне задания (job) Goose — иначе загрузка оборвётся вместе с расширением
        detached = subprocess.DETACHED_PROCESS | subprocess.CREATE_NO_WINDOW
        try:
            subprocess.Popen(cmd, creationflags=detached | subprocess.CREATE_BREAKAWAY_FROM_JOB, **quiet)
        except OSError:
            subprocess.Popen(cmd, creationflags=detached, **quiet)
    except OSError:
        pass


def _local_paths() -> dict[str, str] | None:
    try:
        from huggingface_hub import hf_hub_download

        return {f: hf_hub_download(LOCAL_REPO, f, cache_dir=str(MODELS_DIR), local_files_only=True)
                for f in LOCAL_FILES}
    except Exception:  # noqa: BLE001 — модель не скачана
        return None


class _Local:
    name = f"local:{LOCAL_REPO}"

    def __init__(self, paths: dict[str, str]):
        import onnxruntime as ort
        from tokenizers import Tokenizer

        self.tok = Tokenizer.from_file(paths[LOCAL_FILES[1]])
        self.tok.enable_truncation(512)
        self.tok.enable_padding()
        opts = ort.SessionOptions()
        opts.log_severity_level = 3
        self.sess = ort.InferenceSession(paths[LOCAL_FILES[0]], opts, providers=["CPUExecutionProvider"])
        self.inputs = {i.name for i in self.sess.get_inputs()}

    def encode(self, texts: list[str]) -> np.ndarray:
        out = []
        for i in range(0, len(texts), BATCH):
            enc = self.tok.encode_batch(texts[i:i + BATCH])
            ids = np.array([e.ids for e in enc], dtype=np.int64)
            mask = np.array([e.attention_mask for e in enc], dtype=np.int64)
            feed = {"input_ids": ids, "attention_mask": mask}
            if "token_type_ids" in self.inputs:
                feed["token_type_ids"] = np.zeros_like(ids)
            hidden = self.sess.run(None, feed)[0]
            out.append((hidden * mask[..., None]).sum(1) / mask.sum(1, keepdims=True))
        return np.vstack(out)


class _LiteLLM:
    def __init__(self, cfg: dict[str, str]):
        import httpx

        self.name = f"litellm:{cfg['model']}"
        self.model = cfg["model"]
        self.client = httpx.Client(base_url=cfg["base"], timeout=120,
                                   headers={"Authorization": f"Bearer {cfg['key']}"})

    def encode(self, texts: list[str]) -> np.ndarray:
        out = []
        for i in range(0, len(texts), BATCH):
            resp = self.client.post("/v1/embeddings", json={"model": self.model, "input": texts[i:i + BATCH]})
            resp.raise_for_status()
            out.append(np.array([d["embedding"] for d in sorted(resp.json()["data"], key=lambda d: d["index"])]))
        return np.vstack(out)


_current = None
_checked = 0.0


def get():
    """Текущий эмбеддер или None, если семантический поиск недоступен. Пока локальная модель не скачана, она
    качается в фоне, а наличие проверяется раз в минуту — после загрузки поиск по смыслу включится сам."""
    global _current, _checked
    if _current is not None or time.time() - _checked < 60:
        return _current
    _checked = time.time()
    cfg = _cfg()
    if cfg["backend"] == "off":
        return None
    if cfg["backend"] == "litellm" and cfg["model"]:
        _current = _LiteLLM(cfg)
        return _current
    paths = _local_paths()
    if paths:
        _current = _Local(paths)
    else:
        download_in_background()
    return _current


def _normalize(v: np.ndarray) -> np.ndarray:
    return (v / np.clip(np.linalg.norm(v, axis=1, keepdims=True), 1e-12, None)).astype(np.float32)


def embed_passages(texts: list[str]) -> np.ndarray | None:
    emb = get()
    if emb is None:
        return None
    prefix = "passage: " if isinstance(emb, _Local) else ""
    return _normalize(emb.encode([prefix + t for t in texts]))


def embed_query(text: str) -> np.ndarray | None:
    emb = get()
    if emb is None:
        return None
    prefix = "query: " if isinstance(emb, _Local) else ""
    return _normalize(emb.encode([prefix + text]))[0]


def model_name() -> str:
    emb = get()
    return emb.name if emb else ""


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "download":
        if _cfg()["backend"] != "local":
            print(f"Бэкенд эмбеддингов: {_cfg()['backend']} — локальная модель не нужна")
            sys.exit(0)
        if "--if-enabled" in sys.argv and _local_paths() is None:
            from mcp_registry import enabled
            if "knowledge" not in enabled():
                print("Модель поиска по смыслу не нужна: базы знаний выключены (скачается сама при первом поиске)")
                sys.exit(0)
        try:
            paths = download()
            size = sum(os.path.getsize(p) for p in paths.values()) / 2**20
            print(f"Модель для семантического поиска готова ({size:.0f} МБ)")
            BACKGROUND_LOCK.unlink(missing_ok=True)
        except Exception as e:  # noqa: BLE001 — фоновая загрузка повторится не раньше чем через 30 минут
            print(f"Не удалось скачать модель ({e.__class__.__name__}). "
                  "Базы знаний будут работать в режиме полнотекстового поиска.")
    else:
        print(model_name() or "семантический поиск выключен (модель не скачана или EMBEDDINGS_BACKEND=off)")
