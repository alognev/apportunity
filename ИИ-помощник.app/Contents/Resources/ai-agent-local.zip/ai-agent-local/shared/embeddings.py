"""Эмбеддинги для семантического поиска по локальным базам знаний.

Бэкенды (EMBEDDINGS_BACKEND в .env):
  local   — по умолчанию: модель multilingual-e5-small (ONNX int8, ~115 МБ) на CPU,
            скачивается при установке в ~/.magnit-agent/models;
  litellm — модель эмбеддингов корпоративного шлюза (EMBEDDINGS_MODEL), если её добавят;
  off     — без семантики, только полнотекстовый поиск.

  python embeddings.py download   — скачать локальную модель (делает установщик)
  python embeddings.py status
"""

from __future__ import annotations

import os
import sys
from functools import lru_cache
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mcp_registry import load_env  # noqa: E402

MODELS_DIR = Path.home() / ".magnit-agent" / "models"
LOCAL_REPO = "intfloat/multilingual-e5-small"
LOCAL_FILES = ("onnx/model_qint8_avx512_vnni.onnx", "onnx/tokenizer.json")
BATCH = 32

os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("HF_HUB_VERBOSITY", "error")
os.environ.setdefault("HF_HUB_DISABLE_IMPLICIT_TOKEN", "1")


def _cfg() -> dict[str, str]:
    env = load_env()
    return {
        "backend": (os.environ.get("EMBEDDINGS_BACKEND") or env.get("EMBEDDINGS_BACKEND") or "local").lower(),
        "model": os.environ.get("EMBEDDINGS_MODEL") or env.get("EMBEDDINGS_MODEL") or "",
        "base": (env.get("LLM_BASE_URL") or "").rstrip("/"),
        "key": env.get("LLM_API_KEY") or "",
    }


def download() -> dict[str, str]:
    from huggingface_hub import hf_hub_download

    return {f: hf_hub_download(LOCAL_REPO, f, cache_dir=str(MODELS_DIR)) for f in LOCAL_FILES}


def _local_paths() -> dict[str, str] | None:
    try:
        from huggingface_hub import hf_hub_download

        return {f: hf_hub_download(LOCAL_REPO, f, cache_dir=str(MODELS_DIR), local_files_only=True)
                for f in LOCAL_FILES}
    except Exception:  # noqa: BLE001 — модель не скачана
        return None


class _Local:
    name = f"local:{LOCAL_REPO}"

    def __init__(self, paths: dict[str, str]):
        import onnxruntime as ort
        from tokenizers import Tokenizer

        self.tok = Tokenizer.from_file(paths[LOCAL_FILES[1]])
        self.tok.enable_truncation(512)
        self.tok.enable_padding()
        opts = ort.SessionOptions()
        opts.log_severity_level = 3
        self.sess = ort.InferenceSession(paths[LOCAL_FILES[0]], opts, providers=["CPUExecutionProvider"])
        self.inputs = {i.name for i in self.sess.get_inputs()}

    def encode(self, texts: list[str]) -> np.ndarray:
        out = []
        for i in range(0, len(texts), BATCH):
            enc = self.tok.encode_batch(texts[i:i + BATCH])
            ids = np.array([e.ids for e in enc], dtype=np.int64)
            mask = np.array([e.attention_mask for e in enc], dtype=np.int64)
            feed = {"input_ids": ids, "attention_mask": mask}
            if "token_type_ids" in self.inputs:
                feed["token_type_ids"] = np.zeros_like(ids)
            hidden = self.sess.run(None, feed)[0]
            out.append((hidden * mask[..., None]).sum(1) / mask.sum(1, keepdims=True))
        return np.vstack(out)


class _LiteLLM:
    def __init__(self, cfg: dict[str, str]):
        import httpx

        self.name = f"litellm:{cfg['model']}"
        self.model = cfg["model"]
        self.client = httpx.Client(base_url=cfg["base"], timeout=120,
                                   headers={"Authorization": f"Bearer {cfg['key']}"})

    def encode(self, texts: list[str]) -> np.ndarray:
        out = []
        for i in range(0, len(texts), BATCH):
            resp = self.client.post("/v1/embeddings", json={"model": self.model, "input": texts[i:i + BATCH]})
            resp.raise_for_status()
            out.append(np.array([d["embedding"] for d in sorted(resp.json()["data"], key=lambda d: d["index"])]))
        return np.vstack(out)


@lru_cache
def get():
    """Текущий эмбеддер или None, если семантический поиск недоступен."""
    cfg = _cfg()
    if cfg["backend"] == "off":
        return None
    if cfg["backend"] == "litellm" and cfg["model"]:
        return _LiteLLM(cfg)
    paths = _local_paths()
    return _Local(paths) if paths else None


def _normalize(v: np.ndarray) -> np.ndarray:
    return (v / np.clip(np.linalg.norm(v, axis=1, keepdims=True), 1e-12, None)).astype(np.float32)


def embed_passages(texts: list[str]) -> np.ndarray | None:
    emb = get()
    if emb is None:
        return None
    prefix = "passage: " if isinstance(emb, _Local) else ""
    return _normalize(emb.encode([prefix + t for t in texts]))


def embed_query(text: str) -> np.ndarray | None:
    emb = get()
    if emb is None:
        return None
    prefix = "query: " if isinstance(emb, _Local) else ""
    return _normalize(emb.encode([prefix + text]))[0]


def model_name() -> str:
    emb = get()
    return emb.name if emb else ""


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "download":
        if _cfg()["backend"] != "local":
            print(f"Бэкенд эмбеддингов: {_cfg()['backend']} — локальная модель не нужна")
            sys.exit(0)
        try:
            paths = download()
            size = sum(os.path.getsize(p) for p in paths.values()) / 2**20
            print(f"Модель для семантического поиска готова ({size:.0f} МБ)")
        except Exception as e:  # noqa: BLE001
            print(f"Не удалось скачать модель ({e.__class__.__name__}). "
                  "Базы знаний будут работать в режиме полнотекстового поиска.")
    else:
        print(model_name() or "семантический поиск выключен (модель не скачана или EMBEDDINGS_BACKEND=off)")
