"""Проверка подключений к корпоративным системам: python check_integrations.py"""

from __future__ import annotations

import getpass
import os
import sys
from pathlib import Path
from urllib.parse import quote

import truststore

truststore.inject_into_ssl()

import httpx  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mcp_registry import USER_AGENT, load_env  # noqa: E402

G, Y, R, N = "\033[32m", "\033[33m", "\033[31m", "\033[0m"


def check(title: str, url_key: str, token_key: str, path: str, who) -> None:
    env = load_env()
    if not env.get(token_key):
        print(f"  · {title}: не настроено ({token_key} пуст)")
        return
    try:
        r = httpx.get(env[url_key].rstrip("/") + path, timeout=15,
                      headers={"Authorization": f"Bearer {env[token_key]}", "Accept": "application/json",
                               "User-Agent": USER_AGENT})
        data = r.json() if r.status_code == 200 else {}
        if r.status_code == 200 and data.get("type") != "anonymous":
            print(f"  {G}✓{N} {title}: {who(data)}")
        elif r.status_code == 200:
            print(f"  {R}✗{N} {title}: маркер не принят (сервер видит анонима) — проверьте {token_key}")
        else:
            print(f"  {R}✗{N} {title}: ошибка {r.status_code} — проверьте токен ({token_key})")
    except Exception as e:  # noqa: BLE001
        print(f"  {R}✗{N} {title}: нет связи ({e.__class__.__name__}) — VPN подключён?")


def check_atlassian_cloud(name: str, title: str) -> None:
    import mcp_registry as r
    env = load_env()
    (ju, jt), (cu, ct) = r.ATLASSIAN_CONTOURS[name]
    if not (env.get(jt) or env.get(ct)):
        print(f"  · {title}: не настроено (нет маркеров Jira/Confluence этого контура)")
        return
    h = {"User-Agent": USER_AGENT, "Accept": "application/json, text/event-stream", "Content-Type": "application/json"}
    if env.get(jt):
        h |= {"X-Atlassian-Jira-Personal-Token": env[jt], "X-Atlassian-Jira-Url": env[ju]}
    if env.get(ct):
        h |= {"X-Atlassian-Confluence-Personal-Token": env[ct], "X-Atlassian-Confluence-Url": env[cu]}
    init = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
        "protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "check", "version": "1"}}}
    try:
        resp = httpx.post(env.get("ATLASSIAN_MCP_URL") or r.ATLASSIAN_MCP_URL, json=init, headers=h, timeout=20)
        if resp.status_code == 200:
            print(f"  {G}✓{N} {title}: облачный MCP AI Lab отвечает")
        else:
            print(f"  {R}✗{N} {title}: облачный MCP ответил {resp.status_code}")
    except Exception as e:  # noqa: BLE001
        print(f"  {R}✗{N} {title}: облачный MCP недоступен ({e.__class__.__name__}) — VPN подключён?")


def check_gitlab(name: str, title: str) -> None:
    import mcp_registry as r
    env = load_env()
    url, token_var, base = r.GITLAB_INSTANCES[name]
    if not env.get(token_var):
        print(f"  · {title}: не настроено ({token_var} пуст)")
        return
    h = {"User-Agent": USER_AGENT, "Accept": "application/json, text/event-stream", "Content-Type": "application/json",
         "Authorization": f"Bearer {env[token_var]}"}
    init = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
        "protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "check", "version": "1"}}}
    state = "активен" if name in r.enabled(env) else "выключен в выборе инструментов"
    try:
        resp = httpx.post(url, json=init, headers=h, timeout=20)
        mark = f"{G}✓{N}" if resp.status_code == 200 else f"{R}✗{N}"
        print(f"  {mark} {title}: облачный MCP ответил {resp.status_code} ({state})")
    except Exception as e:  # noqa: BLE001
        print(f"  {R}✗{N} {title}: облачный MCP недоступен ({e.__class__.__name__}) — VPN подключён?")


def check_drive() -> None:
    """Magnit Drive: вход выполнен? рабочая папка доступна? (браузер не открывает)"""
    import json
    import mcp_registry as reg
    auth_file = Path.home() / ".magnit-agent" / "drive-auth.json"
    state = "активен" if "drive" in reg.enabled() else "выключен, Goose включит сам"
    if not auth_file.exists():
        print(f"  · Magnit Drive: вход не выполнен — войдёт при первом обращении (откроется браузер) ({state})")
        return
    try:
        auth = json.loads(auth_file.read_text())
        folder = os.environ.get("DRIVE_DIR") or load_env().get("DRIVE_DIR") or "/MCOS"
        settings = Path.home() / ".magnit-agent" / "drive.json"
        if settings.exists():
            folder = json.loads(settings.read_text()).get("folder") or folder
        url = f"{auth['server']}/remote.php/dav/files/{quote(auth['user'])}{quote('/' + folder.strip('/'))}"
        resp = httpx.request("PROPFIND", url, auth=(auth["login"], auth["password"]), headers={"Depth": "0",
                             "User-Agent": reg.USER_AGENT}, timeout=20)
        if resp.status_code == 401:
            print(f"  {Y}!{N} Magnit Drive: доступ помощника отозван — войдёт заново при первом обращении")
        elif resp.status_code == 404:
            print(f"  {Y}!{N} Magnit Drive: {auth['name']}, но папки {folder} нет — попросите доступ или смените папку")
        else:
            resp.raise_for_status()
            print(f"  {G}✓{N} Magnit Drive: {auth['name']}, рабочая папка {folder} ({state})")
    except Exception as e:  # noqa: BLE001
        print(f"  {R}✗{N} Magnit Drive: недоступен ({e.__class__.__name__}) — VPN подключён?")


def check_calendar() -> None:
    try:
        from exchangelib import GSSAPI, Configuration, Version
        from exchangelib.protocol import Protocol
        from exchangelib.version import EXCHANGE_2016
        cfg = Configuration(service_endpoint=load_env().get("EXCHANGE_EWS_URL", "https://mail.magnit.ru/EWS/Exchange.asmx"),
                            auth_type=GSSAPI, credentials=None, version=Version(build=EXCHANGE_2016))
        box = Protocol(config=cfg).resolve_names([getpass.getuser()])[0]
        print(f"  {G}✓{N} Календарь Outlook: {box.email_address} (Kerberos)")
        state = "активна" if "mail" in reg.enabled() else "выключена в выборе инструментов"
        print(f"  {G}✓{N} Почта Outlook (только чтение): тот же вход Kerberos ({state})")
    except Exception as e:  # noqa: BLE001
        print(f"  {Y}!{N} Календарь Outlook: недоступен ({e.__class__.__name__}). Нужен вход в домен "
              "(Kerberos SSO) и VPN; проверьте командой klist")


if __name__ == "__main__":
    print("Проверка интеграций:")
    check_atlassian_cloud("atlassian", "Jira + Confluence ОМНИ (облако)")
    check_atlassian_cloud("atlassian-it", "Jira + Confluence IT (облако)")
    check("Jira (track.magnit.ru)", "JIRA_URL", "JIRA_TOKEN", "/rest/api/2/myself",
          lambda d: f"{d.get('displayName')} ({d.get('name')})")
    check("Jira IT (jira.corp.tander.ru)", "JIRA_IT_URL", "JIRA_IT_TOKEN", "/rest/api/2/myself",
          lambda d: f"{d.get('displayName')} ({d.get('name')})")
    check("Confluence IT-портал", "CONFLUENCE_IT_URL", "CONFLUENCE_IT_TOKEN", "/rest/api/user/current",
          lambda d: d.get("displayName"))
    check("Confluence eportal", "CONFLUENCE_EPORTAL_URL", "CONFLUENCE_EPORTAL_TOKEN", "/rest/api/user/current",
          lambda d: d.get("displayName"))
    env = load_env()
    if env.get("TAG_WEBHOOK_URL") and not (env.get("TAG_TOKEN") or env.get("TAG_BOT_TOKEN")):
        pass
    elif env.get("TAG_TOKEN") or not env.get("TAG_BOT_TOKEN"):
        check("Tag", "TAG_URL", "TAG_TOKEN", "/api/v4/users/me", lambda d: f"@{d.get('username')}")
    else:
        check("Tag (бот)", "TAG_URL", "TAG_BOT_TOKEN", "/api/v4/users/me",
              lambda d: f"бот @{d.get('username')} → пишет @{env.get('TAG_USER') or getpass.getuser()}")
    if env.get("TAG_WEBHOOK_URL") and not (env.get("TAG_TOKEN") or env.get("TAG_BOT_TOKEN")):
        print(f"  {G}✓{N} Tag: входящий вебхук (только отправка сообщений)")
    check("MagnitGPT", "MAGNITGPT_URL", "MAGNITGPT_API_KEY", "/api/v1/auths/", lambda d: d.get("email"))
    check_gitlab("gitlab", "GitLab coderepo.corp.tander.ru")
    check_gitlab("gitlab-platform", "GitLab gitlab.platform.corp")
    import mcp_registry as reg
    dbs = reg.database_sources()
    if not dbs:
        print("  · Базы данных (DBHub): не настроено (./setup.sh --databases)")
    elif not reg.DBHUB_BIN.exists():
        print(f"  {R}✗{N} Базы данных (DBHub): в списке {len(dbs)}, но DBHub не установлен — ./setup.sh --databases")
    else:
        state = "активен" if "dbhub" in reg.enabled() else "выключен в выборе инструментов"
        print(f"  {G}✓{N} Базы данных (DBHub, только чтение): {', '.join(d['id'] for d in dbs)} ({state})")
    check_calendar()
    check_drive()
    import tracing
    print("  · " + tracing.status(load_env()).replace("\n", "\n    "))
    print("  · Интернет-поиск, локальные базы знаний, автоматизации: всегда включены")
