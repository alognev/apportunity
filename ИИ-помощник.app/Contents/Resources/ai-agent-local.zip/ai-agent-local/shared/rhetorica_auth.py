"""Вход в Риторику (rhetorica.analytics.corp, Data Agent КПД) для MCP-моста: OAuth 2.1 через браузер.

Помощник регистрируется в Риторике как приложение (динамическая регистрация, без секрета), открывает в браузере
страницу входа — пользователь входит корпоративной учётной записью и разрешает доступ, браузер возвращает код
на 127.0.0.1, помощник получает токены (PKCE). Токены хранятся в ~/.magnit-agent/rhetorica-auth.json (права 600)
и обновляются сами (refresh_token). Вместо входа можно задать личный API-токен Риторики (scope mcp:read,
mcp:execute) в .env: RHETORICA_TOKEN. Адрес — RHETORICA_URL (по умолчанию https://rhetorica.analytics.corp).
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parent))
import platform_util  # noqa: E402

BASE = (os.environ.get("RHETORICA_URL") or "https://rhetorica.analytics.corp").rstrip("/")
STATE = Path.home() / ".magnit-agent" / "rhetorica-auth.json"
PORT = 47321  # адрес возврата из браузера: http://127.0.0.1:47321/callback
SCOPES = "mcp:read mcp:execute"
LOGIN_WAIT = 170
UA = {"User-Agent": "magnit-local-agent/1.0 (AI assistant)"}


class LoginNeeded(RuntimeError):
    pass


def _load() -> dict:
    try:
        return json.loads(STATE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save(data: dict) -> None:
    STATE.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(STATE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)


def _redirect() -> str:
    return f"http://127.0.0.1:{PORT}/callback"


def _client_id(st: dict) -> str:
    if st.get("client_id") and st.get("redirect") == _redirect():
        return st["client_id"]
    r = httpx.post(f"{BASE}/oauth/register", headers=UA, timeout=30, verify=platform_util.corp_ssl_context(), json={
        "client_name": "ИИ-помощник (локальный агент)", "redirect_uris": [_redirect()],
        "grant_types": ["authorization_code", "refresh_token"], "response_types": ["code"],
        "token_endpoint_auth_method": "none", "scope": SCOPES})
    r.raise_for_status()
    st.update(client_id=r.json()["client_id"], redirect=_redirect())
    _save(st)
    return st["client_id"]


def _store_tokens(st: dict, tok: dict) -> str:
    st.update(access_token=tok["access_token"], expires_at=time.time() + int(tok.get("expires_in") or 3600) - 60)
    if tok.get("refresh_token"):
        st["refresh_token"] = tok["refresh_token"]
    _save(st)
    return st["access_token"]


def _refresh(st: dict) -> str | None:
    if not st.get("refresh_token"):
        return None
    r = httpx.post(f"{BASE}/oauth/token", headers=UA, timeout=30, verify=platform_util.corp_ssl_context(), data={
        "grant_type": "refresh_token", "refresh_token": st["refresh_token"], "client_id": st.get("client_id", "")})
    if r.status_code != 200:
        st.pop("refresh_token", None)
        st.pop("access_token", None)
        _save(st)
        return None
    return _store_tokens(st, r.json())


def _interactive(st: dict) -> str:
    """Открыть страницу входа в браузере и дождаться кода на 127.0.0.1."""
    client_id = _client_id(st)
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    state = secrets.token_urlsafe(24)
    result: dict = {}

    class Callback(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            q = parse_qs(urlparse(self.path).query)
            if q.get("state", [""])[0] == state:
                result.update(code=q.get("code", [""])[0], error=q.get("error", [""])[0])
            ok = bool(result.get("code"))
            body = ("<meta charset='utf-8'><body style='font-family:-apple-system;padding:40px'><h2>"
                    + ("Готово: ИИ-помощник подключён к Риторике.</h2>Окно можно закрыть."
                       if ok else "Вход не выполнен.</h2>Вернитесь в помощник и попробуйте снова.") + "</body>")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(body.encode())

    try:
        server = HTTPServer(("127.0.0.1", PORT), Callback)
    except OSError as e:
        raise LoginNeeded("Порт для входа в Риторику занят — вход уже идёт в другом окне помощника. "
                          "Завершите его и повторите.") from e
    server.timeout = 1
    url = f"{BASE}/oauth/authorize?" + urlencode({
        "response_type": "code", "client_id": client_id, "redirect_uri": _redirect(), "scope": SCOPES,
        "state": state, "code_challenge": challenge, "code_challenge_method": "S256", "resource": f"{BASE}/mcp"})
    webbrowser.open(url)
    deadline = time.time() + LOGIN_WAIT
    try:
        while not result and time.time() < deadline:
            server.handle_request()
    finally:
        server.server_close()
    if not result.get("code"):
        raise LoginNeeded("Открыл в браузере страницу входа в Риторику. Попроси пользователя войти корпоративной "
                          f"учётной записью и разрешить доступ, затем повтори запрос. Ссылка: {url}")
    r = httpx.post(f"{BASE}/oauth/token", headers=UA, timeout=30, verify=platform_util.corp_ssl_context(), data={
        "grant_type": "authorization_code", "code": result["code"], "redirect_uri": _redirect(),
        "client_id": client_id, "code_verifier": verifier, "resource": f"{BASE}/mcp"})
    r.raise_for_status()
    return _store_tokens(st, r.json())


_lock = threading.Lock()


LOGIN_MARK = Path.home() / ".magnit-agent" / "rhetorica-login.started"


def start_login() -> str:
    """Вход в браузере — отдельным фоновым процессом (он ждёт ответа и сохраняет токен), чтобы мост не держал запуск
    расширения: Goose Desktop иначе показывает «загрузку разговора» до конца ожидания. Повторно, пока идёт вход, не
    запускается. Возвращает текст для пользователя."""
    import subprocess
    try:
        busy = time.time() - LOGIN_MARK.stat().st_mtime < LOGIN_WAIT + 20
    except OSError:
        busy = False
    if not busy:
        LOGIN_MARK.parent.mkdir(parents=True, exist_ok=True)
        LOGIN_MARK.write_text(str(os.getpid()), encoding="utf-8")
        flags = (subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP) if os.name == "nt" else 0
        utf8 = ["-X", "utf8"] if sys.flags.utf8_mode else []
        subprocess.Popen([sys.executable, *utf8, str(Path(__file__).resolve()), "--login"], stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=flags,
                         start_new_session=os.name != "nt")
        platform_util.notify("ИИ-помощник: вход в Риторику",
                             "Войдите в открывшемся окне браузера корпоративной учётной записью")
    return ("Нужен вход в Риторику: открыл окно входа в браузере. Войдите корпоративной учётной записью, затем "
            "повторите (в Goose — новый чат или включить расширение Риторики заново).")


def token(force_refresh: bool = False, interactive: bool = True) -> str:
    """Действующий токен: из .env (RHETORICA_TOKEN), сохранённый, обновлённый или после входа в браузере."""
    if os.environ.get("RHETORICA_TOKEN"):
        return os.environ["RHETORICA_TOKEN"]
    with _lock:
        st = _load()
        if st.get("access_token") and not force_refresh and time.time() < st.get("expires_at", 0):
            return st["access_token"]
        fresh = _refresh(st)
        if fresh:
            return fresh
        if not interactive:
            raise LoginNeeded("Нужен вход в Риторику.")
        return _interactive(st)


if __name__ == "__main__":  # ручной вход: shared/.venv/bin/python shared/rhetorica_auth.py [--login — фоновый, из моста]
    try:
        print("Вход выполнен, токен получен." if token() else "Вход не выполнен.")
    finally:
        if "--login" in sys.argv:
            LOGIN_MARK.unlink(missing_ok=True)
