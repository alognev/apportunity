"""Функции, которые на macOS и Windows делаются по-разному: секреты, окно входа, уведомления.

Секреты: macOS — «Связка ключей» (команда security), Windows — диспетчер учётных данных (pywin32).
Запись на Windows называется «<аккаунт>.<сервис>» и хранит текст в UTF-16LE — как keyring-rs, поэтому
секреты Goose (сервис goose, аккаунт secrets) читаются и пишутся этими же функциями.
Окно входа (логин и пароль): macOS — osascript, Windows — tkinter в отдельном процессе; пароль возвращается через
pipe, в аргументы командной строки не попадает.
Только стандартная библиотека (на Windows — ещё pywin32 из shared/.venv): модуль импортируется из разных окружений.

  python platform_util.py ask-login <заголовок> [логин]   — окно входа (пояснение — в stdin), «логин\\nпароль» — в stdout
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

WINDOWS = os.name == "nt"
PASSWORD_WAIT = 180  # секунд на ввод пароля


# ---------- секреты ----------

def secret_get(service: str, account: str) -> str | None:
    if WINDOWS:
        import pywintypes
        import win32cred
        try:
            blob = win32cred.CredRead(f"{account}.{service}", win32cred.CRED_TYPE_GENERIC)["CredentialBlob"]
        except pywintypes.error:
            return None
        try:
            return blob.decode("utf-16-le") or None
        except UnicodeDecodeError:
            return None
    try:
        r = subprocess.run(["security", "find-generic-password", "-s", service, "-a", account, "-w"],
                           capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired):  # «Связка ключей» заблокирована (экран заблокирован)
        return None
    return r.stdout.rstrip("\n") if r.returncode == 0 and r.stdout.strip() else None


def secret_set(service: str, account: str, value: str, label: str = "") -> bool:
    """Сохранить секрет (создать или заменить). False — не удалось (например, «Связка ключей» заблокирована)."""
    if WINDOWS:
        import win32cred
        win32cred.CredWrite({"Type": win32cred.CRED_TYPE_GENERIC, "TargetName": f"{account}.{service}",
                             "UserName": account, "CredentialBlob": value,
                             "Persist": win32cred.CRED_PERSIST_ENTERPRISE, "Comment": label or service}, 0)
        return True
    # Через stdin команды security -i: секрет не попадает в список процессов (аргументы командной строки)
    esc = lambda s: s.replace("\\", "\\\\").replace('"', '\\"')  # noqa: E731
    cmd = f'add-generic-password -U -s "{esc(service)}" -a "{esc(account)}"'
    cmd += f' -l "{esc(label)}"' if label else ""
    try:
        r = subprocess.run(["security", "-i"], input=f'{cmd} -w "{esc(value)}"\n', capture_output=True, text=True,
                           timeout=30)
    except (OSError, subprocess.TimeoutExpired):
        return False
    return r.returncode == 0 and "error" not in (r.stdout + r.stderr).lower()


def secret_delete(service: str, account: str) -> None:
    if WINDOWS:
        import pywintypes
        import win32cred
        try:
            win32cred.CredDelete(f"{account}.{service}", win32cred.CRED_TYPE_GENERIC, 0)
        except pywintypes.error:
            pass
        return
    subprocess.run(["security", "delete-generic-password", "-s", service, "-a", account],
                   capture_output=True, timeout=30)


# ---------- окно пароля ----------

def ask_login(title: str, text: str, user: str = "") -> tuple[str, str] | None:
    """Системное окно входа: логин (подставлен user, можно изменить) и пароль со скрытым вводом — вводит сам
    пользователь. (логин, пароль) или None — отмена или время вышло."""
    if WINDOWS:
        try:
            r = subprocess.run([sys.executable, __file__, "ask-login", title, user], input=text, capture_output=True,
                               text=True, encoding="utf-8", timeout=PASSWORD_WAIT + 20,
                               env={**os.environ, "PYTHONUTF8": "1"}, creationflags=subprocess.CREATE_NO_WINDOW)
        except (OSError, subprocess.TimeoutExpired):
            return None
        out = r.stdout.rstrip("\r\n")
    else:
        esc = lambda s: s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")  # noqa: E731
        common = f'with title "{esc(title)}" with icon note giving up after {PASSWORD_WAIT}'
        script = [
            f'set u to text returned of (display dialog "{esc(text)}\\n\\nЛогин:" {common} default answer "{esc(user)}" '
            'buttons {"Отмена", "Далее"} default button "Далее")',
            'if u is "" then error number -128',
            f'set p to text returned of (display dialog "Пароль для «" & u & "»:" {common} default answer "" '
            'with hidden answer buttons {"Отмена", "Войти"} default button "Войти")',
            'return u & linefeed & p',
        ]
        try:
            r = subprocess.run(["osascript", *[a for line in script for a in ("-e", line)]], capture_output=True,
                               text=True, timeout=2 * PASSWORD_WAIT + 20)
        except (OSError, subprocess.TimeoutExpired):
            return None
        out = r.stdout.rstrip("\n")
    login, _, password = out.partition("\n")
    login, password = login.strip(), password.rstrip("\r")
    return (login, password) if r.returncode == 0 and login and password else None


def _login_window(title: str, text: str, user: str) -> tuple[str, str] | None:
    """Окно tkinter (Windows): поверх остальных, логин и скрытый пароль, Enter — «Войти», Esc — «Отмена»."""
    import tkinter as tk
    from tkinter import ttk

    result: dict[str, str] = {}
    root = tk.Tk()
    root.title(title)
    root.resizable(False, False)
    root.attributes("-topmost", True)
    frame = ttk.Frame(root, padding=16)
    frame.grid()
    frame.columnconfigure(1, weight=1)  # лишняя ширина (длинное пояснение) — полям, а не колонке подписей
    ttk.Label(frame, text=text, wraplength=420, justify="left").grid(row=0, columnspan=3, sticky="w", pady=(0, 12))
    ttk.Label(frame, text="Логин").grid(row=1, column=0, sticky="w", padx=(0, 8))
    login = ttk.Entry(frame, width=36)
    login.insert(0, user)
    login.grid(row=1, column=1, columnspan=2, sticky="we", pady=4)
    ttk.Label(frame, text="Пароль").grid(row=2, column=0, sticky="w", padx=(0, 8))
    password = ttk.Entry(frame, show="•", width=36)
    password.grid(row=2, column=1, columnspan=2, sticky="we", pady=4)

    def ok(_=None) -> None:
        if not login.get().strip():
            login.focus_set()
            return
        if not password.get():
            password.focus_set()
            return
        result.update(login=login.get().strip(), pw=password.get())
        root.destroy()

    buttons = ttk.Frame(frame)
    buttons.grid(row=3, column=0, columnspan=3, sticky="e", pady=(12, 0))
    ttk.Button(buttons, text="Войти", command=ok, default="active").grid(row=0, column=0, padx=4)
    ttk.Button(buttons, text="Отмена", command=root.destroy).grid(row=0, column=1, padx=4)
    root.bind("<Return>", ok)
    root.bind("<Escape>", lambda _: root.destroy())
    root.after(PASSWORD_WAIT * 1000, root.destroy)
    root.update_idletasks()
    x = (root.winfo_screenwidth() - root.winfo_reqwidth()) // 2
    y = (root.winfo_screenheight() - root.winfo_reqheight()) // 3
    root.geometry(f"+{x}+{y}")
    root.lift()
    root.focus_force()
    (password if user else login).focus_set()  # логин подставлен — сразу к паролю
    root.mainloop()
    return (result["login"], result["pw"]) if result.get("pw") else None


# ---------- сертификаты ----------

CERTS_DIR = Path(__file__).resolve().parent / "certs"
_corp_ssl = None


def corp_ssl_context():
    """SSL-контекст: системное хранилище сертификатов (через truststore) плюс корпоративные корни из shared/certs.
    Нужен там, где сервер подписан центром, которого нет в системе: «Analytics/DWH Root CA» у Риторики на личных ПК
    (сервер свой корень не присылает). Хранилище Windows/«Связку ключей» не меняет."""
    global _corp_ssl
    if _corp_ssl is None:
        import ssl
        try:
            import truststore
            ctx = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        except ImportError:
            ctx = ssl.create_default_context()
        for cert in sorted(CERTS_DIR.glob("*.cer")):
            try:
                ctx.load_verify_locations(cafile=str(cert))
            except (OSError, ssl.SSLError):
                pass
        _corp_ssl = ctx
    return _corp_ssl


# ---------- Windows: программы и Планировщик заданий ----------

def goose_cli() -> Path:
    """Goose CLI. Windows — внутри переносимого Goose Desktop в профиле (ставит windows\\setup.ps1);
    macOS — из PATH (Homebrew), иначе внутри Goose.app (/Applications или ~/Applications)."""
    if not WINDOWS:
        import shutil
        found = shutil.which("goose")
        if found:
            return Path(found)
        for apps in (Path("/Applications"), Path.home() / "Applications"):
            cli = apps / "Goose.app" / "Contents" / "Resources" / "bin" / "goose"
            if cli.exists():
                return cli
        return Path("goose")
    programs = os.environ.get("MAGNIT_PROGRAMS") or str(Path(os.environ.get("LOCALAPPDATA", "")) / "Programs")
    return Path(programs) / "Goose" / "dist-windows" / "resources" / "bin" / "goose.exe"


TASK_FOLDER = "\\MagnitAgent\\"  # папка заданий в Планировщике (создаётся сама, права администратора не нужны)


def task_xml(triggers: str, command: str, arguments: str, workdir: str, description: str, *,
             time_limit: str = "PT2H", restart: bool = False) -> str:
    """Задание Планировщика от имени текущего пользователя (только когда он вошёл в систему, без повышения прав).
    triggers — готовые элементы <…Trigger>; time_limit PT0S — без ограничения времени."""
    from xml.sax.saxutils import escape as esc
    user = f"{os.environ.get('USERDOMAIN', '')}\\{os.environ.get('USERNAME', '')}".lstrip("\\")
    restart_xml = "<RestartOnFailure><Interval>PT1M</Interval><Count>999</Count></RestartOnFailure>" if restart else ""
    return f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Author>ИИ-помощник</Author><Description>{esc(description)}</Description></RegistrationInfo>
  <Triggers>{triggers.replace("{user}", esc(user))}</Triggers>
  <Principals><Principal id="Author"><UserId>{esc(user)}</UserId><LogonType>InteractiveToken</LogonType>
    <RunLevel>LeastPrivilege</RunLevel></Principal></Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <StartWhenAvailable>true</StartWhenAvailable>
    <ExecutionTimeLimit>{time_limit}</ExecutionTimeLimit>
    <Priority>7</Priority>{restart_xml}
  </Settings>
  <Actions Context="Author"><Exec><Command>{esc(command)}</Command><Arguments>{esc(arguments)}</Arguments>
    <WorkingDirectory>{esc(workdir)}</WorkingDirectory></Exec></Actions>
</Task>
"""


def _schtasks(*args: str) -> tuple[bool, str]:
    r = subprocess.run(["schtasks", *args], capture_output=True, encoding="oem", errors="replace",
                       creationflags=subprocess.CREATE_NO_WINDOW)
    return r.returncode == 0, (r.stdout + r.stderr).strip()


def task_install(name: str, xml: str) -> tuple[bool, str]:
    """Создать или заменить задание \\MagnitAgent\\<name>. Возвращает (успех, сообщение schtasks)."""
    import tempfile
    fd, path = tempfile.mkstemp(suffix=".xml")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(xml.encode("utf-16"))  # schtasks /XML ждёт UTF-16 с BOM
        return _schtasks("/Create", "/TN", TASK_FOLDER + name, "/XML", path, "/F")
    finally:
        os.unlink(path)


def task_delete(name: str) -> None:
    _schtasks("/Delete", "/TN", TASK_FOLDER + name, "/F")


def task_run(name: str) -> tuple[bool, str]:
    return _schtasks("/Run", "/TN", TASK_FOLDER + name)


def task_exists(name: str) -> bool:
    return _schtasks("/Query", "/TN", TASK_FOLDER + name)[0]


# ---------- Windows: переменные среды пользователя ----------

def user_env_set(values: dict[str, str | None]) -> None:
    """Переменные среды пользователя (HKCU\\Environment, как setx; None — удалить). Новые программы, запущенные из
    «Пуска» и Проводника, получают их сразу: Windows рассылает WM_SETTINGCHANGE."""
    import ctypes
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_SET_VALUE) as key:
        for name, value in values.items():
            if value is None:
                try:
                    winreg.DeleteValue(key, name)
                except FileNotFoundError:
                    pass
            else:
                winreg.SetValueEx(key, name, 0, winreg.REG_SZ, value)
    result = ctypes.c_size_t()
    ctypes.windll.user32.SendMessageTimeoutW(0xFFFF, 0x001A, 0, "Environment", 0x0002, 5000, ctypes.byref(result))


# ---------- консоль ----------

def enable_ansi() -> None:
    """Цвета ANSI в консоли Windows: старая консоль (conhost) без этого печатает коды как текст."""
    if not WINDOWS:
        return
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)  # ENABLE_VIRTUAL_TERMINAL_PROCESSING
    except (AttributeError, OSError):
        pass


# ---------- уведомления ----------

# Готовый идентификатор приложения PowerShell — без регистрации своего (для этого нужен ярлык в «Пуске»)
_TOAST_APP_ID = r"{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe"
_TOAST_SCRIPT = r"""
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
$xml = New-Object Windows.Data.Xml.Dom.XmlDocument
$xml.LoadXml('<toast><visual><binding template="ToastGeneric"><text/><text/></binding></visual></toast>')
$t = $xml.GetElementsByTagName('text')
$t.Item(0).AppendChild($xml.CreateTextNode($env:MAGNIT_TOAST_TITLE)) | Out-Null
$t.Item(1).AppendChild($xml.CreateTextNode($env:MAGNIT_TOAST_TEXT)) | Out-Null
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($env:MAGNIT_TOAST_APP).Show(
  [Windows.UI.Notifications.ToastNotification]::new($xml))
"""


def notify(title: str, text: str) -> None:
    """Всплывающее уведомление; ошибки не мешают вызывающему."""
    try:
        if WINDOWS:
            # Текст — через переменные окружения: без экранирования и подстановки в команду PowerShell
            subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command",
                            _TOAST_SCRIPT],
                           env={**os.environ, "MAGNIT_TOAST_TITLE": title, "MAGNIT_TOAST_TEXT": text[:200],
                                "MAGNIT_TOAST_APP": _TOAST_APP_ID},
                           capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
            return
        esc = lambda s: s.replace("\\", "\\\\").replace('"', '\\"')  # noqa: E731
        subprocess.run(["osascript", "-e", f'display notification "{esc(text[:200])}" with title "{esc(title)}"'],
                       capture_output=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired):
        pass


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "ask-login":
        sys.stdin.reconfigure(encoding="utf-8")
        sys.stdout.reconfigure(encoding="utf-8")
        got = _login_window(sys.argv[2], sys.stdin.read().strip(), sys.argv[3] if len(sys.argv) > 3 else "")
        if not got:
            sys.exit(1)
        sys.stdout.write(f"{got[0]}\n{got[1]}")
    else:
        sys.exit(__doc__)
