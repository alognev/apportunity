"""Реестр MCP-серверов для всех трёх агентов.

Интеграция доступна, если в .env заполнены нужные переменные (токены), и активна, если
выбрана пользователем: ENABLED_INTEGRATIONS=jira,calendar,... (пусто или нет строки — все
доступные). Неактивные интеграции не подключаются к агенту и не занимают контекст модели.
Только стандартная библиотека: модуль импортируется из разных окружений.

  python mcp_registry.py claude    — JSON-конфиг MCP для Claude Code / Agent SDK
  python mcp_registry.py allowed   — инструменты без подтверждения (через запятую)
  python mcp_registry.py status    — какие интеграции активны
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SHARED = ROOT / "shared"
PY = str(SHARED / ".venv" / "bin" / "python")
PY_ATLASSIAN = str(SHARED / ".venv-atlassian" / "bin" / "python")
LAUNCH = str(SHARED / "mcp_launch.py")
# Корпоративные сайты за QRATOR отклоняют стандартные HTTP-клиенты — агент честно представляется
USER_AGENT = "magnit-local-agent/1.0 (AI assistant)"

# Инструменты Jira/Confluence, которые видит модель (без удаления и администрирования)
JIRA_READ = [
    "jira_search", "jira_get_issue", "jira_get_user_profile", "jira_get_all_projects",
    "jira_search_projects", "jira_get_project_issue_types", "jira_get_create_fields",
    "jira_get_transitions", "jira_search_fields", "jira_get_field_options", "jira_get_link_types",
    "jira_get_agile_boards", "jira_get_board_issues", "jira_get_sprints_from_board",
    "jira_get_sprint_issues", "jira_get_worklog", "jira_download_attachments",
    "jira_search_assignable_users", "jira_get_project_versions", "jira_get_project_components",
]
JIRA_WRITE = [
    "jira_create_issue", "jira_update_issue", "jira_add_comment", "jira_transition_issue",
    "jira_assign_issue", "jira_create_issue_link", "jira_link_to_epic", "jira_add_worklog",
]
CONFLUENCE_READ = [
    "confluence_search", "confluence_get_page", "confluence_get_page_children",
    "confluence_get_space_page_tree", "confluence_get_comments", "confluence_get_labels",
    "confluence_get_attachments", "confluence_download_attachment", "confluence_get_page_history",
    "confluence_search_user",
]
CONFLUENCE_WRITE = [
    "confluence_create_page", "confluence_update_page", "confluence_add_comment", "confluence_add_label",
]

# Облачный Atlassian MCP (AI Lab): одно подключение на контур — Jira + Confluence вместе.
# Инструменты фильтрует локальный мост (mcp_launch.py): компактный набор по умолчанию, без удаления.
ATLASSIAN_MCP_URL = "https://mcp-atlassian.ailab-copilot-prod.corp.tander.ru/mcp"
ATLASSIAN_COMPACT = [
    "jira_search", "jira_get_issue", "jira_get_transitions", "jira_get_user_profile", "jira_get_project_issue_types",
    "jira_create_issue", "jira_update_issue", "jira_add_comment", "jira_transition_issue",
    "confluence_search", "confluence_get_page", "confluence_get_page_children", "confluence_get_comments",
    "confluence_add_comment", "confluence_create_page", "confluence_update_page",
]
# Контур облачного подключения: (переменные Jira, переменные Confluence)
ATLASSIAN_CONTOURS = {
    "atlassian": (("JIRA_URL", "JIRA_TOKEN"), ("CONFLUENCE_EPORTAL_URL", "CONFLUENCE_EPORTAL_TOKEN")),
    "atlassian-it": (("JIRA_IT_URL", "JIRA_IT_TOKEN"), ("CONFLUENCE_IT_URL", "CONFLUENCE_IT_TOKEN")),
}


# Облачный GitLab MCP (AI Lab): отдельный сервер на каждый инстанс GitLab.
GITLAB_INSTANCES = {  # имя: (URL MCP-сервера, переменная с токеном, адрес GitLab)
    "gitlab": ("https://mcp-gitlab.ailab-copilot-prod.corp.tander.ru/mcp", "GITLAB_TOKEN",
               "https://coderepo.corp.tander.ru"),
    "gitlab-platform": ("https://mcp-gitlab-platform.ailab-copilot-prod.corp.tander.ru/mcp", "GITLAB_PLATFORM_TOKEN",
                        "https://gitlab.platform.corp"),
}
GITLAB_READ = [
    "search_repositories", "list_projects", "get_project", "get_repository_tree", "get_file_contents",
    "list_branches", "get_branch", "get_branch_diffs", "list_commits", "get_commit", "get_commit_diff",
    "list_merge_requests", "get_merge_request", "list_merge_request_diffs", "list_issues", "get_issue",
    "get_merge_request_notes", "mr_discussions", "get_merge_request_approval_state",
]
GITLAB_COMPACT = GITLAB_READ + ["create_note", "create_merge_request_note", "approve_merge_request",
                                "unapprove_merge_request"]


def gitlab_tools(env: dict[str, str]) -> list[str] | None:
    """Инструменты GitLab: compact (по умолчанию) или None — все из групп GITLAB_GROUPS (кроме удаления)."""
    if (env.get("GITLAB_PROFILE") or "compact").strip().lower() == "full":
        return None
    return GITLAB_COMPACT


def atlassian_tools(env: dict[str, str]) -> list[str]:
    """Инструменты облачного Atlassian MCP: compact (по умолчанию) или full — как у локального сервера."""
    if (env.get("ATLASSIAN_PROFILE") or "compact").strip().lower() == "full":
        return JIRA_READ + JIRA_WRITE + CONFLUENCE_READ + CONFLUENCE_WRITE
    return ATLASSIAN_COMPACT


DATABASES_FILE = ROOT / "databases.toml"  # личный список баз для DBHub (пароли — не попадает в архив)
DBHUB_BIN = SHARED / ".dbhub" / "node_modules" / ".bin" / "dbhub"


def database_sources() -> list[dict]:
    """Базы из databases.toml: [{"id", "dsn", "description"}]."""
    if not DATABASES_FILE.exists():
        return []
    try:
        import tomllib
        return [s for s in tomllib.loads(DATABASES_FILE.read_text()).get("sources", []) if s.get("id") and s.get("dsn")]
    except Exception:  # noqa: BLE001 — Python < 3.11 или ошибка в файле
        return []


# name: (python, обязательные переменные .env (кортеж — любая из), инструменты без подтверждения или "*")
SERVERS: dict[str, tuple[str, list, list[str] | str]] = {
    "magnit-files": (PY, [], "*"),
    "web": (PY, [], "*"),
    "knowledge": (PY, [], ["kb_list", "kb_search", "kb_read"]),
    "calendar": (PY, [], ["calendar_list_events", "calendar_get_event", "calendar_find_free_time",
                          "calendar_whoami"]),
    "mail": (PY, [], ["mail_folders", "mail_list", "mail_search", "mail_get"]),  # только чтение
    "scheduler": (PY, [], ["automation_list", "automation_history"]),
    "atlassian": (PY, [("JIRA_TOKEN", "CONFLUENCE_EPORTAL_TOKEN")], JIRA_READ + CONFLUENCE_READ),
    "atlassian-it": (PY, [("JIRA_IT_TOKEN", "CONFLUENCE_IT_TOKEN")], JIRA_READ + CONFLUENCE_READ),
    "gitlab": (PY, ["GITLAB_TOKEN"], GITLAB_READ),
    "gitlab-platform": (PY, ["GITLAB_PLATFORM_TOKEN"], GITLAB_READ),
    "dbhub": (PY, ["@databases"], "*"),  # только чтение (SELECT), подтверждение не нужно
    "jira": (PY_ATLASSIAN, ["JIRA_URL", "JIRA_TOKEN"], JIRA_READ),
    "jira-it": (PY_ATLASSIAN, ["JIRA_IT_URL", "JIRA_IT_TOKEN"], JIRA_READ),
    "confluence-it": (PY_ATLASSIAN, ["CONFLUENCE_IT_URL", "CONFLUENCE_IT_TOKEN"], CONFLUENCE_READ),
    "confluence-eportal": (PY_ATLASSIAN, ["CONFLUENCE_EPORTAL_URL", "CONFLUENCE_EPORTAL_TOKEN"],
                           CONFLUENCE_READ),
    "tag": (PY, ["TAG_URL", ("TAG_TOKEN", "TAG_BOT_TOKEN", "TAG_WEBHOOK_URL")], ["tag_whoami", "tag_find_users", "tag_find_channels",
                                           "tag_read_messages", "tag_search_messages"]),
    "magnitgpt": (PY, ["MAGNITGPT_URL", "MAGNITGPT_API_KEY"], ["magnitgpt_list_knowledge",
                  "magnitgpt_search_knowledge", "magnitgpt_list_notes", "magnitgpt_get_note",
                  "magnitgpt_transcribe_audio"]),
}


# Названия для пользователя (установщик, веб-помощник) и примерный объём описаний инструментов
# в токенах, который модель получает в каждом запросе (замерено по схемам инструментов).
TITLES = {
    "magnit-files": "Файлы: Excel, PDF, Word, картинки, сканы",
    "knowledge": "Локальные базы знаний (поиск по документам)",
    "web": "Поиск в интернете",
    "calendar": "Календарь Outlook",
    "mail": "Почта Outlook (только чтение)",
    "scheduler": "Автоматизации по расписанию",
    "atlassian": "Jira + Confluence ОМНИ (облако): track, eportal",
    "atlassian-it": "Jira + Confluence IT (облако): jira.corp, IT-портал",
    "gitlab": "GitLab coderepo.corp.tander.ru (облако)",
    "gitlab-platform": "GitLab gitlab.platform.corp (облако)",
    "dbhub": "Базы данных (DBHub, только чтение)",
    "jira": "Jira track.magnit.ru (локально, резерв)",
    "jira-it": "Jira jira.corp.tander.ru (локально, резерв)",
    "confluence-it": "Confluence IT-портал (локально, резерв)",
    "confluence-eportal": "Confluence eportal (локально, резерв)",
    "tag": "Tag (сообщения)",
    "magnitgpt": "MagnitGPT (протоколы встреч, ASR)",
}
CONTEXT_TOKENS: dict[str, int] = {
    "magnit-files": 700, "web": 560, "knowledge": 900, "calendar": 1670, "mail": 940, "scheduler": 970,
    "atlassian": 9050, "atlassian-it": 9050, "gitlab": 7170, "gitlab-platform": 7170, "dbhub": 560,  # компактный профиль, Jira + Confluence контура
    "jira": 10400, "jira-it": 10400, "confluence-it": 6000, "confluence-eportal": 6000,
    "tag": 1050, "magnitgpt": 710,
}
ALWAYS_ON = {"magnit-files"}  # без него агент не прочитает Excel, PDF и картинки
# Выключены, пока пользователь не включит их сам: локальные Jira/Confluence — резерв облачного MCP;
# почта — личная переписка и тексты от внешних отправителей, включается осознанно
DEFAULT_OFF = {"jira", "jira-it", "confluence-it", "confluence-eportal", "gitlab", "gitlab-platform", "dbhub", "mail"}
DEFAULTS_VERSION = "4"  # меняется при изменении умолчаний — Goose применит их заново


def load_env() -> dict[str, str]:
    env: dict[str, str] = {}
    path = ROOT / ".env"
    if path.exists():
        for line in path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip().strip('"').strip("'")
    return {**env, **{k: v for k, v in os.environ.items() if k in env and v}}


def available(env: dict[str, str] | None = None) -> list[str]:
    """Интеграции, для которых есть всё нужное (токены), — их можно включить."""
    env = env if env is not None else load_env()

    def ok(req) -> bool:
        if req == "@databases":
            return DBHUB_BIN.exists() and bool(database_sources())
        return any(env.get(k) for k in req) if isinstance(req, tuple) else bool(env.get(req))

    return [name for name, (_, required, _) in SERVERS.items() if all(ok(r) for r in required)]


def selection(env: dict[str, str] | None = None) -> set[str] | None:
    """Выбор пользователя из ENABLED_INTEGRATIONS; None — выбор не задан (активно всё доступное)."""
    env = env if env is not None else load_env()
    raw = env.get("ENABLED_INTEGRATIONS", "").strip()
    return {x.strip() for x in raw.split(",") if x.strip()} if raw else None


def enabled(env: dict[str, str] | None = None) -> list[str]:
    """Активные интеграции: доступные и выбранные пользователем."""
    env = env if env is not None else load_env()
    chosen = selection(env)
    if chosen is None:
        return [n for n in available(env) if n not in DEFAULT_OFF]
    return [n for n in available(env) if n in chosen or n in ALWAYS_ON]


def save_selection(names) -> str:
    """Записать выбор в .env (ENABLED_INTEGRATIONS=...), вернуть записанное значение."""
    path = ROOT / ".env"
    lines = path.read_text().splitlines() if path.exists() else []
    value = ",".join(n for n in SERVERS if n in set(names) | ALWAYS_ON)
    for i, line in enumerate(lines):
        if line.startswith("ENABLED_INTEGRATIONS="):
            lines[i] = f"ENABLED_INTEGRATIONS={value}"
            break
    else:
        lines += ["", "# Активные интеграции (остальные не подключаются и не занимают контекст модели).",
                  "# Изменить: ./setup.sh --tools, в Goose — «Расширения», в веб-помощнике — панель «Инструменты».",
                  f"ENABLED_INTEGRATIONS={value}"]
    path.write_text("\n".join(lines) + "\n")
    return value


def claude_config(env: dict[str, str] | None = None) -> dict:
    return {"mcpServers": {
        name: {"type": "stdio", "command": SERVERS[name][0], "args": [LAUNCH, name]}
        for name in enabled(env)
    }}


def auto_allowed(env: dict[str, str] | None = None) -> list[str]:
    """Имена инструментов в формате Claude (mcp__server__tool), которые не требуют подтверждения."""
    result = []
    for name in enabled(env):
        tools = SERVERS[name][2]
        if tools == "*":
            result.append(f"mcp__{name}")
        else:
            result.extend(f"mcp__{name}__{t}" for t in tools)
    return result


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "claude":
        print(json.dumps(claude_config(), ensure_ascii=False))
    elif cmd == "allowed":
        print(",".join(auto_allowed()))
    else:
        on, avail = enabled(), available()
        for name in SERVERS:
            state = "✓ активна" if name in on else ("○ выключена" if name in avail else "· не настроена")
            print(f"  {state:15} {TITLES[name]}")
