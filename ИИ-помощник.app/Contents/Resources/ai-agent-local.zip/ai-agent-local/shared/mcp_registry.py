"""Реестр MCP-серверов для всех трёх агентов.

Интеграция доступна, если в .env заполнены нужные переменные (токены), и активна, если
выбрана пользователем: ENABLED_INTEGRATIONS=jira,calendar,... (пусто или нет строки — все
доступные). Неактивные интеграции не подключаются к агенту и не занимают контекст модели.
Только стандартная библиотека: модуль импортируется из разных окружений.

  python mcp_registry.py claude    — JSON-конфиг MCP для Claude Code / Agent SDK
  python mcp_registry.py allowed   — инструменты без подтверждения (через запятую)
  python mcp_registry.py status    — какие интеграции активны
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SHARED = ROOT / "shared"
PY = str(SHARED / ".venv" / "bin" / "python")
PY_ATLASSIAN = str(SHARED / ".venv-atlassian" / "bin" / "python")
LAUNCH = str(SHARED / "mcp_launch.py")
# Корпоративные сайты за QRATOR отклоняют стандартные HTTP-клиенты — агент честно представляется
USER_AGENT = "magnit-local-agent/1.0 (AI assistant)"

# Инструменты Jira/Confluence, которые видит модель (без удаления и администрирования)
JIRA_READ = [
    "jira_search", "jira_get_issue", "jira_get_user_profile", "jira_get_all_projects",
    "jira_search_projects", "jira_get_project_issue_types", "jira_get_create_fields",
    "jira_get_transitions", "jira_search_fields", "jira_get_field_options", "jira_get_link_types",
    "jira_get_agile_boards", "jira_get_board_issues", "jira_get_sprints_from_board",
    "jira_get_sprint_issues", "jira_get_worklog", "jira_download_attachments",
    "jira_search_assignable_users", "jira_get_project_versions", "jira_get_project_components",
]
JIRA_WRITE = [
    "jira_create_issue", "jira_update_issue", "jira_add_comment", "jira_transition_issue",
    "jira_assign_issue", "jira_create_issue_link", "jira_link_to_epic", "jira_add_worklog",
]
CONFLUENCE_READ = [
    "confluence_search", "confluence_get_page", "confluence_get_page_children",
    "confluence_get_space_page_tree", "confluence_get_comments", "confluence_get_labels",
    "confluence_get_attachments", "confluence_download_attachment", "confluence_get_page_history",
    "confluence_search_user",
]
CONFLUENCE_WRITE = [
    "confluence_create_page", "confluence_update_page", "confluence_add_comment", "confluence_add_label",
]

# Облачный Atlassian MCP (AI Lab): одно подключение на контур — Jira + Confluence вместе.
# Инструменты фильтрует локальный мост (mcp_launch.py): компактный набор по умолчанию, без удаления.
ATLASSIAN_MCP_URL = "https://mcp-atlassian.ailab-copilot-prod.corp.tander.ru/mcp"
ATLASSIAN_COMPACT = [
    "jira_search", "jira_get_issue", "jira_get_transitions", "jira_get_user_profile", "jira_get_project_issue_types",
    "jira_create_issue", "jira_update_issue", "jira_add_comment", "jira_transition_issue",
    "confluence_search", "confluence_get_page", "confluence_get_page_children", "confluence_get_comments",
    "confluence_add_comment", "confluence_create_page", "confluence_update_page",
]
# Контур облачного подключения: (переменные Jira, переменные Confluence)
ATLASSIAN_CONTOURS = {
    "atlassian": (("JIRA_URL", "JIRA_TOKEN"), ("CONFLUENCE_EPORTAL_URL", "CONFLUENCE_EPORTAL_TOKEN")),
    "atlassian-it": (("JIRA_IT_URL", "JIRA_IT_TOKEN"), ("CONFLUENCE_IT_URL", "CONFLUENCE_IT_TOKEN")),
}


# Облачный GitLab MCP (AI Lab): отдельный сервер на каждый инстанс GitLab.
GITLAB_INSTANCES = {  # имя: (URL MCP-сервера, переменная с токеном, адрес GitLab)
    "gitlab": ("https://mcp-gitlab.ailab-copilot-prod.corp.tander.ru/mcp", "GITLAB_TOKEN",
               "https://coderepo.corp.tander.ru"),
    "gitlab-platform": ("https://mcp-gitlab-platform.ailab-copilot-prod.corp.tander.ru/mcp", "GITLAB_PLATFORM_TOKEN",
                        "https://gitlab.platform.corp"),
}
GITLAB_READ = [
    "search_repositories", "list_projects", "get_project", "get_repository_tree", "get_file_contents",
    "list_branches", "get_branch", "get_branch_diffs", "list_commits", "get_commit", "get_commit_diff",
    "list_merge_requests", "get_merge_request", "list_merge_request_diffs", "list_issues", "get_issue",
    "get_merge_request_notes", "mr_discussions", "get_merge_request_approval_state",
]
GITLAB_COMPACT = GITLAB_READ + ["create_note", "create_merge_request_note", "approve_merge_request",
                                "unapprove_merge_request"]


def gitlab_tools(env: dict[str, str]) -> list[str] | None:
    """Инструменты GitLab: compact (по умолчанию) или None — все из групп GITLAB_GROUPS (кроме удаления)."""
    if (env.get("GITLAB_PROFILE") or "compact").strip().lower() == "full":
        return None
    return GITLAB_COMPACT


def atlassian_tools(env: dict[str, str]) -> list[str]:
    """Инструменты облачного Atlassian MCP: compact (по умолчанию) или full — как у локального сервера."""
    if (env.get("ATLASSIAN_PROFILE") or "compact").strip().lower() == "full":
        return JIRA_READ + JIRA_WRITE + CONFLUENCE_READ + CONFLUENCE_WRITE
    return ATLASSIAN_COMPACT


DATABASES_FILE = ROOT / "databases.toml"  # личный список баз для DBHub (пароли — не попадает в архив)
DBHUB_BIN = SHARED / ".dbhub" / "node_modules" / ".bin" / "dbhub"


def database_sources() -> list[dict]:
    """Базы из databases.toml: [{"id", "dsn", "description"}]."""
    if not DATABASES_FILE.exists():
        return []
    try:
        import tomllib
        return [s for s in tomllib.loads(DATABASES_FILE.read_text()).get("sources", []) if s.get("id") and s.get("dsn")]
    except Exception:  # noqa: BLE001 — Python < 3.11 или ошибка в файле
        return []


# name: (python, обязательные переменные .env (кортеж — любая из), инструменты без подтверждения или "*")
SERVERS: dict[str, tuple[str, list, list[str] | str]] = {
    "magnit-files": (PY, [], "*"),
    "web": (PY, [], "*"),
    "knowledge": (PY, [], ["kb_list", "kb_search", "kb_read"]),
    "calendar": (PY, [], ["calendar_list_events", "calendar_get_event", "calendar_find_free_time",
                          "calendar_whoami"]),
    "mail": (PY, [], ["mail_folders", "mail_list", "mail_search", "mail_get"]),  # только чтение
    "scheduler": (PY, [], ["automation_list", "automation_history"]),
    # Magnit Drive (Nextcloud): вход через браузер при первом обращении, токена в .env не нужно
    "drive": (PY, [], ["drive_status", "drive_login", "drive_list", "drive_search", "drive_specs", "drive_read",
                       "drive_download"]),
    "atlassian": (PY, [("JIRA_TOKEN", "CONFLUENCE_EPORTAL_TOKEN")], JIRA_READ + CONFLUENCE_READ),
    "atlassian-it": (PY, [("JIRA_IT_TOKEN", "CONFLUENCE_IT_TOKEN")], JIRA_READ + CONFLUENCE_READ),
    "gitlab": (PY, ["GITLAB_TOKEN"], GITLAB_READ),
    "gitlab-platform": (PY, ["GITLAB_PLATFORM_TOKEN"], GITLAB_READ),
    "dbhub": (PY, ["@databases"], "*"),  # только чтение (SELECT), подтверждение не нужно
    "jira": (PY_ATLASSIAN, ["JIRA_URL", "JIRA_TOKEN"], JIRA_READ),
    "jira-it": (PY_ATLASSIAN, ["JIRA_IT_URL", "JIRA_IT_TOKEN"], JIRA_READ),
    "confluence-it": (PY_ATLASSIAN, ["CONFLUENCE_IT_URL", "CONFLUENCE_IT_TOKEN"], CONFLUENCE_READ),
    "confluence-eportal": (PY_ATLASSIAN, ["CONFLUENCE_EPORTAL_URL", "CONFLUENCE_EPORTAL_TOKEN"],
                           CONFLUENCE_READ),
    "tag": (PY, ["TAG_URL", ("TAG_TOKEN", "TAG_BOT_TOKEN", "TAG_WEBHOOK_URL")], ["tag_whoami", "tag_find_users", "tag_find_channels",
                                           "tag_read_messages", "tag_search_messages"]),
    "magnitgpt": (PY, ["MAGNITGPT_URL", "MAGNITGPT_API_KEY"], ["magnitgpt_list_knowledge",
                  "magnitgpt_search_knowledge", "magnitgpt_list_notes", "magnitgpt_get_note",
                  "magnitgpt_transcribe_audio"]),
}


# Названия для пользователя (установщик, веб-помощник) и примерный объём описаний инструментов
# в токенах, который модель получает в каждом запросе (замерено по схемам инструментов).
TITLES = {
    "magnit-files": "Файлы: Excel, PDF, Word, картинки, сканы",
    "knowledge": "Локальные базы знаний (поиск по документам)",
    "web": "Поиск в интернете",
    "calendar": "Календарь Outlook",
    "mail": "Почта Outlook (только чтение)",
    "scheduler": "Автоматизации по расписанию",
    "drive": "Magnit Drive: общая папка и спеки",
    "atlassian": "Jira + Confluence ОМНИ (облако): track, eportal",
    "atlassian-it": "Jira + Confluence IT (облако): jira.corp, IT-портал",
    "gitlab": "GitLab coderepo.corp.tander.ru (облако)",
    "gitlab-platform": "GitLab gitlab.platform.corp (облако)",
    "dbhub": "Базы данных (DBHub, только чтение)",
    "jira": "Jira track.magnit.ru (локально, резерв)",
    "jira-it": "Jira jira.corp.tander.ru (локально, резерв)",
    "confluence-it": "Confluence IT-портал (локально, резерв)",
    "confluence-eportal": "Confluence eportal (локально, резерв)",
    "tag": "Tag (сообщения)",
    "magnitgpt": "MagnitGPT (протоколы встреч, ASR)",
}
# Что даёт инструмент, простыми словами (10–30 слов): показывается при выборе инструментов (приложение, установщик)
# и попадает в описание расширения Goose — по нему Extension Manager находит выключенный инструмент, если он нужен.
DESCRIPTIONS = {
    "magnit-files": "Читает Excel, PDF, Word, PowerPoint, картинки и сканы, создаёт отчёты и таблицы. Включён всегда.",
    "web": "Ищет и читает страницы в интернете: новости, документацию, справочные сведения, которых нет "
           "во внутренних системах компании.",
    "knowledge": "Поиск по вашим папкам с документами — регламентам, договорам, инструкциям. Находит ответ по смыслу "
                 "и даёт ссылку на файл; документы не покидают компьютер.",
    "calendar": "Показывает ваши встречи, ищет общее свободное время с коллегами, создаёт встречи и отвечает "
                "на приглашения — после вашего подтверждения.",
    "mail": "Разбирает непрочитанные письма, находит письма и вложения, готовит текст ответа. Письма не отправляет "
            "и не помечает прочитанными.",
    "scheduler": "Помощник сам выполняет задание в нужное время без вашего участия — например, каждое утро присылает "
                 "в Tag сводку встреч.",
    "drive": "Magnit Drive (drive.magnit.ru): общая папка команды MCOS со спеками для помощника — найти и прочитать "
             "спеку, скачать выгрузку, сохранить отчёт или новую спеку. Вход корпоративной учётной записью в браузере.",
    "atlassian": "Jira и Confluence контура ОМНИ (track.magnit.ru и eportal): найти и создать задачу, комментарии, "
                 "статусы, поиск и правка страниц со ссылками.",
    "atlassian-it": "Jira и Confluence IT-контура (jira.corp.tander.ru и IT-портал): задачи, комментарии, статусы, "
                    "поиск по технической документации и регламентам IT.",
    "gitlab": "GitLab coderepo.corp.tander.ru: поиск по коду и репозиториям, ветки, коммиты, ревью merge request "
              "и комментарии. Нужен тем, кто работает с кодом.",
    "gitlab-platform": "GitLab gitlab.platform.corp: код, ветки, коммиты, ревью merge request и комментарии "
                       "в платформенном GitLab. Нужен тем, кто работает с кодом.",
    "dbhub": "Базы данных: помощник сам изучает структуру, пишет SQL-запросы и отвечает цифрами и таблицами. "
             "Только чтение — изменить данные нельзя.",
    "jira": "Резервное прямое подключение к Jira track.magnit.ru без облачного сервиса. Включайте, только если "
            "облачный вариант недоступен: занимает много памяти помощника.",
    "jira-it": "Резервное прямое подключение к Jira jira.corp.tander.ru без облачного сервиса. Включайте, только "
               "если облачный вариант недоступен.",
    "confluence-it": "Резервное прямое подключение к Confluence IT-портала без облачного сервиса. Включайте, только "
                     "если облачный вариант недоступен.",
    "confluence-eportal": "Резервное прямое подключение к Confluence eportal без облачного сервиса. Включайте, "
                          "только если облачный вариант недоступен.",
    "tag": "Tag: помощник присылает вам итоги, отчёты и результаты автоматизаций; с ботом — пишет коллегам "
           "и в каналы, читает сообщения.",
    "magnitgpt": "MagnitGPT: протоколы встреч от бота «Запись встреч», базы знаний Knowledge и распознавание "
                 "аудиозаписей в текст.",
}
CONTEXT_TOKENS: dict[str, int] = {
    "magnit-files": 700, "web": 560, "knowledge": 900, "calendar": 1670, "mail": 940, "scheduler": 970, "drive": 2000,
    "atlassian": 9050, "atlassian-it": 9050, "gitlab": 7170, "gitlab-platform": 7170, "dbhub": 560,  # компактный профиль, Jira + Confluence контура
    "jira": 10400, "jira-it": 10400, "confluence-it": 6000, "confluence-eportal": 6000,
    "tag": 1050, "magnitgpt": 710,
}
ALWAYS_ON = {"magnit-files"}  # без него агент не прочитает Excel, PDF и картинки
# Выключены, пока пользователь не включит их сам. Тяжёлые (облачные Jira+Confluence ~9 тыс. токенов на контур, GitLab ~7 тыс.)
# Goose включает сам по необходимости через Extension Manager — они записаны в его настройки выключенными, с описанием.
# По умолчанию включены только интернет, локальные базы знаний и автоматизации (+ файлы — всегда); остальное Goose
# включает сам, когда запрос этого требует.
DEFAULT_ON = {"web", "knowledge", "scheduler"}
DEFAULT_OFF = set(SERVERS) - DEFAULT_ON - ALWAYS_ON
DEFAULTS_VERSION = "7"  # меняется при изменении умолчаний — Goose применит их заново
# Скрыты везде (установщик, приложение, веб-чат, Goose): локальный mcp-atlassian — резерв облачного MCP. Код сохранён;
# вернуть — SHOW_LOCAL_ATLASSIAN=1 в .env.
HIDDEN = {"jira", "jira-it", "confluence-it", "confluence-eportal"}


def visible(env: dict[str, str] | None = None) -> list[str]:
    """Интеграции, которые показываются пользователю (все, кроме скрытых)."""
    env = env if env is not None else load_env()
    show_hidden = env.get("SHOW_LOCAL_ATLASSIAN", "").strip().lower() in ("1", "true", "yes")
    return [n for n in SERVERS if show_hidden or n not in HIDDEN]


def load_env() -> dict[str, str]:
    env: dict[str, str] = {}
    path = ROOT / ".env"
    if path.exists():
        for line in path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip().strip('"').strip("'")
    return {**env, **{k: v for k, v in os.environ.items() if k in env and v}}


def available(env: dict[str, str] | None = None) -> list[str]:
    """Интеграции, для которых есть всё нужное (токены), — их можно включить."""
    env = env if env is not None else load_env()

    def ok(req) -> bool:
        if req == "@databases":
            return DBHUB_BIN.exists() and bool(database_sources())
        return any(env.get(k) for k in req) if isinstance(req, tuple) else bool(env.get(req))

    shown = set(visible(env))
    return [name for name, (_, required, _) in SERVERS.items() if name in shown and all(ok(r) for r in required)]


def selection(env: dict[str, str] | None = None) -> set[str] | None:
    """Выбор пользователя из ENABLED_INTEGRATIONS; None — выбор не задан (активно всё доступное)."""
    env = env if env is not None else load_env()
    raw = env.get("ENABLED_INTEGRATIONS", "").strip()
    return {x.strip() for x in raw.split(",") if x.strip()} if raw else None


def enabled(env: dict[str, str] | None = None) -> list[str]:
    """Активные интеграции: доступные и выбранные пользователем."""
    env = env if env is not None else load_env()
    if os.environ.get("MAGNIT_ALL_INTEGRATIONS") == "1":
        # автоматизации по расписанию: без человека включить инструмент некому — даём все подключённые
        return available(env)
    chosen = selection(env)
    if chosen is None:
        return [n for n in available(env) if n not in DEFAULT_OFF]
    return [n for n in available(env) if n in chosen or n in ALWAYS_ON]


def save_selection(names) -> str:
    """Записать выбор в .env (ENABLED_INTEGRATIONS=...), вернуть записанное значение."""
    path = ROOT / ".env"
    lines = path.read_text().splitlines() if path.exists() else []
    value = ",".join(n for n in SERVERS if n in set(names) | ALWAYS_ON)
    for i, line in enumerate(lines):
        if line.startswith("ENABLED_INTEGRATIONS="):
            lines[i] = f"ENABLED_INTEGRATIONS={value}"
            break
    else:
        lines += ["", "# Активные интеграции (остальные не подключаются и не занимают контекст модели).",
                  "# Изменить: ./setup.sh --tools, в Goose — «Расширения», в веб-помощнике — панель «Инструменты».",
                  f"ENABLED_INTEGRATIONS={value}"]
    path.write_text("\n".join(lines) + "\n")
    return value


def claude_config(env: dict[str, str] | None = None) -> dict:
    return {"mcpServers": {
        name: {"type": "stdio", "command": SERVERS[name][0], "args": [LAUNCH, name]}
        for name in enabled(env)
    }}


def auto_allowed(env: dict[str, str] | None = None) -> list[str]:
    """Имена инструментов в формате Claude (mcp__server__tool), которые не требуют подтверждения."""
    result = []
    for name in enabled(env):
        tools = SERVERS[name][2]
        if tools == "*":
            result.append(f"mcp__{name}")
        else:
            result.extend(f"mcp__{name}__{t}" for t in tools)
    return result


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "claude":
        print(json.dumps(claude_config(), ensure_ascii=False))
    elif cmd == "allowed":
        print(",".join(auto_allowed()))
    else:
        on, avail = enabled(), available()
        for name in visible():
            state = "✓ активна" if name in on else ("○ выключена" if name in avail else "· не настроена")
            print(f"  {state:15} {TITLES[name]}")
