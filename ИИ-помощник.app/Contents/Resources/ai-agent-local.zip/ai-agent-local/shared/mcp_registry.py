"""Реестр MCP-серверов для всех трёх агентов.

Интеграция доступна, если в .env заполнены нужные переменные (токены), и активна, если
выбрана пользователем: ENABLED_INTEGRATIONS=jira,calendar,... (пусто или нет строки — все
доступные). Неактивные интеграции не подключаются к агенту и не занимают контекст модели.
Только стандартная библиотека: модуль импортируется из разных окружений.

  python mcp_registry.py claude    — JSON-конфиг MCP для Claude Code / Agent SDK
  python mcp_registry.py allowed   — инструменты без подтверждения (через запятую)
  python mcp_registry.py status    — какие интеграции активны
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SHARED = ROOT / "shared"


def venv_python(venv: Path) -> Path:
    """Python виртуального окружения: macOS — bin/python, Windows — Scripts\\python.exe."""
    return venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


PY = str(venv_python(SHARED / ".venv"))
PY_ATLASSIAN = str(venv_python(SHARED / ".venv-atlassian"))
LAUNCH = str(SHARED / "mcp_launch.py")
# Модель по умолчанию. Установки, где LLM_MODEL всё ещё прежнее умолчание (OLD_DEFAULT_MODELS), переводятся на новое
# при настройке Goose (configure.py); выбранная пользователем своя модель не меняется.
# 2026-10: основная MagnitCopilot (GLM-5.2) недоступна — по умолчанию MagnitCopilot-Small.
DEFAULT_LLM_MODEL = "MagnitCopilot-Small"
OLD_DEFAULT_MODELS = {"MagnitCopilot"}
# Корпоративные сайты за QRATOR отклоняют стандартные HTTP-клиенты — агент честно представляется
USER_AGENT = "magnit-local-agent/1.0 (AI assistant)"

# Инструменты Jira/Confluence, которые видит модель (без удаления и администрирования)
JIRA_READ = [
    "jira_search", "jira_get_issue", "jira_get_user_profile", "jira_get_all_projects",
    "jira_search_projects", "jira_get_project_issue_types", "jira_get_create_fields",
    "jira_get_transitions", "jira_search_fields", "jira_get_field_options", "jira_get_link_types",
    "jira_get_agile_boards", "jira_get_board_issues", "jira_get_sprints_from_board",
    "jira_get_sprint_issues", "jira_get_worklog", "jira_download_attachments",
    "jira_search_assignable_users", "jira_get_project_versions", "jira_get_project_components",
]
JIRA_WRITE = [
    "jira_create_issue", "jira_update_issue", "jira_add_comment", "jira_transition_issue",
    "jira_assign_issue", "jira_create_issue_link", "jira_link_to_epic", "jira_add_worklog",
]
CONFLUENCE_READ = [
    "confluence_search", "confluence_get_page", "confluence_get_page_children",
    "confluence_get_space_page_tree", "confluence_get_comments", "confluence_get_labels",
    "confluence_get_attachments", "confluence_download_attachment", "confluence_get_page_history",
    "confluence_search_user",
]
CONFLUENCE_WRITE = [
    "confluence_create_page", "confluence_update_page", "confluence_add_comment", "confluence_add_label",
]

# Облачный Atlassian MCP (AI Lab): одно подключение на контур — Jira + Confluence вместе.
# Инструменты фильтрует локальный мост (mcp_launch.py): компактный набор по умолчанию, без удаления.
ATLASSIAN_MCP_URL = "https://mcp-atlassian.ailab-copilot-prod.corp.tander.ru/mcp"
ATLASSIAN_COMPACT = [
    "jira_search", "jira_get_issue", "jira_get_transitions", "jira_get_user_profile", "jira_get_project_issue_types",
    "jira_create_issue", "jira_update_issue", "jira_add_comment", "jira_transition_issue",
    "confluence_search", "confluence_get_page", "confluence_get_page_children", "confluence_get_comments",
    "confluence_add_comment", "confluence_create_page", "confluence_update_page",
]
# Контур облачного подключения: (переменные Jira, переменные Confluence)
ATLASSIAN_CONTOURS = {
    "atlassian": (("JIRA_URL", "JIRA_TOKEN"), ("CONFLUENCE_EPORTAL_URL", "CONFLUENCE_EPORTAL_TOKEN")),
    "atlassian-it": (("JIRA_IT_URL", "JIRA_IT_TOKEN"), ("CONFLUENCE_IT_URL", "CONFLUENCE_IT_TOKEN")),
}


# Облачный GitLab MCP (AI Lab): отдельный сервер на каждый инстанс GitLab.
GITLAB_INSTANCES = {  # имя: (URL MCP-сервера, переменная с токеном, адрес GitLab)
    "gitlab": ("https://mcp-gitlab.ailab-copilot-prod.corp.tander.ru/mcp", "GITLAB_TOKEN",
               "https://coderepo.corp.tander.ru"),
    "gitlab-platform": ("https://mcp-gitlab-platform.ailab-copilot-prod.corp.tander.ru/mcp", "GITLAB_PLATFORM_TOKEN",
                        "https://gitlab.platform.corp"),
}
GITLAB_READ = [
    "search_repositories", "list_projects", "get_project", "get_repository_tree", "get_file_contents",
    "list_branches", "get_branch", "get_branch_diffs", "list_commits", "get_commit", "get_commit_diff",
    "list_merge_requests", "get_merge_request", "list_merge_request_diffs", "list_issues", "get_issue",
    "get_merge_request_notes", "mr_discussions", "get_merge_request_approval_state",
]
GITLAB_COMPACT = GITLAB_READ + ["create_note", "create_merge_request_note", "approve_merge_request",
                                "unapprove_merge_request"]


def gitlab_tools(env: dict[str, str]) -> list[str] | None:
    """Инструменты GitLab: compact (по умолчанию) или None — все из групп GITLAB_GROUPS (кроме удаления)."""
    if (env.get("GITLAB_PROFILE") or "compact").strip().lower() == "full":
        return None
    return GITLAB_COMPACT


def atlassian_tools(env: dict[str, str]) -> list[str]:
    """Инструменты облачного Atlassian MCP: compact (по умолчанию) или full — как у локального сервера."""
    if (env.get("ATLASSIAN_PROFILE") or "compact").strip().lower() == "full":
        return JIRA_READ + JIRA_WRITE + CONFLUENCE_READ + CONFLUENCE_WRITE
    return ATLASSIAN_COMPACT


DATABASES_FILE = ROOT / "databases.toml"  # личный список баз для DBHub (пароли — не попадает в архив)
DBHUB_BIN = SHARED / ".dbhub" / "node_modules" / ".bin" / "dbhub"


def database_sources() -> list[dict]:
    """Базы из databases.toml: [{"id", "dsn", "description"}]."""
    if not DATABASES_FILE.exists():
        return []
    try:
        import tomllib
        return [s for s in tomllib.loads(DATABASES_FILE.read_text(encoding="utf-8")).get("sources", []) if s.get("id") and s.get("dsn")]
    except Exception:  # noqa: BLE001 — Python < 3.11 или ошибка в файле
        return []


# name: (python, обязательные переменные .env (кортеж — любая из), инструменты без подтверждения или "*")
# Каждый сервер грузится по требованию Goose, после подключения в установщике.
# Только чтение можно разрешить автоматически в клиентах Claude.
EXTENDED_READ = {
    "airflow": ["airflow_status", "airflow_find_dags", "airflow_get_dag", "airflow_get_dag_source",
                "airflow_list_runs", "airflow_list_tasks", "airflow_task_log", "airflow_tasks_by_state",
                "airflow_diagnose_dag"],
    "grafana": ["grafana_status", "grafana_list_datasources", "grafana_find_dashboards",
                "grafana_get_dashboard", "grafana_metrics", "grafana_logs"],
    "trino": ["trino_status", "trino_catalogs", "trino_schemas", "trino_find_tables", "trino_describe"],
    "s3": ["s3_status", "s3_list_buckets", "s3_list", "s3_search", "s3_head", "s3_preview"],
    "sourcebot": ["sourcebot_status", "sourcebot_search"],
    "jupyterhub": ["jupyterhub_status", "jupyterhub_server_status", "jupyterhub_list_notebooks",
                   "jupyterhub_get_notebook"],
    "datalens": ["datalens_list_workbooks", "datalens_list_workbook_entries", "datalens_get_dashboard",
                 "datalens_get_entry", "datalens_search_reports"],
    "help": ["help_status", "help_whoami", "help_list_requests", "help_get_request", "help_list_forms"],
}
EXTENDED_WRITES = {
    "airflow": {"airflow_trigger_dag", "airflow_set_dag_paused", "airflow_clear_failed_tasks"},
    "trino": {"trino_cancel"},
    "s3": {"s3_upload"},
    "jupyterhub": {"jupyterhub_start", "jupyterhub_stop", "jupyterhub_save_notebook"},
    "help": {"help_create_request"},
}


def connection_file(key: str) -> Path:
    return Path.home() / ".magnit-agent" / "connections" / key


SERVERS: dict[str, tuple[str, list, list[str] | str]] = {
    **{name: (PY, ["@" + name], tools) for name, tools in EXTENDED_READ.items()},
    "magnit-files": (PY, [], ["read_document", "describe_image", "ocr_pdf"]),  # install_skill — с подтверждением
    "web": (PY, [], "*"),
    "knowledge": (PY, [], ["kb_list", "kb_search", "kb_read"]),
    "calendar": (PY, [], ["calendar_list_events", "calendar_get_event", "calendar_find_free_time",
                          "calendar_whoami"]),
    "mail": (PY, [], ["mail_folders", "mail_list", "mail_search", "mail_get"]),  # только чтение
    "scheduler": (PY, [], ["automation_list", "automation_history"]),
    # Magnit Drive (Nextcloud): вход через браузер при первом обращении, токена в .env не нужно
    "drive": (PY, [], ["drive_status", "drive_login", "drive_list", "drive_search", "drive_specs", "drive_read",
                       "drive_download"]),
    "atlassian": (PY, [("JIRA_TOKEN", "CONFLUENCE_EPORTAL_TOKEN")], JIRA_READ + CONFLUENCE_READ),
    "atlassian-it": (PY, [("JIRA_IT_TOKEN", "CONFLUENCE_IT_TOKEN")], JIRA_READ + CONFLUENCE_READ),
    "gitlab": (PY, ["GITLAB_TOKEN"], GITLAB_READ),
    "gitlab-platform": (PY, ["GITLAB_PLATFORM_TOKEN"], GITLAB_READ),
    "dbhub": (PY, ["@databases"], "*"),  # только чтение (SELECT), подтверждение не нужно
    # Teradata КХД: вход личной учётной записью (Kerberos или пароль из «Связки ключей»), только чтение
    "teradata": (PY, [], "*"),
    # Риторика: Data Agent платформы StarFish (витрины, атрибуты, маппинг); вход через браузер (OAuth) или RHETORICA_TOKEN
    "rhetorica": (PY, [], []),
    "jira": (PY_ATLASSIAN, ["JIRA_URL", "JIRA_TOKEN"], JIRA_READ),
    "jira-it": (PY_ATLASSIAN, ["JIRA_IT_URL", "JIRA_IT_TOKEN"], JIRA_READ),
    "confluence-it": (PY_ATLASSIAN, ["CONFLUENCE_IT_URL", "CONFLUENCE_IT_TOKEN"], CONFLUENCE_READ),
    "confluence-eportal": (PY_ATLASSIAN, ["CONFLUENCE_EPORTAL_URL", "CONFLUENCE_EPORTAL_TOKEN"],
                           CONFLUENCE_READ),
    "tag": (PY, ["TAG_URL", ("TAG_TOKEN", "TAG_BOT_TOKEN", "TAG_WEBHOOK_URL")], ["tag_whoami", "tag_find_users", "tag_find_channels",
                                           "tag_read_messages", "tag_search_messages"]),
    "magnitgpt": (PY, ["MAGNITGPT_URL", "MAGNITGPT_API_KEY"], ["magnitgpt_list_knowledge",
                  "magnitgpt_search_knowledge", "magnitgpt_list_notes", "magnitgpt_get_note",
                  "magnitgpt_transcribe_audio"]),
}


# Названия для пользователя (установщик, веб-помощник) и примерный объём описаний инструментов
# в токенах, который модель получает в каждом запросе (замерено по схемам инструментов).
TITLES = {
    "airflow": "Airflow: загрузки и логи задач",
    "grafana": "Grafana: дашборды, метрики и логи",
    "trino": "Trino: таблицы и SQL на чтение",
    "s3": "S3: файлы в объектном хранилище",
    "sourcebot": "Sourcebot: поиск по корпоративному коду",
    "jupyterhub": "JupyterHub: ноутбуки и личные серверы",
    "datalens": "DataLens: структура отчётов и дашбордов",
    "help": "Help / ШПС: обращения сотрудника",
    "magnit-files": "Файлы: Excel, PDF, Word, картинки, сканы",
    "knowledge": "Локальные базы знаний (поиск по документам)",
    "web": "Поиск в интернете",
    "calendar": "Календарь Outlook",
    "mail": "Почта Outlook (только чтение)",
    "scheduler": "Автоматизации по расписанию",
    "drive": "Magnit Drive: общая папка и спеки",
    "atlassian": "Jira + Confluence ОМНИ (облако): track, eportal",
    "atlassian-it": "Jira + Confluence IT (облако): jira.corp, IT-портал",
    "gitlab": "GitLab coderepo.corp.tander.ru (облако)",
    "gitlab-platform": "GitLab gitlab.platform.corp (облако)",
    "dbhub": "Базы данных (DBHub, только чтение)",
    "teradata": "Teradata КХД (только чтение)",
    "rhetorica": "Риторика: Data Agent (поиск витрин)",
    "jira": "Jira track.magnit.ru (локально, резерв)",
    "jira-it": "Jira jira.corp.tander.ru (локально, резерв)",
    "confluence-it": "Confluence IT-портал (локально, резерв)",
    "confluence-eportal": "Confluence eportal (локально, резерв)",
    "tag": "Tag (сообщения)",
    "magnitgpt": "MagnitGPT (протоколы встреч, ASR)",
}
# Что даёт инструмент, простыми словами (10–30 слов): показывается при выборе инструментов (приложение, установщик)
# и попадает в описание расширения Goose — по нему Extension Manager находит выключенный инструмент, если он нужен.
DESCRIPTIONS = {
    "airflow": "Находит процессы загрузки, смотрит историю запусков, состояние задач и логи, сравнивает сбой с последним успешным запуском.",
    "grafana": "Находит дашборды, запрашивает метрики VictoriaMetrics и логи VictoriaLogs, помогает диагностировать ошибки и задержки в заданный период.",
    "trino": "Ищет каталоги и таблицы Trino, показывает поля, выполняет запросы на чтение и сохраняет результаты в CSV или Excel.",
    "s3": "Ищет объекты в бакете, скачивает и просматривает файлы, загружает локальный файл по подтверждению.",
    "sourcebot": "Ищет фрагменты корпоративного кода по запросу, репозиторию, пути и языку, помогает объяснить найденную реализацию.",
    "jupyterhub": "Показывает статус личных серверов и содержимое ноутбуков. Сохраняет отдельную копию, запускает и останавливает сервер по подтверждению.",
    "datalens": "Находит рабочие книги и дашборды, показывает графики и связанные объекты, помогает ориентироваться в структуре отчёта.",
    "help": "Показывает собственные активные и завершённые обращения Help, готовит заявки по проверенным формам и отправляет после подтверждения.",
    "magnit-files": "Читает Excel, PDF, Word, PowerPoint, картинки и сканы, создаёт отчёты и таблицы; устанавливает навыки "
                    "из Magnit Drive или по ссылке. Включён всегда.",
    "web": "Ищет и читает страницы в интернете: новости, документацию, справочные сведения, которых нет "
           "во внутренних системах компании.",
    "knowledge": "Поиск по вашим папкам с документами — регламентам, договорам, инструкциям. Находит ответ по смыслу "
                 "и даёт ссылку на файл; документы не покидают компьютер.",
    "calendar": "Показывает ваши встречи, ищет общее свободное время с коллегами, создаёт встречи и отвечает "
                "на приглашения — после вашего подтверждения.",
    "mail": "Разбирает непрочитанные письма, находит письма и вложения, готовит текст ответа. Письма не отправляет "
            "и не помечает прочитанными.",
    "scheduler": "Помощник сам выполняет задание в нужное время без вашего участия — например, каждое утро присылает "
                 "в Tag сводку встреч.",
    "drive": "Magnit Drive (drive.magnit.ru): общая папка команды MCOS со спеками для помощника — найти и прочитать "
             "спеку, скачать выгрузку, сохранить отчёт или новую спеку. Вход корпоративной учётной записью в браузере.",
    "atlassian": "Jira и Confluence контура ОМНИ (track.magnit.ru и eportal): найти и создать задачу, комментарии, "
                 "статусы, поиск и правка страниц со ссылками.",
    "atlassian-it": "Jira и Confluence IT-контура (jira.corp.tander.ru и IT-портал): задачи, комментарии, статусы, "
                    "поиск по технической документации и регламентам IT.",
    "gitlab": "GitLab coderepo.corp.tander.ru: поиск по коду и репозиториям, ветки, коммиты, ревью merge request "
              "и комментарии. Нужен тем, кто работает с кодом.",
    "gitlab-platform": "GitLab gitlab.platform.corp: код, ветки, коммиты, ревью merge request и комментарии "
                       "в платформенном GitLab. Нужен тем, кто работает с кодом.",
    "teradata": "Teradata КХД (teradata, tddr): найти витрину, посмотреть колонки, выполнить SQL только на чтение "
                "и выгрузить результат в Excel. Вход личной доменной учётной записью; нужны роли доступа к данным.",
    "rhetorica": "Риторика (Data Agent платформы StarFish): подсказывает, в какой витрине и каких атрибутах лежат нужные данные, "
                 "маппинг витрин StarFish и КХД 1.0, происхождение данных. Вход корпоративной учётной записью в браузере.",
    "dbhub": "Базы данных: помощник сам изучает структуру, пишет SQL-запросы и отвечает цифрами и таблицами. "
             "Только чтение — изменить данные нельзя.",
    "jira": "Резервное прямое подключение к Jira track.magnit.ru без облачного сервиса. Включайте, только если "
            "облачный вариант недоступен: занимает много памяти помощника.",
    "jira-it": "Резервное прямое подключение к Jira jira.corp.tander.ru без облачного сервиса. Включайте, только "
               "если облачный вариант недоступен.",
    "confluence-it": "Резервное прямое подключение к Confluence IT-портала без облачного сервиса. Включайте, только "
                     "если облачный вариант недоступен.",
    "confluence-eportal": "Резервное прямое подключение к Confluence eportal без облачного сервиса. Включайте, "
                          "только если облачный вариант недоступен.",
    "tag": "Tag: помощник присылает вам итоги, отчёты и результаты автоматизаций; с ботом — пишет коллегам "
           "и в каналы, читает сообщения.",
    "magnitgpt": "MagnitGPT: протоколы встреч от бота «Запись встреч», базы знаний Knowledge и распознавание "
                 "аудиозаписей в текст.",
}
CONTEXT_TOKENS: dict[str, int] = {
    "magnit-files": 700, "web": 560, "knowledge": 900, "calendar": 1670, "mail": 940, "scheduler": 970, "drive": 2000,
    "atlassian": 9050, "atlassian-it": 9050, "gitlab": 7170, "gitlab-platform": 7170, "dbhub": 560, "teradata": 1100, "rhetorica": 1500,  # компактный профиль, Jira + Confluence контура
    "jira": 10400, "jira-it": 10400, "confluence-it": 6000, "confluence-eportal": 6000,
    "tag": 1050, "magnitgpt": 710,
}
# Имя расширения в Goose — его видит пользователь (Goose Desktop пишет имя с заглавных букв, дефис → пробел).
# Ключ входит в имя каждого инструмента (<ключ>__<инструмент>); Goose заменяет в нём всё, кроме латиницы, цифр, «_» и
# «-», подчёркиваниями, и два ключа с одинаковым «скелетом» (почта / файлы) ломают конфиг целиком («extension name
# already in use»). Поэтому русские имена подобраны с разными скелетами (goose_names() проверяет), а Jira, Confluence
# и Drive — латиницей по домену. Внутренние имена (mcp_launch, guard, .env) не меняются.
GOOSE_NAMES = {
    "magnit-files": "файлы-и-документы", "web": "интернет-поиск", "knowledge": "базы-знаний", "scheduler": "автоматизации",
    "calendar": "календарь", "mail": "почта", "drive": "drive-magnit", "atlassian": "track-eportal-magnit",
    "atlassian-it": "jira-itportal-tander", "teradata": "данные-teradata", "rhetorica": "риторика",
    "tag": "сообщения-tag", "dbhub": "базы-данных-sql",
}


def goose_skeleton(name: str) -> str:
    """Как Goose превращает имя расширения в префикс имён инструментов."""
    import re
    return re.sub(r"[^A-Za-z0-9_-]", "_", name)


def goose_names(reserved: set[str] = frozenset()) -> dict[str, str]:
    """Внутреннее имя → имя расширения в Goose. Совпадение скелетов (между собой или с reserved — встроенными
    расширениями Goose) — латинское внутреннее имя: лучше латиница, чем неработающий Goose."""
    seen = {goose_skeleton(r) for r in reserved}
    out = {}
    for name in SERVERS:
        key = GOOSE_NAMES.get(name, name)
        if goose_skeleton(key) in seen:
            key = name
        seen.add(goose_skeleton(key))
        out[name] = key
    return out


ALWAYS_ON = {"magnit-files"}  # без него агент не прочитает Excel, PDF и картинки
# Выключены, пока пользователь не включит их сам. Тяжёлые (облачные Jira+Confluence ~9 тыс. токенов на контур, GitLab ~7 тыс.)
# Goose включает сам по необходимости через Extension Manager — они записаны в его настройки выключенными, с описанием.
# По умолчанию включены только интернет и автоматизации (+ файлы — всегда); остальное Goose включает сам, когда запрос
# этого требует. Базы знаний выключены: после первого поиска по смыслу их процесс держит модель e5 (~400 МБ памяти).
DEFAULT_ON = {"web", "scheduler"}
DEFAULT_OFF = set(SERVERS) - DEFAULT_ON - ALWAYS_ON
DEFAULTS_VERSION = "9"  # меняется при изменении умолчаний — Goose применит их заново
# Скрыты везде (установщик, приложение, веб-чат, Goose): локальный mcp-atlassian — резерв облачного MCP. Код сохранён;
# вернуть — SHOW_LOCAL_ATLASSIAN=1 в .env.
HIDDEN = {"jira", "jira-it", "confluence-it", "confluence-eportal"}


def visible(env: dict[str, str] | None = None) -> list[str]:
    """Интеграции, которые показываются пользователю (все, кроме скрытых)."""
    env = env if env is not None else load_env()
    show_hidden = env.get("SHOW_LOCAL_ATLASSIAN", "").strip().lower() in ("1", "true", "yes")
    return [n for n in SERVERS if show_hidden or n not in HIDDEN]


def load_env() -> dict[str, str]:
    env: dict[str, str] = {}
    path = ROOT / ".env"
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip().strip('"').strip("'")
    return {**env, **{k: v for k, v in os.environ.items() if k in env and v}}


def available(env: dict[str, str] | None = None) -> list[str]:
    """Интеграции, для которых есть всё нужное (токены), — их можно включить."""
    env = env if env is not None else load_env()

    def ok(req) -> bool:
        if isinstance(req, str) and req.startswith("@") and req[1:] in EXTENDED_READ:
            key = req[1:].upper() + "_TOKEN"
            return bool(env.get(key)) or connection_file(key).is_file()
        if req == "@databases":
            return DBHUB_BIN.exists() and bool(database_sources())
        return any(env.get(k) for k in req) if isinstance(req, tuple) else bool(env.get(req))

    shown = set(visible(env))
    return [name for name, (_, required, _) in SERVERS.items() if name in shown and all(ok(r) for r in required)]


def selection(env: dict[str, str] | None = None) -> set[str] | None:
    """Выбор пользователя из ENABLED_INTEGRATIONS; None — выбор не задан (активно всё доступное)."""
    env = env if env is not None else load_env()
    raw = env.get("ENABLED_INTEGRATIONS", "").strip()
    return {x.strip() for x in raw.split(",") if x.strip()} if raw else None


def enabled(env: dict[str, str] | None = None) -> list[str]:
    """Активные интеграции: доступные и выбранные пользователем."""
    env = env if env is not None else load_env()
    if os.environ.get("MAGNIT_ALL_INTEGRATIONS") == "1":
        # автоматизации по расписанию: без человека включить инструмент некому — даём все подключённые
        return available(env)
    chosen = selection(env)
    if chosen is None:
        return [n for n in available(env) if n not in DEFAULT_OFF]
    return [n for n in available(env) if n in chosen or n in ALWAYS_ON]


def save_selection(names) -> str:
    """Записать выбор в .env (ENABLED_INTEGRATIONS=...), вернуть записанное значение."""
    path = ROOT / ".env"
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    value = ",".join(n for n in SERVERS if n in set(names) | ALWAYS_ON)
    for i, line in enumerate(lines):
        if line.startswith("ENABLED_INTEGRATIONS="):
            lines[i] = f"ENABLED_INTEGRATIONS={value}"
            break
    else:
        lines += ["", "# Активные интеграции (остальные не подключаются и не занимают контекст модели).",
                  "# Изменить: ./setup.sh --tools, в Goose — «Расширения», в веб-помощнике — панель «Инструменты».",
                  f"ENABLED_INTEGRATIONS={value}"]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return value


def claude_config(env: dict[str, str] | None = None) -> dict:
    return {"mcpServers": {
        name: {"type": "stdio", "command": SERVERS[name][0], "args": [LAUNCH, name]}
        for name in enabled(env)
    }}


def auto_allowed(env: dict[str, str] | None = None) -> list[str]:
    """Имена инструментов в формате Claude (mcp__server__tool), которые не требуют подтверждения."""
    result = []
    for name in enabled(env):
        tools = SERVERS[name][2]
        if tools == "*":
            result.append(f"mcp__{name}")
        else:
            result.extend(f"mcp__{name}__{t}" for t in tools)
    return result


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "claude":
        print(json.dumps(claude_config(), ensure_ascii=False))
    elif cmd == "allowed":
        print(",".join(auto_allowed()))
    else:
        on, avail = enabled(), available()
        for name in visible():
            state = "✓ активна" if name in on else ("○ выключена" if name in avail else "· не настроена")
            print(f"  {state:15} {TITLES[name]}")
