"""Локальный шлюз Anthropic Messages API -> OpenAI Chat Completions (корпоративный LiteLLM).

Нужен агентам A (Claude Code) и C (Claude Agent SDK): они говорят на Anthropic API,
а корпоративный шлюз корректно обрабатывает вызовы инструментов только через
/v1/chat/completions. Запускается автоматически скриптом gateway.sh.
"""

import sys

import truststore

# Системное хранилище сертификатов (корпоративные CA, установленные на компьютер)
truststore.inject_into_ssl()

from litellm import run_server  # noqa: E402

if __name__ == "__main__":
    sys.exit(run_server())
