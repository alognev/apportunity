# Агент B — Goose на корпоративной LLM (ставится по умолчанию)

Open-source агент [Goose](https://github.com/aaif-goose/goose) (прежде block/goose): приложение Goose Desktop и консоль.
Пользователю ничего настраивать не нужно: провайдер, модель, расширения, навыки и инструкции записывает `configure.py`.

```bash
cd ~/Documents/отчёты
magnit-goose                       # интерактивная сессия в Терминале (macOS)
magnit-goose run -t "задание"      # разовое задание
```

Windows: `agent-b-goose\magnit-goose.cmd` (обёртка над `windows\magnit-goose.ps1`), Goose Desktop — ярлык в «Пуске».

## Установка
- **macOS:** `install.sh` (его вызывает `setup.sh`) — общая часть `shared/install-shared.sh`, затем Goose: с Homebrew —
  `block-goose-cli`; с флагом `--desktop` без Homebrew — официальная сборка Goose Desktop с GitHub в `/Applications`
  (или `~/Applications`, если нет прав). CLI есть и внутри приложения: `Goose.app/Contents/Resources/bin/goose`.
- **Windows:** `windows\setup.ps1` — без прав администратора: переносимый Goose Desktop (версия и SHA-256 зашиты в
  скрипте) в `%LOCALAPPDATA%\Programs\Goose`, CLI внутри него. Подробно — `docs/WINDOWS.md`.

## Что делает `configure.py`
- **Папка Goose:** macOS — `~/.config/goose`, Windows — `%APPDATA%\Block\goose\config` (`GOOSE_CONFIG_DIR` — другая папка,
  так работают тесты). Существующие настройки сохраняются, перед изменением — бэкап `config.yaml.bak-…`.
- **Провайдер `magnit_copilot`** (`custom_providers/magnit_copilot.json`): корпоративный LiteLLM, лимит контекста каждой
  модели — из `/model/info` (Small 229 376, MagnitCopilot/Flash 241 808; без сети — последние известные), а не 128k по
  умолчанию. Выбор другого провайдера пользователем (`active_provider`) не трогается; для встроенного DeepSeek
  `deepseek-v4-flash` лимит поднимается до 1 000 000.
- **Ключ LLM** — туда, где его ищет Goose: «Связка ключей» macOS / диспетчер учётных данных Windows
  (`shared/platform_util.py`).
- **Расширения** — серверы из `shared/mcp_registry.py` под русскими именами (`GOOSE_NAMES`: файлы-и-документы,
  интернет-поиск, календарь, track-eportal-magnit, данные-teradata…). По умолчанию включены файлы, интернет и
  автоматизации; остальные записаны выключенными с описанием — Goose включает их сам через Extension Manager
  (`permission.yaml`: без вопроса; `GOOSE_AUTO_ENABLE_EXTENSIONS=0` в `.env` — спрашивать). Встроенные расширения Goose,
  которые тратят контекст впустую (skills, summon, analyze, apps, tom…), выключены.
- **Навыки** — `shared/skills` и `~/.magnit-agent/skills` → `~/.agents/skills` (русские имена: деловое-письмо,
  протокол-встречи…); шапки SKILL.md проверяются, список с точными именами — в `.goosehints`.
- **Инструкции** — `shared/instructions.md` → `.goosehints` (блок между маркерами).
- **Трассировка Langfuse** (если задан ключ) — через локальный ретранслятор 127.0.0.1:4319.

Goose обращается к `/v1/chat/completions` напрямую — локальный шлюз (нужен агентам A и C) ему не нужен.
Режим по умолчанию `smart_approve`: изменения и команды — с подтверждением.

## Проверка
`shared/.venv/bin/python tests/run_tests.py` (Windows: `shared\.venv\Scripts\python.exe tests\run_tests.py`) — быстрые
тесты, в том числе configure.py во временной папке; `--live` — серверы MCP и `goose run` с вопросом модели.
