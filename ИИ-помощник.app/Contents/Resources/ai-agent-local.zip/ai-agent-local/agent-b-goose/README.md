# Агент B — Goose на корпоративной LLM

Open-source агент [Goose](https://github.com/block/goose) (Block): консоль и десктоп-приложение.

```bash
cd ~/Documents/отчёты
magnit-goose                       # интерактивная сессия
magnit-goose run -t "задание"      # разовое задание
```

**Goose Desktop**: откройте приложение Goose. Провайдер, модель и расширения уже настроены.

- `install.sh`: ставит `goose` через Homebrew (с флагом `--desktop` ещё и приложение) и запускает `configure.py`.
- `configure.py` записывает `~/.config/goose/config.yaml` (провайдер `openai` → корпоративный шлюз, расширения `developer`, `magnit-files` и удалённые MCP из `remote-mcp.json`). Токен кладётся в связку ключей macOS, инструкции — в `~/.config/goose/.goosehints`. Существующие настройки сохраняются, при изменениях делается бэкап.
- Goose напрямую работает с `/v1/chat/completions`, локальный шлюз ему не нужен.
- Режим по умолчанию `smart_approve`: правки файлов и команды выполняются с подтверждением. Сменить режим: `goose configure` → goose settings.
