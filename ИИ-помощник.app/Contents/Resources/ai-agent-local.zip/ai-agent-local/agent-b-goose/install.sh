#!/usr/bin/env bash
# Установка агента B (Goose). Флаг --desktop дополнительно ставит приложение Goose Desktop.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
"$HERE/../shared/install-shared.sh"
source "$HERE/../shared/env.sh"

goose_app() { [[ -d "/Applications/Goose.app" || -d "$HOME/Applications/Goose.app" ]]; }
install_desktop_direct() {  # без Homebrew: официальная сборка Goose Desktop с GitHub (подписана разработчиком)
  local url="https://github.com/block/goose/releases/download/stable/Goose.zip" tmp dest="/Applications"
  [[ "$(uname -m)" == "x86_64" ]] && url="https://github.com/block/goose/releases/download/stable/Goose_intel_mac.zip"
  [[ -w "$dest" ]] || { dest="$HOME/Applications"; mkdir -p "$dest"; }
  tmp="$(mktemp -d)"
  echo "Скачиваю приложение Goose (~210 МБ)..."
  curl -fL --retry 2 --progress-bar -o "$tmp/Goose.zip" "$url" || { echo "Не удалось скачать Goose: $url" >&2; rm -rf "$tmp"; return 1; }
  ditto -x -k "$tmp/Goose.zip" "$tmp/app"
  local app; app="$(find "$tmp/app" -maxdepth 2 -name 'Goose.app' | head -1)"
  [[ -n "$app" ]] || { echo "В архиве Goose не найдено приложение" >&2; rm -rf "$tmp"; return 1; }
  ditto "$app" "$dest/Goose.app"
  rm -rf "$tmp"
  echo "Goose установлен: $dest/Goose.app"
}

if command -v brew >/dev/null; then
  command -v goose >/dev/null || brew install block-goose-cli
  if [[ "${1:-}" == "--desktop" ]] && ! goose_app; then brew install --cask block-goose; fi
elif [[ "${1:-}" == "--desktop" ]]; then
  goose_app || install_desktop_direct
else
  echo "Нужен Homebrew (https://brew.sh) — или установка с приложением: install.sh --desktop" >&2; exit 1
fi

"$SHARED_PY" "$HERE/configure.py"

mkdir -p "$HOME/.local/bin"
ln -sf "$HERE/magnit-goose" "$HOME/.local/bin/magnit-goose"
echo
goose_app && echo "Goose Desktop: откройте приложение Goose — настройки уже применены."
if command -v goose >/dev/null; then
  echo "Агент B установлен. Запуск в терминале: magnit-goose (из нужной рабочей папки)"
  case ":$PATH:" in *":$HOME/.local/bin:"*) ;; *) echo "Добавьте в ~/.zshrc: export PATH=\"\$HOME/.local/bin:\$PATH\"";; esac
fi
