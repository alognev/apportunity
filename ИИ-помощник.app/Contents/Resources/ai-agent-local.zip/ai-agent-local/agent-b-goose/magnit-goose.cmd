@echo off
rem Windows: Goose CLI on the corporate model. Usage: magnit-goose [goose arguments], default: session.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\windows\magnit-goose.ps1" %*
exit /b %ERRORLEVEL%
