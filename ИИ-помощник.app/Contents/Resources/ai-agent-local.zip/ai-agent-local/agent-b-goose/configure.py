"""Настройка Goose (CLI и Desktop) на корпоративную LLM.

Что делает:
  1. config.yaml Goose — провайдер, модель, расширения (developer, magnit-files,
     удалённые MCP из remote-mcp.json). Существующие настройки сохраняются, делается бэкап.
  2. Токен LLM кладёт туда, где его ищет Goose: связка ключей macOS / диспетчер учётных данных Windows.
  3. .goosehints — инструкции агента (блок между маркерами обновляется).
  4. permission.yaml — включение выключенных расширений (Extension Manager) без вопроса
     пользователю; GOOSE_AUTO_ENABLE_EXTENSIONS=0 в .env возвращает вопрос.
Папка Goose: macOS — ~/.config/goose, Windows — %APPDATA%\\Block\\goose\\config.

Запуск: shared/.venv/bin/python agent-b-goose/configure.py  (делает install.sh)
"""

from __future__ import annotations

import json
import os
import re
import shutil
import sys
import time
from pathlib import Path

import yaml
from dotenv import dotenv_values

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "shared"))
import mcp_registry  # noqa: E402
import platform_util  # noqa: E402
import tracing  # noqa: E402
from skills_sync import sync as sync_skills  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
WINDOWS = os.name == "nt"
DEFAULT_GOOSE_DIR = (Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming")) / "Block" / "goose" / "config"
                     if WINDOWS else Path.home() / ".config" / "goose")
GOOSE_DIR = Path(os.environ.get("GOOSE_CONFIG_DIR", DEFAULT_GOOSE_DIR))
# Где искать goose: macOS — приложение Goose; Windows — переносимый Goose Desktop в профиле (CLI внутри него)
GOOSE_EXE_CANDIDATES = (
    [Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Goose" / "dist-windows" / "resources" / "bin" / "goose.exe"]
    if WINDOWS else [Path("/Applications/Goose.app/Contents/Resources/bin/goose"),
                     Path.home() / "Applications/Goose.app/Contents/Resources/bin/goose"])
CONFIG = GOOSE_DIR / "config.yaml"
HINTS = GOOSE_DIR / ".goosehints"
MARK_BEGIN = "<!-- magnit-agent:begin -->"
MARK_END = "<!-- magnit-agent:end -->"
APPLIED = Path.home() / ".magnit-agent" / "goose-applied-integrations"  # выбор, уже применённый к Goose
MANAGED = "[magnit]"  # метка удалённых MCP, добавленных из remote-mcp.json
# Встроенные расширения Goose, выключенные по умолчанию (их описания занимают память модели в каждом запросе);
# Goose включает их сам через Extension Manager, когда задача требует. Описания — чтобы он их находил.
BUILTINS_OFF = {
    "skills": "Навыки: пошаговые инструкции для типовых задач — рутина-по-спеке (из Magnit Drive), отчет-по-таблицам, "
              "протокол-встречи, задача-в-jira, поиск-в-confluence, деловое-письмо, разбор-почты, данные-из-teradata.",
    "summon": "Подзадачи: передать часть работы отдельному помощнику-исполнителю, загрузить справочные материалы.",
    "analyze": "Анализ структуры программного кода: обзор папок, файлов, вызовов функций.",
    "apps": "Создание небольших приложений (HTML/JavaScript) в отдельных окнах Goose.",
    "tom": "Дополнительный контекст в каждом сообщении (переменные GOOSE_MOIM_MESSAGE_*).",
}
# Русские названия встроенных расширений Goose: для builtin/platform Goose Desktop показывает display_name
BUILTIN_TITLES = {
    "developer": "Терминал и файлы", "extensionmanager": "Менеджер расширений", "skills": "Навыки",
    "summon": "Помощники-исполнители", "analyze": "Анализ кода", "apps": "Мини-приложения", "tom": "Доп. контекст",
    "todo": "Список дел", "chatrecall": "Память чатов", "code_execution": "Выполнение кода",
    "summarize": "Краткий пересказ", "computercontroller": "Управление компьютером", "autovisualiser": "Визуализация",
    "memory": "Память", "tutorial": "Обучение",
}
ENV_REF = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


def load_env() -> dict[str, str]:
    env = {k: v or "" for k, v in dotenv_values(ROOT / ".env").items()}
    if not env.get("LLM_API_KEY"):
        sys.exit("В .env не задан LLM_API_KEY — запустите setup.sh")
    env["LLM_BASE_URL"] = env["LLM_BASE_URL"].rstrip("/")
    return env


def remote_extensions() -> dict[str, dict]:
    """remote-mcp.json (формат Claude) -> расширения Goose streamable_http."""
    path = ROOT / "remote-mcp.json"
    if not path.exists():
        return {}
    servers = json.loads(path.read_text(encoding="utf-8")).get("mcpServers", {})
    result = {}
    for name, srv in servers.items():
        if srv.get("type", "http") not in ("http", "streamable_http", "sse"):
            print(f"  пропускаю {name}: Goose поддерживает только удалённые HTTP MCP")
            continue
        # ${VAR} в заголовках подставляется из окружения / .env на момент настройки
        values = {**dotenv_values(ROOT / ".env"), **os.environ}
        headers = {k: ENV_REF.sub(lambda m: values.get(m.group(1), ""), v)
                   for k, v in srv.get("headers", {}).items()}
        result[name] = {
            "enabled": True, "type": "streamable_http", "name": name, "uri": srv["url"],
            "headers": headers, "envs": {}, "env_keys": [], "timeout": 300,
            "description": f"{MANAGED} удалённый MCP-сервер {name}", "bundled": None, "available_tools": [],
        }
    return result


def write_config(env: dict[str, str]) -> None:
    GOOSE_DIR.mkdir(parents=True, exist_ok=True)
    old_text = CONFIG.read_text(encoding="utf-8") if CONFIG.exists() else ""
    cfg = yaml.safe_load(old_text) or {} if old_text else {}

    model = env.get("LLM_MODEL") or mcp_registry.DEFAULT_LLM_MODEL
    # Провайдер litellm: Goose сам берёт у LiteLLM лимит контекста каждой модели (/model/info, max_input_tokens) —
    # Small ~229 тыс., MagnitCopilot ~242 тыс. — вместо 128 тыс. по умолчанию у провайдера openai.
    cfg.update({
        "LITELLM_HOST": env["LLM_BASE_URL"],
        "LITELLM_BASE_PATH": "v1/chat/completions",
        "LITELLM_TIMEOUT": 600,
        "OPENAI_HOST": env["LLM_BASE_URL"],          # прежний провайдер openai остаётся доступным в Goose
        "OPENAI_BASE_PATH": "v1/chat/completions",
        "GOOSE_MAX_TOKENS": int(env.get("LLM_MAX_OUTPUT_TOKENS") or 8192),
        "GOOSE_TELEMETRY_ENABLED": False,
    })
    # Новый формат Goose 1.52: список провайдеров + активный. Ключи GOOSE_PROVIDER/GOOSE_MODEL Goose удаляет сам,
    # а при пустом active_provider брал бы их — поэтому пишем сразу новый формат и не трогаем выбор пользователя,
    # если он сам переключился на другого провайдера (например, DeepSeek).
    cfg.pop("GOOSE_PROVIDER", None)
    cfg.pop("GOOSE_MODEL", None)
    providers = cfg.setdefault("providers", {}) or {}
    providers["litellm"] = {"enabled": True, "model": model, "configured": True}
    # Основной провайдер — «Magnit Copilot» (свой список моделей с лимитами контекста, см. write_magnit_provider):
    # у litellm лимит берётся запросом к LiteLLM, а он не успевает там, где TLS медленный (личный ПК через NetBird), —
    # тогда Goose считает 128 тыс. Выбор пользователя (DeepSeek, свой провайдер) не трогаем.
    magnit_ok = False
    try:
        magnit_ok = write_magnit_provider(env)
    except Exception as e:  # noqa: BLE001 — без него останется litellm
        print(f"  ⚠ провайдер Magnit Copilot не записан: {e.__class__.__name__}")
    if magnit_ok:
        providers[MAGNIT_PROVIDER] = {"enabled": True, "model": model, "configured": True}
    if cfg.get("active_provider") in (None, "", "openai", "litellm", MAGNIT_PROVIDER):
        cfg["active_provider"] = MAGNIT_PROVIDER if magnit_ok else "litellm"
    cfg["providers"] = providers
    cfg.setdefault("GOOSE_MODE", "smart_approve")  # правки файлов и команды — с подтверждением
    try:
        write_context_limits(env, cfg)
    except Exception as e:  # noqa: BLE001 — лимиты контекста не должны мешать настройке помощника
        print(f"  ⚠ лимиты контекста не обновлены: {e.__class__.__name__}")
    try:
        tracing.goose_config(cfg, env)  # трассировка Langfuse — через локальный ретранслятор (или убрать адрес)
    except Exception:  # noqa: BLE001 — трассировка не должна мешать настройке помощника
        pass

    ext = cfg.setdefault("extensions", {}) or {}
    # Состояние «вкл/выкл», которое пользователь мог поменять в интерфейсе Goose
    ui_state = {k: bool(v.get("enabled")) for k, v in ext.items()}
    # Удалённые MCP, убранные из remote-mcp.json, удаляем и из Goose
    ext = {k: v for k, v in ext.items() if not str(v.get("description", "")).startswith(MANAGED)}
    ext["developer"] = {
        "enabled": True, "type": "builtin", "name": "developer", "display_name": BUILTIN_TITLES["developer"],
        "timeout": 300, "bundled": True, "description": "Файлы и терминал",
    }
    # Локальные MCP-серверы: в конфиг попадают все доступные (есть токены), флаг «вкл» — по выбору
    # пользователя (ENABLED_INTEGRATIONS). Переключения в интерфейсе Goose сохраняются, пока выбор
    # в .env не изменится (например, через ./setup.sh --tools).
    active = set(mcp_registry.enabled(env))
    selection_now = f'{env.get("ENABLED_INTEGRATIONS", "")}|defaults-v{mcp_registry.DEFAULTS_VERSION}'
    selection_changed = APPLIED.read_text(encoding="utf-8").strip() != selection_now if APPLIED.exists() else True
    names = mcp_registry.goose_names(set(BUILTIN_TITLES) | {k for k, v in ext.items() if v.get("type") != "stdio"})
    for name in mcp_registry.available(env):
        key = names[name]  # имя в Goose (видит пользователь); сервер запускается по внутреннему имени
        on = name in active if selection_changed or key not in ui_state else ui_state[key]
        ext[key] = {
            "enabled": on or name in mcp_registry.ALWAYS_ON, "type": "stdio", "name": key,
            # Windows: Python иначе читает и пишет текст в cp1251. Режим UTF-8 — ключом -X utf8 в аргументах: переменную
            # PYTHONUTF8 из envs Goose Desktop расширениям не передаёт (Drive записал вход в cp1251 и не смог прочитать)
            "cmd": mcp_registry.SERVERS[name][0],
            "args": (["-X", "utf8"] if WINDOWS else []) + [mcp_registry.LAUNCH, name],
            "envs": {"PYTHONUTF8": "1"} if WINDOWS else {}, "env_keys": [], "timeout": 300, "bundled": None,
            "available_tools": [],
            "description": f"{MANAGED} {mcp_registry.TITLES[name]}. {mcp_registry.DESCRIPTIONS.get(name, '')}".strip(),
        }
    for name, title in BUILTIN_TITLES.items():
        if name in ext and ext[name].get("type") in ("builtin", "platform"):
            ext[name]["display_name"] = title
    for name, description in BUILTINS_OFF.items():
        if name not in ext:
            # Goose считает отсутствующее в конфиге встроенное расширение включённым — при новой установке (конфиг
            # пишется до первого запуска Goose) записываем его сами, выключенным
            ext[name] = {"enabled": False, "type": "platform", "name": name, "display_name": BUILTIN_TITLES.get(name, name.capitalize()),
                         "bundled": True, "available_tools": []}
        ext[name]["description"] = skills_description() if name == "skills" else description
        if selection_changed:  # новые умолчания; после — как пользователь переключил в Goose
            ext[name]["enabled"] = False
    APPLIED.parent.mkdir(parents=True, exist_ok=True)
    APPLIED.write_text(selection_now, encoding="utf-8")
    ext.pop("magnit-files-legacy", None)
    ext.update(remote_extensions())
    # Порядок как при повторном запуске (свои расширения — в конце): иначе первая настройка и следующая дают разный
    # текст конфига, и он переписывается с резервной копией без изменений по существу
    ours = {k for k, v in ext.items() if str(v.get("description", "")).startswith(MANAGED)}
    cfg["extensions"] = {**{k: v for k, v in ext.items() if k not in ours}, **{k: ext[k] for k in ext if k in ours}}
    new_text = yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False)
    if new_text == old_text:
        print(f"  конфиг без изменений: {CONFIG}")
        return
    if old_text:
        backup = CONFIG.with_name(f"config.yaml.bak-{time.strftime('%Y%m%d-%H%M%S')}")
        shutil.copy2(CONFIG, backup)
        print(f"  бэкап старого конфига: {backup}")
    CONFIG.write_text(new_text, encoding="utf-8")
    print(f"  конфиг: {CONFIG}")


def store_secret(key: str) -> None:
    """Goose хранит все секреты одной JSON-записью в хранилище ОС (сервис goose, аккаунт secrets)."""
    if os.environ.get("GOOSE_DISABLE_KEYRING"):
        path = GOOSE_DIR / "secrets.yaml"
        data = (yaml.safe_load(path.read_text(encoding="utf-8")) or {}) if path.exists() else {}
        data["OPENAI_API_KEY"] = key
        data["LITELLM_API_KEY"] = key
        path.write_text(yaml.safe_dump(data), encoding="utf-8")
        path.chmod(0o600)
        print(f"  токен сохранён в {path} (keyring отключён)")
        return
    try:
        secrets = json.loads(platform_util.secret_get("goose", "secrets") or "{}")
    except json.JSONDecodeError:
        secrets = {}
    secrets["OPENAI_API_KEY"] = key
    secrets["LITELLM_API_KEY"] = key  # провайдер litellm (лимиты контекста по моделям)
    if not platform_util.secret_set("goose", "secrets", json.dumps(secrets)):
        sys.exit("Не удалось сохранить токен в хранилище секретов (экран заблокирован?) — повторите настройку")
    where = "диспетчере учётных данных Windows (secrets.goose)" if WINDOWS else "связке ключей macOS (goose/secrets)"
    print(f"  токен сохранён в {where}")


# Лимиты контекста, которые Goose знает неверно: провайдер → модель → токенов (встроенный DeepSeek — 128 тыс.)
CONTEXT_OVERRIDES = {"custom_deepseek": {"deepseek-v4-flash": 1_000_000}}
OVERRIDE_MARK = "[magnit: лимит контекста]"


def builtin_provider(name: str) -> dict | None:
    """Описание встроенного провайдера Goose (JSON внутри программы goose) — основа для переопределения."""
    for exe in [shutil.which("goose"), *map(str, GOOSE_EXE_CANDIDATES)]:
        if not exe or not Path(exe).exists():
            continue
        data = Path(exe).read_bytes()
        at = data.find(f'"name": "{name}"'.encode())
        if at < 0:
            continue
        start = data.rfind(b"{", 0, at)
        depth = 0
        for i in range(start, min(len(data), start + 200_000)):
            depth += {123: 1, 125: -1}.get(data[i], 0)
            if depth == 0:
                try:
                    return json.loads(data[start:i + 1].decode("utf-8"))
                except (ValueError, UnicodeDecodeError):
                    break
    return None


# Если LiteLLM недоступен — последние известные лимиты (из /model/info на 14.10.2026)
KNOWN_LIMITS = {"MagnitCopilot-Small": 229_376, "MagnitCopilot": 241_808, "MagnitCopilotFlash": 241_808}


def litellm_limits(env: dict[str, str]) -> dict[str, int]:
    """Лимиты контекста моделей из LiteLLM (/model/info); без сети — последние известные."""
    return {**KNOWN_LIMITS, **_fetch_limits(env)}


def _fetch_limits(env: dict[str, str]) -> dict[str, int]:
    try:
        import httpx
        try:
            import truststore
            truststore.inject_into_ssl()
        except ImportError:
            pass
        r = httpx.get(env["LLM_BASE_URL"].rstrip("/") + "/model/info", timeout=15,
                      headers={"Authorization": f"Bearer {env['LLM_API_KEY']}", "User-Agent": mcp_registry.USER_AGENT})
        return {m["model_name"]: int(m["model_info"]["max_input_tokens"]) for m in r.json().get("data", [])
                if (m.get("model_info") or {}).get("max_input_tokens")}
    except Exception:  # noqa: BLE001
        return {}


MAGNIT_PROVIDER = "magnit_copilot"


def write_magnit_provider(env: dict[str, str]) -> bool:
    """custom_providers/magnit_copilot.json — корпоративный LiteLLM как провайдер Goose со списком моделей и лимитом
    контекста у каждой (max_input_tokens из /model/info; без сети — последние известные). Ключ — тот же LITELLM_API_KEY
    в секретах Goose. Чужой файл с таким именем не перезаписываем."""
    path = GOOSE_DIR / "custom_providers" / f"{MAGNIT_PROVIDER}.json"
    if path.exists() and OVERRIDE_MARK not in path.read_text(encoding="utf-8", errors="ignore"):
        return True  # файл пользователя — оставляем, провайдер есть
    limits = litellm_limits(env)
    model = env.get("LLM_MODEL") or mcp_registry.DEFAULT_LLM_MODEL
    names = sorted(limits, key=lambda n: (n != model, n))  # выбранная модель — первой
    if model not in limits:
        names.insert(0, model)
    data = {
        "name": MAGNIT_PROVIDER, "engine": "openai", "display_name": "Magnit Copilot",
        "description": f"Корпоративные модели Magnit Copilot (LiteLLM) {OVERRIDE_MARK}",
        "api_key_env": "LITELLM_API_KEY", "base_url": env["LLM_BASE_URL"].rstrip("/"),
        "models": [{"name": n, "context_limit": limits.get(n)} for n in names],
        "headers": None, "timeout_seconds": 600, "supports_streaming": True,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, indent=2)
    if not path.exists() or path.read_text(encoding="utf-8") != text:
        path.write_text(text, encoding="utf-8")
    print("  Magnit Copilot: лимиты контекста — " + ", ".join(
        f"{n} {limits[n] // 1000} тыс." for n in names if limits.get(n)))
    return True


def write_context_limits(env: dict[str, str], cfg: dict) -> None:
    """Лимиты контекста для провайдеров, где Goose не знает их сам (иначе 128 тыс.):
    1) встроенные с неверным лимитом (DeepSeek v4 flash → 1 млн) — переопределение в custom_providers;
    2) свои провайдеры пользователя к корпоративному LiteLLM — пустые лимиты из /model/info."""
    folder = GOOSE_DIR / "custom_providers"
    used = set((cfg.get("providers") or {}).keys())
    for name, limits in CONTEXT_OVERRIDES.items():
        if name not in used:
            continue
        path = folder / f"{name}.json"
        if path.exists() and OVERRIDE_MARK not in path.read_text(encoding="utf-8", errors="ignore"):
            continue  # файл создал пользователь — не трогаем
        base = builtin_provider(name)
        if not base:
            print(f"  ⚠ {name}: не нашёл описание провайдера в Goose — лимит контекста не изменён")
            continue
        for m in base.get("models", []):
            if m.get("name") in limits:
                m["context_limit"] = limits[m["name"]]
        base["description"] = f"{base.get('description', '')} {OVERRIDE_MARK}".strip()
        folder.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(base, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"  {base.get('display_name', name)}: лимит контекста " +
              ", ".join(f"{k} — {v // 1000} тыс." for k, v in limits.items()))
    host = env["LLM_BASE_URL"].rstrip("/").split("://")[-1]
    known = None
    for path in sorted(folder.glob("*.json")) if folder.exists() else []:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except ValueError:
            continue
        if host not in str(data.get("base_url", "")):
            continue
        empty = [m for m in data.get("models", []) if not m.get("context_limit")]
        if not empty:
            continue
        known = known if known is not None else litellm_limits(env)
        filled = [m["name"] for m in empty if known.get(m["name"])]
        for m in empty:
            if known.get(m["name"]):
                m["context_limit"] = known[m["name"]]
        if filled:
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"  {data.get('display_name', path.stem)}: лимиты контекста из LiteLLM для {', '.join(filled)}")


def installed_skills() -> dict[str, str]:
    """Навыки помощника (встроенные и личные, в т. ч. импортированные): имя → начало описания."""
    from skills_sync import SOURCES
    items = {}
    for src in SOURCES:
        for skill in sorted(src.glob("*/SKILL.md")) if src.exists() else []:
            text = skill.read_text(encoding="utf-8", errors="ignore")
            try:  # Goose молча пропускает навык с ошибкой в шапке (например, «: » в описании без кавычек)
                head = yaml.safe_load(text.split("---")[1]) if text.startswith("---") else None
                desc = str(head.get("description", "")) if isinstance(head, dict) else ""
                if not isinstance(head, dict) or not head.get("name"):
                    raise ValueError("нет name/description")
            except Exception as e:  # noqa: BLE001
                print(f"  ⚠ навык {skill.parent.name}: ошибка в шапке SKILL.md ({e.__class__.__name__}) — Goose его "
                      "не увидит. Возьмите описание в кавычки.")
                continue
            items[skill.parent.name] = desc.strip()[:110]
    return items


def skills_description() -> str:
    """Описание расширения «Навыки» — по нему Extension Manager находит навык, когда расширение выключено."""
    items = installed_skills()
    if not items:
        return BUILTINS_OFF["skills"]
    return "Навыки — пошаговые инструкции и готовые скрипты для типовых задач: " + "; ".join(
        f"{name} ({desc})" if desc else name for name, desc in items.items())


def goose_names() -> dict[str, str]:
    """Внутреннее имя MCP-сервера → имя расширения в Goose (с учётом встроенных расширений в конфиге)."""
    cfg = (yaml.safe_load(CONFIG.read_text(encoding="utf-8")) or {}) if CONFIG.exists() else {}
    builtin = {k for k, v in (cfg.get("extensions") or {}).items() if v.get("type") != "stdio"}
    return mcp_registry.goose_names(set(BUILTIN_TITLES) | builtin)


def write_hints() -> None:
    python = str(mcp_registry.venv_python(ROOT / "shared" / ".venv"))
    block = (ROOT / "shared" / "instructions.md").read_text(encoding="utf-8").replace("{{PYTHON}}", python)
    renamed = {k: v for k, v in goose_names().items() if k != v}
    if renamed:  # инструкции и навыки общие для всех агентов и называют расширения внутренними именами
        block += ("\n## Имена расширений в Goose\nВ инструкциях и навыках расширения названы внутренними именами; "
                  "в Goose (Extension Manager, manage_extensions) они называются так: " +
                  ", ".join(f"`{k}` → `{v}`" for k, v in renamed.items()) + ".\n")
    skills = installed_skills()
    if skills:  # точные имена: маленькие модели иначе угадывают имя навыка и ищут его по диску
        block += ("\n## Установленные навыки (точное имя для load_skill — о чём)\n" +
                  "\n".join(f"- `{name}` — {desc.split('—')[0].strip()[:70]}" for name, desc in skills.items()) + "\n")
    block = f"{MARK_BEGIN}\n{block.strip()}\n{MARK_END}\n"
    old = HINTS.read_text(encoding="utf-8") if HINTS.exists() else ""
    pattern = re.compile(re.escape(MARK_BEGIN) + r".*?" + re.escape(MARK_END) + r"\n?", re.S)
    # Замена функцией: в блоке пути Windows (D:\...), а «\» в строке замены re.sub — служебный символ
    new = pattern.sub(lambda _: block, old) if MARK_BEGIN in old else (old + ("\n" if old else "") + block)
    HINTS.write_text(new, encoding="utf-8")
    print(f"  инструкции: {HINTS}")


PERMISSIONS = GOOSE_DIR / "permission.yaml"
# Включение/выключение уже настроенных расширений: Goose включает выключенный инструмент (Jira, GitLab…), когда
# задача его требует. Изменяющие действия внутри расширений по-прежнему спрашивают подтверждение и проходят защиту.
AUTO_TOOLS = ["extensionmanager__manage_extensions", "extensionmanager__search_available_extensions",
              "extensionmanager__list_resources", "extensionmanager__read_resource",  # справка расширений — чтение
              # вопрос агенту Риторики: Риторика помечает его изменяющим (создаёт разговор в истории пользователя),
              # но данные он не меняет — без окна «Разрешить?» на каждый вопрос
              "rhetorica__ask_chat"]


def write_permissions(env: dict[str, str]) -> None:
    """Разрешения пользователя (раздел user в permission.yaml — то же, что «Always Allow» в настройках Goose)."""
    auto = env.get("GOOSE_AUTO_ENABLE_EXTENSIONS", "1").strip().lower() not in ("0", "false", "no")
    data = (yaml.safe_load(PERMISSIONS.read_text(encoding="utf-8")) or {}) if PERMISSIONS.exists() else {}
    user = data.setdefault("user", {})
    lists = {k: list(user.get(k) or []) for k in ("always_allow", "ask_before", "never_allow")}
    rhetorica = goose_names()["rhetorica"]  # имя Риторики в Goose; Goose может хранить его и «скелетом»
    extra = [f"{rhetorica}__ask_chat", f"{mcp_registry.goose_skeleton(rhetorica)}__ask_chat"]
    for tool in AUTO_TOOLS + [t for t in extra if t not in AUTO_TOOLS]:
        for k in lists:
            if tool in lists[k]:
                lists[k].remove(tool)
        lists["always_allow" if auto else "ask_before"].append(tool)
    user.update(lists)
    PERMISSIONS.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")
    PERMISSIONS.chmod(0o600)
    print(f"  включение инструментов по необходимости: {'без вопроса' if auto else 'с вопросом'} ({PERMISSIONS})")


def migrate_model(env: dict[str, str]) -> None:
    """Сменилась модель по умолчанию — перевести на неё установку, где стоит прежнее умолчание (своя модель не трогается)."""
    if env.get("LLM_MODEL") not in mcp_registry.OLD_DEFAULT_MODELS:
        return
    path = ROOT / ".env"
    lines = path.read_text(encoding="utf-8").splitlines()
    lines = [f"LLM_MODEL={mcp_registry.DEFAULT_LLM_MODEL}" if ln.startswith("LLM_MODEL=") else ln for ln in lines]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"  модель: {env['LLM_MODEL']} → {mcp_registry.DEFAULT_LLM_MODEL} (новое умолчание)")
    env["LLM_MODEL"] = mcp_registry.DEFAULT_LLM_MODEL


if __name__ == "__main__":
    env = load_env()
    migrate_model(env)
    print("Настраиваю Goose:")
    # Навыки — первыми: синхронизация убирает переименованные встроенные, а их список нужен описанию и .goosehints
    sync_skills(Path.home() / ".agents" / "skills")
    print("  навыки: ~/.agents/skills")
    write_config(env)
    store_secret(env["LLM_API_KEY"])
    write_hints()
    write_permissions(env)
    try:
        print(f"  трассировка Langfuse: {tracing.apply(env)}")
    except Exception:  # noqa: BLE001
        print("  трассировка Langfuse: не настроена (ошибка), помощник работает без неё")
    cfg = yaml.safe_load(CONFIG.read_text(encoding="utf-8")) or {}
    print("Интеграции в Goose (переключаются в разделе «Расширения»):")
    for name in mcp_registry.visible(env):
        e = next((v for v in (cfg.get("extensions") or {}).values()  # ищем по внутреннему имени в args
                  if v.get("type") == "stdio" and (v.get("args") or [""])[-1] == name), None)
        state = ("✓ вкл " if e["enabled"] else "○ выкл") if e else "· нет токена"
        print(f"  {state} {mcp_registry.TITLES[name]}")
    print("Готово.")
