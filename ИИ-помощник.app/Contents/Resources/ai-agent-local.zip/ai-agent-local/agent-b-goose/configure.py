"""Настройка Goose (CLI и Desktop) на корпоративную LLM.

Что делает:
  1. ~/.config/goose/config.yaml — провайдер, модель, расширения (developer, magnit-files,
     удалённые MCP из remote-mcp.json). Существующие настройки сохраняются, делается бэкап.
  2. Токен LLM кладёт в связку ключей macOS (там, где его ищет Goose), не в открытый файл.
  3. ~/.config/goose/.goosehints — инструкции агента (блок между маркерами обновляется).
  4. ~/.config/goose/permission.yaml — включение выключенных расширений (Extension Manager) без вопроса
     пользователю; GOOSE_AUTO_ENABLE_EXTENSIONS=0 в .env возвращает вопрос.

Запуск: shared/.venv/bin/python agent-b-goose/configure.py  (делает install.sh)
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

import yaml
from dotenv import dotenv_values

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "shared"))
import mcp_registry  # noqa: E402
import tracing  # noqa: E402
from skills_sync import sync as sync_skills  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
GOOSE_DIR = Path(os.environ.get("GOOSE_CONFIG_DIR", Path.home() / ".config" / "goose"))
CONFIG = GOOSE_DIR / "config.yaml"
HINTS = GOOSE_DIR / ".goosehints"
MARK_BEGIN = "<!-- magnit-agent:begin -->"
MARK_END = "<!-- magnit-agent:end -->"
APPLIED = Path.home() / ".magnit-agent" / "goose-applied-integrations"  # выбор, уже применённый к Goose
MANAGED = "[magnit]"  # метка удалённых MCP, добавленных из remote-mcp.json
# Встроенные расширения Goose, выключенные по умолчанию (их описания занимают память модели в каждом запросе);
# Goose включает их сам через Extension Manager, когда задача требует. Описания — чтобы он их находил.
BUILTINS_OFF = {
    "skills": "Навыки: пошаговые инструкции для типовых задач — spec-routine (рутина по спеке из Magnit Drive), "
              "data-report (отчёт по таблицам), meeting-protocol (протокол встречи), jira-task (задача в Jira), "
              "confluence-research (исследование по Confluence), business-letter (деловое письмо), "
              "mail-digest (разбор почты).",
    "summon": "Подзадачи: передать часть работы отдельному помощнику-исполнителю, загрузить справочные материалы.",
    "analyze": "Анализ структуры программного кода: обзор папок, файлов, вызовов функций.",
    "apps": "Создание небольших приложений (HTML/JavaScript) в отдельных окнах Goose.",
    "tom": "Дополнительный контекст в каждом сообщении (переменные GOOSE_MOIM_MESSAGE_*).",
}
ENV_REF = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


def load_env() -> dict[str, str]:
    env = {k: v or "" for k, v in dotenv_values(ROOT / ".env").items()}
    if not env.get("LLM_API_KEY"):
        sys.exit("В .env не задан LLM_API_KEY — запустите setup.sh")
    env["LLM_BASE_URL"] = env["LLM_BASE_URL"].rstrip("/")
    return env


def remote_extensions() -> dict[str, dict]:
    """remote-mcp.json (формат Claude) -> расширения Goose streamable_http."""
    path = ROOT / "remote-mcp.json"
    if not path.exists():
        return {}
    servers = json.loads(path.read_text()).get("mcpServers", {})
    result = {}
    for name, srv in servers.items():
        if srv.get("type", "http") not in ("http", "streamable_http", "sse"):
            print(f"  пропускаю {name}: Goose поддерживает только удалённые HTTP MCP")
            continue
        # ${VAR} в заголовках подставляется из окружения / .env на момент настройки
        values = {**dotenv_values(ROOT / ".env"), **os.environ}
        headers = {k: ENV_REF.sub(lambda m: values.get(m.group(1), ""), v)
                   for k, v in srv.get("headers", {}).items()}
        result[name] = {
            "enabled": True, "type": "streamable_http", "name": name, "uri": srv["url"],
            "headers": headers, "envs": {}, "env_keys": [], "timeout": 300,
            "description": f"{MANAGED} удалённый MCP-сервер {name}", "bundled": None, "available_tools": [],
        }
    return result


def write_config(env: dict[str, str]) -> None:
    GOOSE_DIR.mkdir(parents=True, exist_ok=True)
    old_text = CONFIG.read_text() if CONFIG.exists() else ""
    cfg = yaml.safe_load(old_text) or {} if old_text else {}

    cfg.update({
        "GOOSE_PROVIDER": "openai",
        "GOOSE_MODEL": env.get("LLM_MODEL") or mcp_registry.DEFAULT_LLM_MODEL,
        "OPENAI_HOST": env["LLM_BASE_URL"],
        "OPENAI_BASE_PATH": "v1/chat/completions",
        "GOOSE_MAX_TOKENS": int(env.get("LLM_MAX_OUTPUT_TOKENS") or 8192),
        "GOOSE_TELEMETRY_ENABLED": False,
    })
    cfg.setdefault("GOOSE_MODE", "smart_approve")  # правки файлов и команды — с подтверждением
    try:
        tracing.goose_config(cfg, env)  # трассировка Langfuse — через локальный ретранслятор (или убрать адрес)
    except Exception:  # noqa: BLE001 — трассировка не должна мешать настройке помощника
        pass

    ext = cfg.setdefault("extensions", {}) or {}
    # Состояние «вкл/выкл», которое пользователь мог поменять в интерфейсе Goose
    ui_state = {k: bool(v.get("enabled")) for k, v in ext.items()}
    # Удалённые MCP, убранные из remote-mcp.json, удаляем и из Goose
    ext = {k: v for k, v in ext.items() if not str(v.get("description", "")).startswith(MANAGED)}
    ext["developer"] = {
        "enabled": True, "type": "builtin", "name": "developer", "display_name": "Developer Tools",
        "timeout": 300, "bundled": True, "description": "Файлы и терминал",
    }
    # Локальные MCP-серверы: в конфиг попадают все доступные (есть токены), флаг «вкл» — по выбору
    # пользователя (ENABLED_INTEGRATIONS). Переключения в интерфейсе Goose сохраняются, пока выбор
    # в .env не изменится (например, через ./setup.sh --tools).
    active = set(mcp_registry.enabled(env))
    selection_now = f'{env.get("ENABLED_INTEGRATIONS", "")}|defaults-v{mcp_registry.DEFAULTS_VERSION}'
    selection_changed = APPLIED.read_text().strip() != selection_now if APPLIED.exists() else True
    for name in mcp_registry.available(env):
        on = name in active if selection_changed or name not in ui_state else ui_state[name]
        ext[name] = {
            "enabled": on or name in mcp_registry.ALWAYS_ON, "type": "stdio", "name": name,
            "cmd": mcp_registry.SERVERS[name][0], "args": [mcp_registry.LAUNCH, name],
            "envs": {}, "env_keys": [], "timeout": 300, "bundled": None, "available_tools": [],
            "description": f"{MANAGED} {mcp_registry.TITLES[name]}. {mcp_registry.DESCRIPTIONS.get(name, '')}".strip(),
        }
    for name, description in BUILTINS_OFF.items():
        if name in ext:
            ext[name]["description"] = skills_description() if name == "skills" else description
            if selection_changed:  # новые умолчания; после — как пользователь переключил в Goose
                ext[name]["enabled"] = False
    APPLIED.parent.mkdir(parents=True, exist_ok=True)
    APPLIED.write_text(selection_now)
    ext.pop("magnit-files-legacy", None)
    ext.update(remote_extensions())
    cfg["extensions"] = ext
    new_text = yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False)
    if new_text == old_text:
        print(f"  конфиг без изменений: {CONFIG}")
        return
    if old_text:
        backup = CONFIG.with_name(f"config.yaml.bak-{time.strftime('%Y%m%d-%H%M%S')}")
        shutil.copy2(CONFIG, backup)
        print(f"  бэкап старого конфига: {backup}")
    CONFIG.write_text(new_text)
    print(f"  конфиг: {CONFIG}")


def store_secret(key: str) -> None:
    """Goose хранит все секреты одной JSON-записью в Keychain (сервис goose, аккаунт secrets)."""
    if os.environ.get("GOOSE_DISABLE_KEYRING"):
        path = GOOSE_DIR / "secrets.yaml"
        data = (yaml.safe_load(path.read_text()) or {}) if path.exists() else {}
        data["OPENAI_API_KEY"] = key
        path.write_text(yaml.safe_dump(data))
        path.chmod(0o600)
        print(f"  токен сохранён в {path} (keyring отключён)")
        return
    found = subprocess.run(["security", "find-generic-password", "-s", "goose", "-a", "secrets", "-w"],
                           capture_output=True, text=True)
    try:
        secrets = json.loads(found.stdout) if found.returncode == 0 else {}
    except json.JSONDecodeError:
        secrets = {}
    secrets["OPENAI_API_KEY"] = key
    subprocess.run(["security", "add-generic-password", "-U", "-s", "goose", "-a", "secrets",
                    "-w", json.dumps(secrets)], check=True)
    print("  токен сохранён в связке ключей macOS (goose/secrets)")


def installed_skills() -> dict[str, str]:
    """Навыки помощника (встроенные и личные, в т. ч. импортированные): имя → начало описания."""
    from skills_sync import SOURCES
    items = {}
    for src in SOURCES:
        for skill in sorted(src.glob("*/SKILL.md")) if src.exists() else []:
            text = skill.read_text(encoding="utf-8", errors="ignore")
            try:  # Goose молча пропускает навык с ошибкой в шапке (например, «: » в описании без кавычек)
                head = yaml.safe_load(text.split("---")[1]) if text.startswith("---") else None
                desc = str(head.get("description", "")) if isinstance(head, dict) else ""
                if not isinstance(head, dict) or not head.get("name"):
                    raise ValueError("нет name/description")
            except Exception as e:  # noqa: BLE001
                print(f"  ⚠ навык {skill.parent.name}: ошибка в шапке SKILL.md ({e.__class__.__name__}) — Goose его "
                      "не увидит. Возьмите описание в кавычки.")
                continue
            items[skill.parent.name] = desc.strip()[:110]
    return items


def skills_description() -> str:
    """Описание расширения «Навыки» — по нему Extension Manager находит навык, когда расширение выключено."""
    items = installed_skills()
    if not items:
        return BUILTINS_OFF["skills"]
    return "Навыки — пошаговые инструкции и готовые скрипты для типовых задач: " + "; ".join(
        f"{name} ({desc})" if desc else name for name, desc in items.items())


def write_hints() -> None:
    python = str(ROOT / "shared" / ".venv" / "bin" / "python")
    block = (ROOT / "shared" / "instructions.md").read_text().replace("{{PYTHON}}", python)
    skills = installed_skills()
    if skills:  # точные имена: маленькие модели иначе угадывают имя навыка и ищут его по диску
        block += ("\n## Установленные навыки (точное имя для load_skill — о чём)\n" +
                  "\n".join(f"- `{name}` — {desc.split('—')[0].strip()[:70]}" for name, desc in skills.items()) + "\n")
    block = f"{MARK_BEGIN}\n{block.strip()}\n{MARK_END}\n"
    old = HINTS.read_text() if HINTS.exists() else ""
    pattern = re.compile(re.escape(MARK_BEGIN) + r".*?" + re.escape(MARK_END) + r"\n?", re.S)
    new = pattern.sub(block, old) if MARK_BEGIN in old else (old + ("\n" if old else "") + block)
    HINTS.write_text(new)
    print(f"  инструкции: {HINTS}")


PERMISSIONS = GOOSE_DIR / "permission.yaml"
# Включение/выключение уже настроенных расширений: Goose включает выключенный инструмент (Jira, GitLab…), когда
# задача его требует. Изменяющие действия внутри расширений по-прежнему спрашивают подтверждение и проходят защиту.
AUTO_TOOLS = ["extensionmanager__manage_extensions", "extensionmanager__search_available_extensions",
              "extensionmanager__list_resources", "extensionmanager__read_resource",  # справка расширений — чтение
              # вопрос агенту Риторики: Риторика помечает его изменяющим (создаёт разговор в истории пользователя),
              # но данные он не меняет — без окна «Разрешить?» на каждый вопрос
              "rhetorica__ask_chat"]


def write_permissions(env: dict[str, str]) -> None:
    """Разрешения пользователя (раздел user в permission.yaml — то же, что «Always Allow» в настройках Goose)."""
    auto = env.get("GOOSE_AUTO_ENABLE_EXTENSIONS", "1").strip().lower() not in ("0", "false", "no")
    data = (yaml.safe_load(PERMISSIONS.read_text()) or {}) if PERMISSIONS.exists() else {}
    user = data.setdefault("user", {})
    lists = {k: list(user.get(k) or []) for k in ("always_allow", "ask_before", "never_allow")}
    for tool in AUTO_TOOLS:
        for k in lists:
            if tool in lists[k]:
                lists[k].remove(tool)
        lists["always_allow" if auto else "ask_before"].append(tool)
    user.update(lists)
    PERMISSIONS.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False))
    PERMISSIONS.chmod(0o600)
    print(f"  включение инструментов по необходимости: {'без вопроса' if auto else 'с вопросом'} ({PERMISSIONS})")


def migrate_model(env: dict[str, str]) -> None:
    """Сменилась модель по умолчанию — перевести на неё установку, где стоит прежнее умолчание (своя модель не трогается)."""
    if env.get("LLM_MODEL") not in mcp_registry.OLD_DEFAULT_MODELS:
        return
    path = ROOT / ".env"
    lines = path.read_text().splitlines()
    lines = [f"LLM_MODEL={mcp_registry.DEFAULT_LLM_MODEL}" if ln.startswith("LLM_MODEL=") else ln for ln in lines]
    path.write_text("\n".join(lines) + "\n")
    print(f"  модель: {env['LLM_MODEL']} → {mcp_registry.DEFAULT_LLM_MODEL} (новое умолчание)")
    env["LLM_MODEL"] = mcp_registry.DEFAULT_LLM_MODEL


if __name__ == "__main__":
    env = load_env()
    migrate_model(env)
    print("Настраиваю Goose:")
    write_config(env)
    store_secret(env["LLM_API_KEY"])
    write_hints()
    write_permissions(env)
    try:
        print(f"  трассировка Langfuse: {tracing.apply(env)}")
    except Exception:  # noqa: BLE001
        print("  трассировка Langfuse: не настроена (ошибка), помощник работает без неё")
    sync_skills(Path.home() / ".agents" / "skills")
    print("  навыки: ~/.agents/skills")
    cfg = yaml.safe_load(CONFIG.read_text()) or {}
    print("Интеграции в Goose (переключаются в разделе «Расширения»):")
    for name in mcp_registry.visible(env):
        e = (cfg.get("extensions") or {}).get(name)
        state = ("✓ вкл " if e["enabled"] else "○ выкл") if e else "· нет токена"
        print(f"  {state} {mcp_registry.TITLES[name]}")
    print("Готово.")
